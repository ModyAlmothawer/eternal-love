const { onDocumentCreated } = require("firebase-functions/v2/firestore");
const admin = require("firebase-admin");

admin.initializeApp();

/**
 * Triggered whenever a new chat message or voice note is created in a relationship.
 * Dispatches a high-priority push notification to the partner's FCM token.
 */
exports.onChatMessageCreated = onDocumentCreated(
  "relationships/{relId}/messages/{messageId}",
  async (event) => {
    const snap = event.data;
    if (!snap) return;
    const data = snap.data();
    const relId = event.params.relId;
    const messageId = event.params.messageId;

    const senderId = data.senderId || data.senderUid || "";
    const senderName = data.senderName || "الحبيب";
    const text = data.text || data.message || "";
    const mediaType = data.mediaType || "text";

    try {
      // 1. Fetch the relationship document to find partner's UID
      const relDoc = await admin.firestore().collection("relationships").doc(relId).get();
      if (!relDoc.exists) return;
      const relData = relDoc.data();
      const creatorUid = relData.creatorUid || relData.creatorId || "";
      const partnerUid = relData.partnerUid || relData.partnerId || "";

      // Determine recipient UID (the one who didn't send the message)
      const recipientUid = senderId === creatorUid ? partnerUid : creatorUid;
      if (!recipientUid) return;

      // 2. Fetch recipient's FCM token from users/{uid}
      const userDoc = await admin.firestore().collection("users").doc(recipientUid).get();
      if (!userDoc.exists) return;
      const userData = userDoc.data();
      const fcmToken = userData.fcmToken;
      if (!fcmToken) {
        console.log(`No FCM token registered for recipient ${recipientUid}`);
        return;
      }

      // 3. Construct notification payload
      const notificationTitle = `رسالة من ${senderName} ❤️`;
      const notificationBody = mediaType === "voice"
        ? "رسالة صوتية جديدة 🎙️"
        : (text.length > 120 ? text.substring(0, 117) + "..." : text);

      const fcmPayload = {
        token: fcmToken,
        notification: {
          title: notificationTitle,
          body: notificationBody,
        },
        data: {
          type: mediaType === "voice" ? "voice" : "message",
          relationshipId: relId,
          messageId: messageId,
          senderUid: senderId,
          senderName: senderName,
          title: notificationTitle,
          body: notificationBody,
          click_action: "OPEN_CHAT",
        },
        android: {
          priority: "high",
          notification: {
            channelId: "hikaytna_love_messages",
            sound: "default",
            defaultSound: true,
            defaultVibrateTimings: true,
            priority: "high",
          },
        },
      };

      const response = await admin.messaging().send(fcmPayload);
      console.log(`FCM message sent successfully to ${recipientUid}: ${response}`);
    } catch (err) {
      console.error("Error sending FCM notification for chat message:", err);
    }
  }
);

/**
 * Triggered whenever a shared memory is created.
 */
exports.onMemoryCreated = onDocumentCreated(
  "relationships/{relId}/memories/{memoryId}",
  async (event) => {
    const snap = event.data;
    if (!snap) return;
    const data = snap.data();
    const relId = event.params.relId;
    const memoryId = event.params.memoryId;

    const createdByUid = data.createdByUid || "";
    const createdByName = data.createdByName || "حبيبي";
    const title = data.title || "ذكرى جديدة";

    try {
      const relDoc = await admin.firestore().collection("relationships").doc(relId).get();
      if (!relDoc.exists) return;
      const relData = relDoc.data();
      const recipientUid = createdByUid === (relData.creatorUid || relData.creatorId)
        ? (relData.partnerUid || relData.partnerId)
        : (relData.creatorUid || relData.creatorId);
      if (!recipientUid) return;

      const userDoc = await admin.firestore().collection("users").doc(recipientUid).get();
      if (!userDoc.exists) return;
      const fcmToken = userDoc.data()?.fcmToken;
      if (!fcmToken) return;

      await admin.messaging().send({
        token: fcmToken,
        notification: {
          title: `ذكرى جديدة من ${createdByName} 📸`,
          body: title,
        },
        data: {
          type: "memory",
          relationshipId: relId,
          id: memoryId,
          senderUid: createdByUid,
          senderName: createdByName,
          title: `ذكرى جديدة من ${createdByName} 📸`,
          body: title,
        },
        android: {
          priority: "high",
          notification: {
            channelId: "hikaytna_love_messages",
            sound: "default",
          },
        },
      });
    } catch (err) {
      console.error("Error sending FCM notification for memory:", err);
    }
  }
);

/**
 * Triggered on incoming voice/video calls.
 */
exports.onCallInitiated = onDocumentCreated(
  "relationships/{relId}/calls/{callId}",
  async (event) => {
    const snap = event.data;
    if (!snap) return;
    const data = snap.data();
    const relId = event.params.relId;
    const callId = event.params.callId;

    const callerUid = data.callerUid || "";
    const callerName = data.callerName || "حبيبي";
    const callType = data.type || "voice";

    try {
      const relDoc = await admin.firestore().collection("relationships").doc(relId).get();
      if (!relDoc.exists) return;
      const relData = relDoc.data();
      const calleeUid = callerUid === (relData.creatorUid || relData.creatorId)
        ? (relData.partnerUid || relData.partnerId)
        : (relData.creatorUid || relData.creatorId);
      if (!calleeUid) return;

      const userDoc = await admin.firestore().collection("users").doc(calleeUid).get();
      if (!userDoc.exists) return;
      const fcmToken = userDoc.data()?.fcmToken;
      if (!fcmToken) return;

      const title = callType === "video" ? `مكالمة فيديو من ${callerName} 📹` : `مكالمة صوتية من ${callerName} 📞`;
      const body = "اضغط للرد على المكالمة";

      await admin.messaging().send({
        token: fcmToken,
        notification: {
          title: title,
          body: body,
        },
        data: {
          type: "call",
          callType: callType,
          callId: callId,
          relationshipId: relId,
          senderUid: callerUid,
          senderName: callerName,
          title: title,
          body: body,
        },
        android: {
          priority: "high",
          notification: {
            channelId: "hikaytna_love_messages",
            sound: "default",
            priority: "max",
          },
        },
      });
    } catch (err) {
      console.error("Error sending FCM notification for call:", err);
    }
  }
);
