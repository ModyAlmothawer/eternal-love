package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CallOverlay
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.FavoritesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MemoriesScreen
import com.example.ui.screens.NotesGoalsScreen
import com.example.ui.screens.ProfileSettingsScreen
import com.example.ui.theme.EternalLoveTheme
import com.example.ui.theme.IosDarkBackground
import com.example.ui.theme.IosPrimaryTint
import com.example.ui.theme.IosTabBar
import com.example.ui.theme.IosTabItem
import com.example.ui.viewmodel.LoveViewModel

enum class AppScreen {
    HOME,
    NOTES_GOALS,
    MEMORIES,
    CHAT,
    FAVORITES,
    SETTINGS
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            EternalLoveTheme {
                EternalLoveApp()
            }
        }
    }
}

@Composable
fun EternalLoveApp(
    viewModel: LoveViewModel = viewModel()
) {
    val context = LocalContext.current
    val currentUserId by viewModel.currentUserId.collectAsState()
    val user by viewModel.user.collectAsState()
    val loveLetters by viewModel.loveLetters.collectAsState()
    val appUpdate by viewModel.appUpdate.collectAsState()
    val dismissedUpdateDialog by viewModel.dismissedUpdateDialog.collectAsState()
    var currentScreen by remember { mutableStateOf(AppScreen.HOME) }

    // Unread count for Chat Badge
    val unreadChatCount = remember(loveLetters, user?.firebaseUid) {
        val uid = user?.firebaseUid ?: ""
        loveLetters.count { it.senderUid != uid && !it.isRead }
    }

    // Lifecycle-aware presence tracking (online only when app is in foreground)
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, currentUserId) {
        val observer = LifecycleEventObserver { _, event ->
            if (currentUserId != null) {
                when (event) {
                    Lifecycle.Event.ON_START, Lifecycle.Event.ON_RESUME -> {
                        viewModel.setUserPresence(true)
                    }
                    Lifecycle.Event.ON_STOP, Lifecycle.Event.ON_PAUSE -> {
                        viewModel.setUserPresence(false)
                    }
                    else -> {}
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            viewModel.setUserPresence(false)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(IosDarkBackground)
    ) {
        if (currentUserId == null || user == null) {
            AuthScreen(
                viewModel = viewModel,
                onAuthSuccess = {
                    currentScreen = AppScreen.HOME
                }
            )
        } else {
            BackHandler(enabled = currentScreen != AppScreen.HOME) {
                currentScreen = AppScreen.HOME
            }

            val tabs = listOf(
                IosTabItem(id = "home", label = "الرئيسية", icon = Icons.Default.Favorite),
                IosTabItem(id = "notes", label = "حكايتنا", icon = Icons.Default.AutoStories),
                IosTabItem(id = "memories", label = "الذكريات", icon = Icons.Default.PhotoLibrary),
                IosTabItem(id = "chat", label = "الدردشة", icon = Icons.Default.ChatBubble, badgeCount = unreadChatCount),
                IosTabItem(id = "favorites", label = "المفضلة", icon = Icons.Default.Star)
            )

            val selectedTabId = when (currentScreen) {
                AppScreen.HOME -> "home"
                AppScreen.NOTES_GOALS -> "notes"
                AppScreen.MEMORIES -> "memories"
                AppScreen.CHAT -> "chat"
                AppScreen.FAVORITES -> "favorites"
                AppScreen.SETTINGS -> ""
            }

            Scaffold(
                containerColor = IosDarkBackground,
                bottomBar = {
                    // Show iOS tab bar on all main screens; hide when inside Settings
                    if (currentScreen != AppScreen.SETTINGS) {
                        IosTabBar(
                            tabs = tabs,
                            selectedTabId = selectedTabId,
                            onTabSelected = { tabId ->
                                currentScreen = when (tabId) {
                                    "home" -> AppScreen.HOME
                                    "notes" -> AppScreen.NOTES_GOALS
                                    "memories" -> AppScreen.MEMORIES
                                    "chat" -> AppScreen.CHAT
                                    "favorites" -> AppScreen.FAVORITES
                                    else -> AppScreen.HOME
                                }
                            }
                        )
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    when (currentScreen) {
                        AppScreen.HOME -> HomeScreen(
                            viewModel = viewModel,
                            onNavigateToChat = { currentScreen = AppScreen.CHAT },
                            onNavigateToMemories = { currentScreen = AppScreen.MEMORIES },
                            onNavigateToNotesGoals = { currentScreen = AppScreen.NOTES_GOALS },
                            onNavigateToSettings = { currentScreen = AppScreen.SETTINGS }
                        )
                        AppScreen.NOTES_GOALS -> NotesGoalsScreen(
                            viewModel = viewModel,
                            onBack = { currentScreen = AppScreen.HOME }
                        )
                        AppScreen.MEMORIES -> MemoriesScreen(
                            viewModel = viewModel,
                            onBack = { currentScreen = AppScreen.HOME }
                        )
                        AppScreen.CHAT -> ChatScreen(
                            viewModel = viewModel,
                            onBack = { currentScreen = AppScreen.HOME }
                        )
                        AppScreen.FAVORITES -> FavoritesScreen(
                            viewModel = viewModel,
                            onNavigateToChat = { currentScreen = AppScreen.CHAT },
                            onNavigateToMemories = { currentScreen = AppScreen.MEMORIES }
                        )
                        AppScreen.SETTINGS -> ProfileSettingsScreen(
                            viewModel = viewModel,
                            onBack = { currentScreen = AppScreen.HOME },
                            onLoggedOut = {
                                currentScreen = AppScreen.HOME
                            }
                        )
                    }
                }
            }

            // Real-time voice and video call overlay (incoming call dialog and in-call screen)
            CallOverlay(viewModel = viewModel)

            // Remote Update Presentation Dialog
            if (appUpdate != null && (appUpdate!!.isMandatory || !dismissedUpdateDialog)) {
                val update = appUpdate!!
                Dialog(
                    onDismissRequest = {
                        if (!update.isMandatory) {
                            viewModel.dismissUpdateDialog()
                        }
                    },
                    properties = DialogProperties(
                        dismissOnBackPress = !update.isMandatory,
                        dismissOnClickOutside = !update.isMandatory
                    )
                ) {
                    Card(
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E0818)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = if (update.isMandatory) "تحديث إلزامي متوفر 🚀" else "تحديث جديد متوفر 🌟",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "الإصدار ${update.latestVersionName}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = IosPrimaryTint
                            )
                            if (update.releaseNotesAr.isNotBlank()) {
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = update.releaseNotesAr,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                            }
                            Spacer(modifier = Modifier.height(24.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                if (!update.isMandatory) {
                                    OutlinedButton(
                                        onClick = { viewModel.dismissUpdateDialog() },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White.copy(alpha = 0.7f))
                                    ) {
                                        Text("لاحقاً")
                                    }
                                }
                                Button(
                                    onClick = {
                                        if (update.downloadUrl.isNotBlank()) {
                                            try {
                                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(update.downloadUrl))
                                                context.startActivity(intent)
                                            } catch (e: Exception) {
                                                android.widget.Toast.makeText(context, "تعذر فتح رابط التحديث", android.widget.Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = IosPrimaryTint)
                                ) {
                                    Text("تحديث الآن", color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
