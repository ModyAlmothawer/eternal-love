package com.example.service

import android.util.Log
import com.example.util.NotificationHelper
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class LoveFirebaseMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.i("FCMService", "Refreshed FCM token: $token")
        val user = FirebaseAuth.getInstance().currentUser
        if (user != null) {
            FirebaseFirestore.getInstance().collection("users").document(user.uid)
                .set(mapOf("fcmToken" to token), SetOptions.merge())
                .addOnSuccessListener {
                    Log.d("FCMService", "FCM token saved to users/${user.uid}")
                }
                .addOnFailureListener { e ->
                    Log.w("FCMService", "Failed to save FCM token: ${e.message}")
                }
        }
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.d("FCMService", "FCM message received: data=${remoteMessage.data}, notification=${remoteMessage.notification?.body}")

        val data = remoteMessage.data
        val type = data["type"] ?: "message"
        val relationshipId = data["relationshipId"] ?: ""
        val senderUid = data["senderUid"] ?: ""
        val senderName = data["senderName"] ?: "حبيبي"
        val messageId = data["messageId"] ?: (remoteMessage.messageId ?: System.currentTimeMillis().toString())
        val currentUid = FirebaseAuth.getInstance().currentUser?.uid ?: ""

        // Ignore messages sent by self
        if (currentUid.isNotBlank() && senderUid.isNotBlank() && currentUid == senderUid) {
            return
        }

        when (type) {
            "message", "voice" -> {
                val title = remoteMessage.notification?.title ?: data["title"] ?: "رسالة من $senderName ❤️"
                val body = remoteMessage.notification?.body ?: data["body"] ?: if (type == "voice") "رسالة صوتية جديدة 🎙️" else "رسالة جديدة..."
                NotificationHelper.showMessageNotification(
                    context = applicationContext,
                    messageId = messageId,
                    senderUid = senderUid,
                    currentUid = currentUid,
                    senderName = senderName,
                    title = title,
                    messageText = body,
                    relationshipId = relationshipId
                )
            }
            "memory" -> {
                val title = remoteMessage.notification?.title ?: data["title"] ?: "ذكرى جديدة من $senderName 📸"
                val body = remoteMessage.notification?.body ?: data["body"] ?: "ذكرى حب جديدة"
                NotificationHelper.showMemoryNotification(
                    context = applicationContext,
                    memoryId = messageId,
                    senderUid = senderUid,
                    currentUid = currentUid,
                    partnerName = senderName,
                    memoryTitle = body
                )
            }
            "call" -> {
                val callType = data["callType"] ?: "voice"
                val title = if (callType == "video") "مكالمة فيديو واردة من $senderName 📹" else "مكالمة صوتية واردة من $senderName 📞"
                val body = "اضغط للرد على المكالمة"
                NotificationHelper.showMessageNotification(
                    context = applicationContext,
                    messageId = "call_$messageId",
                    senderUid = senderUid,
                    currentUid = currentUid,
                    senderName = senderName,
                    title = title,
                    messageText = body,
                    relationshipId = relationshipId
                )
            }
        }
    }
}
