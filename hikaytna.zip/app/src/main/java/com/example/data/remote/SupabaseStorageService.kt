package com.example.data.remote

import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class SupabaseStorageService(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()
) {
    companion object {
        private const val TAG = "SupabaseStorage"

        @Volatile
        private var INSTANCE: SupabaseStorageService? = null

        fun getInstance(): SupabaseStorageService {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: SupabaseStorageService().also { INSTANCE = it }
            }
        }
    }

    /**
     * Safely retrieves the current Firebase User ID Token for Third-Party Authentication.
     */
    suspend fun getFirebaseIdToken(): String? = withContext(Dispatchers.IO) {
        try {
            val user = FirebaseAuth.getInstance().currentUser
            if (user == null) {
                Log.w(TAG, "No Firebase user signed in when requesting ID token")
                return@withContext null
            }
            val result = user.getIdToken(false).await()
            val token = result.token
            if (token.isNullOrBlank()) {
                Log.w(TAG, "Firebase ID token returned null or empty")
            }
            token
        } catch (e: Exception) {
            Log.e(TAG, "Failed to fetch Firebase ID token: ${e.message}", e)
            null
        }
    }

    /**
     * Uploads media bytes to Supabase Storage in the private 'app-media' bucket.
     * Path must follow the required convention:
     * - users/<uid>/profile/avatar_<timestamp>.jpg
     * - relationships/<relId>/memories/mem_<uuid>.jpg
     * - relationships/<relId>/voice/voice_<uuid>.m4a
     *
     * Returns the persistent canonical reference URL, e.g.:
     * https://epaebeouojogosygfxrv.supabase.co/storage/v1/object/app-media/<cleanPath>
     */
    suspend fun uploadMedia(
        path: String,
        bytes: ByteArray,
        mimeType: String
    ): String? = withContext(Dispatchers.IO) {
        if (bytes.size > SupabaseConfig.MAX_FILE_SIZE_BYTES) {
            Log.e(TAG, "File size (${bytes.size} bytes) exceeds 10MB limit")
            return@withContext null
        }
        val token = getFirebaseIdToken()
        if (token.isNullOrBlank()) {
            Log.e(TAG, "Cannot upload to Supabase: Missing Firebase ID token")
            return@withContext null
        }

        val cleanPath = path.trim().removePrefix("/").removePrefix("app-media/")
        val uploadUrl = "${SupabaseConfig.PROJECT_URL}/storage/v1/object/${SupabaseConfig.BUCKET_NAME}/$cleanPath"

        try {
            val requestBody = bytes.toRequestBody(mimeType.toMediaTypeOrNull())
            val requestBuilder = Request.Builder()
                .url(uploadUrl)
                .post(requestBody)
                .header("Authorization", "Bearer $token")
                .header("x-upsert", "true")

            val pubKey = SupabaseConfig.publishableKey
            if (pubKey.isNotBlank()) {
                requestBuilder.header("apikey", pubKey)
            }

            client.newCall(requestBuilder.build()).execute().use { response ->
                val responseBody = response.body?.string().orEmpty()
                if (response.isSuccessful) {
                    Log.i(TAG, "Successfully uploaded media to Supabase: $cleanPath")
                    return@withContext "${SupabaseConfig.PROJECT_URL}/storage/v1/object/${SupabaseConfig.BUCKET_NAME}/$cleanPath"
                } else {
                    Log.e(TAG, "Supabase upload failed HTTP ${response.code}: $responseBody for URL: $uploadUrl")
                    return@withContext null
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception uploading media to Supabase: ${e.message}", e)
            null
        }
    }

    /**
     * Requests a temporary signed URL from Supabase Storage for reading private objects.
     */
    suspend fun createSignedUrl(
        cleanPath: String,
        expiresInSeconds: Int = 3600
    ): String? = withContext(Dispatchers.IO) {
        val token = getFirebaseIdToken()
        val path = cleanPath.trim().removePrefix("/").removePrefix("app-media/")
        val signUrl = "${SupabaseConfig.PROJECT_URL}/storage/v1/object/sign/${SupabaseConfig.BUCKET_NAME}/$path"

        try {
            val payload = JSONObject().apply {
                put("expiresIn", expiresInSeconds)
            }.toString()

            val requestBody = payload.toRequestBody("application/json; charset=utf-8".toMediaTypeOrNull())
            val requestBuilder = Request.Builder()
                .url(signUrl)
                .post(requestBody)

            if (!token.isNullOrBlank()) {
                requestBuilder.header("Authorization", "Bearer $token")
            }
            val pubKey = SupabaseConfig.publishableKey
            if (pubKey.isNotBlank()) {
                requestBuilder.header("apikey", pubKey)
            }

            client.newCall(requestBuilder.build()).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (response.isSuccessful) {
                    val json = JSONObject(bodyStr)
                    val signedPath = json.optString("signedURL", "").ifBlank {
                        json.optString("signedUrl", "")
                    }
                    if (signedPath.isNotBlank()) {
                        val fullUrl = if (signedPath.startsWith("http://") || signedPath.startsWith("https://")) {
                            signedPath
                        } else {
                            val base = SupabaseConfig.PROJECT_URL.removeSuffix("/")
                            val relative = if (signedPath.startsWith("/")) signedPath else "/$signedPath"
                            if (relative.startsWith("/storage/v1/")) {
                                "$base$relative"
                            } else {
                                "$base/storage/v1$relative"
                            }
                        }
                        val urlWithKey = if (pubKey.isNotBlank() && !fullUrl.contains("apikey=")) {
                            if (fullUrl.contains("?")) "$fullUrl&apikey=$pubKey" else "$fullUrl?apikey=$pubKey"
                        } else {
                            fullUrl
                        }
                        return@withContext urlWithKey
                    }
                }
                Log.w(TAG, "Failed to create signed URL HTTP ${response.code}: $bodyStr for path: $path")
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception generating signed URL: ${e.message}", e)
            null
        }
    }

    /**
     * Deletes a media object from the Supabase 'app-media' bucket.
     */
    suspend fun deleteMedia(rawPathOrUrl: String): Boolean = withContext(Dispatchers.IO) {
        val cleanPath = MediaUrlResolver.extractCleanPath(rawPathOrUrl) ?: rawPathOrUrl.trim().removePrefix("/")
        val token = getFirebaseIdToken()
        val deleteUrl = "${SupabaseConfig.PROJECT_URL}/storage/v1/object/${SupabaseConfig.BUCKET_NAME}"

        try {
            val payload = JSONObject().apply {
                put("prefixes", JSONArray().put(cleanPath))
            }.toString()

            val requestBody = payload.toRequestBody("application/json; charset=utf-8".toMediaTypeOrNull())
            val requestBuilder = Request.Builder()
                .url(deleteUrl)
                .delete(requestBody)

            if (!token.isNullOrBlank()) {
                requestBuilder.header("Authorization", "Bearer $token")
            }
            val pubKey = SupabaseConfig.publishableKey
            if (pubKey.isNotBlank()) {
                requestBuilder.header("apikey", pubKey)
            }

            client.newCall(requestBuilder.build()).execute().use { response ->
                if (response.isSuccessful) {
                    Log.i(TAG, "Successfully deleted Supabase media: $cleanPath")
                    true
                } else {
                    Log.w(TAG, "Delete failed HTTP ${response.code} for $cleanPath: ${response.body?.string()}")
                    false
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception deleting Supabase media: ${e.message}", e)
            false
        }
    }
}
