package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.data.local.LoveDao
import com.example.data.local.LoveDatabase
import com.example.data.model.GoalEntity
import com.example.data.model.LoveLetterEntity
import com.example.data.model.MemoryEntity
import com.example.data.model.NoteEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.RelationshipEntity
import com.example.data.model.SpecialDateEntity
import com.example.data.model.UserEntity
import com.example.data.remote.FirebaseLoveService
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class LoveRepository(
    private val context: Context,
    private val loveDao: LoveDao = LoveDatabase.getDatabase(context).loveDao(),
    val firebaseService: FirebaseLoveService = FirebaseLoveService()
) {
    private val scope = CoroutineScope(Dispatchers.IO)

    private val _currentUserId = MutableStateFlow<Long?>(null)
    val currentUserId: StateFlow<Long?> = _currentUserId.asStateFlow()

    private val _currentRelationshipId = MutableStateFlow<String?>(null)
    val currentRelationshipId: StateFlow<String?> = _currentRelationshipId.asStateFlow()

    private val _partnerIsOnline = MutableStateFlow(false)
    val partnerIsOnline: StateFlow<Boolean> = _partnerIsOnline.asStateFlow()

    private val _partnerLastSeen = MutableStateFlow(0L)
    val partnerLastSeen: StateFlow<Long> = _partnerLastSeen.asStateFlow()

    private val _partnerIsTyping = MutableStateFlow(false)
    val partnerIsTyping: StateFlow<Boolean> = _partnerIsTyping.asStateFlow()

    private val _partnerLastReadAt = MutableStateFlow(0L)
    val partnerLastReadAt: StateFlow<Long> = _partnerLastReadAt.asStateFlow()

    init {
        restoreCurrentUserSession()
    }

    private fun restoreCurrentUserSession() {
        scope.launch {
            try {
                val currentFbUser = firebaseService.currentFirebaseUser
                if (currentFbUser != null) {
                    var localUser = loveDao.getUserByFirebaseUid(currentFbUser.uid)
                    if (localUser == null) {
                        val onlineProfile = firebaseService.fetchUserProfileOnline(currentFbUser.uid)
                        val name = (onlineProfile?.get("displayName") as? String)
                            ?: (onlineProfile?.get("name") as? String)
                            ?: currentFbUser.displayName
                            ?: currentFbUser.email?.substringBefore("@")
                            ?: "حبيبي"
                        val email = currentFbUser.email ?: ""
                        val avatarRes = (onlineProfile?.get("avatarRes") as? String) ?: "avatar_1"
                        val photoUrl = (onlineProfile?.get("photoUrl") as? String) ?: ""
                        val relId = (onlineProfile?.get("relationshipId") as? String)
                        val relCode = (onlineProfile?.get("relationshipCode") as? String) ?: ""
                        val pUid = (onlineProfile?.get("partnerUid") as? String) ?: ""
                        val pName = (onlineProfile?.get("partnerName") as? String) ?: ""

                        val newUser = UserEntity(
                            firebaseUid = currentFbUser.uid,
                            name = name,
                            email = email,
                            avatarRes = avatarRes,
                            photoUrl = photoUrl,
                            partnerUid = pUid,
                            partnerName = pName,
                            relationshipCode = relCode,
                            connectedRelationshipId = relId,
                            isConnected = !relId.isNullOrBlank()
                        )
                        val insertedId = loveDao.insertUser(newUser)
                        localUser = newUser.copy(id = insertedId)
                    }

                    _currentUserId.value = localUser.id
                    localUser.connectedRelationshipId?.let { relId ->
                        if (relId.isNotBlank()) {
                            _currentRelationshipId.value = relId
                            startSync(relId, currentFbUser.uid)
                        }
                    }
                    registerFcmToken(currentFbUser.uid)
                }
            } catch (e: Exception) {
                Log.w("LoveRepository", "Error restoring session: ${e.message}")
            }
        }
    }

    private fun registerFcmToken(uid: String) {
        try {
            FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
                if (!token.isNullOrBlank()) {
                    scope.launch {
                        try {
                            firebaseService.syncUserProfileOnline(
                                uid = uid,
                                name = "",
                                email = ""
                            )
                            com.google.firebase.firestore.FirebaseFirestore.getInstance()
                                .collection("users").document(uid)
                                .set(mapOf("fcmToken" to token), com.google.firebase.firestore.SetOptions.merge())
                        } catch (_: Exception) {}
                    }
                }
            }
        } catch (_: Exception) {}
    }

    fun getUserFlow(userId: Long): Flow<UserEntity?> = loveDao.getUserByIdFlow(userId)

    fun getRelationshipFlow(firestoreId: String): Flow<RelationshipEntity?> =
        loveDao.getRelationshipByFirestoreIdFlow(firestoreId)

    fun getMemoriesFlow(relationshipId: String): Flow<List<MemoryEntity>> =
        loveDao.getMemoriesFlow(relationshipId)

    fun getLoveLettersFlow(relationshipId: String): Flow<List<LoveLetterEntity>> =
        loveDao.getLoveLettersFlow(relationshipId)

    fun getNotesFlow(relationshipId: String): Flow<List<NoteEntity>> =
        loveDao.getNotesFlow(relationshipId)

    fun getGoalsFlow(relationshipId: String): Flow<List<GoalEntity>> =
        loveDao.getGoalsFlow(relationshipId)

    fun getSpecialDatesFlow(relationshipId: String): Flow<List<SpecialDateEntity>> =
        loveDao.getSpecialDatesFlow(relationshipId)

    fun getNotificationsFlow(relationshipId: String): Flow<List<NotificationEntity>> =
        loveDao.getNotificationsFlow(relationshipId)

    suspend fun registerUser(name: String, email: String, pass: String): Result<UserEntity> = withContext(Dispatchers.IO) {
        val result = firebaseService.registerWithFirebase(email, pass)
        if (result.isSuccess) {
            val uid = result.getOrNull() ?: ""
            val user = UserEntity(
                firebaseUid = uid,
                name = name.trim(),
                email = email.trim(),
                isConnected = false
            )
            val id = loveDao.insertUser(user)
            val savedUser = user.copy(id = id)
            _currentUserId.value = id
            firebaseService.syncUserProfileOnline(uid, name, email)
            registerFcmToken(uid)
            Result.success(savedUser)
        } else {
            Result.failure(result.exceptionOrNull() ?: Exception("Registration failed"))
        }
    }

    suspend fun loginUser(email: String, pass: String): Result<UserEntity> = withContext(Dispatchers.IO) {
        val result = firebaseService.loginWithFirebase(email, pass)
        if (result.isSuccess) {
            val uid = result.getOrNull() ?: ""
            var localUser = loveDao.getUserByFirebaseUid(uid)
            val onlineProfile = firebaseService.fetchUserProfileOnline(uid)
            val name = (onlineProfile?.get("displayName") as? String)
                ?: (onlineProfile?.get("name") as? String)
                ?: localUser?.name
                ?: email.substringBefore("@")
            val photoUrl = (onlineProfile?.get("photoUrl") as? String) ?: localUser?.photoUrl ?: ""
            val avatarRes = (onlineProfile?.get("avatarRes") as? String) ?: localUser?.avatarRes ?: "avatar_1"
            val relId = (onlineProfile?.get("relationshipId") as? String) ?: localUser?.connectedRelationshipId
            val relCode = (onlineProfile?.get("relationshipCode") as? String) ?: localUser?.relationshipCode ?: ""
            val pUid = (onlineProfile?.get("partnerUid") as? String) ?: localUser?.partnerUid ?: ""
            val pName = (onlineProfile?.get("partnerName") as? String) ?: localUser?.partnerName ?: ""
            val birthday = (onlineProfile?.get("birthdayMillis") as? Long) ?: localUser?.birthdayMillis ?: 0L

            val updatedUser = (localUser ?: UserEntity(name = name, email = email)).copy(
                firebaseUid = uid,
                name = name,
                email = email,
                avatarRes = avatarRes,
                photoUrl = photoUrl,
                partnerUid = pUid,
                partnerName = pName,
                relationshipCode = relCode,
                connectedRelationshipId = relId,
                isConnected = !relId.isNullOrBlank(),
                birthdayMillis = birthday
            )
            val id = loveDao.insertUser(updatedUser)
            val savedUser = updatedUser.copy(id = id)
            _currentUserId.value = id

            if (!relId.isNullOrBlank()) {
                _currentRelationshipId.value = relId
                startSync(relId, uid)
            }
            registerFcmToken(uid)
            Result.success(savedUser)
        } else {
            Result.failure(result.exceptionOrNull() ?: Exception("Login failed"))
        }
    }

    suspend fun createRelationship(
        user: UserEntity,
        startDateMillis: Long,
        gettingToKnowDateMillis: Long = 0L,
        code: String
    ): Result<RelationshipEntity> = withContext(Dispatchers.IO) {
        try {
            val relId = firebaseService.createFirestoreRelationship(
                creatorUid = user.firebaseUid,
                creatorName = user.name,
                creatorPhoto = user.photoUrl.ifEmpty { user.avatarRes },
                startDateMillis = startDateMillis,
                gettingToKnowDateMillis = gettingToKnowDateMillis,
                code = code
            )
            val relationship = RelationshipEntity(
                firestoreId = relId,
                code = code,
                creatorId = user.firebaseUid,
                creatorName = user.name,
                creatorPhoto = user.photoUrl.ifEmpty { user.avatarRes },
                startDateMillis = startDateMillis,
                gettingToKnowDateMillis = gettingToKnowDateMillis,
                status = "pending"
            )
            val localRelId = loveDao.insertRelationship(relationship)
            val updatedUser = user.copy(
                connectedRelationshipId = relId,
                localRelationshipId = localRelId,
                relationshipCode = code,
                isConnected = true,
                gettingToKnowDateMillis = gettingToKnowDateMillis
            )
            loveDao.updateUser(updatedUser)
            _currentRelationshipId.value = relId
            startSync(relId, user.firebaseUid)
            Result.success(relationship)
        } catch (e: Exception) {
            Log.e("LoveRepository", "Error creating relationship: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun joinRelationship(
        user: UserEntity,
        code: String,
        language: String = "ar"
    ): Result<RelationshipEntity> = withContext(Dispatchers.IO) {
        try {
            val (relId, relData) = firebaseService.joinFirestoreRelationship(
                code = code,
                partnerUid = user.firebaseUid,
                partnerName = user.name,
                partnerPhoto = user.photoUrl.ifEmpty { user.avatarRes },
                language = language
            )
            val creatorId = relData["creatorUid"] as? String ?: relData["creatorId"] as? String ?: ""
            val creatorName = relData["creatorName"] as? String ?: "شريكي"
            val creatorPhoto = relData["creatorPhoto"] as? String ?: "avatar_1"
            val startDate = relData["startDateMillis"] as? Long ?: System.currentTimeMillis()
            val gettingToKnowDate = relData["gettingToKnowDateMillis"] as? Long ?: 0L
            val creatorBirthday = relData["creatorBirthdayMillis"] as? Long ?: 0L
            val partnerBirthday = relData["partnerBirthdayMillis"] as? Long ?: 0L

            val relationship = RelationshipEntity(
                firestoreId = relId,
                code = code,
                creatorId = creatorId,
                creatorName = creatorName,
                creatorPhoto = creatorPhoto,
                partnerId = user.firebaseUid,
                partnerName = user.name,
                partnerPhoto = user.photoUrl.ifEmpty { user.avatarRes },
                startDateMillis = startDate,
                gettingToKnowDateMillis = gettingToKnowDate,
                creatorBirthdayMillis = creatorBirthday,
                partnerBirthdayMillis = partnerBirthday,
                status = "connected"
            )
            val localRelId = loveDao.insertRelationship(relationship)
            val updatedUser = user.copy(
                connectedRelationshipId = relId,
                localRelationshipId = localRelId,
                relationshipCode = code,
                partnerUid = creatorId,
                partnerName = creatorName,
                partnerPhotoUrl = creatorPhoto,
                gettingToKnowDateMillis = gettingToKnowDate,
                isConnected = true
            )
            loveDao.updateUser(updatedUser)
            _currentRelationshipId.value = relId
            startSync(relId, user.firebaseUid)
            Result.success(relationship)
        } catch (e: Exception) {
            Log.e("LoveRepository", "Error joining relationship: ${e.message}", e)
            Result.failure(e)
        }
    }

    fun startSync(relationshipId: String, currentUid: String) {
        firebaseService.startRealtimeListeners(
            relationshipId = relationshipId,
            currentUid = currentUid,
            onRelationshipUpdate = { updatedRel ->
                scope.launch {
                    val existing = loveDao.getRelationshipByFirestoreId(updatedRel.firestoreId)
                    val toSave = if (existing != null) updatedRel.copy(id = existing.id) else updatedRel
                    loveDao.insertRelationship(toSave)
                }
            },
            onPartnerProfileUpdate = { name, photo, avatar, status, emoji ->
                scope.launch {
                    val currentId = _currentUserId.value ?: return@launch
                    val localUser = loveDao.getUserById(currentId) ?: return@launch
                    val updated = localUser.copy(
                        partnerName = name.ifBlank { localUser.partnerName },
                        partnerPhotoUrl = photo.ifBlank { localUser.partnerPhotoUrl },
                        partnerDailyStatus = status,
                        partnerDailyStatusEmoji = emoji
                    )
                    loveDao.updateUser(updated)
                }
            },
            onPartnerTypingUpdate = { isTyping ->
                _partnerIsTyping.value = isTyping
            },
            onPartnerLastReadUpdate = { lastRead ->
                _partnerLastReadAt.value = lastRead
            },
            onMessagesUpdate = { list ->
                scope.launch {
                    loveDao.syncLoveLetters(relationshipId, list)
                }
            },
            onMemoriesUpdate = { list ->
                scope.launch {
                    loveDao.syncMemories(relationshipId, list)
                }
            },
            onGoalsUpdate = { list ->
                scope.launch {
                    loveDao.syncGoals(relationshipId, list)
                }
            },
            onNotesUpdate = { list ->
                scope.launch {
                    loveDao.syncNotes(relationshipId, list)
                }
            }
        )
    }

    suspend fun sendMessage(
        relationshipId: String,
        senderUid: String,
        senderName: String,
        text: String,
        replyToLetter: LoveLetterEntity? = null
    ) = withContext(Dispatchers.IO) {
        if (text.isBlank()) return@withContext
        val letter = LoveLetterEntity(
            firestoreId = UUID.randomUUID().toString(),
            relationshipId = relationshipId,
            senderUid = senderUid,
            senderName = senderName,
            message = text.trim(),
            dateMillis = System.currentTimeMillis(),
            isRead = false,
            replyToId = replyToLetter?.firestoreId,
            replyToSenderName = replyToLetter?.senderName,
            replyToText = replyToLetter?.message,
            mediaType = "text"
        )
        loveDao.insertLoveLetter(letter)
        firebaseService.sendMessageOnline(relationshipId, letter)
    }

    suspend fun sendVoiceNote(
        relationshipId: String,
        senderUid: String,
        senderName: String,
        audioFile: File,
        durationSeconds: Int
    ) = withContext(Dispatchers.IO) {
        try {
            val bytes = audioFile.readBytes()
            val mediaUrl = firebaseService.uploadVoiceNoteBytes(relationshipId, bytes)
            if (!mediaUrl.isNullOrBlank()) {
                val letter = LoveLetterEntity(
                    firestoreId = UUID.randomUUID().toString(),
                    relationshipId = relationshipId,
                    senderUid = senderUid,
                    senderName = senderName,
                    message = "رسالة صوتية",
                    dateMillis = System.currentTimeMillis(),
                    isRead = false,
                    mediaType = "voice",
                    mediaUrl = mediaUrl,
                    durationSeconds = durationSeconds
                )
                loveDao.insertLoveLetter(letter)
                firebaseService.sendMessageOnline(relationshipId, letter)
            }
        } catch (e: Exception) {
            Log.e("LoveRepository", "Error sending voice note: ${e.message}", e)
        }
    }

    suspend fun editMessage(relationshipId: String, messageId: String, newText: String) = withContext(Dispatchers.IO) {
        loveDao.updateLoveLetterMessage(messageId, newText)
        firebaseService.editMessageOnline(relationshipId, messageId, newText)
    }

    suspend fun deleteMessage(relationshipId: String, messageId: String) = withContext(Dispatchers.IO) {
        loveDao.deleteLoveLetter(messageId)
        firebaseService.deleteMessageOnline(relationshipId, messageId)
    }

    suspend fun toggleMessageReaction(relationshipId: String, messageId: String, userUid: String, emoji: String) = withContext(Dispatchers.IO) {
        firebaseService.toggleMessageReaction(relationshipId, messageId, userUid, emoji)
    }

    suspend fun markAllMessagesAsRead(relationshipId: String, currentUid: String, isCreator: Boolean) = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        loveDao.markAllIncomingLoveLettersAsRead(relationshipId, currentUid)
        firebaseService.markAllMessagesReadOnline(relationshipId, currentUid)
        firebaseService.updateLastReadAtOnline(relationshipId, isCreator, now)
    }

    suspend fun updateTypingStatus(relationshipId: String, isCreator: Boolean, isTyping: Boolean) = withContext(Dispatchers.IO) {
        firebaseService.updateTypingStatus(relationshipId, isCreator, isTyping)
    }

    suspend fun updateBirthday(relationshipId: String, uid: String, isCreator: Boolean, birthdayMillis: Long) = withContext(Dispatchers.IO) {
        val currentId = _currentUserId.value ?: return@withContext
        val user = loveDao.getUserById(currentId) ?: return@withContext
        val updatedUser = user.copy(birthdayMillis = birthdayMillis)
        loveDao.updateUser(updatedUser)
        firebaseService.updateUserBirthdayOnline(relationshipId, uid, isCreator, birthdayMillis)
    }

    suspend fun updateRelationshipDates(
        relationshipId: String,
        startDateMillis: Long,
        gettingToKnowDateMillis: Long = 0L
    ) = withContext(Dispatchers.IO) {
        val rel = loveDao.getRelationshipByFirestoreId(relationshipId)
        if (rel != null) {
            val updated = rel.copy(
                startDateMillis = startDateMillis,
                gettingToKnowDateMillis = gettingToKnowDateMillis
            )
            loveDao.updateRelationship(updated)
        }
        val currentId = _currentUserId.value
        if (currentId != null) {
            val user = loveDao.getUserById(currentId)
            if (user != null && gettingToKnowDateMillis > 0L) {
                loveDao.updateUser(user.copy(gettingToKnowDateMillis = gettingToKnowDateMillis))
            }
        }
        firebaseService.updateRelationshipDatesOnline(relationshipId, startDateMillis, gettingToKnowDateMillis)
    }

    suspend fun updateUserProfile(
        user: UserEntity,
        newName: String,
        newAvatarRes: String,
        newPhotoUrl: String,
        relationshipId: String? = null,
        isCreator: Boolean = false
    ) = withContext(Dispatchers.IO) {
        val updated = user.copy(
            name = newName,
            avatarRes = newAvatarRes,
            photoUrl = newPhotoUrl
        )
        loveDao.updateUser(updated)
        firebaseService.updateUserProfileOnline(
            uid = user.firebaseUid,
            name = newName,
            avatarRes = newAvatarRes,
            photoUrl = newPhotoUrl,
            relId = relationshipId,
            isCreator = isCreator
        )
    }

    suspend fun updateUserStatus(
        user: UserEntity,
        status: String,
        emoji: String,
        relationshipId: String? = null,
        isCreator: Boolean = false
    ) = withContext(Dispatchers.IO) {
        val updated = user.copy(
            dailyStatus = status,
            dailyStatusEmoji = emoji,
            statusUpdatedAtMillis = System.currentTimeMillis()
        )
        loveDao.updateUser(updated)
        firebaseService.updateUserStatusOnline(
            uid = user.firebaseUid,
            relId = relationshipId,
            isCreator = isCreator,
            status = status,
            statusEmoji = emoji
        )
    }

    suspend fun addMemory(
        relationshipId: String,
        title: String,
        description: String,
        dateMillis: Long,
        imageBytes: ByteArray?,
        creatorName: String,
        creatorUid: String
    ): Result<MemoryEntity> = withContext(Dispatchers.IO) {
        try {
            val docId = UUID.randomUUID().toString()
            val imageUrl = if (imageBytes != null && imageBytes.isNotEmpty()) {
                firebaseService.uploadMemoryImageBytes(relationshipId, creatorUid, imageBytes) ?: ""
            } else {
                ""
            }
            val memory = MemoryEntity(
                firestoreId = docId,
                relationshipId = relationshipId,
                title = title.trim(),
                description = description.trim(),
                dateMillis = dateMillis,
                imageUrl = imageUrl,
                createdByName = creatorName,
                createdByUid = creatorUid,
                createdAtMillis = System.currentTimeMillis()
            )
            loveDao.insertMemory(memory)
            firebaseService.addMemoryOnline(relationshipId, memory)
            Result.success(memory)
        } catch (e: Exception) {
            Log.e("LoveRepository", "Error adding memory: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun deleteMemory(relationshipId: String, memoryId: String, imageUrl: String) = withContext(Dispatchers.IO) {
        loveDao.deleteMemory(memoryId)
        firebaseService.deleteMemoryOnline(relationshipId, memoryId, imageUrl)
    }

    suspend fun addGoal(
        relationshipId: String,
        title: String,
        description: String,
        targetDate: String,
        category: String,
        creatorName: String,
        creatorUid: String
    ) = withContext(Dispatchers.IO) {
        val docId = UUID.randomUUID().toString()
        val goal = GoalEntity(
            firestoreId = docId,
            relationshipId = relationshipId,
            title = title,
            description = description,
            targetDate = targetDate,
            category = category,
            createdByName = creatorName,
            createdByUid = creatorUid,
            createdAtMillis = System.currentTimeMillis()
        )
        loveDao.insertGoal(goal)
        firebaseService.addGoalOnline(relationshipId, goal)
    }

    suspend fun updateGoalProgress(relationshipId: String, goalId: String, progress: Int, isCompleted: Boolean) = withContext(Dispatchers.IO) {
        firebaseService.updateGoalOnline(relationshipId, goalId, progress, isCompleted)
    }

    suspend fun deleteGoal(relationshipId: String, goalId: String) = withContext(Dispatchers.IO) {
        loveDao.deleteGoal(goalId)
        firebaseService.deleteGoalOnline(relationshipId, goalId)
    }

    suspend fun addNote(
        relationshipId: String,
        title: String,
        content: String,
        category: String,
        authorName: String,
        authorUid: String
    ) = withContext(Dispatchers.IO) {
        val docId = UUID.randomUUID().toString()
        val note = NoteEntity(
            firestoreId = docId,
            relationshipId = relationshipId,
            title = title,
            content = content,
            category = category,
            authorName = authorName,
            authorUid = authorUid,
            updatedAtMillis = System.currentTimeMillis()
        )
        loveDao.insertNote(note)
        firebaseService.addNoteOnline(relationshipId, note)
    }

    suspend fun deleteNote(relationshipId: String, noteId: String) = withContext(Dispatchers.IO) {
        loveDao.deleteNote(noteId)
        firebaseService.deleteNoteOnline(relationshipId, noteId)
    }

    suspend fun disconnectRelationship(relId: String, uid: String) = withContext(Dispatchers.IO) {
        firebaseService.disconnectRelationshipOnline(relId, uid)
        loveDao.deleteRelationship(0, relId)
        _currentRelationshipId.value = null
        val currentId = _currentUserId.value
        if (currentId != null) {
            val user = loveDao.getUserById(currentId)
            if (user != null) {
                loveDao.updateUser(
                    user.copy(
                        connectedRelationshipId = null,
                        localRelationshipId = null,
                        relationshipCode = "",
                        partnerUid = "",
                        partnerName = "",
                        partnerPhotoUrl = "",
                        isConnected = false
                    )
                )
            }
        }
    }

    fun setUserPresence(uid: String, isOnline: Boolean) {
        scope.launch {
            firebaseService.setUserPresence(uid, isOnline)
        }
    }

    fun startListeningToPartnerPresence(partnerUid: String) {
        firebaseService.listenToPartnerPresence(partnerUid) { isOnline, lastSeen ->
            _partnerIsOnline.value = isOnline
            _partnerLastSeen.value = lastSeen
        }
    }

    suspend fun checkAppUpdate(): com.example.data.model.AppUpdateInfo? = withContext(Dispatchers.IO) {
        val githubUpdate = com.example.util.AppUpdateManager.checkRemoteUpdate()
        if (githubUpdate != null) {
            return@withContext githubUpdate
        }
        firebaseService.checkAppUpdate()
    }
}
