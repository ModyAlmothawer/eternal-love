package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.GoalEntity
import com.example.data.model.LoveLetterEntity
import com.example.data.model.MemoryEntity
import com.example.data.model.NoteEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.RelationshipEntity
import com.example.data.model.SpecialDateEntity
import com.example.data.model.UserEntity

@Database(
    entities = [
        UserEntity::class,
        RelationshipEntity::class,
        MemoryEntity::class,
        LoveLetterEntity::class,
        NoteEntity::class,
        GoalEntity::class,
        SpecialDateEntity::class,
        NotificationEntity::class
    ],
    version = 6,
    exportSchema = false
)
abstract class LoveDatabase : RoomDatabase() {
    abstract fun loveDao(): LoveDao

    companion object {
        @Volatile
        private var INSTANCE: LoveDatabase? = null

        fun getDatabase(context: Context): LoveDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    LoveDatabase::class.java,
                    "eternal_love.db"
                ).fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
