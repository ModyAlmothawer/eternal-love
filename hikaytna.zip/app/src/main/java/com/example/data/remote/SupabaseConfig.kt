package com.example.data.remote

import android.util.Log
import com.example.BuildConfig

/**
 * Supabase configuration constants and credentials.
 * Only the public project URL and Publishable/Anon key are stored on client.
 * Firebase Auth token is retrieved securely at runtime and used for Third-Party Auth.
 */
object SupabaseConfig {
    const val PROJECT_URL = "https://epaebeouojogosygfxrv.supabase.co"
    const val BUCKET_NAME = "app-media"
    const val FIREBASE_PROJECT_ID = "lyubov-c1aab"
    const val MAX_FILE_SIZE_BYTES = 10L * 1024L * 1024L // 10 MB strict limit

    @Volatile
    var dynamicPublishableKey: String = ""

    /**
     * Resolves the Supabase publishable/anon key from dynamic config or BuildConfig.
     */
    val publishableKey: String
        get() {
            if (dynamicPublishableKey.isNotBlank()) return dynamicPublishableKey
            return try {
                val field = try { BuildConfig::class.java.getField("SUPABASE_PUBLISHABLE_KEY") } catch (_: Throwable) { null }
                val key = field?.get(null) as? String
                if (!key.isNullOrBlank() && !key.contains("PLACEHOLDER") && key != "MY_SUPABASE_KEY") key.trim() else ""
            } catch (e: Throwable) {
                Log.w("SupabaseConfig", "BuildConfig.SUPABASE_PUBLISHABLE_KEY not available: ${e.message}")
                ""
            }
        }
}
