package com.example.data.remote

import android.util.Log
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

/**
 * Resolves persistent private Supabase Storage references into temporary signed URLs
 * with in-memory caching and automatic expiration refresh.
 */
object MediaUrlResolver {
    private const val TAG = "MediaUrlResolver"

    private data class CachedSignedUrl(
        val signedUrl: String,
        val expiresAtEpochMs: Long
    )

    private val cache = ConcurrentHashMap<String, CachedSignedUrl>()

    fun isSupabaseReference(reference: String?): Boolean {
        if (reference.isNullOrBlank()) return false
        val trimmed = reference.trim()
        return trimmed.contains("supabase.co/storage/v1/object") ||
                trimmed.startsWith("supabase://") ||
                trimmed.startsWith("app-media/")
    }

    fun extractCleanPath(reference: String?): String? {
        if (reference.isNullOrBlank()) return null
        val trimmed = reference.trim()
        return when {
            trimmed.startsWith("supabase://app-media/") -> {
                trimmed.removePrefix("supabase://app-media/")
            }
            trimmed.startsWith("supabase://") -> {
                val afterScheme = trimmed.removePrefix("supabase://")
                afterScheme.substringAfter("/", "")
            }
            trimmed.startsWith("app-media/") -> {
                trimmed.removePrefix("app-media/")
            }
            trimmed.contains("/storage/v1/object/") -> {
                val afterObject = trimmed.substringAfter("/storage/v1/object/")
                    .removePrefix("authenticated/")
                    .removePrefix("public/")
                    .removePrefix("sign/")
                    .substringBefore("?")
                if (afterObject.startsWith("${SupabaseConfig.BUCKET_NAME}/")) {
                    afterObject.removePrefix("${SupabaseConfig.BUCKET_NAME}/")
                } else if (afterObject.contains("/")) {
                    afterObject.substringAfter("/")
                } else {
                    null
                }
            }
            else -> null
        }?.takeIf { it.isNotBlank() }
    }

    suspend fun resolveMediaUrl(
        reference: String?,
        forceRefresh: Boolean = false
    ): String = withContext(Dispatchers.IO) {
        if (reference.isNullOrBlank()) return@withContext ""
        val trimmed = reference.trim()

        if (!isSupabaseReference(trimmed)) {
            return@withContext trimmed
        }

        if (trimmed.contains("token=") && trimmed.contains("/sign/")) {
            return@withContext trimmed
        }

        val cleanPath = extractCleanPath(trimmed) ?: return@withContext trimmed
        val now = System.currentTimeMillis()

        val cached = cache[cleanPath]
        if (!forceRefresh && cached != null && (cached.expiresAtEpochMs - now) > 180_000L) {
            return@withContext cached.signedUrl
        }

        val freshSignedUrl = SupabaseStorageService.getInstance().createSignedUrl(
            cleanPath = cleanPath,
            expiresInSeconds = 3600
        )
        if (!freshSignedUrl.isNullOrBlank()) {
            cache[cleanPath] = CachedSignedUrl(
                signedUrl = freshSignedUrl,
                expiresAtEpochMs = now + 3500_000L
            )
            Log.d(TAG, "Resolved signed URL for $cleanPath")
            return@withContext freshSignedUrl
        } else {
            Log.w(TAG, "Signing failed for $cleanPath; attempting fallback")
            return@withContext cached?.signedUrl ?: trimmed
        }
    }

    fun invalidateCache(reference: String?) {
        val cleanPath = extractCleanPath(reference) ?: return
        cache.remove(cleanPath)
    }

    fun clearCache() {
        cache.clear()
    }
}

@Composable
fun rememberResolvedMediaUrl(rawUrl: String): String {
    var resolvedUrl by remember(rawUrl) { mutableStateOf(rawUrl) }
    LaunchedEffect(rawUrl) {
        if (MediaUrlResolver.isSupabaseReference(rawUrl)) {
            val resolved = MediaUrlResolver.resolveMediaUrl(rawUrl)
            if (resolved.isNotBlank()) {
                resolvedUrl = resolved
            }
        } else {
            resolvedUrl = rawUrl
        }
    }
    return resolvedUrl
}
