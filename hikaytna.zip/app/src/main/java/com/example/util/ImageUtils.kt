package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.util.Log
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.InputStream

object ImageUtils {
    private const val TAG = "ImageUtils"
    private const val MAX_DIMENSION = 1280
    private const val JPEG_QUALITY = 85

    /**
     * Safely reads, downsamples, corrects EXIF orientation, and compresses an image URI into JPEG bytes.
     * Prevents OutOfMemoryError, SecurityException, and URI expiry crashes.
     */
    suspend fun compressAndResizeImageUri(context: Context, uri: Uri?): ByteArray? = withContext(Dispatchers.IO) {
        if (uri == null) return@withContext null
        var inputStream: InputStream? = null
        try {
            // 1. Decode bounds only to prevent OOM
            val options = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            inputStream = context.contentResolver.openInputStream(uri) ?: return@withContext null
            BitmapFactory.decodeStream(inputStream, null, options)
            inputStream.close()

            val origWidth = options.outWidth
            val origHeight = options.outHeight
            if (origWidth <= 0 || origHeight <= 0) {
                Log.w(TAG, "Invalid image dimensions for URI: $uri")
                return@withContext null
            }

            // 2. Compute inSampleSize
            var sampleSize = 1
            var halfWidth = origWidth
            var halfHeight = origHeight
            while (halfWidth > MAX_DIMENSION || halfHeight > MAX_DIMENSION) {
                sampleSize *= 2
                halfWidth /= 2
                halfHeight /= 2
            }

            // 3. Decode scaled bitmap
            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.RGB_565 // More memory efficient
            }
            inputStream = context.contentResolver.openInputStream(uri) ?: return@withContext null
            val decodedBitmap = BitmapFactory.decodeStream(inputStream, null, decodeOptions)
            inputStream.close()

            if (decodedBitmap == null) {
                Log.w(TAG, "Failed to decode bitmap from URI: $uri")
                return@withContext null
            }

            // 4. Handle EXIF orientation rotation
            val rotationDegrees = getExifRotation(context, uri)
            val orientedBitmap = if (rotationDegrees != 0) {
                val matrix = Matrix().apply { postRotate(rotationDegrees.toFloat()) }
                val rotated = Bitmap.createBitmap(
                    decodedBitmap, 0, 0,
                    decodedBitmap.width, decodedBitmap.height,
                    matrix, true
                )
                if (rotated != decodedBitmap) {
                    decodedBitmap.recycle()
                }
                rotated
            } else {
                decodedBitmap
            }

            // 5. Compress to JPEG ByteArray
            val outputStream = ByteArrayOutputStream()
            orientedBitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, outputStream)
            orientedBitmap.recycle()
            val bytes = outputStream.toByteArray()
            outputStream.close()

            Log.i(TAG, "Successfully compressed image to ${bytes.size / 1024} KB")
            return@withContext bytes
        } catch (oom: OutOfMemoryError) {
            Log.e(TAG, "OutOfMemoryError while resizing image: ${oom.message}", oom)
            System.gc()
            return@withContext null
        } catch (se: SecurityException) {
            Log.e(TAG, "SecurityException accessing URI: ${se.message}", se)
            return@withContext null
        } catch (e: Exception) {
            Log.e(TAG, "Error compressing image URI: ${e.message}", e)
            return@withContext null
        } finally {
            try {
                inputStream?.close()
            } catch (_: Exception) {}
        }
    }

    suspend fun saveImageLocally(context: Context, uri: Uri?, subDir: String, prefix: String): String? = withContext(Dispatchers.IO) {
        if (uri == null) return@withContext null
        try {
            val bytes = compressAndResizeImageUri(context, uri) ?: return@withContext null
            val dir = java.io.File(context.filesDir, subDir)
            if (!dir.exists()) {
                dir.mkdirs()
            }
            val fileName = "${prefix}_${System.currentTimeMillis()}.jpg"
            val file = java.io.File(dir, fileName)
            file.writeBytes(bytes)
            Log.i(TAG, "Saved image locally to ${file.absolutePath} (${bytes.size / 1024} KB)")
            file.absolutePath
        } catch (e: Exception) {
            Log.e(TAG, "Error saving image locally: ${e.message}", e)
            null
        }
    }

    suspend fun saveBytesLocally(context: Context, bytes: ByteArray, subDir: String, prefix: String): String? = withContext(Dispatchers.IO) {
        try {
            val dir = java.io.File(context.filesDir, subDir)
            if (!dir.exists()) {
                dir.mkdirs()
            }
            val fileName = "${prefix}_${System.currentTimeMillis()}.jpg"
            val file = java.io.File(dir, fileName)
            file.writeBytes(bytes)
            Log.i(TAG, "Saved image bytes locally to ${file.absolutePath} (${bytes.size / 1024} KB)")
            file.absolutePath
        } catch (e: Exception) {
            Log.e(TAG, "Error saving bytes locally: ${e.message}", e)
            null
        }
    }

    private fun getExifRotation(context: Context, uri: Uri): Int {
        var inputStream: InputStream? = null
        return try {
            inputStream = context.contentResolver.openInputStream(uri) ?: return 0
            val exif = ExifInterface(inputStream)
            when (exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90
                ExifInterface.ORIENTATION_ROTATE_180 -> 180
                ExifInterface.ORIENTATION_ROTATE_270 -> 270
                else -> 0
            }
        } catch (e: Exception) {
            0
        } finally {
            try {
                inputStream?.close()
            } catch (_: Exception) {}
        }
    }
}
