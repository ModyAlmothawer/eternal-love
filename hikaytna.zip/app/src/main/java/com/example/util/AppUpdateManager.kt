package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Log
import androidx.core.content.FileProvider
import com.example.BuildConfig
import com.example.data.model.AppUpdateInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

object AppUpdateManager {
    private const val TAG = "AppUpdateManager"
    const val DEFAULT_UPDATE_URL = "https://raw.githubusercontent.com/algmalm044/hikaytna/main/update.json"

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .followRedirects(true)
            .build()
    }

    suspend fun checkRemoteUpdate(customUrl: String? = null): AppUpdateInfo? = withContext(Dispatchers.IO) {
        val targetUrl = customUrl?.takeIf { it.isNotBlank() } ?: DEFAULT_UPDATE_URL
        try {
            val request = Request.Builder()
                .url(targetUrl)
                .header("Cache-Control", "no-cache")
                .build()

            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.w(TAG, "Failed to fetch update.json: HTTP ${response.code}")
                    return@withContext null
                }
                val bodyString = response.body?.string() ?: return@withContext null
                val json = JSONObject(bodyString)

                val latestCode = json.optInt("latestVersionCode", 1)
                val latestName = json.optString("latestVersionName", "1.0")
                val apkUrl = json.optString("apkUrl", json.optString("downloadUrl", ""))
                val releaseNotes = json.optString("releaseNotes", json.optString("releaseNotesAr", ""))
                val sha256 = json.optString("sha256", "")
                val isMandatory = json.optBoolean("isMandatory", false)

                AppUpdateInfo(
                    latestVersionCode = latestCode,
                    latestVersionName = latestName,
                    apkUrl = apkUrl,
                    downloadUrl = apkUrl,
                    releaseNotes = releaseNotes,
                    releaseNotesAr = releaseNotes,
                    sha256 = sha256,
                    isMandatory = isMandatory
                )
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error checking remote update from $targetUrl: ${e.message}")
            null
        }
    }

    fun canInstallApk(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.packageManager.canRequestPackageInstalls()
        } else {
            true
        }
    }

    fun requestInstallPermission(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val intent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }

    suspend fun downloadAndInstallApk(
        context: Context,
        updateInfo: AppUpdateInfo,
        onProgress: (Float) -> Unit,
        onError: (String) -> Unit
    ) = withContext(Dispatchers.IO) {
        val apkUrl = updateInfo.effectiveApkUrl
        if (apkUrl.isBlank()) {
            withContext(Dispatchers.Main) { onError("رابط تحميل التحديث غير متوفر") }
            return@withContext
        }

        try {
            val updatesDir = File(context.cacheDir, "updates").apply { mkdirs() }
            val apkFile = File(updatesDir, "Lyubov-${updateInfo.latestVersionName}.apk")

            val request = Request.Builder().url(apkUrl).build()
            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    withContext(Dispatchers.Main) { onError("فشل تحميل ملف التحديث: HTTP ${response.code}") }
                    return@withContext
                }

                val body = response.body ?: run {
                    withContext(Dispatchers.Main) { onError("استجابة التحميل فارغة") }
                    return@withContext
                }

                val totalBytes = body.contentLength()
                var downloadedBytes = 0L

                body.byteStream().use { input ->
                    FileOutputStream(apkFile).use { output ->
                        val buffer = ByteArray(8 * 1024)
                        var bytesRead: Int
                        while (input.read(buffer).also { bytesRead = it } != -1) {
                            output.write(buffer, 0, bytesRead)
                            downloadedBytes += bytesRead
                            if (totalBytes > 0) {
                                val progress = downloadedBytes.toFloat() / totalBytes.toFloat()
                                withContext(Dispatchers.Main) { onProgress(progress) }
                            }
                        }
                    }
                }
            }

            // Verify sha256 if present
            if (updateInfo.sha256.isNotBlank()) {
                val computedHash = computeSha256(apkFile)
                if (!computedHash.equals(updateInfo.sha256.trim(), ignoreCase = true)) {
                    apkFile.delete()
                    withContext(Dispatchers.Main) { onError("فشل التحقق من أمان ملف التحديث (عدم تطابق SHA-256)") }
                    return@withContext
                }
            }

            // Trigger system installer
            withContext(Dispatchers.Main) {
                launchSystemInstaller(context, apkFile, onError)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception downloading APK: ${e.message}", e)
            withContext(Dispatchers.Main) {
                onError("حدث خطأ أثناء تحميل التحديث: ${e.localizedMessage}")
            }
        }
    }

    private fun launchSystemInstaller(context: Context, apkFile: File, onError: (String) -> Unit) {
        try {
            val apkUri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                apkFile
            )

            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(apkUri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch package installer: ${e.message}", e)
            onError("تعذر تشغيل مثبت التطبيقات: ${e.localizedMessage}")
        }
    }

    private fun computeSha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { fis ->
            val buffer = ByteArray(8192)
            var n: Int
            while (fis.read(buffer).also { n = it } != -1) {
                digest.update(buffer, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
