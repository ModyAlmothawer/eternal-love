package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppUpdateInfo
import com.example.data.model.CallSession
import com.example.data.model.GoalEntity
import com.example.data.model.LoveLetterEntity
import com.example.data.model.MemoryEntity
import com.example.data.model.NoteEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.RelationshipEntity
import com.example.data.model.SpecialDateEntity
import com.example.data.model.UserEntity
import com.example.data.remote.FirebaseLoveService
import com.example.data.repository.LoveRepository
import com.example.util.AudioRecorderHelper
import com.example.util.ImageUtils
import com.example.util.WebRtcManager
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@OptIn(ExperimentalCoroutinesApi::class)
class LoveViewModel(application: Application) : AndroidViewModel(application) {

    val repository = LoveRepository(application)
    val webRtcManager = WebRtcManager.getInstance(application)
    val audioRecorderHelper = AudioRecorderHelper(application)

    val currentUserId: StateFlow<Long?> = repository.currentUserId
    val currentRelationshipId: StateFlow<String?> = repository.currentRelationshipId

    val user: StateFlow<UserEntity?> = currentUserId.flatMapLatest { id ->
        if (id != null) repository.getUserFlow(id) else flowOf(null)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val relationship: StateFlow<RelationshipEntity?> = currentRelationshipId.flatMapLatest { relId ->
        if (!relId.isNullOrBlank()) repository.getRelationshipFlow(relId) else flowOf(null)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val memories: StateFlow<List<MemoryEntity>> = currentRelationshipId.flatMapLatest { relId ->
        if (!relId.isNullOrBlank()) repository.getMemoriesFlow(relId) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val loveLetters: StateFlow<List<LoveLetterEntity>> = currentRelationshipId.flatMapLatest { relId ->
        if (!relId.isNullOrBlank()) repository.getLoveLettersFlow(relId) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notes: StateFlow<List<NoteEntity>> = currentRelationshipId.flatMapLatest { relId ->
        if (!relId.isNullOrBlank()) repository.getNotesFlow(relId) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val goals: StateFlow<List<GoalEntity>> = currentRelationshipId.flatMapLatest { relId ->
        if (!relId.isNullOrBlank()) repository.getGoalsFlow(relId) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val specialDates: StateFlow<List<SpecialDateEntity>> = currentRelationshipId.flatMapLatest { relId ->
        if (!relId.isNullOrBlank()) repository.getSpecialDatesFlow(relId) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<NotificationEntity>> = currentRelationshipId.flatMapLatest { relId ->
        if (!relId.isNullOrBlank()) repository.getNotificationsFlow(relId) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val partnerIsOnline: StateFlow<Boolean> = repository.partnerIsOnline
    val partnerLastSeen: StateFlow<Long> = repository.partnerLastSeen
    val partnerIsTyping: StateFlow<Boolean> = repository.partnerIsTyping
    val partnerLastReadAt: StateFlow<Long> = repository.partnerLastReadAt

    private val _appUpdate = MutableStateFlow<AppUpdateInfo?>(null)
    val appUpdate: StateFlow<AppUpdateInfo?> = _appUpdate.asStateFlow()

    private val _incomingCallSession = MutableStateFlow<CallSession?>(null)
    val incomingCallSession: StateFlow<CallSession?> = _incomingCallSession.asStateFlow()

    private var incomingCallListener: ListenerRegistration? = null

    init {
        viewModelScope.launch {
            checkAppUpdate()
        }
        viewModelScope.launch {
            relationship.collect { rel ->
                val currentUser = user.value
                val currentUid = currentUser?.firebaseUid ?: ""
                if (rel != null && rel.firestoreId.isNotBlank() && currentUid.isNotBlank()) {
                    val relId = rel.firestoreId
                    setupIncomingCallListener(relId, currentUid)
                    val partnerUid = if (currentUid == rel.creatorId) rel.partnerId else rel.creatorId
                    if (!partnerUid.isNullOrBlank()) {
                        repository.startListeningToPartnerPresence(partnerUid)
                    }
                }
            }
        }
    }

    fun setupIncomingCallListener(relId: String, currentUid: String) {
        incomingCallListener?.remove()
        incomingCallListener = repository.firebaseService.listenToIncomingCall(relId, currentUid) { callSession ->
            _incomingCallSession.value = callSession
        }
    }

    val currentAppVersionCode: Int = com.example.BuildConfig.VERSION_CODE
    val currentAppVersionName: String = com.example.BuildConfig.VERSION_NAME

    private val _dismissedUpdateDialog = MutableStateFlow(false)
    val dismissedUpdateDialog: StateFlow<Boolean> = _dismissedUpdateDialog.asStateFlow()

    fun dismissUpdateDialog() {
        _dismissedUpdateDialog.value = true
    }

    private val _isDownloadingUpdate = MutableStateFlow(false)
    val isDownloadingUpdate: StateFlow<Boolean> = _isDownloadingUpdate.asStateFlow()

    private val _downloadProgress = MutableStateFlow(0f)
    val downloadProgress: StateFlow<Float> = _downloadProgress.asStateFlow()

    private val _updateErrorMessage = MutableStateFlow<String?>(null)
    val updateErrorMessage: StateFlow<String?> = _updateErrorMessage.asStateFlow()

    fun dismissUpdateError() {
        _updateErrorMessage.value = null
    }

    fun startApkUpdate(context: android.content.Context, updateInfo: AppUpdateInfo) {
        if (!com.example.util.AppUpdateManager.canInstallApk(context)) {
            com.example.util.AppUpdateManager.requestInstallPermission(context)
            _updateErrorMessage.value = "يرجى تفعيل خيار السماح بتثبيت التطبيقات من هذا المصدر في إعدادات النظام للمتابعة"
            return
        }

        viewModelScope.launch {
            _isDownloadingUpdate.value = true
            _downloadProgress.value = 0f
            _updateErrorMessage.value = null
            com.example.util.AppUpdateManager.downloadAndInstallApk(
                context = context,
                updateInfo = updateInfo,
                onProgress = { progress ->
                    _downloadProgress.value = progress
                },
                onError = { err ->
                    _isDownloadingUpdate.value = false
                    _updateErrorMessage.value = err
                }
            )
            _isDownloadingUpdate.value = false
        }
    }

    suspend fun checkAppUpdate() {
        val info = repository.checkAppUpdate()
        if (info != null && info.latestVersionCode > currentAppVersionCode) {
            _appUpdate.value = info
        } else {
            _appUpdate.value = null
        }
    }

    // --- Authentication ---
    fun register(name: String, email: String, pass: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val result = repository.registerUser(name, email, pass)
            if (result.isSuccess) {
                onResult(true, "تم إنشاء الحساب بنجاح")
            } else {
                val err = result.exceptionOrNull()
                val message = if (err != null) FirebaseLoveService.mapFirebaseException(err, "ar") else "فشل إنشاء الحساب"
                onResult(false, message)
            }
        }
    }

    fun login(email: String, pass: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val result = repository.loginUser(email, pass)
            if (result.isSuccess) {
                onResult(true, "تم تسجيل الدخول بنجاح")
            } else {
                val err = result.exceptionOrNull()
                val message = if (err != null) FirebaseLoveService.mapFirebaseException(err, "ar") else "فشل تسجيل الدخول"
                onResult(false, message)
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            val uid = user.value?.firebaseUid ?: ""
            if (uid.isNotBlank()) {
                repository.setUserPresence(uid, false)
            }
            incomingCallListener?.remove()
            repository.firebaseService.signOut()
        }
    }

    // --- Relationship ---
    fun createRelationship(startDateMillis: Long, gettingToKnowDateMillis: Long = 0L, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val u = user.value
            if (u == null) {
                onResult(false, "يرجى تسجيل الدخول أولاً")
                return@launch
            }
            // Generate 6-digit numeric invite code
            val code = (100000..999999).random().toString()
            val result = repository.createRelationship(u, startDateMillis, gettingToKnowDateMillis, code)
            if (result.isSuccess) {
                onResult(true, code)
            } else {
                val err = result.exceptionOrNull()
                val msg = if (err != null) FirebaseLoveService.mapFirebaseException(err, "ar") else "فشل إنشاء القصة"
                onResult(false, msg)
            }
        }
    }

    fun joinRelationship(code: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val u = user.value
            if (u == null) {
                onResult(false, "يرجى تسجيل الدخول أولاً")
                return@launch
            }
            val result = repository.joinRelationship(u, code, "ar")
            if (result.isSuccess) {
                onResult(true, "تم الربط بشريكك بنجاح! ❤️")
            } else {
                val err = result.exceptionOrNull()
                val msg = if (err != null) FirebaseLoveService.mapFirebaseException(err, "ar") else "فشل الربط"
                onResult(false, msg)
            }
        }
    }

    fun updateRelationshipDates(startDateMillis: Long, gettingToKnowDateMillis: Long) {
        viewModelScope.launch {
            val relId = currentRelationshipId.value ?: return@launch
            repository.updateRelationshipDates(relId, startDateMillis, gettingToKnowDateMillis)
        }
    }

    fun updateGettingToKnowDate(gettingToKnowDateMillis: Long) {
        viewModelScope.launch {
            val relId = currentRelationshipId.value ?: return@launch
            val rel = relationship.value
            val currentStart = rel?.startDateMillis ?: System.currentTimeMillis()
            repository.updateRelationshipDates(relId, currentStart, gettingToKnowDateMillis)
        }
    }

    fun updateUserBirthday(birthdayMillis: Long) {
        viewModelScope.launch {
            val u = user.value ?: return@launch
            val rel = relationship.value
            val relId = rel?.firestoreId ?: ""
            val isCreator = rel?.creatorId == u.firebaseUid
            repository.updateBirthday(relId, u.firebaseUid, isCreator, birthdayMillis)
        }
    }

    fun updateUserProfile(name: String, avatarRes: String, imageUri: Uri?, onDone: () -> Unit) {
        viewModelScope.launch {
            val u = user.value ?: return@launch
            val rel = relationship.value
            val relId = rel?.firestoreId
            val isCreator = rel?.creatorId == u.firebaseUid

            var photoUrl = u.photoUrl
            if (imageUri != null) {
                val bytes = ImageUtils.compressAndResizeImageUri(getApplication(), imageUri)
                if (bytes != null && bytes.isNotEmpty()) {
                    val uploadedUrl = repository.firebaseService.uploadProfileImageBytes(u.firebaseUid, bytes)
                    if (!uploadedUrl.isNullOrBlank()) {
                        photoUrl = uploadedUrl
                    }
                }
            }
            repository.updateUserProfile(u, name, avatarRes, photoUrl, relId, isCreator)
            onDone()
        }
    }

    fun updateUserStatus(status: String, emoji: String) {
        viewModelScope.launch {
            val u = user.value ?: return@launch
            val rel = relationship.value
            val relId = rel?.firestoreId
            val isCreator = rel?.creatorId == u.firebaseUid
            repository.updateUserStatus(u, status, emoji, relId, isCreator)
        }
    }

    // --- Chat & Messages ---
    fun sendMessage(text: String, replyTo: LoveLetterEntity? = null) {
        viewModelScope.launch {
            val u = user.value ?: return@launch
            val relId = currentRelationshipId.value ?: return@launch
            repository.sendMessage(relId, u.firebaseUid, u.name, text, replyTo)
        }
    }

    fun sendVoiceNote(audioFile: File, durationSeconds: Int) {
        viewModelScope.launch {
            val u = user.value ?: return@launch
            val relId = currentRelationshipId.value ?: return@launch
            repository.sendVoiceNote(relId, u.firebaseUid, u.name, audioFile, durationSeconds)
        }
    }

    fun editMessage(messageId: String, newText: String) {
        viewModelScope.launch {
            val relId = currentRelationshipId.value ?: return@launch
            repository.editMessage(relId, messageId, newText)
        }
    }

    fun deleteMessage(messageId: String) {
        viewModelScope.launch {
            val relId = currentRelationshipId.value ?: return@launch
            repository.deleteMessage(relId, messageId)
        }
    }

    fun toggleMessageReaction(messageId: String, emoji: String) {
        viewModelScope.launch {
            val u = user.value ?: return@launch
            val relId = currentRelationshipId.value ?: return@launch
            repository.toggleMessageReaction(relId, messageId, u.firebaseUid, emoji)
        }
    }

    fun markAllMessagesAsRead() {
        viewModelScope.launch {
            val u = user.value ?: return@launch
            val rel = relationship.value ?: return@launch
            val relId = rel.firestoreId
            val isCreator = rel.creatorId == u.firebaseUid
            repository.markAllMessagesAsRead(relId, u.firebaseUid, isCreator)
        }
    }

    fun updateTypingStatus(isTyping: Boolean) {
        viewModelScope.launch {
            val u = user.value ?: return@launch
            val rel = relationship.value ?: return@launch
            val isCreator = rel.creatorId == u.firebaseUid
            repository.updateTypingStatus(rel.firestoreId, isCreator, isTyping)
        }
    }

    // --- Memories ---
    fun addMemory(title: String, description: String, dateMillis: Long, imageUri: Uri?, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val u = user.value ?: return@launch
            val relId = currentRelationshipId.value ?: return@launch
            val bytes = if (imageUri != null) {
                ImageUtils.compressAndResizeImageUri(getApplication(), imageUri)
            } else null

            val result = repository.addMemory(
                relationshipId = relId,
                title = title,
                description = description,
                dateMillis = dateMillis,
                imageBytes = bytes,
                creatorName = u.name,
                creatorUid = u.firebaseUid
            )
            onDone(result.isSuccess)
        }
    }

    fun deleteMemory(memoryId: String, imageUrl: String) {
        viewModelScope.launch {
            val relId = currentRelationshipId.value ?: return@launch
            repository.deleteMemory(relId, memoryId, imageUrl)
        }
    }

    // --- Goals & Notes ---
    fun addGoal(title: String, description: String, targetDate: String, category: String) {
        viewModelScope.launch {
            val u = user.value ?: return@launch
            val relId = currentRelationshipId.value ?: return@launch
            repository.addGoal(relId, title, description, targetDate, category, u.name, u.firebaseUid)
        }
    }

    fun updateGoal(goalId: String, progress: Int, isCompleted: Boolean) {
        viewModelScope.launch {
            val relId = currentRelationshipId.value ?: return@launch
            repository.updateGoalProgress(relId, goalId, progress, isCompleted)
        }
    }

    fun deleteGoal(goalId: String) {
        viewModelScope.launch {
            val relId = currentRelationshipId.value ?: return@launch
            repository.deleteGoal(relId, goalId)
        }
    }

    fun addNote(title: String, content: String, category: String) {
        viewModelScope.launch {
            val u = user.value ?: return@launch
            val relId = currentRelationshipId.value ?: return@launch
            repository.addNote(relId, title, content, category, u.name, u.firebaseUid)
        }
    }

    fun deleteNote(noteId: String) {
        viewModelScope.launch {
            val relId = currentRelationshipId.value ?: return@launch
            repository.deleteNote(relId, noteId)
        }
    }

    fun disconnectRelationship() {
        viewModelScope.launch {
            val u = user.value ?: return@launch
            val relId = currentRelationshipId.value ?: ""
            repository.disconnectRelationship(relId, u.firebaseUid)
        }
    }

    // --- Calling (WebRTC) ---
    fun startCall(type: String) {
        viewModelScope.launch {
            val u = user.value ?: return@launch
            val rel = relationship.value ?: return@launch
            val relId = rel.firestoreId
            val calleeUid = if (u.firebaseUid == rel.creatorId) rel.partnerId else rel.creatorId
            if (calleeUid.isNullOrBlank()) return@launch
            webRtcManager.startCall(
                relationshipId = relId,
                callerUid = u.firebaseUid,
                callerName = u.name,
                calleeUid = calleeUid,
                type = type
            )
        }
    }

    fun acceptIncomingCall() {
        val session = _incomingCallSession.value ?: return
        _incomingCallSession.value = null
        viewModelScope.launch {
            webRtcManager.acceptCall(session)
        }
    }

    fun declineIncomingCall() {
        val session = _incomingCallSession.value ?: return
        _incomingCallSession.value = null
        viewModelScope.launch {
            repository.firebaseService.updateCallStatus(session.relationshipId, session.callId, "declined")
        }
    }

    fun endCall() {
        webRtcManager.endCall()
    }

    fun setUserPresence(isOnline: Boolean) {
        val uid = user.value?.firebaseUid ?: ""
        if (uid.isNotBlank()) {
            repository.setUserPresence(uid, isOnline)
        }
    }

    override fun onCleared() {
        super.onCleared()
        incomingCallListener?.remove()
        webRtcManager.cleanupPeerConnection()
    }
}
