package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.model.UserEntity
import com.example.ui.theme.IosButtonStyle
import com.example.ui.theme.IosCardBorder
import com.example.ui.theme.IosCardSurface
import com.example.ui.theme.IosCardSurfaceElevated
import com.example.ui.theme.IosDarkBackground
import com.example.ui.theme.IosGlassSurface
import com.example.ui.theme.IosPrimaryGradient
import com.example.ui.theme.IosPrimaryTint
import com.example.ui.theme.IosSubtleSeparator
import com.example.ui.theme.IosTextPrimary
import com.example.ui.theme.IosTextSecondary
import com.example.ui.theme.IosTextTertiary
import com.example.ui.theme.IosButton
import com.example.ui.theme.IosTextField
import com.example.ui.theme.IosWidgetCard
import com.example.ui.viewmodel.LoveViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

@Composable
fun HomeScreen(
    viewModel: LoveViewModel,
    onNavigateToChat: () -> Unit,
    onNavigateToMemories: () -> Unit,
    onNavigateToNotesGoals: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val user by viewModel.user.collectAsState()
    val relationship by viewModel.relationship.collectAsState()
    val partnerIsOnline by viewModel.partnerIsOnline.collectAsState()

    val context = LocalContext.current
    var showDailyStatusDialog by remember { mutableStateOf(false) }
    var showCreateRelDialog by remember { mutableStateOf(false) }
    var showJoinRelDialog by remember { mutableStateOf(false) }

    val currentUid = user?.firebaseUid ?: ""
    val isCreator = currentUid == relationship?.creatorId

    val partnerName = if (isCreator) {
        relationship?.partnerName?.ifBlank { user?.partnerName } ?: "شريكي"
    } else {
        relationship?.creatorName?.ifBlank { user?.partnerName } ?: "شريكي"
    }

    val partnerPhoto = if (isCreator) {
        relationship?.partnerPhoto?.ifBlank { user?.partnerPhotoUrl } ?: ""
    } else {
        relationship?.creatorPhoto?.ifBlank { user?.partnerPhotoUrl } ?: ""
    }

    val partnerStatus = if (isCreator) {
        relationship?.partnerStatus?.ifBlank { user?.partnerDailyStatus } ?: ""
    } else {
        relationship?.creatorStatus?.ifBlank { user?.partnerDailyStatus } ?: ""
    }

    val partnerStatusEmoji = if (isCreator) {
        relationship?.partnerStatusEmoji?.ifBlank { user?.partnerDailyStatusEmoji } ?: ""
    } else {
        relationship?.creatorStatusEmoji?.ifBlank { user?.partnerDailyStatusEmoji } ?: ""
    }

    val partnerBirthday = if (isCreator) {
        relationship?.partnerBirthdayMillis ?: 0L
    } else {
        relationship?.creatorBirthdayMillis ?: 0L
    }

    val myBirthday = if (isCreator) {
        relationship?.creatorBirthdayMillis ?: user?.birthdayMillis ?: 0L
    } else {
        relationship?.partnerBirthdayMillis ?: user?.birthdayMillis ?: 0L
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(IosDarkBackground)
            .testTag("home_screen"),
        contentPadding = PaddingValues(bottom = 100.dp)
    ) {
        // iOS Large Title & Couple Avatars Bar
        item {
            IosHomeHeader(
                user = user,
                partnerName = partnerName,
                partnerPhoto = partnerPhoto,
                partnerIsOnline = partnerIsOnline,
                relationshipName = relationship?.relationshipName ?: "قصتنا الأبدية",
                onOpenSettings = onNavigateToSettings
            )
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Relationship State (Unpaired / Pending / Connected)
        item {
            val currentRel = relationship
            Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                if (currentRel == null) {
                    IosUnpairedCard(
                        onCreateClick = { showCreateRelDialog = true },
                        onJoinClick = { showJoinRelDialog = true }
                    )
                } else if (currentRel.status == "pending" || currentRel.partnerId.isNullOrBlank()) {
                    IosPendingPartnerCard(
                        code = currentRel.code,
                        onCopy = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("Love Code", currentRel.code)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "تم نسخ كود الربط بنجاح", Toast.LENGTH_SHORT).show()
                        },
                        onCancel = {
                            viewModel.disconnectRelationship()
                            Toast.makeText(context, "تم إلغاء كود الربط", Toast.LENGTH_SHORT).show()
                        }
                    )
                } else {
                    IosRelationshipDurationWidget(
                        startDateMillis = currentRel.startDateMillis,
                        gettingToKnowDateMillis = currentRel.gettingToKnowDateMillis,
                        partnerName = partnerName
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Partner Mood & Status Widget
        item {
            Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                IosPartnerMoodWidget(
                    partnerName = partnerName,
                    status = partnerStatus,
                    emoji = partnerStatusEmoji,
                    myStatus = user?.dailyStatus ?: "",
                    myEmoji = user?.dailyStatusEmoji ?: "",
                    onUpdateMyStatus = { showDailyStatusDialog = true }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Birthdays Widget
        item {
            Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                IosBirthdaysWidget(
                    partnerName = partnerName,
                    partnerBirthdayMillis = partnerBirthday,
                    myBirthdayMillis = myBirthday
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Quick Navigation Tiles
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Text(
                    text = "الأقسام السريعة",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = IosTextPrimary,
                    modifier = Modifier.padding(bottom = 12.dp, start = 4.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    IosQuickNavCard(
                        title = "الدردشة",
                        subtitle = "رسائل وصوتيات ومكالمات",
                        icon = Icons.Default.ChatBubble,
                        color = Color(0xFFFF2D55),
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToChat
                    )
                    IosQuickNavCard(
                        title = "الذكريات",
                        subtitle = "ألبوم صورنا الخالدة",
                        icon = Icons.Default.PhotoLibrary,
                        color = Color(0xFFAF52DE),
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToMemories
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    IosQuickNavCard(
                        title = "حكايتنا",
                        subtitle = "الجدول الزمني وأهدافنا",
                        icon = Icons.Default.AutoStories,
                        color = Color(0xFFFF9500),
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToNotesGoals
                    )
                    IosQuickNavCard(
                        title = "الإعدادات",
                        subtitle = "الملف الشخصي والربط",
                        icon = Icons.Default.Settings,
                        color = Color(0xFF007AFF),
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToSettings
                    )
                }
            }
        }
    }

    // Daily Status Sheet/Dialog
    if (showDailyStatusDialog) {
        IosDailyStatusSheet(
            currentStatus = user?.dailyStatus ?: "",
            currentEmoji = user?.dailyStatusEmoji ?: "❤️",
            onDismiss = { showDailyStatusDialog = false },
            onSave = { newStatus, newEmoji ->
                viewModel.updateUserStatus(newStatus, newEmoji)
                showDailyStatusDialog = false
            }
        )
    }

    // Create Relationship Dialog
    if (showCreateRelDialog) {
        IosCreateRelationshipSheet(
            onDismiss = { showCreateRelDialog = false },
            onCreate = { startDate, gettingToKnowDate ->
                viewModel.createRelationship(startDate, gettingToKnowDate) { success, codeOrMsg ->
                    showCreateRelDialog = false
                    if (success) {
                        Toast.makeText(context, "تم إنشاء القصة بنجاح! كود الربط: $codeOrMsg", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(context, codeOrMsg, Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }

    // Join Relationship Dialog
    if (showJoinRelDialog) {
        IosJoinRelationshipSheet(
            onDismiss = { showJoinRelDialog = false },
            onJoin = { code ->
                viewModel.joinRelationship(code) { success, msg ->
                    showJoinRelDialog = false
                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                }
            }
        )
    }
}

@Composable
private fun IosHomeHeader(
    user: UserEntity?,
    partnerName: String,
    partnerPhoto: String,
    partnerIsOnline: Boolean,
    relationshipName: String,
    onOpenSettings: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.statusBars)
            .padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = relationshipName,
                    style = MaterialTheme.typography.labelMedium,
                    color = IosPrimaryTint,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Любовь",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold,
                    color = IosTextPrimary,
                    fontSize = 34.sp
                )
            }

            // Coupled iOS Avatars Pill
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = IosCardSurface,
                border = BorderStroke(0.8.dp, IosCardBorder),
                modifier = Modifier
                    .clickable(onClick = onOpenSettings)
                    .padding(2.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Partner Avatar with Online Indicator
                    Box(contentAlignment = Alignment.BottomEnd) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF2A152B)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (partnerPhoto.isNotBlank()) {
                                AsyncImage(
                                    model = partnerPhoto,
                                    contentDescription = "صورة $partnerName",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Text(
                                    text = partnerName.take(1).ifBlank { "❤️" },
                                    color = IosPrimaryTint,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                            }
                        }
                        if (partnerIsOnline) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF34C759))
                                    .border(BorderStroke(1.5.dp, IosDarkBackground), CircleShape)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = null,
                        tint = IosPrimaryTint,
                        modifier = Modifier.size(14.dp)
                    )

                    Spacer(modifier = Modifier.width(4.dp))

                    // My Avatar
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(IosPrimaryGradient),
                        contentAlignment = Alignment.Center
                    ) {
                        if (!user?.photoUrl.isNullOrBlank()) {
                            AsyncImage(
                                model = user!!.photoUrl,
                                contentDescription = "صورتي",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Text(
                                text = user?.name?.take(1) ?: "أنا",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun IosRelationshipDurationWidget(
    startDateMillis: Long,
    gettingToKnowDateMillis: Long,
    partnerName: String
) {
    val now = System.currentTimeMillis()
    val diffDays = ((now - startDateMillis) / TimeUnit.DAYS.toMillis(1)).coerceAtLeast(0)

    val knowDays = if (gettingToKnowDateMillis > 0L) {
        ((now - gettingToKnowDateMillis) / TimeUnit.DAYS.toMillis(1)).coerceAtLeast(0)
    } else null

    val startCal = Calendar.getInstance().apply { timeInMillis = startDateMillis }
    val nowCal = Calendar.getInstance()
    var years = nowCal.get(Calendar.YEAR) - startCal.get(Calendar.YEAR)
    var months = nowCal.get(Calendar.MONTH) - startCal.get(Calendar.MONTH)
    if (months < 0) {
        years--
        months += 12
    }

    val startDateStr = SimpleDateFormat("d MMMM yyyy", Locale("ar")).format(Date(startDateMillis))

    IosWidgetCard {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Favorite,
                    contentDescription = null,
                    tint = IosPrimaryTint,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "معًا في رحلة حب أبدية",
                    style = MaterialTheme.typography.labelMedium,
                    color = IosTextSecondary,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Large Hero Counter
            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "$diffDays",
                    style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = IosTextPrimary,
                    fontSize = 48.sp
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "يومًا من الحب ❤️",
                    style = MaterialTheme.typography.titleMedium,
                    color = IosPrimaryTint,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Years and Months breakdown pill
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(IosCardSurfaceElevated)
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "$years سنة و $months شهر",
                    style = MaterialTheme.typography.bodySmall,
                    color = IosTextPrimary,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "•", color = IosTextTertiary)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "البداية: $startDateStr",
                    style = MaterialTheme.typography.bodySmall,
                    color = IosTextSecondary
                )
            }

            // Getting to know date row if available
            if (gettingToKnowDateMillis > 0L && knowDays != null) {
                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(thickness = 0.5.dp, color = IosSubtleSeparator)
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val knowDateStr = SimpleDateFormat("d MMMM yyyy", Locale("ar")).format(Date(gettingToKnowDateMillis))
                    Column {
                        Text(
                            text = "تاريخ أول لقاء وتعارف",
                            style = MaterialTheme.typography.labelSmall,
                            color = IosTextTertiary
                        )
                        Text(
                            text = knowDateStr,
                            style = MaterialTheme.typography.bodySmall,
                            color = IosTextPrimary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    Text(
                        text = "$knowDays يوم تعارف ✨",
                        style = MaterialTheme.typography.bodyMedium,
                        color = IosPrimaryTint,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@Composable
private fun IosPartnerMoodWidget(
    partnerName: String,
    status: String,
    emoji: String,
    myStatus: String,
    myEmoji: String,
    onUpdateMyStatus: () -> Unit
) {
    IosWidgetCard {
        Column(modifier = Modifier.padding(18.dp)) {
            // Partner Status Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(IosCardSurfaceElevated),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = emoji.ifBlank { "❤️" }, fontSize = 26.sp)
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "شعور $partnerName اليوم",
                        style = MaterialTheme.typography.labelSmall,
                        color = IosTextTertiary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = status.ifBlank { "يفكر فيك بكل دفء وحب..." },
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = IosTextPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(thickness = 0.5.dp, color = IosSubtleSeparator)
            Spacer(modifier = Modifier.height(12.dp))

            // My Status Touch Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(IosCardSurfaceElevated)
                    .clickable(onClick = onUpdateMyStatus)
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(text = myEmoji.ifBlank { "💭" }, fontSize = 18.sp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = if (myStatus.isNotBlank()) myStatus else "شارك حبيبك شعورك الحالي...",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (myStatus.isNotBlank()) IosTextPrimary else IosTextTertiary,
                        maxLines = 1
                    )
                }

                Text(
                    text = "تعديل",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = IosPrimaryTint
                )
            }
        }
    }
}

@Composable
private fun IosBirthdaysWidget(
    partnerName: String,
    partnerBirthdayMillis: Long,
    myBirthdayMillis: Long
) {
    IosWidgetCard {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFFF2D55).copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Cake,
                        contentDescription = null,
                        tint = Color(0xFFFF2D55),
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "أعياد الميلاد القادمة 🎂",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = IosTextPrimary
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Partner Birthday Row
            if (partnerBirthdayMillis > 0L) {
                val pDays = computeDaysUntilNextBirthday(partnerBirthdayMillis)
                val pAge = computeCurrentAge(partnerBirthdayMillis)
                val pDateStr = SimpleDateFormat("d MMMM", Locale("ar")).format(Date(partnerBirthdayMillis))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "عيد ميلاد $partnerName ($pDateStr)",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = IosTextPrimary
                        )
                        Text(
                            text = "العمر الحالي: $pAge سنة",
                            style = MaterialTheme.typography.labelSmall,
                            color = IosTextTertiary
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (pDays <= 7) Color(0xFFFF2D55) else IosCardSurfaceElevated)
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = if (pDays == 0) "اليوم! 🎉" else "بعد $pDays يوم",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (pDays <= 7) Color.White else IosPrimaryTint
                        )
                    }
                }
            } else {
                Text(
                    text = "لم يحدد $partnerName تاريخ ميلاده بعد",
                    style = MaterialTheme.typography.bodySmall,
                    color = IosTextTertiary
                )
            }

            if (myBirthdayMillis > 0L) {
                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(thickness = 0.5.dp, color = IosSubtleSeparator)
                Spacer(modifier = Modifier.height(10.dp))

                val myDays = computeDaysUntilNextBirthday(myBirthdayMillis)
                val myAge = computeCurrentAge(myBirthdayMillis)
                val myDateStr = SimpleDateFormat("d MMMM", Locale("ar")).format(Date(myBirthdayMillis))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "عيد ميلادي ($myDateStr)",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                            color = IosTextSecondary
                        )
                        Text(
                            text = "العمر الحالي: $myAge سنة",
                            style = MaterialTheme.typography.labelSmall,
                            color = IosTextTertiary
                        )
                    }

                    Text(
                        text = if (myDays == 0) "اليوم! 🎂" else "بعد $myDays يوم",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = IosTextSecondary
                    )
                }
            }
        }
    }
}

@Composable
private fun IosQuickNavCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    IosWidgetCard(
        onClick = onClick,
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(color.copy(alpha = 0.18f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = color,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = IosTextPrimary
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = IosTextTertiary,
                maxLines = 1
            )
        }
    }
}

@Composable
fun IosUnpairedCard(
    onCreateClick: () -> Unit,
    onJoinClick: () -> Unit
) {
    IosWidgetCard {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(CircleShape)
                    .background(IosPrimaryTint.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Favorite,
                    contentDescription = null,
                    tint = IosPrimaryTint,
                    modifier = Modifier.size(36.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "ابدآ حكايتكما معًا في Любовь ❤️",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = IosTextPrimary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "اربطا حسابيكما لمشاركة الذكريات السرية، عداد الحب، ومكالمات الصوت والفيديو في مساحتكما الخاصة.",
                style = MaterialTheme.typography.bodyMedium,
                color = IosTextSecondary,
                textAlign = TextAlign.Center,
                lineHeight = 22.sp
            )

            Spacer(modifier = Modifier.height(22.dp))

            IosButton(
                text = "إنشاء قصة حب جديدة",
                onClick = onCreateClick,
                icon = Icons.Default.Favorite,
                style = IosButtonStyle.PRIMARY
            )

            Spacer(modifier = Modifier.height(10.dp))

            IosButton(
                text = "الانضمام بكود الشريك",
                onClick = onJoinClick,
                icon = Icons.Default.Link,
                style = IosButtonStyle.SECONDARY
            )
        }
    }
}

@Composable
private fun IosPendingPartnerCard(
    code: String,
    onCopy: () -> Unit,
    onCancel: () -> Unit = {}
) {
    IosWidgetCard {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFF9500).copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.HourglassTop,
                    contentDescription = null,
                    tint = Color(0xFFFF9500),
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "في انتظار انضمام شريكك 💌",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = IosTextPrimary
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "شارك هذا الكود مع شريكك ليدخله في تطبيقه:",
                style = MaterialTheme.typography.bodySmall,
                color = IosTextSecondary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(16.dp))

            Surface(
                shape = RoundedCornerShape(16.dp),
                color = IosCardSurfaceElevated,
                border = BorderStroke(0.8.dp, IosCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 18.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = code,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = IosPrimaryTint,
                        letterSpacing = 6.sp
                    )

                    IosButton(
                        text = "نسخ",
                        onClick = onCopy,
                        icon = Icons.Default.ContentCopy,
                        style = IosButtonStyle.SECONDARY,
                        modifier = Modifier.width(90.dp),
                        height = 38.dp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            TextButton(
                onClick = onCancel,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "إلغاء هذا الكود والبدء من جديد",
                    color = Color(0xFFFF453A),
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
private fun IosDailyStatusSheet(
    currentStatus: String,
    currentEmoji: String,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var status by remember { mutableStateOf(currentStatus) }
    var selectedEmoji by remember { mutableStateOf(currentEmoji) }
    val emojiChoices = listOf("❤️", "😍", "🥰", "☕", "😴", "✨", "🔥", "🌸", "🥺", "💪")

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xE6201A29))
                .border(BorderStroke(0.8.dp, IosCardBorder), RoundedCornerShape(24.dp))
                .padding(22.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "كيف تشعر اليوم؟ ✨",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = IosTextPrimary
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    emojiChoices.take(5).forEach { em ->
                        Text(
                            text = em,
                            fontSize = 26.sp,
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(if (selectedEmoji == em) IosPrimaryTint.copy(alpha = 0.25f) else Color.Transparent)
                                .clickable { selectedEmoji = em }
                                .padding(8.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    emojiChoices.drop(5).forEach { em ->
                        Text(
                            text = em,
                            fontSize = 26.sp,
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(if (selectedEmoji == em) IosPrimaryTint.copy(alpha = 0.25f) else Color.Transparent)
                                .clickable { selectedEmoji = em }
                                .padding(8.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                IosTextField(
                    value = status,
                    onValueChange = { status = it },
                    placeholder = "اكتب رسالة شعور قصيرة لشريكك...",
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    IosButton(
                        text = "إلغاء",
                        onClick = onDismiss,
                        style = IosButtonStyle.SECONDARY,
                        modifier = Modifier.weight(1f)
                    )
                    IosButton(
                        text = "حفظ الشعور",
                        onClick = { onSave(status, selectedEmoji) },
                        style = IosButtonStyle.PRIMARY,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun IosCreateRelationshipSheet(
    onDismiss: () -> Unit,
    onCreate: (startDateMillis: Long, gettingToKnowDateMillis: Long) -> Unit
) {
    var isSubmitting by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = { if (!isSubmitting) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xE6201A29))
                .border(BorderStroke(0.8.dp, IosCardBorder), RoundedCornerShape(24.dp))
                .padding(22.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "إنشاء قصة حب جديدة 💖",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = IosTextPrimary
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "سيتم إنشاء كود ربط فريد من 6 أرقام لتشاركه مع شريكك، وسيبدأ عداد الحب الأبدي فوراً من اليوم.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = IosTextSecondary,
                    textAlign = TextAlign.Center,
                    lineHeight = 22.sp
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    IosButton(
                        text = "إلغاء",
                        onClick = onDismiss,
                        style = IosButtonStyle.SECONDARY,
                        enabled = !isSubmitting,
                        modifier = Modifier.weight(1f)
                    )
                    IosButton(
                        text = "ابدأ قصتنا",
                        onClick = {
                            isSubmitting = true
                            onCreate(System.currentTimeMillis(), 0L)
                        },
                        style = IosButtonStyle.PRIMARY,
                        loading = isSubmitting,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun IosJoinRelationshipSheet(
    onDismiss: () -> Unit,
    onJoin: (code: String) -> Unit
) {
    var codeInput by remember { mutableStateOf("") }
    var isSubmitting by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = { if (!isSubmitting) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xE6201A29))
                .border(BorderStroke(0.8.dp, IosCardBorder), RoundedCornerShape(24.dp))
                .padding(22.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "الانضمام بكود الشريك 🔗",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = IosTextPrimary
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "أدخل كود الربط المكون من 6 أرقام الذي شاركه معك شريكك:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = IosTextSecondary,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(16.dp))

                IosTextField(
                    value = codeInput,
                    onValueChange = { if (it.length <= 6) codeInput = it.trim() },
                    placeholder = "مثال: 483921",
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    IosButton(
                        text = "إلغاء",
                        onClick = onDismiss,
                        style = IosButtonStyle.SECONDARY,
                        enabled = !isSubmitting,
                        modifier = Modifier.weight(1f)
                    )
                    IosButton(
                        text = "ربط الآن",
                        onClick = {
                            if (codeInput.length == 6) {
                                isSubmitting = true
                                onJoin(codeInput)
                            }
                        },
                        style = IosButtonStyle.PRIMARY,
                        enabled = codeInput.length == 6 && !isSubmitting,
                        loading = isSubmitting,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

private fun computeDaysUntilNextBirthday(birthdayMillis: Long): Int {
    if (birthdayMillis <= 0L) return -1
    val bCal = Calendar.getInstance().apply { timeInMillis = birthdayMillis }
    val now = Calendar.getInstance()

    val next = Calendar.getInstance().apply {
        set(Calendar.MONTH, bCal.get(Calendar.MONTH))
        set(Calendar.DAY_OF_MONTH, bCal.get(Calendar.DAY_OF_MONTH))
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }

    val todayMidnight = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }

    if (next.before(todayMidnight)) {
        next.add(Calendar.YEAR, 1)
    }

    val diffMs = next.timeInMillis - todayMidnight.timeInMillis
    return (diffMs / TimeUnit.DAYS.toMillis(1)).toInt()
}

private fun computeCurrentAge(birthdayMillis: Long): Int {
    if (birthdayMillis <= 0L) return 0
    val bCal = Calendar.getInstance().apply { timeInMillis = birthdayMillis }
    val now = Calendar.getInstance()
    var age = now.get(Calendar.YEAR) - bCal.get(Calendar.YEAR)
    if (now.get(Calendar.DAY_OF_YEAR) < bCal.get(Calendar.DAY_OF_YEAR)) {
        age--
    }
    return age.coerceAtLeast(0)
}
