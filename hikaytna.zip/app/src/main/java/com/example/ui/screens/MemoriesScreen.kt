package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBackIos
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.model.MemoryEntity
import com.example.data.remote.MediaUrlResolver
import com.example.data.remote.rememberResolvedMediaUrl
import com.example.ui.theme.IosButton
import com.example.ui.theme.IosButtonStyle
import com.example.ui.theme.IosCardBorder
import com.example.ui.theme.IosCardSurface
import com.example.ui.theme.IosCardSurfaceElevated
import com.example.ui.theme.IosDarkBackground
import com.example.ui.theme.IosEmptyState
import com.example.ui.theme.IosPrimaryTint
import com.example.ui.theme.IosSegmentedControl
import com.example.ui.theme.IosSubtleSeparator
import com.example.ui.theme.IosTextField
import com.example.ui.theme.IosTextPrimary
import com.example.ui.theme.IosTextSecondary
import com.example.ui.theme.IosTextTertiary
import com.example.ui.theme.IosWidgetCard
import com.example.ui.viewmodel.LoveViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MemoriesScreen(
    viewModel: LoveViewModel,
    onBack: (() -> Unit)? = null
) {
    val memories by viewModel.memories.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    var selectedMemoryForViewer by remember { mutableStateOf<MemoryEntity?>(null) }
    var selectedViewMode by remember { mutableIntStateOf(0) } // 0: Apple Photos Grid, 1: Timeline Feed

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(IosDarkBackground)
    ) {
        // iOS Navigation Bar / Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.statusBars)
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (onBack != null) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBackIos,
                                contentDescription = "رجوع",
                                tint = IosPrimaryTint,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                    Text(
                        text = "الذكريات",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = IosTextPrimary,
                        fontSize = 32.sp
                    )
                }

                // Apple-style Action Pill Button
                IosButton(
                    text = "إضافة",
                    onClick = { showAddDialog = true },
                    icon = Icons.Default.Add,
                    style = IosButtonStyle.PRIMARY,
                    modifier = Modifier.width(96.dp),
                    height = 36.dp
                )
            }
        }

        // View Mode Segmented Control
        Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
            IosSegmentedControl(
                items = listOf("ألبوم الصور", "اليوميات والقصص"),
                selectedIndex = selectedViewMode,
                onItemSelected = { selectedViewMode = it }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (memories.isEmpty()) {
            IosEmptyState(
                icon = Icons.Default.PhotoLibrary,
                title = "لا توجد ذكريات بعد",
                description = "سجلا أسعد اللحظات والرحلات وصور الحب المشتركة لتظل محفوظة للأبد في ألبومكما.",
                actionButtonText = "إضافة أول ذكرى",
                onActionClick = { showAddDialog = true }
            )
        } else {
            if (selectedViewMode == 0) {
                // Apple Photos Style Multi-Column Grid
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 100.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(memories, key = { it.firestoreId.ifBlank { it.dateMillis.toString() } }) { memory ->
                        IosPhotoThumbnailCard(
                            memory = memory,
                            onClick = { selectedMemoryForViewer = memory }
                        )
                    }
                }
            } else {
                // Journal / Story Feed
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 100.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(memories, key = { it.firestoreId.ifBlank { it.dateMillis.toString() } }) { memory ->
                        IosMemoryDetailCard(
                            memory = memory,
                            onClick = { selectedMemoryForViewer = memory },
                            onDelete = { viewModel.deleteMemory(memory.firestoreId, memory.imageUrl) }
                        )
                    }
                }
            }
        }
    }

    // Full-Screen Photo Viewer Dialog
    if (selectedMemoryForViewer != null) {
        val memory = selectedMemoryForViewer!!
        IosPhotoDetailViewerDialog(
            memory = memory,
            onDismiss = { selectedMemoryForViewer = null },
            onDelete = {
                viewModel.deleteMemory(memory.firestoreId, memory.imageUrl)
                selectedMemoryForViewer = null
            }
        )
    }

    // Add Memory Sheet
    if (showAddDialog) {
        IosAddMemorySheet(
            onDismiss = { showAddDialog = false },
            onSave = { title, desc, uri ->
                viewModel.addMemory(title, desc, System.currentTimeMillis(), uri) {
                    showAddDialog = false
                }
            }
        )
    }
}

@Composable
private fun IosPhotoThumbnailCard(
    memory: MemoryEntity,
    onClick: () -> Unit
) {
    val resolvedUrl = rememberResolvedMediaUrl(memory.imageUrl)
    val dateStr = remember(memory.dateMillis) {
        SimpleDateFormat("d MMM yyyy", Locale("ar")).format(Date(memory.dateMillis))
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(IosCardSurface)
            .border(BorderStroke(0.8.dp, IosCardBorder), RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
    ) {
        if (!resolvedUrl.isNullOrBlank()) {
            AsyncImage(
                model = resolvedUrl,
                contentDescription = memory.title,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PhotoLibrary,
                    contentDescription = null,
                    tint = IosTextTertiary,
                    modifier = Modifier.size(36.dp)
                )
            }
        }

        // Bottom Title Overlay
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(Color.Black.copy(alpha = 0.65f))
                .padding(horizontal = 10.dp, vertical = 8.dp)
        ) {
            Column {
                Text(
                    text = memory.title.ifBlank { "لحظة حب" },
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = dateStr,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.75f),
                    fontSize = 10.sp
                )
            }
        }
    }
}

@Composable
private fun IosMemoryDetailCard(
    memory: MemoryEntity,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    val resolvedUrl = rememberResolvedMediaUrl(memory.imageUrl)
    val dateStr = remember(memory.dateMillis) {
        SimpleDateFormat("d MMMM yyyy", Locale("ar")).format(Date(memory.dateMillis))
    }

    IosWidgetCard(onClick = onClick) {
        Column(modifier = Modifier.fillMaxWidth()) {
            if (!resolvedUrl.isNullOrBlank()) {
                AsyncImage(
                    model = resolvedUrl,
                    contentDescription = memory.title,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                        .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)),
                    contentScale = ContentScale.Crop
                )
            }

            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = memory.title.ifBlank { "لحظة حب" },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = IosTextPrimary
                        )
                        Text(
                            text = if (memory.createdByName.isNotBlank()) "بواسطة ${memory.createdByName} • $dateStr" else dateStr,
                            style = MaterialTheme.typography.labelSmall,
                            color = IosTextTertiary,
                            fontSize = 11.sp
                        )
                    }

                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "حذف",
                            tint = Color(0xFFFF453A),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                if (memory.description.isNotBlank()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = memory.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = IosTextSecondary,
                        lineHeight = 22.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun IosPhotoDetailViewerDialog(
    memory: MemoryEntity,
    onDismiss: () -> Unit,
    onDelete: () -> Unit
) {
    val resolvedUrl = rememberResolvedMediaUrl(memory.imageUrl)
    var showDeleteConfirm by remember { mutableStateOf(false) }
    val dateStr = remember(memory.dateMillis) {
        SimpleDateFormat("d MMMM yyyy", Locale("ar")).format(Date(memory.dateMillis))
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.94f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.statusBars)
            ) {
                // Top Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0x33FFFFFF))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق",
                            tint = Color.White
                        )
                    }

                    IconButton(
                        onClick = { showDeleteConfirm = true },
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0x33FF453A))
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "حذف الذكرى",
                            tint = Color(0xFFFF453A)
                        )
                    }
                }

                // Photo Center
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    if (!resolvedUrl.isNullOrBlank()) {
                        AsyncImage(
                            model = resolvedUrl,
                            contentDescription = memory.title,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp)),
                            contentScale = ContentScale.Fit
                        )
                    }
                }

                // Bottom Info Sheet
                Surface(
                    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                    color = Color(0xE61E1424),
                    border = BorderStroke(0.8.dp, IosCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(22.dp)) {
                        Text(
                            text = memory.title,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = IosTextPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = dateStr,
                            style = MaterialTheme.typography.labelMedium,
                            color = IosPrimaryTint
                        )

                        if (memory.description.isNotBlank()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = memory.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = IosTextSecondary,
                                lineHeight = 22.sp
                            )
                        }
                    }
                }
            }
        }

        if (showDeleteConfirm) {
            Dialog(
                onDismissRequest = { showDeleteConfirm = false },
                properties = DialogProperties(usePlatformDefaultWidth = false)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .clip(RoundedCornerShape(22.dp))
                        .background(Color(0xE6201A29))
                        .border(BorderStroke(0.8.dp, IosCardBorder), RoundedCornerShape(22.dp))
                        .padding(20.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "حذف هذه الذكرى؟",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = IosTextPrimary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "سيتم حذف الصورة وتفاصيلها نهائياً من القصة.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = IosTextSecondary
                        )
                        Spacer(modifier = Modifier.height(18.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            IosButton(
                                text = "إلغاء",
                                onClick = { showDeleteConfirm = false },
                                style = IosButtonStyle.SECONDARY,
                                modifier = Modifier.weight(1f)
                            )
                            IosButton(
                                text = "حذف",
                                onClick = {
                                    showDeleteConfirm = false
                                    onDelete()
                                },
                                style = IosButtonStyle.DESTRUCTIVE,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun IosAddMemorySheet(
    onDismiss: () -> Unit,
    onSave: (String, String, Uri?) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var isSaving by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            selectedImageUri = uri
        }
    }

    Dialog(
        onDismissRequest = { if (!isSaving) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xE6201A29))
                .border(BorderStroke(0.8.dp, IosCardBorder), RoundedCornerShape(24.dp))
                .padding(22.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "إضافة ذكرى جديدة 📸",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = IosTextPrimary
                )

                Spacer(modifier = Modifier.height(16.dp))

                // iOS Photo Picker Container
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(IosCardSurfaceElevated)
                        .border(BorderStroke(0.8.dp, IosCardBorder), RoundedCornerShape(16.dp))
                        .clickable {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    if (selectedImageUri != null) {
                        AsyncImage(
                            model = selectedImageUri,
                            contentDescription = "صورة الذكرى",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(IosPrimaryTint.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AddPhotoAlternate,
                                    contentDescription = "اختيار صورة",
                                    tint = IosPrimaryTint,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "اضغط لاختيار صورة من المعرض",
                                style = MaterialTheme.typography.bodySmall,
                                color = IosTextSecondary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                IosTextField(
                    value = title,
                    onValueChange = { title = it },
                    placeholder = "عنوان الذكرى (مثال: يوم خطوبتنا)",
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                IosTextField(
                    value = description,
                    onValueChange = { description = it },
                    placeholder = "وصف المشاعر وتفاصيل اللحظة...",
                    singleLine = false,
                    maxLines = 3
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    IosButton(
                        text = "إلغاء",
                        onClick = onDismiss,
                        style = IosButtonStyle.SECONDARY,
                        enabled = !isSaving,
                        modifier = Modifier.weight(1f)
                    )
                    IosButton(
                        text = "حفظ الذكرى",
                        onClick = {
                            if (title.isNotBlank() && !isSaving) {
                                isSaving = true
                                onSave(title.trim(), description.trim(), selectedImageUri)
                            }
                        },
                        style = IosButtonStyle.PRIMARY,
                        enabled = title.isNotBlank() && !isSaving,
                        loading = isSaving,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}
