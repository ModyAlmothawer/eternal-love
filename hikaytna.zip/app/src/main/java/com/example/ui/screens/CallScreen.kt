package com.example.ui.screens

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.IosCardBorder
import com.example.ui.theme.IosCardSurfaceElevated
import com.example.ui.theme.IosDarkBackground
import com.example.ui.theme.IosGlassSurface
import com.example.ui.theme.IosPrimaryGradient
import com.example.ui.theme.IosPrimaryTint
import com.example.ui.theme.IosTextPrimary
import com.example.ui.theme.IosTextSecondary
import com.example.ui.viewmodel.LoveViewModel
import com.example.util.CallState
import org.webrtc.RendererCommon
import org.webrtc.SurfaceViewRenderer

@Composable
fun CallOverlay(
    viewModel: LoveViewModel
) {
    val context = LocalContext.current
    val incomingSession by viewModel.incomingCallSession.collectAsState()
    val callState by viewModel.webRtcManager.callState.collectAsState()
    val activeSession by viewModel.webRtcManager.activeSession.collectAsState()
    val statusMessage by viewModel.webRtcManager.statusMessage.collectAsState()
    val callDuration by viewModel.webRtcManager.callDurationSeconds.collectAsState()
    val isMicMuted by viewModel.webRtcManager.isMicMuted.collectAsState()
    val isCameraEnabled by viewModel.webRtcManager.isCameraEnabled.collectAsState()
    val isSpeakerphoneOn by viewModel.webRtcManager.isSpeakerphoneOn.collectAsState()
    val localVideoTrack by viewModel.webRtcManager.localVideo.collectAsState()
    val remoteVideoTrack by viewModel.webRtcManager.remoteVideo.collectAsState()

    val incomingPermissionsLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        val micOk = perms[android.Manifest.permission.RECORD_AUDIO] == true
        val camOk = incomingSession?.type != "video" || perms[android.Manifest.permission.CAMERA] == true
        if (micOk && camOk) {
            viewModel.acceptIncomingCall()
        } else {
            android.widget.Toast.makeText(context, "يرجى منح الأذونات المطلوبة للرد على المكالمة", android.widget.Toast.LENGTH_LONG).show()
        }
    }

    // 1. Incoming Call Dialog (iOS Incoming Call Banner / Sheet Style)
    if (incomingSession != null && callState == CallState.IDLE) {
        val session = incomingSession!!
        Dialog(
            onDismissRequest = { viewModel.declineIncomingCall() },
            properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false, usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.65f))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(32.dp),
                    color = Color(0xE6201828),
                    border = BorderStroke(1.dp, IosCardBorder),
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .testTag("incoming_call_dialog")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Caller Glow Avatar
                        Box(
                            modifier = Modifier
                                .size(88.dp)
                                .clip(CircleShape)
                                .background(IosPrimaryGradient),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (session.type == "video") Icons.Default.Videocam else Icons.Default.Call,
                                contentDescription = "مكالمة واردة",
                                tint = Color.White,
                                modifier = Modifier.size(46.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        Text(
                            text = session.callerName.ifBlank { "حبيبي" },
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = IosTextPrimary
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = if (session.type == "video") "FaceTime مكالمة فيديو واردة" else "مكالمة صوتية واردة...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = IosTextSecondary
                        )

                        Spacer(modifier = Modifier.height(32.dp))

                        // iOS Call Controls (Decline & Accept)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            // Decline button
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                FilledIconButton(
                                    onClick = { viewModel.declineIncomingCall() },
                                    modifier = Modifier
                                        .size(64.dp)
                                        .testTag("decline_call_button"),
                                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color(0xFFFF3B30))
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CallEnd,
                                        contentDescription = "رفض",
                                        tint = Color.White,
                                        modifier = Modifier.size(30.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("رفض", style = MaterialTheme.typography.labelMedium, color = IosTextSecondary)
                            }

                            // Accept button
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                FilledIconButton(
                                    onClick = {
                                        val s = incomingSession
                                        val micGranted = androidx.core.content.ContextCompat.checkSelfPermission(
                                            context, android.Manifest.permission.RECORD_AUDIO
                                        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                                        val camGranted = s?.type != "video" || androidx.core.content.ContextCompat.checkSelfPermission(
                                            context, android.Manifest.permission.CAMERA
                                        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                                        if (!micGranted || !camGranted) {
                                            val needed = mutableListOf(android.Manifest.permission.RECORD_AUDIO)
                                            if (s?.type == "video") needed.add(android.Manifest.permission.CAMERA)
                                            incomingPermissionsLauncher.launch(needed.toTypedArray())
                                        } else {
                                            viewModel.acceptIncomingCall()
                                        }
                                    },
                                    modifier = Modifier
                                        .size(64.dp)
                                        .testTag("accept_call_button"),
                                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color(0xFF34C759))
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Call,
                                        contentDescription = "قبول",
                                        tint = Color.White,
                                        modifier = Modifier.size(30.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("قبول", style = MaterialTheme.typography.labelMedium, color = IosTextSecondary)
                            }
                        }
                    }
                }
            }
        }
    }

    // 2. Active Call Screen (iOS FaceTime / Phone Style)
    if (callState != CallState.IDLE) {
        val isVideoCall = activeSession?.type == "video"
        Dialog(
            onDismissRequest = { viewModel.endCall() },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("active_call_screen"),
                color = Color.Black
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    if (isVideoCall) {
                        // Remote video full screen
                        if (remoteVideoTrack != null) {
                            AndroidView(
                                factory = { ctx ->
                                    SurfaceViewRenderer(ctx).apply {
                                        layoutParams = FrameLayout.LayoutParams(
                                            ViewGroup.LayoutParams.MATCH_PARENT,
                                            ViewGroup.LayoutParams.MATCH_PARENT
                                        )
                                        init(viewModel.webRtcManager.eglBase.eglBaseContext, null)
                                        setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL)
                                        setEnableHardwareScaler(true)
                                        remoteVideoTrack?.addSink(this)
                                    }
                                },
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(Color(0xFF1C0A22), Color(0xFF0D0212), Color.Black)
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "في انتظار تشغيل كاميرا الشريك...",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = Color.White.copy(alpha = 0.7f)
                                )
                            }
                        }

                        // Local video small PiP overlay
                        if (localVideoTrack != null && isCameraEnabled) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(top = 54.dp, end = 20.dp)
                                    .size(width = 110.dp, height = 160.dp)
                                    .clip(RoundedCornerShape(20.dp))
                                    .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.3f)), RoundedCornerShape(20.dp))
                                    .background(Color.Black)
                            ) {
                                AndroidView(
                                    factory = { ctx ->
                                        SurfaceViewRenderer(ctx).apply {
                                            layoutParams = FrameLayout.LayoutParams(
                                                ViewGroup.LayoutParams.MATCH_PARENT,
                                                ViewGroup.LayoutParams.MATCH_PARENT
                                            )
                                            init(viewModel.webRtcManager.eglBase.eglBaseContext, null)
                                            setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL)
                                            setMirror(true)
                                            setEnableHardwareScaler(true)
                                            localVideoTrack?.addSink(this)
                                        }
                                    },
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    } else {
                        // Voice Call UI (iOS Call Screen Layout)
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(Color(0xFF281134), Color(0xFF15081E), Color(0xFF0A040F))
                                    )
                                )
                                .padding(top = 110.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(130.dp)
                                    .clip(CircleShape)
                                    .background(IosPrimaryGradient),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Call,
                                    contentDescription = "مكالمة صوتية",
                                    tint = Color.White,
                                    modifier = Modifier.size(68.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(28.dp))

                            Text(
                                text = activeSession?.callerName ?: "حبيبي",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = if (callState == CallState.CONNECTED) {
                                    val mins = callDuration / 60
                                    val secs = callDuration % 60
                                    "%02d:%02d".format(mins, secs)
                                } else {
                                    statusMessage
                                },
                                style = MaterialTheme.typography.titleMedium,
                                color = IosPrimaryTint,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    // Top Info Bar for Video
                    if (isVideoCall) {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = Color(0xB31E1528),
                            border = BorderStroke(0.8.dp, IosCardBorder),
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(top = 50.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = activeSession?.callerName ?: "حبيبي",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = if (callState == CallState.CONNECTED) {
                                        val mins = callDuration / 60
                                        val secs = callDuration % 60
                                        "%02d:%02d".format(mins, secs)
                                    } else {
                                        statusMessage
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = IosPrimaryTint
                                )
                            }
                        }
                    }

                    // iOS Floating Control Panel at Bottom
                    Surface(
                        shape = RoundedCornerShape(36.dp),
                        color = Color(0xCC1A1024),
                        border = BorderStroke(1.dp, IosCardBorder),
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 44.dp, start = 20.dp, end = 20.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Mic Mute toggle
                            FilledIconButton(
                                onClick = { viewModel.webRtcManager.toggleMic() },
                                modifier = Modifier
                                    .size(52.dp)
                                    .testTag("toggle_mic_button"),
                                colors = IconButtonDefaults.filledIconButtonColors(
                                    containerColor = if (isMicMuted) Color(0xFFFF3B30) else Color.White.copy(alpha = 0.12f)
                                )
                            ) {
                                Icon(
                                    imageVector = if (isMicMuted) Icons.Default.MicOff else Icons.Default.Mic,
                                    contentDescription = "كتم الصوت",
                                    tint = Color.White
                                )
                            }

                            // Speakerphone toggle
                            FilledIconButton(
                                onClick = { viewModel.webRtcManager.toggleSpeakerphone() },
                                modifier = Modifier
                                    .size(52.dp)
                                    .testTag("toggle_speaker_button"),
                                colors = IconButtonDefaults.filledIconButtonColors(
                                    containerColor = if (isSpeakerphoneOn) IosPrimaryTint else Color.White.copy(alpha = 0.12f)
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VolumeUp,
                                    contentDescription = "مكبر الصوت",
                                    tint = Color.White
                                )
                            }

                            if (isVideoCall) {
                                // Camera toggle
                                FilledIconButton(
                                    onClick = { viewModel.webRtcManager.toggleCamera() },
                                    modifier = Modifier
                                        .size(52.dp)
                                        .testTag("toggle_camera_button"),
                                    colors = IconButtonDefaults.filledIconButtonColors(
                                        containerColor = if (isCameraEnabled) Color.White.copy(alpha = 0.12f) else Color(0xFFFF3B30)
                                    )
                                ) {
                                    Icon(
                                        imageVector = if (isCameraEnabled) Icons.Default.Videocam else Icons.Default.VideocamOff,
                                        contentDescription = "الكاميرا",
                                        tint = Color.White
                                    )
                                }

                                // Switch Camera
                                FilledIconButton(
                                    onClick = { viewModel.webRtcManager.switchCamera() },
                                    modifier = Modifier
                                        .size(52.dp)
                                        .testTag("switch_camera_button"),
                                    colors = IconButtonDefaults.filledIconButtonColors(
                                        containerColor = Color.White.copy(alpha = 0.12f)
                                    )
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Cameraswitch,
                                        contentDescription = "تبديل الكاميرا",
                                        tint = Color.White
                                    )
                                }
                            }

                            // Hangup Button
                            FilledIconButton(
                                onClick = { viewModel.endCall() },
                                modifier = Modifier
                                    .size(56.dp)
                                    .testTag("end_call_button"),
                                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color(0xFFFF3B30))
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CallEnd,
                                    contentDescription = "إنهاء المكالمة",
                                    tint = Color.White,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
