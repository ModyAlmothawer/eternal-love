package com.example.ui.coil

import coil.intercept.Interceptor
import coil.request.ImageResult
import com.example.data.remote.MediaUrlResolver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Coil ImageLoader interceptor that automatically intercepts any private Supabase
 * Storage references and resolves them to temporary signed URLs before Coil loads the image.
 */
class SupabaseMediaInterceptor : Interceptor {
    override suspend fun intercept(chain: Interceptor.Chain): ImageResult {
        val request = chain.request
        val data = request.data
        if (data is String && MediaUrlResolver.isSupabaseReference(data)) {
            val resolvedUrl = withContext(Dispatchers.IO) {
                MediaUrlResolver.resolveMediaUrl(data)
            }
            if (resolvedUrl.isNotBlank() && resolvedUrl != data) {
                val newRequest = request.newBuilder()
                    .data(resolvedUrl)
                    .build()
                return chain.proceed(newRequest)
            }
        }
        return chain.proceed(request)
    }
}
