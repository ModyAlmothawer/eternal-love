package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBackIos
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.GoalEntity
import com.example.data.model.NoteEntity
import com.example.ui.theme.IosButton
import com.example.ui.theme.IosButtonStyle
import com.example.ui.theme.IosCardBorder
import com.example.ui.theme.IosCardSurface
import com.example.ui.theme.IosCardSurfaceElevated
import com.example.ui.theme.IosDarkBackground
import com.example.ui.theme.IosEmptyState
import com.example.ui.theme.IosPrimaryGradient
import com.example.ui.theme.IosPrimaryTint
import com.example.ui.theme.IosSegmentedControl
import com.example.ui.theme.IosSubtleSeparator
import com.example.ui.theme.IosTextField
import com.example.ui.theme.IosTextPrimary
import com.example.ui.theme.IosTextSecondary
import com.example.ui.theme.IosTextTertiary
import com.example.ui.theme.IosWidgetCard
import com.example.ui.viewmodel.LoveViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

@Composable
fun NotesGoalsScreen(
    viewModel: LoveViewModel,
    onBack: (() -> Unit)? = null
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val goals by viewModel.goals.collectAsState()
    val notes by viewModel.notes.collectAsState()
    val relationship by viewModel.relationship.collectAsState()

    var showAddGoalDialog by remember { mutableStateOf(false) }
    var showAddNoteDialog by remember { mutableStateOf(false) }

    val segments = listOf("الجدول الزمني", "أهدافنا (${goals.size})", "ملاحظاتنا (${notes.size})")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(IosDarkBackground)
    ) {
        // iOS Navigation Bar / Title
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.statusBars)
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (onBack != null) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBackIos,
                                contentDescription = "رجوع",
                                tint = IosPrimaryTint,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                    Text(
                        text = "حكايتنا",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = IosTextPrimary,
                        fontSize = 32.sp
                    )
                }

                // Add button pill
                if (selectedTab > 0) {
                    IosButton(
                        text = "إضافة",
                        onClick = {
                            if (selectedTab == 1) showAddGoalDialog = true
                            else showAddNoteDialog = true
                        },
                        icon = Icons.Default.Add,
                        style = IosButtonStyle.PRIMARY,
                        modifier = Modifier.width(96.dp),
                        height = 36.dp
                    )
                }
            }
        }

        // iOS Segmented Control
        Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
            IosSegmentedControl(
                items = segments,
                selectedIndex = selectedTab,
                onItemSelected = { selectedTab = it }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        when (selectedTab) {
            0 -> {
                // Timeline of relationship
                TimelineTab(
                    startDateMillis = relationship?.startDateMillis ?: System.currentTimeMillis(),
                    gettingToKnowDateMillis = relationship?.gettingToKnowDateMillis ?: 0L,
                    goals = goals
                )
            }
            1 -> {
                // Goals list
                if (goals.isEmpty()) {
                    IosEmptyState(
                        icon = Icons.Default.Star,
                        title = "لا توجد أهداف مسجلة بعد",
                        description = "ضعا أهدافكما وأحلامكما المشتركة (سفر، منزل، خطط مستقبلية) وتابعا تقدمكما سويًا.",
                        actionButtonText = "إضافة هدف جديد",
                        onActionClick = { showAddGoalDialog = true }
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 100.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(goals, key = { it.firestoreId }) { goal ->
                            IosGoalCardItem(
                                goal = goal,
                                onProgressChange = { p, comp -> viewModel.updateGoal(goal.firestoreId, p, comp) },
                                onDelete = { viewModel.deleteGoal(goal.firestoreId) }
                            )
                        }
                    }
                }
            }
            2 -> {
                // Notes list
                if (notes.isEmpty()) {
                    IosEmptyState(
                        icon = Icons.Default.Notes,
                        title = "لا توجد ملاحظات حالياً",
                        description = "سجلا أفكاركما، قوائم التسوق، رسائل الحب واللحظات الخاصة التي تودان تذكرها دائمًا.",
                        actionButtonText = "كتابة ملاحظة جديدة",
                        onActionClick = { showAddNoteDialog = true }
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 100.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(notes, key = { it.firestoreId }) { note ->
                            IosNoteCardItem(
                                note = note,
                                onDelete = { viewModel.deleteNote(note.firestoreId) }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAddGoalDialog) {
        IosAddGoalSheet(
            onDismiss = { showAddGoalDialog = false },
            onSave = { title, desc, date, cat ->
                viewModel.addGoal(title, desc, date, cat)
                showAddGoalDialog = false
            }
        )
    }

    if (showAddNoteDialog) {
        IosAddNoteSheet(
            onDismiss = { showAddNoteDialog = false },
            onSave = { title, content, cat ->
                viewModel.addNote(title, content, cat)
                showAddNoteDialog = false
            }
        )
    }
}

@Composable
private fun TimelineTab(
    startDateMillis: Long,
    gettingToKnowDateMillis: Long,
    goals: List<GoalEntity>
) {
    val now = System.currentTimeMillis()
    val diffDays = ((now - startDateMillis) / TimeUnit.DAYS.toMillis(1)).coerceAtLeast(0)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Milestone 1: Beginning of love
        item {
            TimelineEventCard(
                icon = Icons.Default.Favorite,
                iconTint = IosPrimaryTint,
                dateMillis = startDateMillis,
                title = "بداية قصة حبنا الأبدية ❤️",
                subtitle = "اليوم الذي ارتبطت فيه قلوبنا وبدأ عداد حبنا الأبدي ($diffDays يومًا حتى اليوم).",
                badge = "محطة أساسية"
            )
        }

        // Milestone 2: Getting to know date if set
        if (gettingToKnowDateMillis > 0L) {
            val knowDays = ((now - gettingToKnowDateMillis) / TimeUnit.DAYS.toMillis(1)).coerceAtLeast(0)
            item {
                TimelineEventCard(
                    icon = Icons.Default.Star,
                    iconTint = Color(0xFFFF9500),
                    dateMillis = gettingToKnowDateMillis,
                    title = "أول تعارف ولقاء أرواح ✨",
                    subtitle = "اللحظة التي جمعتنا لأول مرة وبدأت شرارة الحديث ($knowDays يومًا مضت).",
                    badge = "أول لقاء"
                )
            }
        }

        // Milestone 3: Completed goals as milestone achievements
        val completedGoals = goals.filter { it.isCompleted }
        if (completedGoals.isNotEmpty()) {
            item {
                Text(
                    text = "أحلام أنجزناها معًا 🏆",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = IosTextPrimary,
                    modifier = Modifier.padding(top = 10.dp, start = 4.dp)
                )
            }

            items(completedGoals) { goal ->
                TimelineEventCard(
                    icon = Icons.Default.CheckCircle,
                    iconTint = Color(0xFF34C759),
                    dateMillis = goal.createdAtMillis,
                    title = goal.title,
                    subtitle = goal.description.ifBlank { "تم تحقيق هذا الهدف المشترك بنجاح!" },
                    badge = goal.category
                )
            }
        }
    }
}

@Composable
private fun TimelineEventCard(
    icon: ImageVector,
    iconTint: Color,
    dateMillis: Long,
    title: String,
    subtitle: String,
    badge: String
) {
    val dateStr = remember(dateMillis) {
        SimpleDateFormat("d MMMM yyyy", Locale("ar")).format(Date(dateMillis))
    }

    IosWidgetCard {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(iconTint.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = dateStr,
                        style = MaterialTheme.typography.labelSmall,
                        color = IosTextTertiary,
                        fontSize = 11.sp
                    )

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = IosCardSurfaceElevated,
                        border = BorderStroke(0.8.dp, IosCardBorder)
                    ) {
                        Text(
                            text = badge,
                            style = MaterialTheme.typography.labelSmall,
                            color = iconTint,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 10.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = IosTextPrimary
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = IosTextSecondary,
                    lineHeight = 20.sp
                )
            }
        }
    }
}

@Composable
private fun IosGoalCardItem(
    goal: GoalEntity,
    onProgressChange: (Int, Boolean) -> Unit,
    onDelete: () -> Unit
) {
    var sliderValue by remember(goal.progress) { mutableStateOf(goal.progress.toFloat()) }

    IosWidgetCard {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    IconButton(
                        onClick = {
                            val newCompleted = !goal.isCompleted
                            val newProgress = if (newCompleted) 100 else goal.progress
                            onProgressChange(newProgress, newCompleted)
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = if (goal.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                            contentDescription = "إتمام الهدف",
                            tint = if (goal.isCompleted) Color(0xFF34C759) else IosTextTertiary,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    Column {
                        Text(
                            text = goal.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (goal.isCompleted) IosTextSecondary else IosTextPrimary
                        )
                        if (goal.category.isNotBlank()) {
                            Text(
                                text = goal.category,
                                style = MaterialTheme.typography.labelSmall,
                                color = IosPrimaryTint,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "حذف",
                        tint = Color(0xFFFF453A),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            if (goal.description.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = goal.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = IosTextSecondary,
                    lineHeight = 20.sp,
                    modifier = Modifier.padding(start = 42.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Progress Slider and Value
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "نسبة الإنجاز",
                        style = MaterialTheme.typography.labelSmall,
                        color = IosTextTertiary
                    )
                    Text(
                        text = "${sliderValue.toInt()}%",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (sliderValue.toInt() == 100) Color(0xFF34C759) else IosPrimaryTint
                    )
                }

                Slider(
                    value = sliderValue,
                    onValueChange = { sliderValue = it },
                    onValueChangeFinished = {
                        val p = sliderValue.toInt()
                        onProgressChange(p, p == 100)
                    },
                    valueRange = 0f..100f,
                    colors = SliderDefaults.colors(
                        thumbColor = IosPrimaryTint,
                        activeTrackColor = IosPrimaryTint,
                        inactiveTrackColor = IosCardSurfaceElevated
                    )
                )
            }
        }
    }
}

@Composable
private fun IosNoteCardItem(
    note: NoteEntity,
    onDelete: () -> Unit
) {
    val dateStr = remember(note.updatedAtMillis) {
        SimpleDateFormat("d MMMM yyyy - hh:mm a", Locale("ar")).format(Date(note.updatedAtMillis))
    }

    IosWidgetCard {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = note.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = IosTextPrimary
                    )
                    Text(
                        text = "${note.authorName.ifBlank { "شريكي" }} • $dateStr",
                        style = MaterialTheme.typography.labelSmall,
                        color = IosTextTertiary,
                        fontSize = 11.sp
                    )
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "حذف",
                        tint = Color(0xFFFF453A),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            if (note.content.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = note.content,
                    style = MaterialTheme.typography.bodyMedium,
                    color = IosTextSecondary,
                    lineHeight = 22.sp
                )
            }
        }
    }
}

@Composable
private fun IosAddGoalSheet(
    onDismiss: () -> Unit,
    onSave: (title: String, desc: String, targetDate: String, category: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("حلمنا") }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xE6201A29))
                .border(BorderStroke(0.8.dp, IosCardBorder), RoundedCornerShape(24.dp))
                .padding(22.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "إضافة حلم جديد ✨",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = IosTextPrimary
                )

                Spacer(modifier = Modifier.height(16.dp))

                IosTextField(
                    value = title,
                    onValueChange = { title = it },
                    placeholder = "عنوان الحلم المشترك (مثال: رحلة إلى باريس)",
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                IosTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    placeholder = "تفاصيل الحلم وخطة تحقيقه...",
                    singleLine = false,
                    maxLines = 3
                )

                Spacer(modifier = Modifier.height(10.dp))

                IosTextField(
                    value = category,
                    onValueChange = { category = it },
                    placeholder = "التصنيف (مثال: سفر، بيت، أهداف)",
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    IosButton(
                        text = "إلغاء",
                        onClick = onDismiss,
                        style = IosButtonStyle.SECONDARY,
                        modifier = Modifier.weight(1f)
                    )
                    IosButton(
                        text = "حفظ الحلم",
                        onClick = {
                            if (title.isNotBlank()) {
                                onSave(title.trim(), desc.trim(), "", category.trim())
                            }
                        },
                        style = IosButtonStyle.PRIMARY,
                        enabled = title.isNotBlank(),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun IosAddNoteSheet(
    onDismiss: () -> Unit,
    onSave: (title: String, content: String, category: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xE6201A29))
                .border(BorderStroke(0.8.dp, IosCardBorder), RoundedCornerShape(24.dp))
                .padding(22.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "كتابة ملاحظة جديدة 📝",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = IosTextPrimary
                )

                Spacer(modifier = Modifier.height(16.dp))

                IosTextField(
                    value = title,
                    onValueChange = { title = it },
                    placeholder = "عنوان الملاحظة...",
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                IosTextField(
                    value = content,
                    onValueChange = { content = it },
                    placeholder = "اكتب أفكارك وملاحظاتك لشريكك هنا...",
                    singleLine = false,
                    maxLines = 5
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    IosButton(
                        text = "إلغاء",
                        onClick = onDismiss,
                        style = IosButtonStyle.SECONDARY,
                        modifier = Modifier.weight(1f)
                    )
                    IosButton(
                        text = "حفظ الملاحظة",
                        onClick = {
                            if (title.isNotBlank() || content.isNotBlank()) {
                                onSave(title.ifBlank { "ملاحظة حب" }.trim(), content.trim(), "عام")
                            }
                        },
                        style = IosButtonStyle.PRIMARY,
                        enabled = title.isNotBlank() || content.isNotBlank(),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}
