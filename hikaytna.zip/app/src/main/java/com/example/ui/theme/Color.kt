package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Soft Premium iOS-Inspired Dark Palette (Comfortable Charcoal/Plum-Black, Soft Rose, Lavender & Champagne)
val ModernDarkBackground = Color(0xFF131017) // Deep soft charcoal/plum-black (not harsh black)
val ModernDarkSurface = Color(0xFF1C1723) // Soft translucent dark surface
val ModernDarkSurfaceElevated = Color(0xFF241E2D) // Slightly lighter translucent surface
val ModernDarkSurfaceBorder = Color(0x1FFFFFFF) // Extremely subtle hairline border
val DarkBurgundy = Color(0xFF191420)
val DeepMidnight = Color(0xFF131017)

// Soft Primary Rose / Muted Pink (Gentle on the eyes, romantic, premium)
val CrimsonPrimary = Color(0xFFE28498) // Soft muted rose
val CrimsonPrimaryLight = Color(0xFFEDB2C0) // Delicate soft blush
val CrimsonPrimaryDark = Color(0xFFC7697D) // Deep muted rose
val RomanticRed = CrimsonPrimary

// Secondary Lavender & Violet
val SoftLavender = Color(0xFFA99AC7)
val SoftViolet = Color(0xFFBCAFD7)

// Warm Champagne & Accent (Used lightly)
val RoseGold = Color(0xFFDEBE8A) // Soft warm champagne gold
val RoseGoldDark = Color(0xFFC9A66F)
val SoftBlush = Color(0xFFF9ECF0)
val WarmWhite = Color(0xFFF7F4F8) // Warm off-white for primary text
val MutedRose = Color(0xFFA59EAD) // Soft gray/lavender for secondary text

val GlassCardBackground = Color(0x33251F2E)
val GlassCardBorder = Color(0x1FFFFFFF)

// Soft Gradients
val ModernBackgroundGradient = Brush.verticalGradient(
    colors = listOf(
        Color(0xFF191421),
        Color(0xFF131017),
        Color(0xFF0F0D12)
    )
)
val RomanticGradient = ModernBackgroundGradient

val ModernCardGradient = Brush.linearGradient(
    colors = listOf(
        Color(0x282C2436),
        Color(0x181F1927)
    )
)
val RomanticCardGradient = ModernCardGradient

val CrimsonButtonGradient = Brush.horizontalGradient(
    colors = listOf(
        Color(0xFFE28498),
        Color(0xFFD67388)
    )
)

val GoldAccentGradient = Brush.horizontalGradient(
    colors = listOf(
        Color(0xFFDEBE8A),
        Color(0xFFCFAC74)
    )
)
