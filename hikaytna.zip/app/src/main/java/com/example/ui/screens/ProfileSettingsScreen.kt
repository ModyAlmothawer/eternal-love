package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBackIos
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.ui.theme.IosAlertDialog
import com.example.ui.theme.IosButton
import com.example.ui.theme.IosButtonStyle
import com.example.ui.theme.IosCardBorder
import com.example.ui.theme.IosCardSurface
import com.example.ui.theme.IosCardSurfaceElevated
import com.example.ui.theme.IosDarkBackground
import com.example.ui.theme.IosPrimaryGradient
import com.example.ui.theme.IosPrimaryTint
import com.example.ui.theme.IosSettingsRow
import com.example.ui.theme.IosSettingsSection
import com.example.ui.theme.IosSubtleSeparator
import com.example.ui.theme.IosTextField
import com.example.ui.theme.IosTextPrimary
import com.example.ui.theme.IosTextSecondary
import com.example.ui.theme.IosTextTertiary
import com.example.ui.theme.IosWidgetCard
import com.example.ui.viewmodel.LoveViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileSettingsScreen(
    viewModel: LoveViewModel,
    onBack: (() -> Unit)? = null,
    onLoggedOut: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val user by viewModel.user.collectAsState()
    val relationship by viewModel.relationship.collectAsState()
    val appUpdate by viewModel.appUpdate.collectAsState()

    var showEditNameDialog by remember { mutableStateOf(false) }
    var showBirthdayPicker by remember { mutableStateOf(false) }
    var showRelationshipDatePicker by remember { mutableStateOf(false) }
    var showGettingToKnowDatePicker by remember { mutableStateOf(false) }
    var showDisconnectConfirm by remember { mutableStateOf(false) }
    var isUploadingPhoto by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            isUploadingPhoto = true
            viewModel.updateUserProfile(
                name = user?.name ?: "",
                avatarRes = user?.avatarRes ?: "avatar_1",
                imageUri = uri
            ) {
                isUploadingPhoto = false
                Toast.makeText(context, "تم تحديث صورتك الشخصية بنجاح", Toast.LENGTH_SHORT).show()
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(IosDarkBackground),
        contentPadding = PaddingValues(bottom = 100.dp)
    ) {
        // iOS Navigation Bar / Title
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (onBack != null) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBackIos,
                                contentDescription = "رجوع",
                                tint = IosPrimaryTint,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                    Text(
                        text = "الإعدادات",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = IosTextPrimary,
                        fontSize = 32.sp
                    )
                }
            }
        }

        // Profile Hero Header (iOS Apple ID style)
        item {
            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                IosWidgetCard {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Large Avatar with Camera Badge
                        Box(
                            modifier = Modifier
                                .size(96.dp)
                                .clip(CircleShape)
                                .background(IosPrimaryGradient)
                                .clickable {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (!user?.photoUrl.isNullOrBlank()) {
                                AsyncImage(
                                    model = user!!.photoUrl,
                                    contentDescription = "صورتي",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Text(
                                    text = user?.name?.take(1) ?: "❤️",
                                    fontSize = 38.sp,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            if (isUploadingPhoto) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.Black.copy(alpha = 0.5f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(36.dp),
                                        color = Color.White,
                                        strokeWidth = 3.dp
                                    )
                                }
                            } else {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.BottomEnd)
                                        .size(30.dp)
                                        .clip(CircleShape)
                                        .background(IosPrimaryTint)
                                        .border(BorderStroke(2.dp, IosDarkBackground), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CameraAlt,
                                        contentDescription = "تغيير الصورة",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // User Name
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = user?.name ?: "مستخدم Любовь",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = IosTextPrimary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            IconButton(
                                onClick = { showEditNameDialog = true },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "تعديل الاسم",
                                    tint = IosPrimaryTint,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        // Masked Email
                        val maskedEmail = maskEmail(user?.email ?: "")
                        if (maskedEmail.isNotBlank()) {
                            Text(
                                text = maskedEmail,
                                style = MaterialTheme.typography.bodySmall,
                                color = IosTextTertiary
                            )
                        }

                        // Relationship Status Tag
                        if (relationship != null) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = IosCardSurfaceElevated,
                                border = BorderStroke(0.8.dp, IosCardBorder)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Favorite,
                                        contentDescription = null,
                                        tint = IosPrimaryTint,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (relationship!!.status == "connected") "مرتبط مع ${relationship!!.partnerName.ifBlank { "شريكي" }}" else "في انتظار انضمام الشريك",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = IosTextSecondary,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section: Relationship & Couple Code
        item {
            relationship?.let { rel ->
                IosSettingsSection(title = "كود الربط وقصة الحب") {
                    // Copyable Code Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "كود الربط الخاص بكما",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = IosTextPrimary
                            )
                            Text(
                                text = "شارك هذا الكود لربط التطبيقين معاً",
                                style = MaterialTheme.typography.labelSmall,
                                color = IosTextTertiary
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = rel.code,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = IosPrimaryTint,
                                letterSpacing = 2.sp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            IconButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    val clip = ClipData.newPlainText("Love Code", rel.code)
                                    clipboard.setPrimaryClip(clip)
                                    Toast.makeText(context, "تم نسخ كود الربط", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "نسخ",
                                    tint = IosPrimaryTint,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section: Important Dates & Anniversaries
        item {
            val myBdayStr = if ((user?.birthdayMillis ?: 0L) > 0L) {
                SimpleDateFormat("d MMMM yyyy", Locale("ar")).format(Date(user!!.birthdayMillis))
            } else "لم يُحدد بعد"

            val relStartStr = if ((relationship?.startDateMillis ?: 0L) > 0L) {
                SimpleDateFormat("d MMMM yyyy", Locale("ar")).format(Date(relationship!!.startDateMillis))
            } else "لم يُحدد بعد"

            val gettingToKnowStr = if ((relationship?.gettingToKnowDateMillis ?: 0L) > 0L) {
                SimpleDateFormat("d MMMM yyyy", Locale("ar")).format(Date(relationship!!.gettingToKnowDateMillis))
            } else "اختياري"

            IosSettingsSection(title = "التواريخ والمناسبات الخاصة") {
                IosSettingsRow(
                    icon = Icons.Default.Cake,
                    iconTint = Color(0xFFFF2D55),
                    title = "عيد ميلادي",
                    subtitle = myBdayStr,
                    onClick = { showBirthdayPicker = true }
                )

                if (relationship != null) {
                    IosSettingsRow(
                        icon = Icons.Default.CalendarMonth,
                        iconTint = Color(0xFFAF52DE),
                        title = "تاريخ بداية العلاقة",
                        subtitle = relStartStr,
                        onClick = { showRelationshipDatePicker = true }
                    )

                    IosSettingsRow(
                        icon = Icons.Default.Info,
                        iconTint = Color(0xFFFF9500),
                        title = "تاريخ أول لقاء وتعارف",
                        subtitle = gettingToKnowStr,
                        onClick = { showGettingToKnowDatePicker = true },
                        showDivider = false
                    )
                }
            }
        }

        // Section: System & App Updates
        item {
            IosSettingsSection(title = "حول التطبيق والتحديثات") {
                val updateText = if (appUpdate != null) "إصدار جديد متاح (${appUpdate!!.latestVersionName})" else "تطبيقك محدّث لآخر إصدار (1.0)"

                IosSettingsRow(
                    icon = Icons.Default.SystemUpdate,
                    iconTint = Color(0xFF007AFF),
                    title = "التحقق من التحديثات",
                    subtitle = updateText,
                    onClick = {
                        scope.launch {
                            viewModel.checkAppUpdate()
                            Toast.makeText(context, "جاري التحقق من التحديثات...", Toast.LENGTH_SHORT).show()
                        }
                    }
                )

                IosSettingsRow(
                    icon = Icons.Default.Lock,
                    iconTint = Color(0xFF34C759),
                    title = "الخصوصية والتشفير",
                    subtitle = "بياناتكما مشفرة ومحفوظة بسرية تامة",
                    onClick = {
                        Toast.makeText(context, "جميع الرسائل والوسائط مشفرة وخاصة بكما فقط.", Toast.LENGTH_LONG).show()
                    },
                    showDivider = false
                )
            }
        }

        // Section: Sensitive Actions (Unlink & Sign Out)
        item {
            IosSettingsSection(title = "الحساب والأمان") {
                if (relationship != null) {
                    IosSettingsRow(
                        icon = Icons.Default.LinkOff,
                        iconTint = Color(0xFFFF453A),
                        title = "فصل الربط مع الشريك",
                        subtitle = "إلغاء اتصال الحسابين",
                        textColor = Color(0xFFFF453A),
                        onClick = { showDisconnectConfirm = true }
                    )
                }

                IosSettingsRow(
                    icon = Icons.AutoMirrored.Filled.ExitToApp,
                    iconTint = IosTextTertiary,
                    title = "تسجيل الخروج",
                    subtitle = "الخروج من الحساب الحالي",
                    textColor = IosTextSecondary,
                    onClick = {
                        viewModel.logout()
                        onLoggedOut()
                    },
                    showDivider = false
                )
            }
        }
    }

    // Edit Name Dialog
    if (showEditNameDialog) {
        var newName by remember { mutableStateOf(user?.name ?: "") }
        Dialog(
            onDismissRequest = { showEditNameDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.9f)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0xE6201A29))
                    .border(BorderStroke(0.8.dp, IosCardBorder), RoundedCornerShape(24.dp))
                    .padding(22.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "تعديل اسمك في التطبيق",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = IosTextPrimary
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    IosTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        placeholder = "اسمك الجديد...",
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        IosButton(
                            text = "إلغاء",
                            onClick = { showEditNameDialog = false },
                            style = IosButtonStyle.SECONDARY,
                            modifier = Modifier.weight(1f)
                        )
                        IosButton(
                            text = "حفظ",
                            onClick = {
                                if (newName.isNotBlank()) {
                                    viewModel.updateUserProfile(newName.trim(), user?.avatarRes ?: "avatar_1", null) {}
                                    showEditNameDialog = false
                                }
                            },
                            style = IosButtonStyle.PRIMARY,
                            enabled = newName.isNotBlank(),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }

    // Birthday DatePicker Dialog
    if (showBirthdayPicker) {
        val datePickerState = rememberDatePickerState()
        DatePickerDialog(
            onDismissRequest = { showBirthdayPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    val selectedMillis = datePickerState.selectedDateMillis
                    if (selectedMillis != null) {
                        viewModel.updateUserBirthday(selectedMillis)
                    }
                    showBirthdayPicker = false
                }) {
                    Text("حفظ", color = IosPrimaryTint, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showBirthdayPicker = false }) {
                    Text("إلغاء", color = IosTextSecondary)
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    // Relationship Start DatePicker Dialog
    if (showRelationshipDatePicker) {
        val datePickerState = rememberDatePickerState()
        DatePickerDialog(
            onDismissRequest = { showRelationshipDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    val selectedMillis = datePickerState.selectedDateMillis
                    if (selectedMillis != null) {
                        val currentGettingToKnow = relationship?.gettingToKnowDateMillis ?: 0L
                        viewModel.updateRelationshipDates(selectedMillis, currentGettingToKnow)
                    }
                    showRelationshipDatePicker = false
                }) {
                    Text("حفظ", color = IosPrimaryTint, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRelationshipDatePicker = false }) {
                    Text("إلغاء", color = IosTextSecondary)
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    // Getting-To-Know DatePicker Dialog
    if (showGettingToKnowDatePicker) {
        val datePickerState = rememberDatePickerState()
        DatePickerDialog(
            onDismissRequest = { showGettingToKnowDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    val selectedMillis = datePickerState.selectedDateMillis
                    if (selectedMillis != null) {
                        viewModel.updateGettingToKnowDate(selectedMillis)
                    }
                    showGettingToKnowDatePicker = false
                }) {
                    Text("حفظ", color = IosPrimaryTint, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showGettingToKnowDatePicker = false }) {
                    Text("إلغاء", color = IosTextSecondary)
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    // Disconnect Confirm Dialog
    if (showDisconnectConfirm) {
        IosAlertDialog(
            title = "فصل الربط مع الشريك؟",
            message = "هل أنت متأكد من رغبتك في فصل الربط مع شريكك؟ ستتمكن من ربط حساب جديد بكود آخر لاحقاً.",
            confirmText = "تأكيد الفصل",
            dismissText = "إلغاء",
            onConfirm = {
                showDisconnectConfirm = false
                viewModel.disconnectRelationship()
                Toast.makeText(context, "تم فصل الربط بنجاح", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { showDisconnectConfirm = false },
            isDestructive = true
        )
    }
}

private fun maskEmail(email: String): String {
    if (email.isBlank() || !email.contains("@")) return email
    val parts = email.split("@")
    val name = parts[0]
    val domain = parts[1]
    val maskedName = if (name.length > 2) "${name.take(1)}***${name.takeLast(1)}" else "${name.take(1)}***"
    val domainParts = domain.split(".")
    val maskedDomain = if (domainParts.size > 1) {
        val dName = domainParts[0]
        val tld = domainParts.drop(1).joinToString(".")
        "${dName.take(1)}***.$tld"
    } else {
        domain
    }
    return "$maskedName@$maskedDomain"
}
