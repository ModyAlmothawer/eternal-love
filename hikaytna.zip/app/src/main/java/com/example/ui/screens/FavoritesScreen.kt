package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.LoveLetterEntity
import com.example.data.model.MemoryEntity
import com.example.data.remote.MediaUrlResolver
import com.example.data.remote.rememberResolvedMediaUrl
import com.example.ui.theme.IosCardBorder
import com.example.ui.theme.IosCardSurface
import com.example.ui.theme.IosCardSurfaceElevated
import com.example.ui.theme.IosDarkBackground
import com.example.ui.theme.IosEmptyState
import com.example.ui.theme.IosLargeTitle
import com.example.ui.theme.IosPrimaryTint
import com.example.ui.theme.IosSegmentedControl
import com.example.ui.theme.IosTextPrimary
import com.example.ui.theme.IosTextSecondary
import com.example.ui.theme.IosTextTertiary
import com.example.ui.theme.IosWidgetCard
import com.example.ui.viewmodel.LoveViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun FavoritesScreen(
    viewModel: LoveViewModel,
    onNavigateToChat: () -> Unit,
    onNavigateToMemories: () -> Unit
) {
    val context = LocalContext.current
    val loveLetters by viewModel.loveLetters.collectAsState()
    val memories by viewModel.memories.collectAsState()

    var selectedSegment by remember { mutableIntStateOf(0) }
    val segments = listOf("الكل", "رسائل مميزة", "ألبوم الصور")

    // Filter letters with reactions or voice or long romantic notes
    val favoriteLetters = remember(loveLetters) {
        loveLetters.filter { it.reactions.isNotBlank() || it.mediaType == "voice" || it.message.length > 30 }
    }

    // Memories with photos
    val photoMemories = remember(memories) {
        memories.filter { it.imageUrl.isNotBlank() || it.imageDrawableName.isNotBlank() }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(IosDarkBackground)
    ) {
        // iOS Large Title
        IosLargeTitle(
            title = "المفضلة",
            subtitle = "أجمل اللحظات والرسائل المحفوظة في قلوبنا"
        )

        // iOS Segmented Control
        Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
            IosSegmentedControl(
                items = segments,
                selectedIndex = selectedSegment,
                onItemSelected = { selectedSegment = it }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        when (selectedSegment) {
            0 -> {
                // All favorites
                if (favoriteLetters.isEmpty() && photoMemories.isEmpty()) {
                    IosEmptyState(
                        icon = Icons.Default.Star,
                        title = "لا توجد عناصر مفضلة بعد",
                        description = "تظهر هنا الرسائل التي تحتوي على تفاعلات حب، التسجيلات الصوتية، وأجمل صور ذكرياتكما معًا.",
                        actionButtonText = "افتح الدردشة",
                        onActionClick = onNavigateToChat
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 100.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        if (photoMemories.isNotEmpty()) {
                            item {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "صور الذكريات",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = IosTextPrimary
                                    )
                                    Text(
                                        text = "${photoMemories.size} صور",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = IosPrimaryTint,
                                        modifier = Modifier.clickable(onClick = onNavigateToMemories)
                                    )
                                }
                            }

                            item {
                                LazyVerticalGrid(
                                    columns = GridCells.Fixed(3),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(130.dp),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                    userScrollEnabled = false
                                ) {
                                    items(photoMemories.take(3)) { memory ->
                                        FavoritePhotoThumbnail(memory = memory, onClick = onNavigateToMemories)
                                    }
                                }
                            }
                        }

                        if (favoriteLetters.isNotEmpty()) {
                            item {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "الرسائل الخاصة والمميزة",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = IosTextPrimary
                                )
                            }

                            items(favoriteLetters) { letter ->
                                FavoriteLetterCard(letter = letter, onClick = onNavigateToChat)
                            }
                        }
                    }
                }
            }
            1 -> {
                // Favorite Letters only
                if (favoriteLetters.isEmpty()) {
                    IosEmptyState(
                        icon = Icons.Default.ChatBubbleOutline,
                        title = "لا توجد رسائل مميزة حالياً",
                        description = "أرسل رسالة رومانسية أو تفاعل مع رسائل شريكك بقلب لتظهر هنا.",
                        actionButtonText = "إرسال رسالة",
                        onActionClick = onNavigateToChat
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 100.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(favoriteLetters) { letter ->
                            FavoriteLetterCard(letter = letter, onClick = onNavigateToChat)
                        }
                    }
                }
            }
            2 -> {
                // Photos only
                if (photoMemories.isEmpty()) {
                    IosEmptyState(
                        icon = Icons.Default.PhotoLibrary,
                        title = "لا توجد صور ذكريات بعد",
                        description = "أضف صورة جميلة في قسم الذكريات لتوثيق أسعد أوقاتكما معًا.",
                        actionButtonText = "إضافة ذكرى جديدة",
                        onActionClick = onNavigateToMemories
                    )
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 100.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(photoMemories) { memory ->
                            FavoritePhotoThumbnail(memory = memory, height = 180, onClick = onNavigateToMemories)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FavoriteLetterCard(
    letter: LoveLetterEntity,
    onClick: () -> Unit
) {
    val dateStr = remember(letter.dateMillis) {
        SimpleDateFormat("d MMMM yyyy - hh:mm a", Locale("ar")).format(Date(letter.dateMillis))
    }

    IosWidgetCard(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(IosPrimaryTint.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (letter.mediaType == "voice") Icons.Default.Mic else Icons.Default.Favorite,
                            contentDescription = null,
                            tint = IosPrimaryTint,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = letter.senderName.ifBlank { "رسالة حب" },
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = IosTextPrimary
                        )
                        Text(
                            text = dateStr,
                            style = MaterialTheme.typography.labelSmall,
                            color = IosTextTertiary,
                            fontSize = 11.sp
                        )
                    }
                }

                if (letter.reactions.isNotBlank()) {
                    val reactionList = letter.reactions.split(",").mapNotNull {
                        val parts = it.split(":")
                        if (parts.size == 2) parts[1] else null
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        reactionList.distinct().take(3).forEach { emoji ->
                            Text(text = emoji, fontSize = 16.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (letter.mediaType == "voice") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(IosCardSurfaceElevated)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = null,
                        tint = IosPrimaryTint,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "تسجيل صوتي خاص (${letter.durationSeconds} ثانية)",
                        style = MaterialTheme.typography.bodySmall,
                        color = IosTextPrimary,
                        fontWeight = FontWeight.Medium
                    )
                }
            } else {
                Text(
                    text = letter.message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = IosTextPrimary,
                    maxLines = 4,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 22.sp
                )
            }
        }
    }
}

@Composable
private fun FavoritePhotoThumbnail(
    memory: MemoryEntity,
    height: Int = 120,
    onClick: () -> Unit
) {
    val context = LocalContext.current
    val resolvedUrl = rememberResolvedMediaUrl(memory.imageUrl)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(height.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(IosCardSurface)
            .border(androidx.compose.foundation.BorderStroke(0.8.dp, IosCardBorder), RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
    ) {
        if (!resolvedUrl.isNullOrBlank()) {
            AsyncImage(
                model = resolvedUrl,
                contentDescription = memory.title,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PhotoLibrary,
                    contentDescription = null,
                    tint = IosTextTertiary,
                    modifier = Modifier.size(32.dp)
                )
            }
        }

        // Title overlay gradient at bottom
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(Color.Black.copy(alpha = 0.55f))
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Text(
                text = memory.title.ifBlank { "ذكرى" },
                style = MaterialTheme.typography.labelSmall,
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontSize = 11.sp
            )
        }
    }
}
