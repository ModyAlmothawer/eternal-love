package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.border
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Mood
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Reply
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.example.data.model.LoveLetterEntity
import com.example.data.remote.rememberResolvedMediaUrl
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.ModernDarkBackground
import com.example.ui.theme.ModernDarkSurface
import com.example.ui.theme.ModernDarkSurfaceElevated
import com.example.ui.theme.RoseGold
import com.example.ui.viewmodel.LoveViewModel
import com.example.util.AudioPlayerHelper
import com.example.util.NotificationHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun formatChatDateSeparator(timestampMillis: Long): String {
    val messageCal = java.util.Calendar.getInstance().apply { timeInMillis = timestampMillis }
    val nowCal = java.util.Calendar.getInstance()

    val isSameYear = messageCal.get(java.util.Calendar.YEAR) == nowCal.get(java.util.Calendar.YEAR)
    val dayOfYearDiff = nowCal.get(java.util.Calendar.DAY_OF_YEAR) - messageCal.get(java.util.Calendar.DAY_OF_YEAR)

    return when {
        isSameYear && dayOfYearDiff == 0 -> "اليوم"
        isSameYear && dayOfYearDiff == 1 -> "أمس"
        isSameYear -> SimpleDateFormat("d MMMM", Locale("ar")).format(Date(timestampMillis))
        else -> SimpleDateFormat("d MMMM yyyy", Locale("ar")).format(Date(timestampMillis))
    }
}

private val REACTION_EMOJIS = listOf("❤️", "😍", "😘", "🥰", "😂", "🥺", "🔥", "🌹")

private val QUICK_EMOJIS = listOf(
    "❤️", "💖", "💕", "💞", "💓", "💘", "💝", "💗",
    "😍", "🥰", "😘", "🥺", "✨", "🌹", "👑", "🕊️",
    "😊", "🤗", "💌", "💍", "💋", "🙈", "🌸", "⭐"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: LoveViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val user by viewModel.user.collectAsState()
    val relationship by viewModel.relationship.collectAsState()
    val loveLetters by viewModel.loveLetters.collectAsState()
    val partnerIsOnline by viewModel.partnerIsOnline.collectAsState()
    val partnerLastSeen by viewModel.partnerLastSeen.collectAsState()
    val partnerIsTyping by viewModel.partnerIsTyping.collectAsState()
    val partnerLastReadAt by viewModel.partnerLastReadAt.collectAsState()

    var messageText by remember { mutableStateOf("") }
    var replyingToMessage by remember { mutableStateOf<LoveLetterEntity?>(null) }
    var editingMessage by remember { mutableStateOf<LoveLetterEntity?>(null) }
    var showEmojiPanel by remember { mutableStateOf(false) }
    var isRecordingAudio by remember { mutableStateOf(false) }
    var recordingSeconds by remember { mutableStateOf(0) }

    val listState = rememberLazyListState()

    val relId = relationship?.firestoreId ?: ""
    val currentUid = user?.firebaseUid ?: ""
    val partnerUid = if (currentUid == relationship?.creatorId) relationship?.partnerId else relationship?.creatorId
    val partnerName = if (currentUid == relationship?.creatorId) {
        relationship?.partnerName?.ifBlank { user?.partnerName } ?: "حبيبي"
    } else {
        relationship?.creatorName?.ifBlank { user?.partnerName } ?: "حبيبي"
    }
    val partnerPhoto = if (currentUid == relationship?.creatorId) {
        relationship?.partnerPhoto?.ifBlank { user?.partnerPhotoUrl } ?: ""
    } else {
        relationship?.creatorPhoto?.ifBlank { user?.partnerPhotoUrl } ?: ""
    }

    // Entering and leaving conversation: suppress notifications and mark messages read
    DisposableEffect(relId) {
        NotificationHelper.isChatScreenActive = true
        NotificationHelper.activeChatRelationshipId = relId
        viewModel.markAllMessagesAsRead()
        NotificationHelper.clearChatNotifications(context)

        onDispose {
            NotificationHelper.isChatScreenActive = false
            NotificationHelper.activeChatRelationshipId = null
            viewModel.updateTypingStatus(false)
            AudioPlayerHelper.stopAudio(context)
        }
    }

    // Call permissions launcher
    val callPermissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val micGranted = permissions[Manifest.permission.RECORD_AUDIO] == true
        if (!micGranted) {
            Toast.makeText(context, "إذن الميكروفون مطلوب لإجراء المكالمة", Toast.LENGTH_SHORT).show()
        }
    }

    // Audio recording timer
    LaunchedEffect(isRecordingAudio) {
        if (isRecordingAudio) {
            recordingSeconds = 0
            while (isRecordingAudio) {
                delay(1000)
                recordingSeconds += 1
            }
        }
    }

    // Typing debounce
    LaunchedEffect(messageText) {
        if (messageText.isNotBlank()) {
            viewModel.updateTypingStatus(true)
            delay(2000)
            viewModel.updateTypingStatus(false)
        } else {
            viewModel.updateTypingStatus(false)
        }
    }

    // Realtime incoming message read triggering while viewing conversation
    LaunchedEffect(loveLetters) {
        val hasUnreadIncoming = loveLetters.any { it.senderUid != currentUid && !it.isRead }
        if (hasUnreadIncoming) {
            viewModel.markAllMessagesAsRead()
        }
    }

    // Subtle local contextual emoji suggestions based on typing
    val suggestedEmojis by remember(messageText) {
        derivedStateOf {
            if (messageText.isBlank()) emptyList()
            else {
                val suggestions = mutableListOf<String>()
                val lower = messageText.trim()
                if (lower.contains("بحبك") || lower.contains("احبك") || lower.contains("أحبك")) {
                    suggestions.addAll(listOf("🥰", "❤️"))
                } else if (lower.contains("حب") || lower.contains("عشق") || lower.contains("غرام")) {
                    suggestions.add("❤️")
                }
                if (lower.contains("قلب") || lower.contains("روحي") || lower.contains("عمري")) {
                    if (!suggestions.contains("❤️")) suggestions.add("❤️")
                    suggestions.add("💖")
                }
                if (lower.contains("ضحك") || lower.contains("هههه") || lower.contains("ههه") || lower.contains("نكتة")) {
                    suggestions.add("😂")
                }
                if (lower.contains("فرح") || lower.contains("مبسوط") || lower.contains("سعيد") || lower.contains("الحمد لله")) {
                    suggestions.addAll(listOf("😊", "🎉"))
                }
                if (lower.contains("زعلان") || lower.contains("حزين") || lower.contains("اشتقت") || lower.contains("وحشتني")) {
                    suggestions.addAll(listOf("😢", "🥺"))
                }
                if (lower.contains("حضن") || lower.contains("ضمة") || lower.contains("احضني")) {
                    suggestions.add("🤗")
                }
                if (lower.contains("بوسة") || lower.contains("قبلة") || lower.contains("امواه")) {
                    suggestions.add("😘")
                }
                if (lower.contains("صباح") || lower.contains("ورد") || lower.contains("ياسمين")) {
                    suggestions.addAll(listOf("🌸", "🌹"))
                }
                if (lower.contains("مساء") || lower.contains("تصبح") || lower.contains("نوم") || lower.contains("قمر")) {
                    suggestions.addAll(listOf("🌙", "✨"))
                }
                suggestions.distinct().take(6)
            }
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("chat_screen"),
        containerColor = com.example.ui.theme.IosDarkBackground,
        topBar = {
            Surface(
                color = com.example.ui.theme.IosGlassSurface,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("chat_top_bar")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(58.dp)
                            .padding(horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Back Button & Partner info
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            IconButton(
                                onClick = onBack,
                                modifier = Modifier.size(44.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "رجوع",
                                    tint = com.example.ui.theme.IosPrimaryTint,
                                    modifier = Modifier.size(22.dp)
                                )
                            }

                            // Partner Avatar with iOS Glowing Online Ring
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF24152A)),
                                contentAlignment = Alignment.Center
                            ) {
                                if (partnerPhoto.isNotBlank()) {
                                    AsyncImage(
                                        model = partnerPhoto,
                                        contentDescription = "صورة الشريك",
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    Text(
                                        text = partnerName.take(1).ifBlank { "❤️" },
                                        color = com.example.ui.theme.IosAccentGold,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    )
                                }

                                if (partnerIsOnline) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.BottomEnd)
                                            .size(11.dp)
                                            .clip(CircleShape)
                                            .background(com.example.ui.theme.IosDarkBackground)
                                            .padding(1.5.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .clip(CircleShape)
                                                .background(com.example.ui.theme.IosSuccessGreen)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column {
                                Text(
                                    text = partnerName,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                val statusSubtitle = when {
                                    partnerIsTyping -> "يكتب الآن..."
                                    partnerIsOnline -> "متصل الآن 🟢"
                                    partnerLastSeen > 0L -> {
                                        val timeStr = SimpleDateFormat("h:mm a", Locale("ar")).format(Date(partnerLastSeen))
                                        "آخر ظهور $timeStr"
                                    }
                                    else -> "الدردشة"
                                }
                                Text(
                                    text = statusSubtitle,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (partnerIsTyping) com.example.ui.theme.IosPrimaryTint else com.example.ui.theme.IosTextSecondary,
                                    maxLines = 1
                                )
                            }
                        }

                        // iOS-Style Glass Action Buttons: Audio & Video Calls
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(18.dp),
                                color = Color.White.copy(alpha = 0.08f),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(18.dp))
                                    .clickable {
                                        val micGranted = ContextCompat.checkSelfPermission(
                                            context, Manifest.permission.RECORD_AUDIO
                                        ) == PackageManager.PERMISSION_GRANTED
                                        if (!micGranted) {
                                            callPermissionsLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
                                        } else {
                                            viewModel.startCall("voice")
                                        }
                                    }
                                    .testTag("start_voice_call_button")
                            ) {
                                Box(modifier = Modifier.padding(8.dp)) {
                                    Icon(
                                        imageVector = Icons.Default.Call,
                                        contentDescription = "اتصال صوتي",
                                        tint = com.example.ui.theme.IosAccentGold,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(18.dp),
                                color = Color.White.copy(alpha = 0.08f),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(18.dp))
                                    .clickable {
                                        val micGranted = ContextCompat.checkSelfPermission(
                                            context, Manifest.permission.RECORD_AUDIO
                                        ) == PackageManager.PERMISSION_GRANTED
                                        val camGranted = ContextCompat.checkSelfPermission(
                                            context, Manifest.permission.CAMERA
                                        ) == PackageManager.PERMISSION_GRANTED
                                        if (!micGranted || !camGranted) {
                                            callPermissionsLauncher.launch(
                                                arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
                                            )
                                        } else {
                                            viewModel.startCall("video")
                                        }
                                    }
                                    .testTag("start_video_call_button")
                            ) {
                                Box(modifier = Modifier.padding(8.dp)) {
                                    Icon(
                                        imageVector = Icons.Default.Videocam,
                                        contentDescription = "اتصال فيديو",
                                        tint = com.example.ui.theme.IosPrimaryTint,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                    androidx.compose.material3.HorizontalDivider(
                        thickness = 0.5.dp,
                        color = com.example.ui.theme.IosSubtleSeparator
                    )
                }
            }
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(com.example.ui.theme.IosGlassSurface)
            ) {
                androidx.compose.material3.HorizontalDivider(
                    thickness = 0.5.dp,
                    color = com.example.ui.theme.IosSubtleSeparator
                )

                // Reply Preview Bar
                AnimatedVisibility(
                    visible = replyingToMessage != null,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    replyingToMessage?.let { reply ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF221124))
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(3.dp)
                                    .height(36.dp)
                                    .background(com.example.ui.theme.IosPrimaryTint)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "الرد على ${reply.senderName}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = com.example.ui.theme.IosPrimaryTint,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = reply.message,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White.copy(alpha = 0.8f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            IconButton(onClick = { replyingToMessage = null }) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "إلغاء الرد",
                                    tint = Color.White.copy(alpha = 0.6f)
                                )
                            }
                        }
                    }
                }

                // Voice Recording Live Bar
                if (isRecordingAudio) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFFF3B30))
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "تسجيل صوتي: %02d:%02d".format(recordingSeconds / 60, recordingSeconds % 60),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium,
                                color = Color.White
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Cancel
                            TextButton(onClick = {
                                viewModel.audioRecorderHelper.cancelRecording()
                                isRecordingAudio = false
                            }) {
                                Text("إلغاء", color = Color(0xFFFF453A), fontWeight = FontWeight.Medium)
                            }
                            Spacer(modifier = Modifier.width(4.dp))
                            // Stop & Send
                            IconButton(
                                onClick = {
                                    val (recordedFile, duration) = viewModel.audioRecorderHelper.stopRecording()
                                    isRecordingAudio = false
                                    if (recordedFile != null && recordedFile.exists() && duration >= 1) {
                                        viewModel.sendVoiceNote(recordedFile, duration)
                                    }
                                },
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(com.example.ui.theme.IosPrimaryTint)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Send,
                                    contentDescription = "إرسال الصوت",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                } else {
                    // Subtle dynamic emoji suggestions based on typing
                    AnimatedVisibility(
                        visible = suggestedEmojis.isNotEmpty(),
                        enter = fadeIn(),
                        exit = fadeOut()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "اقتراح:",
                                style = MaterialTheme.typography.labelSmall,
                                color = com.example.ui.theme.IosTextSecondary,
                                fontSize = 11.sp
                            )
                            suggestedEmojis.forEach { emoji ->
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color(0xFF2B1934),
                                    modifier = Modifier.clickable {
                                        messageText = if (messageText.endsWith(" ")) "$messageText$emoji " else "$messageText $emoji "
                                    }
                                ) {
                                    Text(
                                        text = emoji,
                                        fontSize = 18.sp,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Normal Composer
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Emoji Panel Button
                        IconButton(
                            onClick = { showEmojiPanel = !showEmojiPanel },
                            modifier = Modifier.size(40.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Mood,
                                contentDescription = "رموز تعبيرية",
                                tint = if (showEmojiPanel) com.example.ui.theme.IosPrimaryTint else com.example.ui.theme.IosAccentGold,
                                modifier = Modifier.size(26.dp)
                            )
                        }

                        // Message Input (iOS-style pill input)
                        TextField(
                            value = messageText,
                            onValueChange = { messageText = it },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("chat_input_field"),
                            placeholder = {
                                Text(
                                    text = "اكتب لحبيبك رسالة...",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color.White.copy(alpha = 0.45f)
                                )
                            },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color(0xFF1E1424),
                                unfocusedContainerColor = Color(0xFF1E1424),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            ),
                            shape = RoundedCornerShape(22.dp),
                            maxLines = 4
                        )

                        Spacer(modifier = Modifier.width(6.dp))

                        if (messageText.isNotBlank()) {
                            // Send Text Message
                            IconButton(
                                onClick = {
                                    val textToSend = messageText
                                    val reply = replyingToMessage
                                    messageText = ""
                                    replyingToMessage = null
                                    viewModel.sendMessage(textToSend, reply)
                                    scope.launch {
                                        listState.animateScrollToItem(0)
                                    }
                                },
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(com.example.ui.theme.IosPrimaryTint)
                                    .testTag("send_message_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Send,
                                    contentDescription = "إرسال",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        } else {
                            // Record Voice Note
                            IconButton(
                                onClick = {
                                    val micPermission = ContextCompat.checkSelfPermission(
                                        context, Manifest.permission.RECORD_AUDIO
                                    ) == PackageManager.PERMISSION_GRANTED
                                    if (!micPermission) {
                                        callPermissionsLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
                                    } else {
                                        val file = viewModel.audioRecorderHelper.startRecording()
                                        if (file != null) {
                                            isRecordingAudio = true
                                        } else {
                                            Toast.makeText(context, "تعذر بدء تسجيل الصوت", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF24152A))
                                    .testTag("record_voice_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = "تسجيل صوتي",
                                    tint = com.example.ui.theme.IosAccentGold,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }

                    // Emoji Drawer Tray
                    AnimatedVisibility(
                        visible = showEmojiPanel,
                        enter = fadeIn(),
                        exit = fadeOut()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF130919))
                                .padding(vertical = 8.dp)
                        ) {
                            Text(
                                text = "رموز ومشاعر سريعة ❤️",
                                style = MaterialTheme.typography.labelSmall,
                                color = com.example.ui.theme.IosAccentGold,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                            )
                            LazyRow(
                                modifier = Modifier.fillMaxWidth(),
                                contentPadding = PaddingValues(horizontal = 12.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(QUICK_EMOJIS) { emoji ->
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(CircleShape)
                                            .background(Color(0x22FFFFFF))
                                            .clickable {
                                                messageText += emoji
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(text = emoji, fontSize = 22.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (loveLetters.isEmpty()) {
                // Empty state
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "بداية حديثكما العذب 💌",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "أرسل أول كلمة لحبيبك لتبدأ حكايتكما الخالدة...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = RoseGold
                    )
                }
            } else {
                // Chat message bubbles (reverse order: newest at bottom)
                LazyColumn(
                    state = listState,
                    reverseLayout = true,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp)
                ) {
                    itemsIndexed(
                        items = loveLetters,
                        key = { _, it -> it.firestoreId.ifBlank { it.dateMillis.toString() } }
                    ) { index, letter ->
                        val isFromMe = letter.senderUid == currentUid
                        // Sender derives ✓ / ✓✓ from actual recipient read state
                        val isSeenByRecipient = isFromMe && (letter.isRead || (partnerLastReadAt >= letter.dateMillis))

                        val resolvedSenderName = if (isFromMe) {
                            user?.name ?: "أنا"
                        } else {
                            partnerName
                        }

                        MessageBubbleItem(
                            letter = letter,
                            isFromMe = isFromMe,
                            isSeen = isSeenByRecipient,
                            resolvedSenderName = resolvedSenderName,
                            onReply = { replyingToMessage = letter },
                            onEdit = { editingMessage = letter },
                            onDelete = { viewModel.deleteMessage(letter.firestoreId) },
                            onToggleReaction = { emoji ->
                                viewModel.toggleMessageReaction(letter.firestoreId, emoji)
                            }
                        )

                        // Date Separator between days (older item is index + 1 in reverse layout)
                        val olderLetter = loveLetters.getOrNull(index + 1)
                        val shouldShowDate = olderLetter == null ||
                            formatChatDateSeparator(letter.dateMillis) != formatChatDateSeparator(olderLetter.dateMillis)

                        if (shouldShowDate) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = Color.White.copy(alpha = 0.12f),
                                    border = androidx.compose.foundation.BorderStroke(0.5.dp, Color.White.copy(alpha = 0.12f))
                                ) {
                                    Text(
                                        text = formatChatDateSeparator(letter.dateMillis),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White.copy(alpha = 0.9f),
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        } else {
                            Spacer(modifier = Modifier.height(6.dp))
                        }
                    }
                }
            }
        }
    }

    // Edit message dialog
    if (editingMessage != null) {
        var editText by remember { mutableStateOf(editingMessage!!.message) }
        AlertDialog(
            onDismissRequest = { editingMessage = null },
            title = { Text("تعديل الرسالة", color = Color.White) },
            text = {
                OutlinedTextField(
                    value = editText,
                    onValueChange = { editText = it },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val toEdit = editingMessage!!
                    editingMessage = null
                    if (editText.isNotBlank()) {
                        viewModel.editMessage(toEdit.firestoreId, editText)
                    }
                }) {
                    Text("حفظ التعديل", color = CrimsonPrimary)
                }
            },
            dismissButton = {
                TextButton(onClick = { editingMessage = null }) {
                    Text("إلغاء", color = Color.White.copy(alpha = 0.7f))
                }
            },
            containerColor = ModernDarkSurface
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MessageBubbleItem(
    letter: LoveLetterEntity,
    isFromMe: Boolean,
    isSeen: Boolean,
    resolvedSenderName: String,
    onReply: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onToggleReaction: (String) -> Unit
) {
    val context = LocalContext.current
    var showMenu by remember { mutableStateOf(false) }
    var showReactionPicker by remember { mutableStateOf(false) }

    val bubbleColor = if (isFromMe) CrimsonPrimary else Color(0xFF250E20)
    val alignment = if (isFromMe) Alignment.End else Alignment.Start
    val bubbleShape = if (isFromMe) {
        RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = 18.dp, bottomEnd = 4.dp)
    } else {
        RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = 4.dp, bottomEnd = 18.dp)
    }

    val timeString = remember(letter.dateMillis) {
        SimpleDateFormat("h:mm a", Locale("ar")).format(Date(letter.dateMillis))
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp),
        horizontalAlignment = alignment
    ) {
        // Long Press Reaction Bar Popover
        AnimatedVisibility(
            visible = showReactionPicker,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Surface(
                shape = RoundedCornerShape(26.dp),
                color = Color(0xFF1E1424),
                border = androidx.compose.foundation.BorderStroke(0.6.dp, Color(0x33FFFFFF)),
                shadowElevation = 10.dp,
                modifier = Modifier.padding(bottom = 6.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    REACTION_EMOJIS.forEach { emoji ->
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .clickable {
                                    showReactionPicker = false
                                    onToggleReaction(emoji)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = emoji, fontSize = 21.sp)
                        }
                    }
                }
            }
        }

        // Bubble Container
        Box {
            Box(
                modifier = Modifier
                    .widthIn(max = 290.dp)
                    .clip(bubbleShape)
                    .then(
                        if (isFromMe) {
                            Modifier.background(com.example.ui.theme.IosPrimaryGradient)
                        } else {
                            Modifier
                                .background(com.example.ui.theme.IosCardSurface)
                                .border(
                                    width = 0.6.dp,
                                    color = com.example.ui.theme.IosCardBorder,
                                    shape = bubbleShape
                                )
                        }
                    )
                    .combinedClickable(
                        onClick = {},
                        onLongClick = {
                            showReactionPicker = true
                            showMenu = true
                        }
                    )
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    // Reply preview inside bubble
                    if (!letter.replyToText.isNullOrBlank()) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color.Black.copy(alpha = 0.25f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 6.dp)
                        ) {
                            Column(modifier = Modifier.padding(6.dp)) {
                                Text(
                                    text = letter.replyToSenderName ?: "الحبيب",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isFromMe) Color.White else com.example.ui.theme.IosAccentGold
                                )
                                Text(
                                    text = letter.replyToText,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White.copy(alpha = 0.85f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    // Content: Text or Voice Note
                    if (letter.mediaType == "voice" && letter.mediaUrl.isNotBlank()) {
                        VoiceNoteBubble(
                            mediaUrl = letter.mediaUrl,
                            durationSeconds = letter.durationSeconds,
                            isFromMe = isFromMe
                        )
                    } else {
                        Text(
                            text = letter.message,
                            style = MaterialTheme.typography.bodyLarge,
                            color = Color.White
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Bottom info: Time, edited tag, read receipt
                    Row(
                        modifier = Modifier.align(Alignment.End),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (letter.isEdited) {
                            Text(
                                text = "مُعدّلة",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White.copy(alpha = 0.65f),
                                fontSize = 10.sp
                            )
                        }
                        Text(
                            text = timeString,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.65f),
                            fontSize = 11.sp
                        )

                        // Read receipt checkmarks: ✓ vs ✓✓
                        if (isFromMe) {
                            Icon(
                                imageVector = if (isSeen) Icons.Default.DoneAll else Icons.Default.Done,
                                contentDescription = if (isSeen) "تمت المشاهدة" else "تم الإرسال",
                                tint = if (isSeen) com.example.ui.theme.IosAccentGold else Color.White.copy(alpha = 0.6f),
                                modifier = Modifier.size(15.dp)
                            )
                        }
                    }
                }
            }

            // Dropdown Menu for options
            DropdownMenu(
                expanded = showMenu,
                onDismissRequest = { showMenu = false }
            ) {
                DropdownMenuItem(
                    text = { Text("رد") },
                    leadingIcon = { Icon(Icons.Default.Reply, contentDescription = null) },
                    onClick = {
                        showMenu = false
                        onReply()
                    }
                )
                if (isFromMe && letter.mediaType != "voice") {
                    DropdownMenuItem(
                        text = { Text("تعديل") },
                        leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) },
                        onClick = {
                            showMenu = false
                            onEdit()
                        }
                    )
                }
                if (isFromMe) {
                    DropdownMenuItem(
                        text = { Text("حذف الرسالة", color = Color(0xFFE57373)) },
                        leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFE57373)) },
                        onClick = {
                            showMenu = false
                            onDelete()
                        }
                    )
                }
            }
        }

        // Reaction Badge overlay below bubble
        if (letter.reactions.isNotBlank()) {
            val reactionEmojis = letter.reactions.split(",").mapNotNull { entry ->
                entry.substringAfter(":", "").takeIf { it.isNotBlank() }
            }
            if (reactionEmojis.isNotEmpty()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF33142B),
                    shadowElevation = 2.dp,
                    modifier = Modifier.padding(top = 2.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        reactionEmojis.distinct().take(4).forEach { emoji ->
                            Text(text = emoji, fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun VoiceNoteBubble(
    mediaUrl: String,
    durationSeconds: Int,
    isFromMe: Boolean
) {
    val context = LocalContext.current
    val currentPlayingUrl by AudioPlayerHelper.currentlyPlayingUrl.collectAsState()
    val isPlaying by AudioPlayerHelper.isPlaying.collectAsState()
    val isBuffering by AudioPlayerHelper.isBuffering.collectAsState()
    val progressPercent by AudioPlayerHelper.progressPercent.collectAsState()
    val currentSeconds by AudioPlayerHelper.currentPositionSeconds.collectAsState()
    val errorUrl by AudioPlayerHelper.playbackErrorUrl.collectAsState()

    val isThisAudioPlaying = currentPlayingUrl == mediaUrl && isPlaying
    val isThisAudioBuffering = currentPlayingUrl == mediaUrl && isBuffering
    val isThisAudioError = errorUrl == mediaUrl

    val effectiveSeconds = if (currentPlayingUrl == mediaUrl) currentSeconds else durationSeconds
    val timeLabel = "%02d:%02d".format(effectiveSeconds / 60, effectiveSeconds % 60)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Play / Pause / Loading button
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(if (isFromMe) Color.White.copy(alpha = 0.25f) else CrimsonPrimary)
                .clickable {
                    if (isThisAudioPlaying) {
                        AudioPlayerHelper.pauseAudio()
                    } else {
                        AudioPlayerHelper.playAudio(mediaUrl, context)
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            if (isThisAudioBuffering) {
                CircularProgressIndicator(
                    modifier = Modifier.size(22.dp),
                    color = Color.White,
                    strokeWidth = 2.dp
                )
            } else {
                Icon(
                    imageVector = if (isThisAudioPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isThisAudioPlaying) "إيقاف مؤقت" else "تشغيل الصوت",
                    tint = Color.White,
                    modifier = Modifier.size(26.dp)
                )
            }
        }

        Spacer(modifier = Modifier.width(10.dp))

        // Audio progress bar & waveform simulation
        Column(modifier = Modifier.weight(1f)) {
            Slider(
                value = if (currentPlayingUrl == mediaUrl) progressPercent else 0f,
                onValueChange = { percent ->
                    if (currentPlayingUrl == mediaUrl) {
                        AudioPlayerHelper.seekTo(percent)
                    } else {
                        AudioPlayerHelper.playAudio(mediaUrl, context)
                        AudioPlayerHelper.seekTo(percent)
                    }
                },
                colors = SliderDefaults.colors(
                    thumbColor = Color.White,
                    activeTrackColor = if (isFromMe) Color.White else CrimsonPrimary,
                    inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                ),
                modifier = Modifier.height(24.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (isThisAudioError) "تعذر التشغيل" else timeLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isThisAudioError) Color(0xFFFF8A80) else Color.White.copy(alpha = 0.8f)
                )
                Text(
                    text = "رسالة صوتية 🎙️",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.6f)
                )
            }
        }
    }
}
