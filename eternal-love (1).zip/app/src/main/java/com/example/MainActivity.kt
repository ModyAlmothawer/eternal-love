package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.example.data.local.LoveDatabase
import com.example.data.repository.LoveRepository
import com.example.ui.screens.CelebrationScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.MainAppContainer
import com.example.ui.screens.RegisterScreen
import com.example.ui.screens.RelationshipSetupScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.WelcomeScreen
import com.example.ui.theme.EternalLoveTheme
import com.example.ui.viewmodel.AuthScreenState
import com.example.ui.viewmodel.AuthViewModel
import com.example.ui.viewmodel.AuthViewModelFactory
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.MainViewModelFactory

class MainActivity : ComponentActivity() {

    private lateinit var repository: LoveRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = LoveDatabase.getDatabase(applicationContext)
        repository = LoveRepository(database.loveDao(), applicationContext)

        val authViewModel: AuthViewModel by viewModels {
            AuthViewModelFactory(repository)
        }

        val mainViewModel: MainViewModel by viewModels {
            MainViewModelFactory(repository)
        }

        setContent {
            val isDark by repository.isDarkMode.collectAsState()
            val currentLanguage by repository.currentLanguage.collectAsState()

            val isRtl = currentLanguage == "ar"
            val layoutDirection = if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr

            CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
                EternalLoveTheme(darkTheme = isDark) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        EternalLoveApp(
                            authViewModel = authViewModel,
                            mainViewModel = mainViewModel
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun EternalLoveApp(
    authViewModel: AuthViewModel,
    mainViewModel: MainViewModel
) {
    val authScreenState by authViewModel.screenState.collectAsState()
    val isLoading by authViewModel.isLoading.collectAsState()
    val errorMessage by authViewModel.errorMessage.collectAsState()
    val successMessage by authViewModel.successMessage.collectAsState()
    val generatedCode by authViewModel.generatedCode.collectAsState()
    val currentUser by authViewModel.currentUser.collectAsState()
    val currentRelationship by authViewModel.currentRelationship.collectAsState()
    val currentLanguage by authViewModel.currentLanguage.collectAsState()
    val showForgotPasswordDialog by authViewModel.showForgotPasswordDialog.collectAsState()

    AnimatedContent(
        targetState = authScreenState,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "auth_screen_transition"
    ) { screen ->
        when (screen) {
            AuthScreenState.Splash -> {
                SplashScreen()
            }
            AuthScreenState.Welcome -> {
                WelcomeScreen(
                    onGetStarted = { authViewModel.navigateTo(AuthScreenState.Register) },
                    onLogin = { authViewModel.navigateTo(AuthScreenState.Login) },
                    currentLanguage = currentLanguage,
                    onLanguageChange = { authViewModel.setLanguage(it) }
                )
            }
            AuthScreenState.Login -> {
                LoginScreen(
                    onLogin = { email, pass ->
                        authViewModel.login(email, pass)
                    },
                    onNavigateToRegister = {
                        authViewModel.navigateTo(AuthScreenState.Register)
                    },
                    onForgotPassword = { email ->
                        authViewModel.sendPasswordReset(email)
                    },
                    isLoading = isLoading,
                    errorMessage = errorMessage,
                    successMessage = successMessage,
                    showForgotDialog = showForgotPasswordDialog,
                    onShowForgotDialog = { authViewModel.showForgotPassword(it) }
                )
            }
            AuthScreenState.Register -> {
                RegisterScreen(
                    onRegister = { name, email, pass, confirmPass ->
                        authViewModel.register(name, email, pass, confirmPass)
                    },
                    onNavigateToLogin = {
                        authViewModel.navigateTo(AuthScreenState.Login)
                    },
                    isLoading = isLoading,
                    errorMessage = errorMessage
                )
            }
            AuthScreenState.SetupRelationship -> {
                RelationshipSetupScreen(
                    onCreateRelationship = { partnerName, startDateMillis ->
                        authViewModel.createRelationship(partnerName, startDateMillis)
                    },
                    onJoinRelationship = { code ->
                        authViewModel.joinRelationship(code)
                    },
                    isLoading = isLoading,
                    errorMessage = errorMessage,
                    generatedCode = generatedCode
                )
            }
            AuthScreenState.Celebration -> {
                CelebrationScreen(
                    userName = currentUser?.name ?: "You",
                    partnerName = currentUser?.partnerName?.ifBlank { "My Love" }
                        ?: currentRelationship?.partnerName?.ifBlank { "My Love" }
                        ?: "My Love",
                    loveCode = generatedCode ?: currentRelationship?.code,
                    onContinue = {
                        authViewModel.proceedToMain()
                    }
                )
            }
            AuthScreenState.Main -> {
                MainAppContainer(
                    viewModel = mainViewModel,
                    onLogout = {
                        authViewModel.logout()
                    },
                    onDisconnected = {
                        authViewModel.navigateTo(AuthScreenState.SetupRelationship)
                    }
                )
            }
        }
    }
}
