package com.example.data.remote

import android.util.Log
import com.example.data.model.GoalEntity
import com.example.data.model.LoveLetterEntity
import com.example.data.model.MemoryEntity
import com.example.data.model.NoteEntity
import com.example.data.model.RelationshipEntity
import com.example.data.model.UserEntity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.tasks.await
import java.util.UUID

class FirebaseLoveService {
    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    private val firestore: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }

    private var relationshipListener: ListenerRegistration? = null
    private var lettersListener: ListenerRegistration? = null
    private var memoriesListener: ListenerRegistration? = null
    private var goalsListener: ListenerRegistration? = null
    private var notesListener: ListenerRegistration? = null

    val currentFirebaseUser: FirebaseUser?
        get() = try {
            auth.currentUser
        } catch (e: Exception) {
            null
        }

    suspend fun registerWithFirebase(email: String, pass: String): String? {
        return try {
            val authResult = auth.createUserWithEmailAndPassword(email, pass).await()
            authResult.user?.uid
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "FirebaseAuth register error: ${e.message}")
            // Return null or throw so caller knows to use fallback or propagate message
            null
        }
    }

    suspend fun loginWithFirebase(email: String, pass: String): String? {
        return try {
            val authResult = auth.signInWithEmailAndPassword(email, pass).await()
            authResult.user?.uid
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "FirebaseAuth login error: ${e.message}")
            null
        }
    }

    suspend fun sendPasswordResetEmail(email: String): Result<Unit> {
        return try {
            auth.sendPasswordResetEmail(email.trim()).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "sendPasswordResetEmail error: ${e.message}")
            Result.failure(e)
        }
    }

    fun signOut() {
        try {
            stopAllListeners()
            auth.signOut()
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "SignOut error: ${e.message}")
        }
    }

    suspend fun createFirestoreRelationship(
        creatorUid: String,
        creatorName: String,
        partnerName: String,
        startDateMillis: Long,
        code: String
    ): String {
        val relId = UUID.randomUUID().toString().take(12)
        val data = hashMapOf(
            "id" to relId,
            "code" to code,
            "creatorUid" to creatorUid,
            "creatorName" to creatorName,
            "creatorPhoto" to "avatar_1",
            "partnerUid" to "",
            "partnerName" to partnerName,
            "partnerPhoto" to "avatar_2",
            "startDateMillis" to startDateMillis,
            "relationshipName" to "$creatorName ❤️ $partnerName",
            "status" to "pending",
            "createdAtMillis" to System.currentTimeMillis(),
            "updatedAtMillis" to System.currentTimeMillis()
        )

        try {
            firestore.collection("relationships").document(relId).set(data).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error creating relationship on Firestore: ${e.message}")
        }
        return relId
    }

    suspend fun joinFirestoreRelationship(
        code: String,
        partnerUid: String,
        partnerName: String
    ): Pair<String, Map<String, Any?>>? {
        return try {
            val querySnapshot = firestore.collection("relationships")
                .whereEqualTo("code", code.trim())
                .limit(1)
                .get()
                .await()

            if (querySnapshot.isEmpty) {
                return null
            }

            val doc = querySnapshot.documents[0]
            val relId = doc.id
            val creatorUid = doc.getString("creatorUid") ?: ""

            if (creatorUid == partnerUid) {
                throw Exception("Cannot join your own code")
            }

            val currentPartnerUid = doc.getString("partnerUid")
            if (!currentPartnerUid.isNullOrBlank() && currentPartnerUid != partnerUid) {
                throw Exception("Relationship is already connected to another partner")
            }

            val updates = mapOf(
                "partnerUid" to partnerUid,
                "partnerName" to partnerName,
                "status" to "connected",
                "updatedAtMillis" to System.currentTimeMillis()
            )

            firestore.collection("relationships").document(relId).update(updates).await()

            Pair(relId, doc.data ?: emptyMap())
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "Error joining relationship: ${e.message}")
            throw e
        }
    }

    fun startRealtimeListeners(
        relationshipId: String,
        onRelationshipUpdate: (RelationshipEntity) -> Unit,
        onLettersUpdate: (List<LoveLetterEntity>) -> Unit,
        onMemoriesUpdate: (List<MemoryEntity>) -> Unit,
        onGoalsUpdate: (List<GoalEntity>) -> Unit,
        onNotesUpdate: (List<NoteEntity>) -> Unit
    ) {
        stopAllListeners()

        try {
            // 1. Relationship Document Listener
            relationshipListener = firestore.collection("relationships")
                .document(relationshipId)
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null || !snapshot.exists()) {
                        return@addSnapshotListener
                    }
                    val entity = RelationshipEntity(
                        firestoreId = snapshot.id,
                        code = snapshot.getString("code") ?: "",
                        creatorId = snapshot.getString("creatorUid") ?: "",
                        creatorName = snapshot.getString("creatorName") ?: "",
                        creatorPhoto = snapshot.getString("creatorPhoto") ?: "avatar_1",
                        partnerId = snapshot.getString("partnerUid"),
                        partnerName = snapshot.getString("partnerName") ?: "",
                        partnerPhoto = snapshot.getString("partnerPhoto") ?: "avatar_2",
                        startDateMillis = snapshot.getLong("startDateMillis") ?: System.currentTimeMillis(),
                        relationshipName = snapshot.getString("relationshipName") ?: "Our Story",
                        status = snapshot.getString("status") ?: "connected",
                        createdAtMillis = snapshot.getLong("createdAtMillis") ?: System.currentTimeMillis()
                    )
                    onRelationshipUpdate(entity)
                }

            // 2. Letters Listener
            lettersListener = firestore.collection("relationships")
                .document(relationshipId)
                .collection("letters")
                .orderBy("dateMillis", Query.Direction.DESCENDING)
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) return@addSnapshotListener
                    val list = snapshot.documents.mapNotNull { doc ->
                        LoveLetterEntity(
                            firestoreId = doc.id,
                            relationshipId = relationshipId,
                            senderUid = doc.getString("senderUid") ?: "",
                            senderName = doc.getString("senderName") ?: "",
                            title = doc.getString("title") ?: "",
                            message = doc.getString("message") ?: "",
                            dateMillis = doc.getLong("dateMillis") ?: System.currentTimeMillis(),
                            isRead = doc.getBoolean("isRead") ?: false,
                            themeColorIndex = (doc.getLong("themeColorIndex") ?: 0L).toInt()
                        )
                    }
                    onLettersUpdate(list)
                }

            // 3. Memories Listener
            memoriesListener = firestore.collection("relationships")
                .document(relationshipId)
                .collection("memories")
                .orderBy("dateMillis", Query.Direction.DESCENDING)
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) return@addSnapshotListener
                    val list = snapshot.documents.mapNotNull { doc ->
                        MemoryEntity(
                            firestoreId = doc.id,
                            relationshipId = relationshipId,
                            title = doc.getString("title") ?: "",
                            description = doc.getString("description") ?: "",
                            dateMillis = doc.getLong("dateMillis") ?: System.currentTimeMillis(),
                            imageUrl = doc.getString("imageUrl") ?: "",
                            imageDrawableName = doc.getString("imageDrawableName") ?: "img_memory_default",
                            location = doc.getString("location") ?: "",
                            createdByName = doc.getString("createdByName") ?: "",
                            createdByUid = doc.getString("createdByUid") ?: ""
                        )
                    }
                    onMemoriesUpdate(list)
                }

            // 4. Goals Listener
            goalsListener = firestore.collection("relationships")
                .document(relationshipId)
                .collection("goals")
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) return@addSnapshotListener
                    val list = snapshot.documents.mapNotNull { doc ->
                        GoalEntity(
                            firestoreId = doc.id,
                            relationshipId = relationshipId,
                            title = doc.getString("title") ?: "",
                            description = doc.getString("description") ?: "",
                            progress = (doc.getLong("progress") ?: 0L).toInt(),
                            isCompleted = doc.getBoolean("isCompleted") ?: false,
                            targetDate = doc.getString("targetDate") ?: "",
                            category = doc.getString("category") ?: "Life & Romance"
                        )
                    }
                    onGoalsUpdate(list)
                }

            // 5. Notes Listener
            notesListener = firestore.collection("relationships")
                .document(relationshipId)
                .collection("notes")
                .orderBy("updatedAtMillis", Query.Direction.DESCENDING)
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) return@addSnapshotListener
                    val list = snapshot.documents.mapNotNull { doc ->
                        NoteEntity(
                            firestoreId = doc.id,
                            relationshipId = relationshipId,
                            title = doc.getString("title") ?: "",
                            content = doc.getString("content") ?: "",
                            category = doc.getString("category") ?: "General",
                            authorName = doc.getString("authorName") ?: "",
                            authorUid = doc.getString("authorUid") ?: "",
                            updatedAtMillis = doc.getLong("updatedAtMillis") ?: System.currentTimeMillis()
                        )
                    }
                    onNotesUpdate(list)
                }

        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Could not start Firestore listeners: ${e.message}")
        }
    }

    suspend fun sendLetterOnline(relId: String, letter: LoveLetterEntity) {
        try {
            val docId = UUID.randomUUID().toString()
            val data = hashMapOf(
                "id" to docId,
                "senderUid" to letter.senderUid,
                "senderName" to letter.senderName,
                "title" to letter.title,
                "message" to letter.message,
                "dateMillis" to letter.dateMillis,
                "isRead" to false,
                "themeColorIndex" to letter.themeColorIndex
            )
            firestore.collection("relationships").document(relId).collection("letters").document(docId).set(data).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error sending letter online: ${e.message}")
        }
    }

    suspend fun addMemoryOnline(relId: String, memory: MemoryEntity) {
        try {
            val docId = UUID.randomUUID().toString()
            val data = hashMapOf(
                "id" to docId,
                "title" to memory.title,
                "description" to memory.description,
                "dateMillis" to memory.dateMillis,
                "imageUrl" to memory.imageUrl,
                "imageDrawableName" to memory.imageDrawableName,
                "location" to memory.location,
                "createdByName" to memory.createdByName,
                "createdByUid" to memory.createdByUid,
                "createdAtMillis" to memory.createdAtMillis
            )
            firestore.collection("relationships").document(relId).collection("memories").document(docId).set(data).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error adding memory online: ${e.message}")
        }
    }

    suspend fun addGoalOnline(relId: String, goal: GoalEntity) {
        try {
            val docId = UUID.randomUUID().toString()
            val data = hashMapOf(
                "id" to docId,
                "title" to goal.title,
                "description" to goal.description,
                "progress" to goal.progress,
                "isCompleted" to goal.isCompleted,
                "targetDate" to goal.targetDate,
                "category" to goal.category
            )
            firestore.collection("relationships").document(relId).collection("goals").document(docId).set(data).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error adding goal online: ${e.message}")
        }
    }

    suspend fun updateGoalOnline(relId: String, goalId: String, progress: Int, isCompleted: Boolean) {
        try {
            val updates = mapOf(
                "progress" to progress,
                "isCompleted" to isCompleted
            )
            firestore.collection("relationships").document(relId).collection("goals").document(goalId).update(updates).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error updating goal online: ${e.message}")
        }
    }

    suspend fun addNoteOnline(relId: String, note: NoteEntity) {
        try {
            val docId = UUID.randomUUID().toString()
            val data = hashMapOf(
                "id" to docId,
                "title" to note.title,
                "content" to note.content,
                "category" to note.category,
                "authorName" to note.authorName,
                "authorUid" to note.authorUid,
                "updatedAtMillis" to note.updatedAtMillis
            )
            firestore.collection("relationships").document(relId).collection("notes").document(docId).set(data).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error adding note online: ${e.message}")
        }
    }

    suspend fun updateRelationshipDetailsOnline(relId: String, name: String, startDateMillis: Long) {
        try {
            val updates = mapOf(
                "relationshipName" to name,
                "startDateMillis" to startDateMillis,
                "updatedAtMillis" to System.currentTimeMillis()
            )
            firestore.collection("relationships").document(relId).update(updates).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error updating relationship online: ${e.message}")
        }
    }

    fun stopAllListeners() {
        relationshipListener?.remove()
        relationshipListener = null
        lettersListener?.remove()
        lettersListener = null
        memoriesListener?.remove()
        memoriesListener = null
        goalsListener?.remove()
        goalsListener = null
        notesListener?.remove()
        notesListener = null
    }
}
