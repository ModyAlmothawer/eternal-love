package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.FloatingHeartsBackground
import com.example.ui.components.GlassCard
import com.example.ui.components.RomanticAvatar
import com.example.ui.components.RomanticButton
import com.example.ui.components.RomanticOutlinedButton
import com.example.ui.components.RomanticTextField
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.RomanticGradient
import com.example.ui.theme.RoseGold
import com.example.ui.theme.SoftBlush
import com.example.ui.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ProfileAndSettingsScreen(
    viewModel: MainViewModel,
    onLogout: () -> Unit,
    onDisconnected: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentUser by viewModel.currentUser.collectAsState()
    val relationship by viewModel.currentRelationship.collectAsState()
    val isDark by viewModel.isDarkMode.collectAsState()
    val currentLang by viewModel.currentLanguage.collectAsState()

    val isEditingProfile by viewModel.isEditingProfile.collectAsState()
    val isEditingRelationship by viewModel.isEditingRelationship.collectAsState()
    val showDisconnectConfirmation by viewModel.showDisconnectConfirmation.collectAsState()

    val fallbackPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.uploadProfileImage(uri)
        }
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.uploadProfileImage(uri)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(RomanticGradient)
            .testTag("profile_screen")
    ) {
        FloatingHeartsBackground(heartCount = 8)

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = stringResource(R.string.tab_profile),
                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                    color = SoftBlush
                )
            }

            // User Profile Card
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(contentAlignment = Alignment.BottomEnd) {
                            RomanticAvatar(
                                photoUrl = currentUser?.photoUrl ?: "",
                                avatarRes = currentUser?.avatarRes ?: "avatar_1",
                                size = 84.dp,
                                borderColor = CrimsonPrimary,
                                borderWidth = 3.dp
                            )

                            // Pick Photo Button (No crash with safe ImageUtils compression)
                            Box(
                                modifier = Modifier
                                    .size(30.dp)
                                    .clip(CircleShape)
                                    .background(CrimsonPrimary)
                                    .clickable {
                                        try {
                                            photoPickerLauncher.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        } catch (e: Exception) {
                                            try {
                                                fallbackPickerLauncher.launch("image/*")
                                            } catch (_: Exception) {}
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CameraAlt,
                                    contentDescription = "Upload photo",
                                    tint = SoftBlush,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = currentUser?.name ?: stringResource(R.string.you),
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = SoftBlush
                        )

                        Text(
                            text = currentUser?.email ?: "",
                            style = MaterialTheme.typography.bodySmall,
                            color = RoseGold
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        RomanticOutlinedButton(
                            text = stringResource(R.string.edit_profile),
                            onClick = { viewModel.isEditingProfile.value = true },
                            icon = Icons.Default.Edit,
                            testTag = "btn_edit_profile"
                        )
                    }
                }
            }

            // Relationship Info Card
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = stringResource(R.string.relationship_details_title),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = SoftBlush
                            )

                            IconButton(
                                onClick = { viewModel.isEditingRelationship.value = true },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Edit Relationship",
                                    tint = RoseGold,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        // Code Section
                        val code = relationship?.code?.takeIf { it.isNotBlank() } ?: currentUser?.relationshipCode?.takeIf { it.isNotBlank() }
                        if (!code.isNullOrBlank()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(Color(0x332B1020))
                                    .border(1.dp, Color(0x33FF4D79), RoundedCornerShape(14.dp))
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = stringResource(R.string.your_love_code),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = RoseGold
                                    )
                                    Text(
                                        text = code,
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            letterSpacing = 2.sp
                                        ),
                                        color = SoftBlush
                                    )
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    IconButton(
                                        onClick = {
                                            try {
                                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                                val clip = ClipData.newPlainText("Love Code", code)
                                                clipboard.setPrimaryClip(clip)
                                                Toast.makeText(context, context.getString(R.string.code_copied), Toast.LENGTH_SHORT).show()
                                            } catch (e: Exception) {
                                                Log.w("ProfileScreen", "Failed to copy code: ${e.message}")
                                            }
                                        },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ContentCopy,
                                            contentDescription = "Copy code",
                                            tint = SoftBlush,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }

                                    IconButton(
                                        onClick = {
                                            try {
                                                val sendIntent: Intent = Intent().apply {
                                                    action = Intent.ACTION_SEND
                                                    putExtra(Intent.EXTRA_TEXT, context.getString(R.string.share_code_text, code))
                                                    type = "text/plain"
                                                }
                                                val chooser = Intent.createChooser(sendIntent, context.getString(R.string.share_chooser_title)).apply {
                                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                                }
                                                context.startActivity(chooser)
                                            } catch (e: Exception) {
                                                Log.w("ProfileScreen", "Failed to share code: ${e.message}")
                                            }
                                        },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Share,
                                            contentDescription = "Share code",
                                            tint = SoftBlush,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Settings & Preferences Card
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.settings_title),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = SoftBlush
                        )

                        // Language Toggle
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0x332B1020))
                                .clickable {
                                    val nextLang = if (currentLang == "ar") "en" else "ar"
                                    viewModel.setLanguage(nextLang)
                                }
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Language,
                                    contentDescription = "Language",
                                    tint = RoseGold,
                                    modifier = Modifier.size(22.dp)
                                )
                                Text(
                                    text = stringResource(R.string.language),
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                                    color = SoftBlush
                                )
                            }
                            Text(
                                text = if (currentLang == "ar") "العربية (مصر)" else "English",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                color = CrimsonPrimary
                            )
                        }

                        // Romantic Dark Theme (Permanent)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0x332B1020))
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DarkMode,
                                    contentDescription = "Dark Mode",
                                    tint = RoseGold,
                                    modifier = Modifier.size(22.dp)
                                )
                                Text(
                                    text = stringResource(R.string.romantic_dark_theme),
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                                    color = SoftBlush
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(CrimsonPrimary.copy(alpha = 0.2f))
                                    .border(1.dp, CrimsonPrimary.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "مفعل دائماً ✨",
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                    color = SoftBlush
                                )
                            }
                        }
                    }
                }
            }

            // Danger & Account Actions
            item {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    RomanticOutlinedButton(
                        text = stringResource(R.string.disconnect_relationship),
                        onClick = { viewModel.showDisconnectConfirmation.value = true },
                        icon = Icons.Default.LinkOff,
                        borderColor = MaterialTheme.colorScheme.error.copy(alpha = 0.5f),
                        textColor = MaterialTheme.colorScheme.error,
                        testTag = "btn_disconnect_relationship"
                    )

                    RomanticOutlinedButton(
                        text = stringResource(R.string.logout),
                        onClick = onLogout,
                        icon = Icons.Default.ExitToApp,
                        testTag = "btn_logout"
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }

        // Edit Profile Dialog
        if (isEditingProfile) {
            EditProfileDialog(
                currentName = currentUser?.name ?: "",
                currentAvatar = currentUser?.avatarRes ?: "avatar_1",
                onDismiss = { viewModel.isEditingProfile.value = false },
                onSave = { name, avatar ->
                    viewModel.updateProfile(name, avatar)
                }
            )
        }

        // Edit Relationship Dialog
        if (isEditingRelationship) {
            EditRelationshipDialog(
                currentName = relationship?.relationshipName ?: "قصتنا",
                currentStartDateMillis = if ((relationship?.startDateMillis ?: 0L) > 0L) (relationship?.startDateMillis ?: System.currentTimeMillis()) else System.currentTimeMillis(),
                onDismiss = { viewModel.isEditingRelationship.value = false },
                onSave = { name, startMillis ->
                    viewModel.updateRelationship(name, startMillis)
                }
            )
        }

        // Disconnect Confirmation Dialog
        if (showDisconnectConfirmation) {
            AlertDialog(
                onDismissRequest = { viewModel.showDisconnectConfirmation.value = false },
                title = {
                    Text(
                        text = stringResource(R.string.disconnect_title),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = SoftBlush
                    )
                },
                text = {
                    Text(
                        text = stringResource(R.string.disconnect_warning),
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            viewModel.disconnectRelationship(onDisconnected)
                        }
                    ) {
                        Text(
                            text = stringResource(R.string.disconnect_relationship),
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                dismissButton = {
                    TextButton(onClick = { viewModel.showDisconnectConfirmation.value = false }) {
                        Text(text = stringResource(R.string.cancel), color = RoseGold)
                    }
                },
                containerColor = Color(0xFF200918),
                shape = RoundedCornerShape(20.dp)
            )
        }
    }
}

@Composable
fun EditProfileDialog(
    currentName: String,
    currentAvatar: String,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var name by remember { mutableStateOf(currentName) }
    var selectedAvatar by remember { mutableStateOf(currentAvatar) }

    val avatars = listOf("avatar_1", "avatar_2", "avatar_3", "avatar_4")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = stringResource(R.string.edit_profile),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = SoftBlush
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                RomanticTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = stringResource(R.string.name),
                    placeholder = stringResource(R.string.name_placeholder),
                    testTag = "input_edit_name"
                )

                Text(
                    text = stringResource(R.string.choose_avatar),
                    style = MaterialTheme.typography.bodySmall,
                    color = RoseGold
                )

                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(avatars) { av ->
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .border(
                                    2.dp,
                                    if (selectedAvatar == av) CrimsonPrimary else Color.Transparent,
                                    CircleShape
                                )
                                .clickable { selectedAvatar = av }
                                .padding(4.dp)
                        ) {
                            RomanticAvatar(
                                photoUrl = "",
                                avatarRes = av,
                                size = 52.dp
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            RomanticButton(
                text = stringResource(R.string.save),
                onClick = { onSave(name.trim(), selectedAvatar) },
                modifier = Modifier.padding(horizontal = 8.dp),
                testTag = "btn_save_edit_profile"
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(text = stringResource(R.string.cancel), color = RoseGold)
            }
        },
        containerColor = Color(0xFF200918),
        shape = RoundedCornerShape(22.dp)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditRelationshipDialog(
    currentName: String,
    currentStartDateMillis: Long,
    onDismiss: () -> Unit,
    onSave: (String, Long) -> Unit
) {
    var name by remember { mutableStateOf(currentName) }
    var selectedDateMillis by remember { mutableLongStateOf(currentStartDateMillis) }
    var showDatePicker by remember { mutableStateOf(false) }

    val datePickerState = rememberDatePickerState(
        initialSelectedDateMillis = selectedDateMillis
    )

    val dateFormat = remember { SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()) }
    val formattedDate = remember(selectedDateMillis) { dateFormat.format(Date(selectedDateMillis)) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = stringResource(R.string.edit_relationship_title),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = SoftBlush
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                RomanticTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = stringResource(R.string.relationship_name_label),
                    placeholder = "قصتنا",
                    testTag = "input_edit_rel_name"
                )

                // Date Picker field
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0x332B1020))
                        .border(1.dp, Color(0x33FF4D79), RoundedCornerShape(14.dp))
                        .clickable { showDatePicker = true }
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CalendarMonth,
                            contentDescription = null,
                            tint = CrimsonPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = formattedDate,
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            color = SoftBlush
                        )
                    }
                    Text(
                        text = stringResource(R.string.edit),
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                        color = RoseGold
                    )
                }
            }
        },
        confirmButton = {
            RomanticButton(
                text = stringResource(R.string.save),
                onClick = { onSave(name.trim(), selectedDateMillis) },
                modifier = Modifier.padding(horizontal = 8.dp),
                testTag = "btn_save_edit_relationship"
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(text = stringResource(R.string.cancel), color = RoseGold)
            }
        },
        containerColor = Color(0xFF200918),
        shape = RoundedCornerShape(22.dp)
    )

    if (showDatePicker) {
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        datePickerState.selectedDateMillis?.let {
                            selectedDateMillis = it
                        }
                        showDatePicker = false
                    }
                ) {
                    Text(text = stringResource(R.string.save), color = CrimsonPrimary, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) {
                    Text(text = stringResource(R.string.cancel), color = RoseGold)
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }
}
