package com.example.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.AchievementItem
import com.example.data.model.GoalEntity
import com.example.data.model.LoveLetterEntity
import com.example.data.model.MemoryEntity
import com.example.data.model.NoteEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.RelationshipEntity
import com.example.data.model.SpecialDateEntity
import com.example.data.model.UserEntity
import com.example.data.repository.LoveRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.TimeZone

data class RelationshipDuration(
    val years: Long = 0,
    val months: Long = 0,
    val days: Long = 0,
    val hours: Long = 0,
    val minutes: Long = 0,
    val seconds: Long = 0,
    val totalDays: Long = 0,
    val totalMonths: Long = 0,
    val totalHours: Long = 0
)

enum class MainTab {
    HOME,
    MEMORIES,
    LETTERS, // Chat / الدردشة
    GOALS,
    PROFILE
}

class MainViewModel(
    private val repository: LoveRepository
) : ViewModel() {

    val isDarkMode: StateFlow<Boolean> = repository.isDarkMode
    val currentLanguage: StateFlow<String> = repository.currentLanguage

    val currentUser: StateFlow<UserEntity?> = repository.currentUserFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val currentRelationship: StateFlow<RelationshipEntity?> = repository.currentRelationshipFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _currentTab = MutableStateFlow(MainTab.HOME)
    val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

    // Real-time dynamic counter ticker
    private val _relationshipDuration = MutableStateFlow(RelationshipDuration())
    val relationshipDuration: StateFlow<RelationshipDuration> = _relationshipDuration.asStateFlow()

    // Active sub-screen/dialog states
    val selectedMemory = MutableStateFlow<MemoryEntity?>(null)
    val selectedLoveLetter = MutableStateFlow<LoveLetterEntity?>(null)
    val isWritingLetter = MutableStateFlow(false)
    val isAddingMemory = MutableStateFlow(false)
    val isAddingNote = MutableStateFlow(false)
    val isAddingGoal = MutableStateFlow(false)
    val isAddingSpecialDate = MutableStateFlow(false)
    val isViewingNotes = MutableStateFlow(false)
    val isViewingSpecialDates = MutableStateFlow(false)
    val isViewingNotifications = MutableStateFlow(false)
    val isViewingStory = MutableStateFlow(false)
    val isEditingProfile = MutableStateFlow(false)
    val isEditingRelationship = MutableStateFlow(false)
    val showDisconnectConfirmation = MutableStateFlow(false)
    val isUpdatingStatus = MutableStateFlow(false)

    // Data streams based on connected relationship
    val memories: StateFlow<List<MemoryEntity>> = currentRelationship.flatMapLatest { rel ->
        val relId = rel?.firestoreId?.takeIf { it.isNotBlank() } ?: rel?.id?.toString()
        if (relId != null) repository.getMemories(relId) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val loveLetters: StateFlow<List<LoveLetterEntity>> = currentRelationship.flatMapLatest { rel ->
        val relId = rel?.firestoreId?.takeIf { it.isNotBlank() } ?: rel?.id?.toString()
        if (relId != null) repository.getLoveLetters(relId) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notes: StateFlow<List<NoteEntity>> = currentRelationship.flatMapLatest { rel ->
        val relId = rel?.firestoreId?.takeIf { it.isNotBlank() } ?: rel?.id?.toString()
        if (relId != null) repository.getNotes(relId) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val goals: StateFlow<List<GoalEntity>> = currentRelationship.flatMapLatest { rel ->
        val relId = rel?.firestoreId?.takeIf { it.isNotBlank() } ?: rel?.id?.toString()
        if (relId != null) repository.getGoals(relId) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val specialDates: StateFlow<List<SpecialDateEntity>> = currentRelationship.flatMapLatest { rel ->
        val relId = rel?.firestoreId?.takeIf { it.isNotBlank() } ?: rel?.id?.toString()
        if (relId != null) repository.getSpecialDates(relId) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<NotificationEntity>> = currentRelationship.flatMapLatest { rel ->
        val relId = rel?.firestoreId?.takeIf { it.isNotBlank() } ?: rel?.id?.toString()
        if (relId != null) repository.getNotifications(relId) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val achievements: StateFlow<List<AchievementItem>> = combine(
        currentRelationship,
        loveLetters,
        memories,
        goals
    ) { rel, letters, mems, gls ->
        repository.getAchievements(
            relationship = rel,
            memoriesCount = mems.size,
            lettersCount = letters.size,
            goalsDoneCount = gls.count { it.isCompleted }
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Start real-time ticker
        viewModelScope.launch {
            while (isActive) {
                updateDuration()
                delay(1000)
            }
        }
    }

    private fun updateDuration() {
        val rel = currentRelationship.value ?: return
        val startMillis = rel.startDateMillis
        val nowMillis = System.currentTimeMillis()

        if (nowMillis < startMillis) {
            _relationshipDuration.value = RelationshipDuration()
            return
        }

        val startCal = Calendar.getInstance(TimeZone.getDefault()).apply { timeInMillis = startMillis }
        val nowCal = Calendar.getInstance(TimeZone.getDefault()).apply { timeInMillis = nowMillis }

        var years = nowCal.get(Calendar.YEAR) - startCal.get(Calendar.YEAR)
        var months = nowCal.get(Calendar.MONTH) - startCal.get(Calendar.MONTH)
        var days = nowCal.get(Calendar.DAY_OF_MONTH) - startCal.get(Calendar.DAY_OF_MONTH)

        if (days < 0) {
            months -= 1
            val tempCal = Calendar.getInstance().apply {
                timeInMillis = nowMillis
                add(Calendar.MONTH, -1)
            }
            days += tempCal.getActualMaximum(Calendar.DAY_OF_MONTH)
        }

        if (months < 0) {
            years -= 1
            months += 12
        }

        val totalDiffMillis = nowMillis - startMillis
        val totalDays = totalDiffMillis / (1000 * 60 * 60 * 24)
        val totalHours = totalDiffMillis / (1000 * 60 * 60)
        val totalMonths = (years * 12) + months

        val hours = (totalDiffMillis / (1000 * 60 * 60)) % 24
        val minutes = (totalDiffMillis / (1000 * 60)) % 60
        val seconds = (totalDiffMillis / 1000) % 60

        _relationshipDuration.value = RelationshipDuration(
            years = maxOf(0, years.toLong()),
            months = maxOf(0, months.toLong()),
            days = maxOf(0, days.toLong()),
            hours = maxOf(0, hours),
            minutes = maxOf(0, minutes),
            seconds = maxOf(0, seconds),
            totalDays = maxOf(0, totalDays),
            totalMonths = maxOf(0, totalMonths.toLong()),
            totalHours = maxOf(0, totalHours)
        )
    }

    fun selectTab(tab: MainTab) {
        _currentTab.value = tab
    }

    fun toggleDarkMode(enabled: Boolean) {
        viewModelScope.launch {
            repository.setDarkMode(enabled)
        }
    }

    fun setLanguage(lang: String) {
        viewModelScope.launch {
            repository.setLanguage(lang)
        }
    }

    // Daily Mood / Status
    fun updateDailyStatus(status: String, emoji: String) {
        viewModelScope.launch {
            repository.updateDailyStatus(status, emoji)
            isUpdatingStatus.value = false
        }
    }

    fun addMemory(
        title: String,
        description: String,
        dateMillis: Long,
        imageUri: Uri?,
        location: String
    ) {
        val rel = currentRelationship.value ?: return
        val relId = rel.firestoreId.takeIf { it.isNotBlank() } ?: rel.id.toString()
        val user = currentUser.value ?: return
        viewModelScope.launch {
            repository.addMemory(
                relationshipId = relId,
                title = title,
                description = description,
                dateMillis = dateMillis,
                imageUri = imageUri,
                location = location,
                authorName = user.name
            )
            isAddingMemory.value = false
        }
    }

    fun deleteMemory(firestoreId: String) {
        val rel = currentRelationship.value
        val relId = rel?.firestoreId ?: ""
        viewModelScope.launch {
            repository.deleteMemory(firestoreId, relId)
            if (selectedMemory.value?.firestoreId == firestoreId) {
                selectedMemory.value = null
            }
        }
    }

    fun sendLoveLetter(title: String, message: String, themeIndex: Int) {
        val rel = currentRelationship.value ?: return
        val relId = rel.firestoreId.takeIf { it.isNotBlank() } ?: rel.id.toString()
        val user = currentUser.value ?: return
        viewModelScope.launch {
            repository.sendLoveLetter(
                relationshipId = relId,
                senderName = user.name,
                title = title,
                message = message,
                themeIndex = themeIndex
            )
            isWritingLetter.value = false
        }
    }

    fun openLoveLetter(letter: LoveLetterEntity) {
        selectedLoveLetter.value = letter
        viewModelScope.launch {
            repository.markLoveLetterAsRead(letter.firestoreId)
        }
    }

    fun deleteLoveLetter(firestoreId: String) {
        val rel = currentRelationship.value
        val relId = rel?.firestoreId ?: ""
        viewModelScope.launch {
            repository.deleteLoveLetter(firestoreId, relId)
            if (selectedLoveLetter.value?.firestoreId == firestoreId) {
                selectedLoveLetter.value = null
            }
        }
    }

    fun addNote(title: String, content: String, category: String) {
        val rel = currentRelationship.value ?: return
        val relId = rel.firestoreId.takeIf { it.isNotBlank() } ?: rel.id.toString()
        val user = currentUser.value ?: return
        viewModelScope.launch {
            repository.addNote(
                relationshipId = relId,
                title = title,
                content = content,
                category = category,
                authorName = user.name
            )
            isAddingNote.value = false
        }
    }

    fun deleteNote(firestoreId: String) {
        val rel = currentRelationship.value
        val relId = rel?.firestoreId ?: ""
        viewModelScope.launch {
            repository.deleteNote(firestoreId, relId)
        }
    }

    fun addGoal(title: String, description: String, targetDate: String, category: String) {
        val rel = currentRelationship.value ?: return
        val relId = rel.firestoreId.takeIf { it.isNotBlank() } ?: rel.id.toString()
        viewModelScope.launch {
            repository.addGoal(
                relationshipId = relId,
                title = title,
                description = description,
                targetDate = targetDate,
                category = category
            )
            isAddingGoal.value = false
        }
    }

    fun updateGoalProgress(goal: GoalEntity, progress: Int, completed: Boolean) {
        viewModelScope.launch {
            repository.updateGoalProgress(goal, progress, completed)
        }
    }

    fun deleteGoal(firestoreId: String) {
        val rel = currentRelationship.value
        val relId = rel?.firestoreId ?: ""
        viewModelScope.launch {
            repository.deleteGoal(firestoreId, relId)
        }
    }

    fun addSpecialDate(title: String, dateMillis: Long, type: String) {
        val rel = currentRelationship.value ?: return
        val relId = rel.firestoreId.takeIf { it.isNotBlank() } ?: rel.id.toString()
        viewModelScope.launch {
            repository.addSpecialDate(
                relationshipId = relId,
                title = title,
                dateMillis = dateMillis,
                type = type,
                iconName = "calendar"
            )
            isAddingSpecialDate.value = false
        }
    }

    fun deleteSpecialDate(id: Long) {
        viewModelScope.launch {
            repository.deleteSpecialDate(id)
        }
    }

    fun updateProfile(name: String, avatarRes: String, photoUrl: String = "") {
        viewModelScope.launch {
            val currentPhoto = currentUser.value?.photoUrl ?: ""
            val finalPhotoUrl = if (photoUrl.isNotBlank()) photoUrl else currentPhoto
            repository.updateUserProfile(name, avatarRes, finalPhotoUrl)
            isEditingProfile.value = false
        }
    }

    fun uploadProfileImage(uri: Uri) {
        viewModelScope.launch {
            repository.uploadProfileImageUri(uri)
        }
    }

    fun updateRelationship(name: String, startDateMillis: Long) {
        viewModelScope.launch {
            repository.updateRelationshipDetails(name, startDateMillis)
            isEditingRelationship.value = false
        }
    }

    fun disconnectRelationship(onDisconnected: () -> Unit) {
        viewModelScope.launch {
            repository.disconnectRelationship()
            showDisconnectConfirmation.value = false
            onDisconnected()
        }
    }
}

class MainViewModelFactory(private val repository: LoveRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return MainViewModel(repository) as T
    }
}
