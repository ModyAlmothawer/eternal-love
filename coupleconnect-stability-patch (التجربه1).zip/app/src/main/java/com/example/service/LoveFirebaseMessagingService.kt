package com.example.service

import android.util.Log
import com.example.util.NotificationHelper
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class LoveFirebaseMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d("LoveFCM", "New FCM token received: $token")
        val currentUid = FirebaseAuth.getInstance().currentUser?.uid
        if (!currentUid.isNullOrBlank()) {
            try {
                FirebaseFirestore.getInstance().collection("users")
                    .document(currentUid)
                    .update("fcmToken", token)
            } catch (e: Exception) {
                Log.w("LoveFCM", "Failed to update FCM token in Firestore: ${e.message}")
            }
        }
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.d("LoveFCM", "Message received from: ${remoteMessage.from}")

        val data = remoteMessage.data
        val senderUid = data["senderUid"] ?: data["senderId"] ?: ""
        val currentUid = FirebaseAuth.getInstance().currentUser?.uid ?: ""

        // Never notify sender of their own action
        if (senderUid.isNotBlank() && currentUid.isNotBlank() && senderUid == currentUid) {
            return
        }

        val type = data["type"] ?: "message"
        val senderName = data["senderName"] ?: "شريك حياتك"
        val title = data["title"] ?: remoteMessage.notification?.title ?: ""
        val body = data["body"] ?: data["message"] ?: remoteMessage.notification?.body ?: ""
        val id = data["id"] ?: data["messageId"] ?: System.currentTimeMillis().toString()

        when (type) {
            "status" -> {
                NotificationHelper.showStatusNotification(
                    context = applicationContext,
                    senderUid = senderUid,
                    currentUid = currentUid,
                    partnerName = senderName,
                    newStatus = body,
                    newEmoji = data["emoji"] ?: "❤️"
                )
            }
            "goal" -> {
                NotificationHelper.showGoalNotification(
                    context = applicationContext,
                    goalId = id,
                    senderUid = senderUid,
                    currentUid = currentUid,
                    partnerName = senderName,
                    goalTitle = title.ifBlank { body }
                )
            }
            "memory" -> {
                NotificationHelper.showMemoryNotification(
                    context = applicationContext,
                    memoryId = id,
                    senderUid = senderUid,
                    currentUid = currentUid,
                    partnerName = senderName,
                    memoryTitle = title.ifBlank { body }
                )
            }
            else -> {
                NotificationHelper.showMessageNotification(
                    context = applicationContext,
                    messageId = id,
                    senderUid = senderUid,
                    currentUid = currentUid,
                    senderName = senderName,
                    title = title,
                    messageText = body
                )
            }
        }
    }
}
