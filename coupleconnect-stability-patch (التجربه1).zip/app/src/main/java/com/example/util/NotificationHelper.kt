package com.example.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.R

object NotificationHelper {
    private const val CHANNEL_ID = "hikaytna_love_messages"
    private const val CHANNEL_NAME = "Любовь Notifications"
    private const val CHANNEL_DESCRIPTION = "Notifications for chat messages, goals, memories, and feelings from your partner"
    private const val NOTIFICATION_ID_BASE = 1000

    private val notifiedItemIds = mutableSetOf<String>()

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, importance).apply {
                description = CHANNEL_DESCRIPTION
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 150, 250)
                enableLights(true)
            }
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            notificationManager?.createNotificationChannel(channel)
        }
    }

    private fun postNotification(
        context: Context,
        notificationId: Int,
        uniqueKey: String,
        senderUid: String,
        currentUid: String,
        title: String,
        body: String
    ) {
        // Never notify for actions performed by current user
        if (senderUid.isNotBlank() && currentUid.isNotBlank() && senderUid == currentUid) {
            return
        }
        // Avoid duplicate notifications
        if (uniqueKey.isNotBlank() && notifiedItemIds.contains(uniqueKey)) {
            return
        }
        if (uniqueKey.isNotBlank()) {
            notifiedItemIds.add(uniqueKey)
        }

        try {
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pendingIntent = PendingIntent.getActivity(
                context,
                notificationId,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)

            val notificationManager = NotificationManagerCompat.from(context)
            if (notificationManager.areNotificationsEnabled()) {
                notificationManager.notify(notificationId, builder.build())
            }
        } catch (e: Exception) {
            Log.w("NotificationHelper", "Could not show notification: ${e.message}")
        }
    }

    fun showMessageNotification(
        context: Context,
        messageId: String,
        senderUid: String,
        currentUid: String,
        senderName: String,
        title: String,
        messageText: String
    ) {
        val displayTitle = if (senderName.isNotBlank()) "رسالة جديدة من $senderName 💬" else "رسالة جديدة في الدردشة 💬"
        val displayBody = messageText.ifBlank { "فتح الدردشة..." }
        postNotification(
            context = context,
            notificationId = NOTIFICATION_ID_BASE + 1,
            uniqueKey = "msg_$messageId",
            senderUid = senderUid,
            currentUid = currentUid,
            title = displayTitle,
            body = displayBody
        )
    }

    fun showStatusNotification(
        context: Context,
        senderUid: String,
        currentUid: String,
        partnerName: String,
        newStatus: String,
        newEmoji: String
    ) {
        if (newStatus.isBlank() && newEmoji.isBlank()) return
        val displayTitle = if (partnerName.isNotBlank()) "إحساس $partnerName النهارده $newEmoji" else "إحساس شريك حياتك $newEmoji"
        val displayBody = if (newStatus.isNotBlank()) newStatus else "شارك إحساسه الجديد معاك"
        val uniqueKey = "status_${senderUid}_${newStatus}_${newEmoji}"
        postNotification(
            context = context,
            notificationId = NOTIFICATION_ID_BASE + 2,
            uniqueKey = uniqueKey,
            senderUid = senderUid,
            currentUid = currentUid,
            title = displayTitle,
            body = displayBody
        )
    }

    fun showGoalNotification(
        context: Context,
        goalId: String,
        senderUid: String,
        currentUid: String,
        partnerName: String,
        goalTitle: String
    ) {
        val displayTitle = if (partnerName.isNotBlank()) "هدف جديد من $partnerName ✨" else "هدف جديد لحبنا ✨"
        val displayBody = goalTitle.ifBlank { "تمت إضافة هدف مشترك جديد" }
        postNotification(
            context = context,
            notificationId = NOTIFICATION_ID_BASE + 3,
            uniqueKey = "goal_$goalId",
            senderUid = senderUid,
            currentUid = currentUid,
            title = displayTitle,
            body = displayBody
        )
    }

    fun showMemoryNotification(
        context: Context,
        memoryId: String,
        senderUid: String,
        currentUid: String,
        partnerName: String,
        memoryTitle: String
    ) {
        val displayTitle = if (partnerName.isNotBlank()) "ذكرى جديدة من $partnerName 📸" else "ذكرى جديدة في حكايتنا 📸"
        val displayBody = memoryTitle.ifBlank { "تمت إضافة صورة وذكرى جميلة" }
        postNotification(
            context = context,
            notificationId = NOTIFICATION_ID_BASE + 4,
            uniqueKey = "memory_$memoryId",
            senderUid = senderUid,
            currentUid = currentUid,
            title = displayTitle,
            body = displayBody
        )
    }
}
