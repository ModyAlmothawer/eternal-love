package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.util.Log
import com.example.data.local.LoveDao
import com.example.data.model.AchievementItem
import com.example.data.model.GoalEntity
import com.example.data.model.LoveLetterEntity
import com.example.data.model.MemoryEntity
import com.example.data.model.NoteEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.RelationshipEntity
import com.example.data.model.SpecialDateEntity
import com.example.data.model.UserEntity
import com.example.data.remote.FirebaseLoveService
import com.example.util.ImageUtils
import com.example.util.NotificationHelper
import com.example.util.WebRtcManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.random.Random

class LoveRepository(
    private val loveDao: LoveDao,
    private val firebaseService: FirebaseLoveService,
    val context: Context
) {
    val webRtcManager: WebRtcManager by lazy { WebRtcManager.getInstance(context) }
    private val prefs: SharedPreferences =
        context.getSharedPreferences("eternal_love_prefs", Context.MODE_PRIVATE)

    private val _currentUserId = MutableStateFlow<Long?>(null)
    val currentUserId: StateFlow<Long?> = _currentUserId.asStateFlow()

    // Always dark romantic theme
    private val _isDarkMode = MutableStateFlow(true)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    private val _isNotificationsEnabled =
        MutableStateFlow(prefs.getBoolean("pref_notifications", true))
    val isNotificationsEnabled: StateFlow<Boolean> = _isNotificationsEnabled.asStateFlow()

    private val _currentLanguage =
        MutableStateFlow(prefs.getString("pref_language", "ar") ?: "ar")
    val currentLanguage: StateFlow<String> = _currentLanguage.asStateFlow()

    private val _partnerIsTyping = MutableStateFlow(false)
    val partnerIsTyping: StateFlow<Boolean> = _partnerIsTyping.asStateFlow()

    private val _incomingCall = MutableStateFlow<com.example.data.model.CallSession?>(null)
    val incomingCall: StateFlow<com.example.data.model.CallSession?> = _incomingCall.asStateFlow()

    private var incomingCallListener: com.google.firebase.firestore.ListenerRegistration? = null
    private var partnerPresenceListener: com.google.firebase.firestore.ListenerRegistration? = null

    fun clearIncomingCall() {
        _incomingCall.value = null
    }

    private val repoScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    init {
        NotificationHelper.createNotificationChannel(context)
        val savedUserId = prefs.getLong("saved_user_id", -1L)
        if (savedUserId != -1L) {
            _currentUserId.value = savedUserId
            repoScope.launch {
                val user = loveDao.getUserById(savedUserId)
                if (user != null && !user.connectedRelationshipId.isNullOrBlank()) {
                    startRealtimeSync(user.connectedRelationshipId, user.firebaseUid)
                }
            }
        }
    }

    val currentUserFlow: Flow<UserEntity?> = _currentUserId.flatMapLatest { id ->
        if (id != null) loveDao.getUserByIdFlow(id) else flowOf(null)
    }

    val currentRelationshipFlow: Flow<RelationshipEntity?> = currentUserFlow.flatMapLatest { user ->
        val firestoreId = user?.connectedRelationshipId
        val localId = user?.localRelationshipId
        if (!firestoreId.isNullOrBlank()) {
            loveDao.getRelationshipByFirestoreIdFlow(firestoreId)
        } else if (localId != null) {
            loveDao.getRelationshipFlow(localId)
        } else {
            flowOf(null)
        }
    }

    // --- Authentication ---

    suspend fun registerUser(
        name: String,
        email: String,
        password: String
    ): Result<UserEntity> = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase()
        val cleanName = name.trim()
        val currentLang = _currentLanguage.value

        if (cleanName.isBlank() || cleanEmail.isBlank() || password.isBlank()) {
            val msg = if (currentLang == "ar") "برجاء ملء جميع الحقول المطلوبة." else "Please fill in all required fields."
            return@withContext Result.failure(Exception(msg))
        }
        if (password.length < 6) {
            val msg = if (currentLang == "ar") "كلمة السر يجب أن تكون 6 أحرف على الأقل." else "Password must be at least 6 characters."
            return@withContext Result.failure(Exception(msg))
        }

        val existingUser = loveDao.getUserByEmail(cleanEmail)
        if (existingUser != null) {
            val msg = if (currentLang == "ar") "هذا البريد مسجل بالفعل، برجاء تسجيل الدخول." else "This email is already registered. Please log in."
            return@withContext Result.failure(Exception(msg))
        }

        var firebaseUid = ""
        val fbResult = firebaseService.registerWithFirebase(cleanEmail, password)
        if (fbResult.isSuccess) {
            firebaseUid = fbResult.getOrDefault("")
        } else {
            val ex = fbResult.exceptionOrNull() ?: Exception("Firebase error")
            val userFriendlyMsg = FirebaseLoveService.mapFirebaseException(ex, currentLang)
            return@withContext Result.failure(Exception(userFriendlyMsg))
        }

        val passwordHash = hashPassword(password)
        val newUser = UserEntity(
            firebaseUid = firebaseUid,
            name = cleanName,
            email = cleanEmail,
            passwordHash = passwordHash,
            avatarRes = "avatar_1"
        )
        val userId = loveDao.insertUser(newUser)
        val savedUser = newUser.copy(id = userId)

        if (firebaseUid.isNotBlank()) {
            firebaseService.syncUserProfileOnline(
                uid = firebaseUid,
                name = cleanName,
                email = cleanEmail,
                avatarRes = "avatar_1"
            )
        }

        prefs.edit().putLong("saved_user_id", userId).apply()
        _currentUserId.value = userId
        Result.success(savedUser)
    }

    suspend fun loginUser(email: String, password: String): Result<UserEntity> =
        withContext(Dispatchers.IO) {
            val cleanEmail = email.trim().lowercase()
            val currentLang = _currentLanguage.value

            if (cleanEmail.isBlank() || password.isBlank()) {
                val msg = if (currentLang == "ar") "برجاء ملء جميع الحقول المطلوبة." else "Please fill in all fields."
                return@withContext Result.failure(Exception(msg))
            }

            var firebaseUid = ""
            val fbResult = firebaseService.loginWithFirebase(cleanEmail, password)
            if (fbResult.isSuccess) {
                firebaseUid = fbResult.getOrDefault("")
            } else {
                val ex = fbResult.exceptionOrNull() ?: Exception("Login error")
                val userFriendlyMsg = FirebaseLoveService.mapFirebaseException(ex, currentLang)
                return@withContext Result.failure(Exception(userFriendlyMsg))
            }

            var localUser = loveDao.getUserByEmail(cleanEmail)
            if (localUser == null && firebaseUid.isNotBlank()) {
                localUser = loveDao.getUserByFirebaseUid(firebaseUid)
            }

            val loggedInUser = if (localUser != null) {
                val updated = localUser.copy(firebaseUid = firebaseUid.ifEmpty { localUser.firebaseUid })
                loveDao.updateUser(updated)
                updated
            } else {
                val onlineProfile = if (firebaseUid.isNotBlank()) {
                    firebaseService.fetchUserProfileOnline(firebaseUid)
                } else null

                val name = onlineProfile?.get("displayName") as? String
                    ?: onlineProfile?.get("name") as? String
                    ?: cleanEmail.substringBefore("@")
                val avatarRes = onlineProfile?.get("avatarRes") as? String ?: "avatar_1"
                val photoUrl = onlineProfile?.get("photoUrl") as? String ?: ""
                val relId = onlineProfile?.get("relationshipId") as? String
                val relCode = onlineProfile?.get("relationshipCode") as? String ?: ""
                val partnerName = onlineProfile?.get("partnerName") as? String ?: ""
                val partnerUid = onlineProfile?.get("partnerUid") as? String ?: ""

                val newUser = UserEntity(
                    firebaseUid = firebaseUid,
                    name = name,
                    email = cleanEmail,
                    passwordHash = hashPassword(password),
                    avatarRes = avatarRes,
                    photoUrl = photoUrl,
                    partnerName = partnerName,
                    partnerUid = partnerUid,
                    relationshipCode = relCode,
                    connectedRelationshipId = relId,
                    isConnected = !relId.isNullOrBlank()
                )
                val newId = loveDao.insertUser(newUser)
                newUser.copy(id = newId)
            }

            prefs.edit().putLong("saved_user_id", loggedInUser.id).apply()
            _currentUserId.value = loggedInUser.id

            if (!loggedInUser.connectedRelationshipId.isNullOrBlank()) {
                startRealtimeSync(loggedInUser.connectedRelationshipId, loggedInUser.firebaseUid)
            }

            Result.success(loggedInUser)
        }

    suspend fun sendPasswordResetEmail(email: String): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim()
        val currentLang = _currentLanguage.value
        if (cleanEmail.isBlank()) {
            val msg = if (currentLang == "ar") "برجاء إدخال البريد الإلكتروني" else "Please enter your email"
            return@withContext Result.failure(Exception(msg))
        }
        val res = firebaseService.sendPasswordResetEmail(cleanEmail)
        if (res.isFailure) {
            val ex = res.exceptionOrNull() ?: Exception("Error")
            val msg = FirebaseLoveService.mapFirebaseException(ex, currentLang)
            Result.failure(Exception(msg))
        } else {
            res
        }
    }

    fun logout() {
        firebaseService.signOut()
        prefs.edit().remove("saved_user_id").apply()
        _currentUserId.value = null
    }

    suspend fun updateUserProfile(name: String, avatarRes: String, photoUrl: String = "") = withContext(Dispatchers.IO) {
        val userId = _currentUserId.value ?: return@withContext
        val user = loveDao.getUserById(userId) ?: return@withContext
        val finalPhotoUrl = if (photoUrl.isNotEmpty()) photoUrl else user.photoUrl
        val updatedUser = user.copy(name = name.trim(), avatarRes = avatarRes, photoUrl = finalPhotoUrl)
        loveDao.updateUser(updatedUser)

        val relFirestoreId = user.connectedRelationshipId
        var isCreator = false
        if (!relFirestoreId.isNullOrBlank()) {
            val rel = loveDao.getRelationshipByFirestoreId(relFirestoreId)
            if (rel != null) {
                isCreator = (rel.creatorId == user.firebaseUid)
                val updatedRel = if (isCreator) {
                    rel.copy(creatorName = name.trim(), creatorPhoto = finalPhotoUrl.ifEmpty { avatarRes })
                } else {
                    rel.copy(partnerName = name.trim(), partnerPhoto = finalPhotoUrl.ifEmpty { avatarRes })
                }
                loveDao.updateRelationship(updatedRel)
            }
        }

        if (user.firebaseUid.isNotBlank()) {
            // Never upload local file paths (/data/...) to Firestore as partner device cannot access them
            val onlinePhoto = if (finalPhotoUrl.startsWith("http://") || finalPhotoUrl.startsWith("https://")) {
                finalPhotoUrl
            } else {
                avatarRes
            }
            firebaseService.updateUserProfileOnline(
                uid = user.firebaseUid,
                name = name.trim(),
                avatarRes = avatarRes,
                photoUrl = onlinePhoto,
                relId = relFirestoreId,
                isCreator = isCreator
            )
        }
    }

    suspend fun uploadProfileImageUri(imageUri: Uri): String? = withContext(Dispatchers.IO) {
        val userId = _currentUserId.value ?: return@withContext null
        val user = loveDao.getUserById(userId) ?: return@withContext null
        if (user.firebaseUid.isBlank()) return@withContext null

        try {
            // 1. Save locally immediately so current user sees the photo right away
            val localPath = ImageUtils.saveImageLocally(context, imageUri, "profile", "avatar_${user.firebaseUid}")
            if (!localPath.isNullOrBlank()) {
                val updatedUser = user.copy(photoUrl = localPath)
                loveDao.updateUser(updatedUser)
            }

            // 2. Compress and upload bytes to Firebase Storage
            val bytes = ImageUtils.compressAndResizeImageUri(context, imageUri)
            if (bytes != null && bytes.isNotEmpty()) {
                val photoUrl = firebaseService.uploadProfileImageBytes(user.firebaseUid, bytes)
                if (!photoUrl.isNullOrBlank()) {
                    updateUserProfile(user.name, user.avatarRes, photoUrl)
                    return@withContext photoUrl
                }
            }
            localPath
        } catch (e: Exception) {
            Log.e("LoveRepository", "Error in uploadProfileImageUri: ${e.message}", e)
            null
        }
    }

    // --- Daily Status / Feeling ---

    suspend fun updateDailyStatus(status: String, emoji: String) = withContext(Dispatchers.IO) {
        val userId = _currentUserId.value ?: return@withContext
        val user = loveDao.getUserById(userId) ?: return@withContext
        val updatedUser = user.copy(
            dailyStatus = status,
            dailyStatusEmoji = emoji,
            statusUpdatedAtMillis = System.currentTimeMillis()
        )
        loveDao.updateUser(updatedUser)

        val relFirestoreId = user.connectedRelationshipId
        var isCreator = false
        if (!relFirestoreId.isNullOrBlank()) {
            val rel = loveDao.getRelationshipByFirestoreId(relFirestoreId)
            if (rel != null) {
                isCreator = (rel.creatorId == user.firebaseUid)
                val updatedRel = if (isCreator) {
                    rel.copy(creatorStatus = status, creatorStatusEmoji = emoji)
                } else {
                    rel.copy(partnerStatus = status, partnerStatusEmoji = emoji)
                }
                loveDao.updateRelationship(updatedRel)
            }
        }

        if (user.firebaseUid.isNotBlank()) {
            firebaseService.updateUserStatusOnline(
                uid = user.firebaseUid,
                relId = relFirestoreId,
                isCreator = isCreator,
                status = status,
                statusEmoji = emoji
            )
        }
    }

    // --- Relationship Creation & Connection ---

    suspend fun createRelationship(
        startDateMillis: Long = System.currentTimeMillis()
    ): Result<Pair<RelationshipEntity, String>> = withContext(Dispatchers.IO) {
        val userId = _currentUserId.value ?: return@withContext Result.failure(Exception("User not found"))
        val user = loveDao.getUserById(userId) ?: return@withContext Result.failure(Exception("User not found"))
        val code = generateUnique6DigitCode()
        val creatorUid = if (user.firebaseUid.isNotBlank()) user.firebaseUid else "user_$userId"
        val creatorPhoto = user.photoUrl.ifEmpty { user.avatarRes }

        val firestoreRelId = firebaseService.createFirestoreRelationship(
            creatorUid = creatorUid,
            creatorName = user.name,
            creatorPhoto = creatorPhoto,
            startDateMillis = startDateMillis,
            code = code
        )

        val relationship = RelationshipEntity(
            firestoreId = firestoreRelId,
            code = code,
            creatorId = creatorUid,
            creatorName = user.name,
            creatorPhoto = creatorPhoto,
            partnerName = "في انتظار الشريك...",
            partnerPhoto = "avatar_2",
            startDateMillis = startDateMillis,
            relationshipName = "قصتنا",
            status = "pending"
        )
        val relLocalId = loveDao.insertRelationship(relationship)
        val savedRel = relationship.copy(id = relLocalId)

        val updatedUser = user.copy(
            relationshipCode = code,
            connectedRelationshipId = firestoreRelId,
            localRelationshipId = relLocalId,
            isConnected = true
        )
        loveDao.updateUser(updatedUser)

        startRealtimeSync(firestoreRelId, user.firebaseUid)
        Result.success(Pair(savedRel, code))
    }

    suspend fun joinRelationship(code: String): Result<RelationshipEntity> =
        withContext(Dispatchers.IO) {
            val userId = _currentUserId.value ?: return@withContext Result.failure(Exception("User not found"))
            val user = loveDao.getUserById(userId) ?: return@withContext Result.failure(Exception("User not found"))
            val cleanCode = code.trim()
            val userUid = if (user.firebaseUid.isNotBlank()) user.firebaseUid else "user_$userId"
            val userPhoto = user.photoUrl.ifEmpty { user.avatarRes }

            try {
                val joinResult = firebaseService.joinFirestoreRelationship(
                    code = cleanCode,
                    partnerUid = userUid,
                    partnerName = user.name,
                    partnerPhoto = userPhoto,
                    language = _currentLanguage.value
                )

                val (relId, data) = joinResult
                val creatorUid = data["creatorUid"] as? String ?: ""
                val creatorName = data["creatorName"] as? String ?: (if (_currentLanguage.value == "ar") "حبيبي" else "My Partner")
                val creatorPhoto = data["creatorPhoto"] as? String ?: "avatar_1"
                val startDateMillis = (data["startDateMillis"] as? Long) ?: System.currentTimeMillis()
                val relName = data["relationshipName"] as? String ?: "$creatorName & ${user.name}"

                val relationship = RelationshipEntity(
                    firestoreId = relId,
                    code = cleanCode,
                    creatorId = creatorUid,
                    creatorName = creatorName,
                    creatorPhoto = creatorPhoto,
                    partnerId = userUid,
                    partnerName = user.name,
                    partnerPhoto = userPhoto,
                    startDateMillis = startDateMillis,
                    relationshipName = relName,
                    status = "connected"
                )
                val localId = loveDao.insertRelationship(relationship)

                val updatedUser = user.copy(
                    partnerName = creatorName,
                    partnerUid = creatorUid,
                    partnerPhotoUrl = creatorPhoto,
                    relationshipCode = cleanCode,
                    connectedRelationshipId = relId,
                    localRelationshipId = localId,
                    isConnected = true
                )
                loveDao.updateUser(updatedUser)

                startRealtimeSync(relId, user.firebaseUid)
                Result.success(relationship.copy(id = localId))
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    private fun startRealtimeSync(relationshipId: String, currentUid: String) {
        var isInitialMessagesSync = true
        var isInitialMemoriesSync = true
        var isInitialGoalsSync = true

        incomingCallListener?.remove()
        incomingCallListener = firebaseService.listenToIncomingCall(relationshipId, currentUid) { call ->
            _incomingCall.value = call
        }
        partnerPresenceListener?.remove()
        partnerPresenceListener = null

        firebaseService.startRealtimeListeners(
            relationshipId = relationshipId,
            currentUid = currentUid,
            onRelationshipUpdate = { rel ->
                repoScope.launch {
                    val existing = loveDao.getRelationshipByFirestoreId(rel.firestoreId)
                    val relLocalId = if (existing != null) {
                        loveDao.updateRelationship(rel.copy(id = existing.id))
                        existing.id
                    } else {
                        loveDao.insertRelationship(rel)
                    }

                    val currentUserIdVal = _currentUserId.value
                    if (currentUserIdVal != null) {
                        val currentUser = loveDao.getUserById(currentUserIdVal)
                        if (currentUser != null) {
                            val isCreator = (rel.creatorId == currentUser.firebaseUid)
                            val newPartnerName = if (isCreator) rel.partnerName else rel.creatorName
                            val newPartnerPhoto = if (isCreator) rel.partnerPhoto else rel.creatorPhoto
                            val newPartnerUid = if (isCreator) (rel.partnerId ?: "") else rel.creatorId
                            val newPartnerStatus = if (isCreator) rel.partnerStatus else rel.creatorStatus
                            val newPartnerStatusEmoji = if (isCreator) rel.partnerStatusEmoji else rel.creatorStatusEmoji
                            val partnerOnlineBday = if (isCreator) rel.partnerBirthdayMillis else rel.creatorBirthdayMillis
                            val myOnlineBday = if (isCreator) rel.creatorBirthdayMillis else rel.partnerBirthdayMillis

                            val hasChanges = (newPartnerUid.isNotBlank() && currentUser.partnerUid != newPartnerUid) ||
                                (newPartnerName.isNotBlank() && currentUser.partnerName != newPartnerName) ||
                                (newPartnerPhoto.isNotBlank() && currentUser.partnerPhotoUrl != newPartnerPhoto) ||
                                (newPartnerStatus.isNotBlank() && currentUser.partnerDailyStatus != newPartnerStatus) ||
                                (newPartnerStatusEmoji.isNotBlank() && currentUser.partnerDailyStatusEmoji != newPartnerStatusEmoji) ||
                                (partnerOnlineBday > 0L && currentUser.partnerBirthdayMillis != partnerOnlineBday) ||
                                (myOnlineBday > 0L && currentUser.birthdayMillis != myOnlineBday)

                            if (hasChanges) {
                                loveDao.updateUser(
                                    currentUser.copy(
                                        partnerName = newPartnerName.ifBlank { currentUser.partnerName },
                                        partnerUid = newPartnerUid.ifBlank { currentUser.partnerUid },
                                        partnerPhotoUrl = newPartnerPhoto.ifBlank { currentUser.partnerPhotoUrl },
                                        partnerDailyStatus = newPartnerStatus.ifBlank { currentUser.partnerDailyStatus },
                                        partnerDailyStatusEmoji = newPartnerStatusEmoji.ifBlank { currentUser.partnerDailyStatusEmoji },
                                        partnerBirthdayMillis = if (partnerOnlineBday > 0L) partnerOnlineBday else currentUser.partnerBirthdayMillis,
                                        birthdayMillis = if (myOnlineBday > 0L) myOnlineBday else currentUser.birthdayMillis,
                                        isConnected = true,
                                        localRelationshipId = relLocalId
                                    )
                                )
                            }

                            if (newPartnerUid.isNotBlank() && partnerPresenceListener == null) {
                                partnerPresenceListener = firebaseService.listenToPartnerPresence(newPartnerUid) { isOnline, lastSeenMillis ->
                                    repoScope.launch {
                                        val cId = _currentUserId.value ?: return@launch
                                        val userObj = loveDao.getUserById(cId) ?: return@launch
                                        if (userObj.partnerIsOnline != isOnline || userObj.partnerLastSeenMillis != lastSeenMillis) {
                                            loveDao.updateUser(
                                                userObj.copy(
                                                    partnerIsOnline = isOnline,
                                                    partnerLastSeenMillis = lastSeenMillis
                                                )
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            onPartnerProfileUpdate = { name, photo, avatar, status, emoji ->
                repoScope.launch {
                    val currentUserIdVal = _currentUserId.value ?: return@launch
                    val currentUser = loveDao.getUserById(currentUserIdVal) ?: return@launch
                    val updatedPartnerPhoto = photo.ifEmpty { avatar }
                    val prevStatus = currentUser.partnerDailyStatus
                    val prevEmoji = currentUser.partnerDailyStatusEmoji
                    
                    val isStatusChanged = (status.isNotBlank() && status != prevStatus) || (emoji.isNotBlank() && emoji != prevEmoji)

                    loveDao.updateUser(
                        currentUser.copy(
                            partnerName = name.ifEmpty { currentUser.partnerName },
                            partnerPhotoUrl = updatedPartnerPhoto.ifEmpty { currentUser.partnerPhotoUrl },
                            partnerDailyStatus = status.ifEmpty { currentUser.partnerDailyStatus },
                            partnerDailyStatusEmoji = emoji.ifEmpty { currentUser.partnerDailyStatusEmoji }
                        )
                    )

                    if (_isNotificationsEnabled.value && isStatusChanged && currentUser.partnerUid.isNotBlank()) {
                        NotificationHelper.showStatusNotification(
                            context = context,
                            senderUid = currentUser.partnerUid,
                            currentUid = currentUser.firebaseUid,
                            partnerName = name.ifBlank { currentUser.partnerName },
                            newStatus = status,
                            newEmoji = emoji
                        )
                    }
                }
            },
            onPartnerTypingUpdate = { isTyping ->
                _partnerIsTyping.value = isTyping
            },
            onMessagesUpdate = { letters ->
                repoScope.launch {
                    loveDao.syncLoveLetters(relationshipId, letters)
                    val currentUserIdVal = _currentUserId.value
                    val currentUser = currentUserIdVal?.let { loveDao.getUserById(it) }
                    val currentUidVal = currentUser?.firebaseUid ?: currentUid

                    if (isInitialMessagesSync) {
                        isInitialMessagesSync = false
                        // On app open / initial snapshot: mark all existing messages as notified
                        // so they never repeat as notifications
                        letters.forEach { letter ->
                            if (letter.firestoreId.isNotBlank()) {
                                NotificationHelper.markAsNotified(context, "msg_${letter.firestoreId}")
                            }
                        }
                    } else {
                        // Realtime update: notify ONLY for new unread messages from partner
                        if (_isNotificationsEnabled.value && letters.isNotEmpty()) {
                            val newPartnerLetters = letters.filter { letter ->
                                letter.senderUid.isNotBlank() &&
                                letter.senderUid != currentUidVal &&
                                !letter.isRead &&
                                !NotificationHelper.hasBeenNotified(context, "msg_${letter.firestoreId}")
                            }
                            newPartnerLetters.forEach { letter ->
                                NotificationHelper.showMessageNotification(
                                    context = context,
                                    messageId = letter.firestoreId,
                                    senderUid = letter.senderUid,
                                    currentUid = currentUidVal,
                                    senderName = letter.senderName,
                                    title = letter.title,
                                    messageText = letter.message,
                                    relationshipId = relationshipId
                                )
                            }
                        }
                    }
                }
            },
            onMemoriesUpdate = { memories ->
                repoScope.launch {
                    loveDao.syncMemories(relationshipId, memories)
                    val currentUserIdVal = _currentUserId.value
                    val currentUser = currentUserIdVal?.let { loveDao.getUserById(it) }
                    val currentUidVal = currentUser?.firebaseUid ?: currentUid

                    if (isInitialMemoriesSync) {
                        isInitialMemoriesSync = false
                        memories.forEach { mem ->
                            if (mem.firestoreId.isNotBlank()) {
                                NotificationHelper.markAsNotified(context, "memory_${mem.firestoreId}")
                            }
                        }
                    } else {
                        if (_isNotificationsEnabled.value && memories.isNotEmpty()) {
                            val newMemories = memories.filter { mem ->
                                mem.createdByUid.isNotBlank() &&
                                mem.createdByUid != currentUidVal &&
                                !NotificationHelper.hasBeenNotified(context, "memory_${mem.firestoreId}")
                            }
                            newMemories.forEach { mem ->
                                NotificationHelper.showMemoryNotification(
                                    context = context,
                                    memoryId = mem.firestoreId,
                                    senderUid = mem.createdByUid,
                                    currentUid = currentUidVal,
                                    partnerName = mem.createdByName.ifBlank { currentUser?.partnerName ?: "" },
                                    memoryTitle = mem.title
                                )
                            }
                        }
                    }
                }
            },
            onGoalsUpdate = { goals ->
                repoScope.launch {
                    loveDao.syncGoals(relationshipId, goals)
                    val currentUserIdVal = _currentUserId.value
                    val currentUser = currentUserIdVal?.let { loveDao.getUserById(it) }
                    val currentUidVal = currentUser?.firebaseUid ?: currentUid

                    if (isInitialGoalsSync) {
                        isInitialGoalsSync = false
                        goals.forEach { goal ->
                            if (goal.firestoreId.isNotBlank()) {
                                NotificationHelper.markAsNotified(context, "goal_${goal.firestoreId}")
                            }
                        }
                    } else {
                        if (_isNotificationsEnabled.value && goals.isNotEmpty()) {
                            val newGoals = goals.filter { goal ->
                                goal.createdByUid.isNotBlank() &&
                                goal.createdByUid != currentUidVal &&
                                !NotificationHelper.hasBeenNotified(context, "goal_${goal.firestoreId}")
                            }
                            newGoals.forEach { goal ->
                                NotificationHelper.showGoalNotification(
                                    context = context,
                                    goalId = goal.firestoreId,
                                    senderUid = goal.createdByUid,
                                    currentUid = currentUidVal,
                                    partnerName = goal.createdByName.ifBlank { currentUser?.partnerName ?: "" },
                                    goalTitle = goal.title
                                )
                            }
                        }
                    }
                }
            },
            onNotesUpdate = { notes ->
                repoScope.launch {
                    loveDao.syncNotes(relationshipId, notes)
                }
            }
        )
    }

    suspend fun disconnectRelationship(): Result<Unit> = withContext(Dispatchers.IO) {
        val userId = _currentUserId.value ?: return@withContext Result.failure(Exception("User not found"))
        val user = loveDao.getUserById(userId) ?: return@withContext Result.failure(Exception("User not found"))
        val relFirestoreId = user.connectedRelationshipId ?: ""
        val localId = user.localRelationshipId ?: 0L

        firebaseService.stopAllListeners()
        incomingCallListener?.remove()
        incomingCallListener = null
        partnerPresenceListener?.remove()
        partnerPresenceListener = null
        _incomingCall.value = null
        if (relFirestoreId.isNotBlank() && user.firebaseUid.isNotBlank()) {
            firebaseService.disconnectRelationshipOnline(relFirestoreId, user.firebaseUid)
        }

        val updatedUser = user.copy(
            connectedRelationshipId = null,
            localRelationshipId = null,
            isConnected = false,
            relationshipCode = "",
            partnerName = "",
            partnerUid = "",
            partnerPhotoUrl = "",
            partnerDailyStatus = "",
            partnerDailyStatusEmoji = ""
        )
        loveDao.updateUser(updatedUser)
        loveDao.deleteRelationship(localId, relFirestoreId)
        Result.success(Unit)
    }

    suspend fun updateRelationshipDetails(name: String, startDateMillis: Long) =
        withContext(Dispatchers.IO) {
            val user = _currentUserId.value?.let { loveDao.getUserById(it) }
            val relId = user?.connectedRelationshipId
            val rel = if (!relId.isNullOrBlank()) {
                loveDao.getRelationshipByFirestoreId(relId)
            } else {
                user?.localRelationshipId?.let { loveDao.getRelationshipById(it) }
            } ?: return@withContext

            val updated = rel.copy(
                relationshipName = name.ifBlank { rel.relationshipName },
                startDateMillis = startDateMillis
            )
            loveDao.updateRelationship(updated)
            val effectiveFirestoreId = rel.firestoreId.ifBlank { relId ?: "" }
            if (effectiveFirestoreId.isNotBlank()) {
                firebaseService.updateRelationshipDetailsOnline(effectiveFirestoreId, updated.relationshipName, startDateMillis)
            }
        }

    suspend fun updateMyBirthday(myBirthdayMillis: Long) = withContext(Dispatchers.IO) {
        if (myBirthdayMillis <= 0L) return@withContext
        val user = _currentUserId.value?.let { loveDao.getUserById(it) } ?: return@withContext

        // 1. Update user's own local birthday
        val updatedUser = user.copy(birthdayMillis = myBirthdayMillis)
        loveDao.updateUser(updatedUser)

        // 2. Identify relationship and whether user is creator or partner
        val relId = user.connectedRelationshipId
        val rel = if (!relId.isNullOrBlank()) {
            loveDao.getRelationshipByFirestoreId(relId)
        } else {
            user.localRelationshipId?.let { loveDao.getRelationshipById(it) }
        }

        if (rel != null) {
            val isCreator = (rel.creatorId == user.firebaseUid)
            val updatedRel = if (isCreator) {
                rel.copy(creatorBirthdayMillis = myBirthdayMillis)
            } else {
                rel.copy(partnerBirthdayMillis = myBirthdayMillis)
            }
            loveDao.updateRelationship(updatedRel)

            val effectiveFirestoreId = rel.firestoreId.ifBlank { relId ?: "" }
            if (effectiveFirestoreId.isNotBlank()) {
                firebaseService.updateUserBirthdayOnline(
                    relId = effectiveFirestoreId,
                    uid = user.firebaseUid,
                    isCreator = isCreator,
                    birthdayMillis = myBirthdayMillis
                )
            }
        } else if (user.firebaseUid.isNotBlank()) {
            firebaseService.updateUserBirthdayOnline(
                relId = "",
                uid = user.firebaseUid,
                isCreator = true,
                birthdayMillis = myBirthdayMillis
            )
        }
    }

    suspend fun updateBirthdays(myBirthdayMillis: Long? = null, partnerBirthdayMillis: Long? = null) =
        withContext(Dispatchers.IO) {
            // Strictly enforce: users can only update their own birthday from their own device
            if (myBirthdayMillis != null && myBirthdayMillis > 0L) {
                updateMyBirthday(myBirthdayMillis)
            }
        }

    private var lastTypingUpdateTime = 0L

    suspend fun setTyping(isTyping: Boolean) = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        if (isTyping && now - lastTypingUpdateTime < 1500L) {
            return@withContext
        }
        lastTypingUpdateTime = now

        val user = _currentUserId.value?.let { loveDao.getUserById(it) } ?: return@withContext
        val relId = user.connectedRelationshipId ?: return@withContext
        val rel = loveDao.getRelationshipByFirestoreId(relId) ?: return@withContext
        val isCreator = (rel.creatorId == user.firebaseUid)
        firebaseService.updateTypingStatus(relId, isCreator, isTyping)
    }

    // Memories
    fun getMemories(relationshipId: String, altRelationshipId: String = ""): Flow<List<MemoryEntity>> =
        loveDao.getMemoriesFlow(relationshipId, altRelationshipId)

    suspend fun addMemory(
        relationshipId: String,
        title: String,
        description: String,
        dateMillis: Long,
        imageUri: Uri?,
        location: String,
        authorName: String
    ) = withContext(Dispatchers.IO) {
        val user = _currentUserId.value?.let { loveDao.getUserById(it) }
        val effectiveRelId = if (relationshipId.isNotBlank() && relationshipId.length > 5) {
            relationshipId
        } else {
            val relByLocal = user?.localRelationshipId?.let { loveDao.getRelationshipById(it) }
            relByLocal?.firestoreId?.takeIf { it.isNotBlank() }
                ?: (user?.connectedRelationshipId?.takeIf { it.isNotBlank() } ?: "")
        }
        val memoryId = UUID.randomUUID().toString()
        var uploadedUrl = ""
        var localFilePath: String? = null

        if (imageUri != null) {
            val bytes = ImageUtils.compressAndResizeImageUri(context, imageUri)
            if (bytes != null && bytes.isNotEmpty()) {
                if (effectiveRelId.isNotBlank()) {
                    val url = firebaseService.uploadMemoryImageBytes(effectiveRelId, user?.firebaseUid ?: "", bytes)
                    if (url.isNullOrBlank()) {
                        throw IllegalStateException("فشل رفع صورة الذكرى إلى السحابة. يرجى التأكد من اتصال الإنترنت والمحاولة مجدداً.")
                    }
                    uploadedUrl = url
                } else {
                    localFilePath = ImageUtils.saveBytesLocally(context, bytes, "memories", "mem_$memoryId")
                }
            } else {
                throw IllegalStateException("تعذر قراءة الصورة المحددة. يرجى اختيار صورة صالحة.")
            }
        }

        val finalImageUrl = uploadedUrl.ifBlank { localFilePath ?: "" }

        val memory = MemoryEntity(
            firestoreId = memoryId,
            relationshipId = effectiveRelId,
            title = title,
            description = description,
            dateMillis = dateMillis,
            imageUrl = finalImageUrl,
            imageDrawableName = "",
            location = location,
            createdByName = authorName,
            createdByUid = user?.firebaseUid ?: ""
        )
        loveDao.insertMemory(memory)
        if (effectiveRelId.isNotBlank()) {
            firebaseService.addMemoryOnline(effectiveRelId, memory.copy(imageUrl = uploadedUrl))
        }
    }

    suspend fun deleteMemory(firestoreId: String, relationshipId: String = "") = withContext(Dispatchers.IO) {
        val user = _currentUserId.value?.let { loveDao.getUserById(it) }
        val effectiveRelId = if (relationshipId.isNotBlank() && relationshipId.length > 5) {
            relationshipId
        } else {
            val relByLocal = user?.localRelationshipId?.let { loveDao.getRelationshipById(it) }
            relByLocal?.firestoreId?.takeIf { it.isNotBlank() }
                ?: (user?.connectedRelationshipId?.takeIf { it.isNotBlank() } ?: "")
        }
        val existingMemories = if (effectiveRelId.isNotBlank()) {
            loveDao.getMemoriesFlow(effectiveRelId).firstOrNull()
        } else null
        val imageUrl = existingMemories?.find { it.firestoreId == firestoreId }?.imageUrl ?: ""

        loveDao.deleteMemory(firestoreId)
        if (effectiveRelId.isNotBlank()) {
            firebaseService.deleteMemoryOnline(effectiveRelId, firestoreId, imageUrl)
        }
    }

    // Love Letters / Messages (Chat)
    fun getLoveLetters(relationshipId: String, altRelationshipId: String = ""): Flow<List<LoveLetterEntity>> =
        loveDao.getLoveLettersFlow(relationshipId, altRelationshipId)

    suspend fun sendLoveLetter(
        relationshipId: String,
        senderName: String,
        title: String,
        message: String,
        themeIndex: Int,
        replyToId: String? = null,
        replyToSenderName: String? = null,
        replyToText: String? = null
    ) = withContext(Dispatchers.IO) {
        val user = _currentUserId.value?.let { loveDao.getUserById(it) }
        val messageId = UUID.randomUUID().toString()
        val effectiveRelId = if (relationshipId.isNotBlank()) relationshipId else (user?.connectedRelationshipId ?: "")
        val letter = LoveLetterEntity(
            firestoreId = messageId,
            relationshipId = effectiveRelId,
            senderUid = user?.firebaseUid ?: "",
            senderName = senderName,
            title = title,
            message = message,
            dateMillis = System.currentTimeMillis(),
            themeColorIndex = themeIndex,
            replyToId = replyToId,
            replyToSenderName = replyToSenderName,
            replyToText = replyToText,
            isEdited = false
        )
        loveDao.insertLoveLetter(letter)
        if (effectiveRelId.isNotBlank()) {
            firebaseService.sendMessageOnline(effectiveRelId, letter)
        }
    }

    suspend fun editLoveLetter(
        relationshipId: String,
        messageId: String,
        newText: String
    ) = withContext(Dispatchers.IO) {
        loveDao.updateLoveLetterMessage(messageId, newText)
        val user = _currentUserId.value?.let { loveDao.getUserById(it) }
        val effectiveRelId = if (relationshipId.isNotBlank()) relationshipId else {
            user?.connectedRelationshipId ?: ""
        }
        if (effectiveRelId.isNotBlank()) {
            firebaseService.editMessageOnline(effectiveRelId, messageId, newText)
        }
    }

    suspend fun markAllMessagesAsRead(relationshipId: String) = withContext(Dispatchers.IO) {
        val user = _currentUserId.value?.let { loveDao.getUserById(it) }
        val currentUid = user?.firebaseUid ?: ""
        if (currentUid.isNotBlank() && relationshipId.isNotBlank()) {
            loveDao.markAllIncomingLoveLettersAsRead(relationshipId, currentUid)
        }
        val effectiveRelId = if (relationshipId.isNotBlank() && !relationshipId.all { it.isDigit() }) {
            relationshipId
        } else {
            user?.connectedRelationshipId ?: ""
        }
        if (effectiveRelId.isNotBlank() && user != null && user.firebaseUid.isNotBlank()) {
            firebaseService.markAllMessagesReadOnline(effectiveRelId, user.firebaseUid)
        }
    }

    suspend fun deleteLoveLetter(firestoreId: String, relationshipId: String = "") = withContext(Dispatchers.IO) {
        loveDao.deleteLoveLetter(firestoreId)
        val relId = if (relationshipId.isNotBlank()) relationshipId else {
            val user = _currentUserId.value?.let { loveDao.getUserById(it) }
            user?.connectedRelationshipId ?: ""
        }
        if (relId.isNotBlank()) {
            firebaseService.deleteMessageOnline(relId, firestoreId)
        }
    }

    suspend fun markLoveLetterAsRead(firestoreId: String, relationshipId: String = "") = withContext(Dispatchers.IO) {
        loveDao.markLoveLetterAsRead(firestoreId)
        val relId = if (relationshipId.isNotBlank()) relationshipId else {
            val user = _currentUserId.value?.let { loveDao.getUserById(it) }
            user?.connectedRelationshipId ?: ""
        }
        if (relId.isNotBlank() && firestoreId.isNotBlank()) {
            firebaseService.markMessageReadOnline(relId, firestoreId)
        }
    }

    suspend fun sendVoiceMessage(
        relationshipId: String,
        senderName: String,
        audioBytes: ByteArray,
        durationSeconds: Int
    ) = withContext(Dispatchers.IO) {
        val user = _currentUserId.value?.let { loveDao.getUserById(it) }
        val messageId = UUID.randomUUID().toString()
        val effectiveRelId = if (relationshipId.isNotBlank()) relationshipId else (user?.connectedRelationshipId ?: "")
        val voiceUrl = if (effectiveRelId.isNotBlank()) {
            firebaseService.uploadVoiceNoteBytes(effectiveRelId, audioBytes) ?: ""
        } else ""

        val letter = LoveLetterEntity(
            firestoreId = messageId,
            relationshipId = effectiveRelId,
            senderUid = user?.firebaseUid ?: "",
            senderName = senderName,
            title = "تسجيل صوتي",
            message = "تسجيل صوتي ($durationSeconds ثانية)",
            dateMillis = System.currentTimeMillis(),
            themeColorIndex = 0,
            mediaType = "voice",
            mediaUrl = voiceUrl,
            durationSeconds = durationSeconds
        )
        loveDao.insertLoveLetter(letter)
        if (effectiveRelId.isNotBlank()) {
            firebaseService.sendMessageOnline(effectiveRelId, letter)
        }
    }

    suspend fun toggleMessageReaction(
        relationshipId: String,
        messageId: String,
        emoji: String
    ) = withContext(Dispatchers.IO) {
        val user = _currentUserId.value?.let { loveDao.getUserById(it) } ?: return@withContext
        val effectiveRelId = if (relationshipId.isNotBlank()) relationshipId else (user.connectedRelationshipId ?: "")

        try {
            val letters = loveDao.getLoveLettersFlow(effectiveRelId).firstOrNull()
            val target = letters?.find { it.firestoreId == messageId }
            if (target != null) {
                val map = target.reactions.split(",").filter { it.contains(":") }.associate {
                    val p = it.split(":")
                    p[0] to p[1]
                }.toMutableMap()
                if (map[user.firebaseUid] == emoji) {
                    map.remove(user.firebaseUid)
                } else {
                    map[user.firebaseUid] = emoji
                }
                val newReactions = map.entries.joinToString(",") { "${it.key}:${it.value}" }
                loveDao.updateLoveLetterReactions(messageId, newReactions)
            }
        } catch (e: Exception) {
            Log.w("LoveRepository", "Error doing optimistic reaction update: ${e.message}")
        }

        if (effectiveRelId.isNotBlank()) {
            firebaseService.toggleMessageReaction(effectiveRelId, messageId, user.firebaseUid, emoji)
        }
    }

    suspend fun setUserPresence(isOnline: Boolean) = withContext(Dispatchers.IO) {
        val user = _currentUserId.value?.let { loveDao.getUserById(it) } ?: return@withContext
        if (user.firebaseUid.isNotBlank()) {
            firebaseService.setUserPresence(user.firebaseUid, isOnline)
        }
    }

    suspend fun initiateCall(type: String): String = withContext(Dispatchers.IO) {
        val user = _currentUserId.value?.let { loveDao.getUserById(it) } ?: return@withContext ""
        val relId = user.connectedRelationshipId ?: ""
        val partnerUid = user.partnerUid
        if (relId.isBlank() || partnerUid.isBlank()) return@withContext ""
        firebaseService.initiateCall(relId, user.firebaseUid, user.name, partnerUid, type)
    }

    suspend fun updateCallStatus(callId: String, status: String) = withContext(Dispatchers.IO) {
        val user = _currentUserId.value?.let { loveDao.getUserById(it) } ?: return@withContext
        val relId = user.connectedRelationshipId ?: ""
        if (relId.isNotBlank() && callId.isNotBlank()) {
            firebaseService.updateCallStatus(relId, callId, status)
        }
    }

    suspend fun checkAppUpdate(): com.example.data.model.AppUpdateInfo? = withContext(Dispatchers.IO) {
        firebaseService.checkAppUpdate()
    }

    // Notes
    fun getNotes(relationshipId: String): Flow<List<NoteEntity>> =
        loveDao.getNotesFlow(relationshipId)

    suspend fun addNote(
        relationshipId: String,
        title: String,
        content: String,
        category: String,
        authorName: String
    ) = withContext(Dispatchers.IO) {
        val user = _currentUserId.value?.let { loveDao.getUserById(it) }
        val noteId = UUID.randomUUID().toString()
        val note = NoteEntity(
            firestoreId = noteId,
            relationshipId = relationshipId,
            title = title,
            content = content,
            category = category,
            authorName = authorName,
            authorUid = user?.firebaseUid ?: ""
        )
        loveDao.insertNote(note)
        firebaseService.addNoteOnline(relationshipId, note)
    }

    suspend fun deleteNote(firestoreId: String, relationshipId: String = "") = withContext(Dispatchers.IO) {
        loveDao.deleteNote(firestoreId)
        val relId = if (relationshipId.isNotBlank()) relationshipId else {
            val user = _currentUserId.value?.let { loveDao.getUserById(it) }
            user?.connectedRelationshipId ?: ""
        }
        if (relId.isNotBlank()) {
            firebaseService.deleteNoteOnline(relId, firestoreId)
        }
    }

    // Goals (Simple, with creator's name recorded)
    fun getGoals(relationshipId: String): Flow<List<GoalEntity>> =
        loveDao.getGoalsFlow(relationshipId)

    suspend fun addGoal(
        relationshipId: String,
        title: String,
        description: String,
        targetDate: String,
        category: String
    ) = withContext(Dispatchers.IO) {
        val user = _currentUserId.value?.let { loveDao.getUserById(it) }
        val goalId = UUID.randomUUID().toString()
        val creatorName = user?.name ?: "الشريك"

        val goal = GoalEntity(
            firestoreId = goalId,
            relationshipId = relationshipId,
            title = title,
            description = description,
            targetDate = targetDate,
            category = category.ifBlank { "عام" },
            createdByName = creatorName,
            createdByUid = user?.firebaseUid ?: "",
            createdAtMillis = System.currentTimeMillis()
        )
        loveDao.insertGoal(goal)
        firebaseService.addGoalOnline(relationshipId, goal)
    }

    suspend fun updateGoalProgress(goal: GoalEntity, progress: Int, isCompleted: Boolean) =
        withContext(Dispatchers.IO) {
            val updated = goal.copy(progress = progress, isCompleted = isCompleted)
            loveDao.updateGoal(updated)
            firebaseService.updateGoalOnline(goal.relationshipId, goal.firestoreId, progress, isCompleted)
        }

    suspend fun deleteGoal(firestoreId: String, relationshipId: String = "") = withContext(Dispatchers.IO) {
        loveDao.deleteGoal(firestoreId)
        val relId = if (relationshipId.isNotBlank()) relationshipId else {
            val user = _currentUserId.value?.let { loveDao.getUserById(it) }
            user?.connectedRelationshipId ?: ""
        }
        if (relId.isNotBlank()) {
            firebaseService.deleteGoalOnline(relId, firestoreId)
        }
    }

    // Special Dates
    fun getSpecialDates(relationshipId: String): Flow<List<SpecialDateEntity>> =
        loveDao.getSpecialDatesFlow(relationshipId)

    suspend fun addSpecialDate(
        relationshipId: String,
        title: String,
        dateMillis: Long,
        type: String,
        iconName: String
    ) = withContext(Dispatchers.IO) {
        loveDao.insertSpecialDate(
            SpecialDateEntity(
                relationshipId = relationshipId,
                title = title,
                dateMillis = dateMillis,
                type = type,
                iconName = iconName
            )
        )
    }

    suspend fun deleteSpecialDate(id: Long) = withContext(Dispatchers.IO) {
        loveDao.deleteSpecialDate(id)
    }

    // Notifications
    fun getNotifications(relationshipId: String): Flow<List<NotificationEntity>> =
        loveDao.getNotificationsFlow(relationshipId)

    suspend fun addNotification(
        relationshipId: String,
        title: String,
        message: String,
        iconType: String
    ) = withContext(Dispatchers.IO) {
        loveDao.insertNotification(
            NotificationEntity(
                relationshipId = relationshipId,
                title = title,
                message = message,
                iconType = iconType
            )
        )
    }

    suspend fun markNotificationAsRead(id: Long) = withContext(Dispatchers.IO) {
        loveDao.markNotificationAsRead(id)
    }

    // Achievements calculation
    fun getAchievements(
        relationship: RelationshipEntity?,
        memoriesCount: Int,
        lettersCount: Int,
        goalsDoneCount: Int
    ): List<AchievementItem> {
        val startDate = relationship?.startDateMillis ?: System.currentTimeMillis()
        val daysTogether = ((System.currentTimeMillis() - startDate) / (1000 * 60 * 60 * 24)).coerceAtLeast(0)
        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val startFormatted = dateFormat.format(Date(startDate))

        return listOf(
            AchievementItem(
                id = "day_1",
                titleRes = com.example.R.string.achievement_first_day,
                descRes = com.example.R.string.achievement_first_day_desc,
                isUnlocked = daysTogether >= 1,
                progressPercent = (daysTogether.toFloat() / 1f).coerceIn(0f, 1f),
                icon = "❤️",
                unlockedDate = if (daysTogether >= 1) startFormatted else null
            ),
            AchievementItem(
                id = "days_7",
                titleRes = com.example.R.string.achievement_7_days,
                descRes = com.example.R.string.achievement_7_days_desc,
                isUnlocked = daysTogether >= 7,
                progressPercent = (daysTogether.toFloat() / 7f).coerceIn(0f, 1f),
                icon = "🌸"
            ),
            AchievementItem(
                id = "days_30",
                titleRes = com.example.R.string.achievement_30_days,
                descRes = com.example.R.string.achievement_30_days_desc,
                isUnlocked = daysTogether >= 30,
                progressPercent = (daysTogether.toFloat() / 30f).coerceIn(0f, 1f),
                icon = "✨"
            ),
            AchievementItem(
                id = "days_100",
                titleRes = com.example.R.string.achievement_100_days,
                descRes = com.example.R.string.achievement_100_days_desc,
                isUnlocked = daysTogether >= 100,
                progressPercent = (daysTogether.toFloat() / 100f).coerceIn(0f, 1f),
                icon = "👑"
            ),
            AchievementItem(
                id = "year_1",
                titleRes = com.example.R.string.achievement_1_year,
                descRes = com.example.R.string.achievement_1_year_desc,
                isUnlocked = daysTogether >= 365,
                progressPercent = (daysTogether.toFloat() / 365f).coerceIn(0f, 1f),
                icon = "💍"
            ),
            AchievementItem(
                id = "first_memory",
                titleRes = com.example.R.string.achievement_first_memory,
                descRes = com.example.R.string.achievement_first_memory_desc,
                isUnlocked = memoriesCount >= 1,
                progressPercent = if (memoriesCount >= 1) 1f else 0f,
                icon = "📸"
            ),
            AchievementItem(
                id = "first_letter",
                titleRes = com.example.R.string.achievement_first_letter,
                descRes = com.example.R.string.achievement_first_letter_desc,
                isUnlocked = lettersCount >= 1,
                progressPercent = if (lettersCount >= 1) 1f else 0f,
                icon = "💬"
            ),
            AchievementItem(
                id = "first_goal",
                titleRes = com.example.R.string.achievement_first_goal,
                descRes = com.example.R.string.achievement_first_goal_desc,
                isUnlocked = goalsDoneCount >= 1,
                progressPercent = if (goalsDoneCount >= 1) 1f else 0f,
                icon = "🎯"
            )
        )
    }

    // Settings
    fun setDarkMode(enabled: Boolean) {
        prefs.edit().putBoolean("pref_dark_mode", enabled).apply()
        _isDarkMode.value = enabled
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("pref_notifications", enabled).apply()
        _isNotificationsEnabled.value = enabled
    }

    fun setLanguage(lang: String) {
        prefs.edit().putString("pref_language", lang).apply()
        _currentLanguage.value = lang
    }

    private fun generateUnique6DigitCode(): String {
        return String.format(Locale.US, "%06d", Random.nextInt(100000, 999999))
    }

    private fun hashPassword(password: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(password.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
