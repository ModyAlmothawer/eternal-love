package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val firebaseUid: String = "",
    val name: String,
    val email: String,
    val passwordHash: String = "",
    val avatarRes: String = "avatar_1",
    val photoUrl: String = "",
    val partnerName: String = "",
    val partnerUid: String = "",
    val partnerPhotoUrl: String = "",
    val relationshipCode: String = "",
    val connectedRelationshipId: String? = null,
    val localRelationshipId: Long? = null,
    val isConnected: Boolean = false,
    val dailyStatus: String = "",
    val dailyStatusEmoji: String = "",
    val statusUpdatedAtMillis: Long = 0L,
    val partnerDailyStatus: String = "",
    val partnerDailyStatusEmoji: String = "",
    val partnerStatusUpdatedAtMillis: Long = 0L,
    val birthdayMillis: Long = 0L,
    val partnerBirthdayMillis: Long = 0L,
    val isOnline: Boolean = false,
    val lastSeenMillis: Long = 0L,
    val partnerIsOnline: Boolean = false,
    val partnerLastSeenMillis: Long = 0L,
    val createdAtMillis: Long = System.currentTimeMillis()
) {
    val dailyEmoji: String get() = dailyStatusEmoji
    val partnerDailyEmoji: String get() = partnerDailyStatusEmoji
}

@Entity(tableName = "relationships")
data class RelationshipEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val firestoreId: String = "",
    val code: String, // 6-digit unique code e.g. "483921"
    val creatorId: String = "",
    val creatorName: String = "",
    val creatorPhoto: String = "",
    val creatorStatus: String = "",
    val creatorStatusEmoji: String = "",
    val partnerId: String? = null,
    val partnerName: String = "",
    val partnerPhoto: String = "",
    val partnerStatus: String = "",
    val partnerStatusEmoji: String = "",
    val startDateMillis: Long = System.currentTimeMillis(),
    val creatorBirthdayMillis: Long = 0L,
    val partnerBirthdayMillis: Long = 0L,
    val relationshipName: String = "قصتنا",
    val status: String = "connected", // "pending", "connected", "disconnected"
    val coverImageRes: String = "default_cover",
    val createdAtMillis: Long = System.currentTimeMillis()
) {
    val invitationCode: String get() = code
}

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey val firestoreId: String = "",
    val id: Long = 0,
    val relationshipId: String = "",
    val title: String,
    val description: String,
    val dateMillis: Long,
    val imageDrawableName: String = "",
    val imageUrl: String = "",
    val location: String = "",
    val createdByName: String = "",
    val createdByUid: String = "",
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "love_letters")
data class LoveLetterEntity(
    @PrimaryKey val firestoreId: String = "",
    val id: Long = 0,
    val relationshipId: String = "",
    val senderUid: String = "",
    val senderName: String,
    val title: String = "",
    val message: String,
    val dateMillis: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val themeColorIndex: Int = 0,
    val replyToId: String? = null,
    val replyToSenderName: String? = null,
    val replyToText: String? = null,
    val isEdited: Boolean = false,
    val mediaType: String = "text", // "text", "voice", "call"
    val mediaUrl: String = "",
    val durationSeconds: Int = 0,
    val reactions: String = "" // e.g. "uid:❤️,uid2:🔥"
)

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey val firestoreId: String = "",
    val id: Long = 0,
    val relationshipId: String = "",
    val title: String,
    val content: String,
    val category: String = "عام",
    val authorName: String = "",
    val authorUid: String = "",
    val updatedAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "goals")
data class GoalEntity(
    @PrimaryKey val firestoreId: String = "",
    val id: Long = 0,
    val relationshipId: String = "",
    val title: String,
    val description: String = "",
    val progress: Int = 0, // 0 to 100
    val isCompleted: Boolean = false,
    val targetDate: String = "",
    val category: String = "عام",
    val createdByName: String = "",
    val createdByUid: String = "",
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "special_dates")
data class SpecialDateEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val firestoreId: String = "",
    val relationshipId: String = "",
    val title: String,
    val dateMillis: Long,
    val type: String = "ذكرى سنوية",
    val iconName: String = "favorite"
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val firestoreId: String = "",
    val relationshipId: String = "",
    val title: String,
    val message: String,
    val timestampMillis: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val iconType: String = "love"
) {
    val createdAtMillis: Long get() = timestampMillis
}

data class AchievementItem(
    val id: String,
    val titleRes: Int,
    val descRes: Int,
    val isUnlocked: Boolean,
    val progressPercent: Float,
    val icon: String,
    val unlockedDate: String? = null
)

data class DailyMoodOption(
    val id: String,
    val emoji: String,
    val titleAr: String,
    val titleEn: String
)

data class CallSession(
    val callId: String = "",
    val relationshipId: String = "",
    val callerUid: String = "",
    val callerName: String = "",
    val calleeUid: String = "",
    val type: String = "voice", // "voice" or "video"
    val status: String = "calling", // "calling", "ringing", "connected", "ended", "declined"
    val createdAtMillis: Long = System.currentTimeMillis(),
    val durationSeconds: Int = 0
)

data class AppUpdateInfo(
    val latestVersionCode: Int = 1,
    val latestVersionName: String = "1.0",
    val downloadUrl: String = "",
    val releaseNotesAr: String = "",
    val isMandatory: Boolean = false
)

