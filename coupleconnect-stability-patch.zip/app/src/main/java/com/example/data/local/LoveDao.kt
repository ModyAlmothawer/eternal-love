package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.data.model.GoalEntity
import com.example.data.model.LoveLetterEntity
import com.example.data.model.MemoryEntity
import com.example.data.model.NoteEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.RelationshipEntity
import com.example.data.model.SpecialDateEntity
import com.example.data.model.UserEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface LoveDao {
    // User operations
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity): Long

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    fun getUserByIdFlow(id: Long): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    suspend fun getUserById(id: Long): UserEntity?

    @Query("SELECT * FROM users WHERE firebaseUid = :uid LIMIT 1")
    suspend fun getUserByFirebaseUid(uid: String): UserEntity?

    // Relationship operations
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRelationship(relationship: RelationshipEntity): Long

    @Update
    suspend fun updateRelationship(relationship: RelationshipEntity)

    @Query("SELECT * FROM relationships WHERE code = :code LIMIT 1")
    suspend fun getRelationshipByCode(code: String): RelationshipEntity?

    @Query("SELECT * FROM relationships WHERE firestoreId = :firestoreId LIMIT 1")
    suspend fun getRelationshipByFirestoreId(firestoreId: String): RelationshipEntity?

    @Query("SELECT * FROM relationships WHERE firestoreId = :firestoreId LIMIT 1")
    fun getRelationshipByFirestoreIdFlow(firestoreId: String): Flow<RelationshipEntity?>

    @Query("SELECT * FROM relationships WHERE id = :id LIMIT 1")
    fun getRelationshipFlow(id: Long): Flow<RelationshipEntity?>

    @Query("SELECT * FROM relationships WHERE id = :id LIMIT 1")
    suspend fun getRelationshipById(id: Long): RelationshipEntity?

    @Query("DELETE FROM relationships WHERE id = :id OR firestoreId = :firestoreId")
    suspend fun deleteRelationship(id: Long, firestoreId: String)

    // Memories
    @Query("SELECT * FROM memories WHERE relationshipId = :relationshipId ORDER BY dateMillis DESC")
    fun getMemoriesFlow(relationshipId: String): Flow<List<MemoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(memory: MemoryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemories(memories: List<MemoryEntity>)

    @Update
    suspend fun updateMemory(memory: MemoryEntity)

    @Query("DELETE FROM memories WHERE firestoreId = :firestoreId")
    suspend fun deleteMemory(firestoreId: String)

    @Query("DELETE FROM memories WHERE relationshipId = :relationshipId")
    suspend fun clearMemories(relationshipId: String)

    @Transaction
    suspend fun syncMemories(relationshipId: String, memories: List<MemoryEntity>) {
        clearMemories(relationshipId)
        insertMemories(memories)
    }

    // Love Letters / Messages (Chat)
    @Query("SELECT * FROM love_letters WHERE relationshipId = :relationshipId ORDER BY dateMillis DESC")
    fun getLoveLettersFlow(relationshipId: String): Flow<List<LoveLetterEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLoveLetter(letter: LoveLetterEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLoveLetters(letters: List<LoveLetterEntity>)

    @Query("UPDATE love_letters SET isRead = 1 WHERE firestoreId = :firestoreId")
    suspend fun markLoveLetterAsRead(firestoreId: String)

    @Query("UPDATE love_letters SET isRead = 1 WHERE relationshipId = :relationshipId")
    suspend fun markAllLoveLettersAsRead(relationshipId: String)

    @Query("UPDATE love_letters SET message = :newText, isEdited = 1 WHERE firestoreId = :firestoreId")
    suspend fun updateLoveLetterMessage(firestoreId: String, newText: String)

    @Query("DELETE FROM love_letters WHERE firestoreId = :firestoreId")
    suspend fun deleteLoveLetter(firestoreId: String)

    @Query("DELETE FROM love_letters WHERE relationshipId = :relationshipId")
    suspend fun clearLoveLetters(relationshipId: String)

    @Transaction
    suspend fun syncLoveLetters(relationshipId: String, letters: List<LoveLetterEntity>) {
        clearLoveLetters(relationshipId)
        insertLoveLetters(letters)
    }

    // Notes
    @Query("SELECT * FROM notes WHERE relationshipId = :relationshipId ORDER BY updatedAtMillis DESC")
    fun getNotesFlow(relationshipId: String): Flow<List<NoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: NoteEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotes(notes: List<NoteEntity>)

    @Update
    suspend fun updateNote(note: NoteEntity)

    @Query("DELETE FROM notes WHERE firestoreId = :firestoreId")
    suspend fun deleteNote(firestoreId: String)

    @Query("DELETE FROM notes WHERE relationshipId = :relationshipId")
    suspend fun clearNotes(relationshipId: String)

    @Transaction
    suspend fun syncNotes(relationshipId: String, notes: List<NoteEntity>) {
        clearNotes(relationshipId)
        insertNotes(notes)
    }

    // Goals
    @Query("SELECT * FROM goals WHERE relationshipId = :relationshipId ORDER BY createdAtMillis DESC")
    fun getGoalsFlow(relationshipId: String): Flow<List<GoalEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoal(goal: GoalEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoals(goals: List<GoalEntity>)

    @Update
    suspend fun updateGoal(goal: GoalEntity)

    @Query("DELETE FROM goals WHERE firestoreId = :firestoreId")
    suspend fun deleteGoal(firestoreId: String)

    @Query("DELETE FROM goals WHERE relationshipId = :relationshipId")
    suspend fun clearGoals(relationshipId: String)

    @Transaction
    suspend fun syncGoals(relationshipId: String, goals: List<GoalEntity>) {
        clearGoals(relationshipId)
        insertGoals(goals)
    }

    // Special Dates
    @Query("SELECT * FROM special_dates WHERE relationshipId = :relationshipId ORDER BY dateMillis ASC")
    fun getSpecialDatesFlow(relationshipId: String): Flow<List<SpecialDateEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSpecialDate(date: SpecialDateEntity): Long

    @Query("DELETE FROM special_dates WHERE id = :id")
    suspend fun deleteSpecialDate(id: Long)

    // Notifications
    @Query("SELECT * FROM notifications WHERE relationshipId = :relationshipId ORDER BY timestampMillis DESC")
    fun getNotificationsFlow(relationshipId: String): Flow<List<NotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity): Long

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :id")
    suspend fun markNotificationAsRead(id: Long)
}
