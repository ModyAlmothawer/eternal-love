package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.LoveLetterEntity
import com.example.ui.components.FloatingHeartsBackground
import com.example.ui.components.GlassCard
import com.example.ui.components.RomanticAvatar
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.DarkBurgundy
import com.example.ui.theme.RomanticGradient
import com.example.ui.theme.RoseGold
import com.example.ui.theme.SoftBlush
import com.example.ui.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LoveLettersScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val letters by viewModel.loveLetters.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val relationship by viewModel.currentRelationship.collectAsState()

    var messageText by remember { mutableStateOf("") }
    var letterToDelete by remember { mutableStateOf<LoveLetterEntity?>(null) }

    val quickPhrases = listOf(
        "وحشتني أوي ❤️",
        "بحبك من كل قلبي ✨",
        "صباح الورد يا روحي 🌸",
        "مساء الحب والسعادة 💕",
        "أنت أجمل نعمة في حياتي 👑"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(RomanticGradient)
            .testTag("chat_screen")
    ) {
        FloatingHeartsBackground(heartCount = 8)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .imePadding()
        ) {
            // Chat Header
            ChatHeader(
                partnerName = currentUser?.partnerName?.ifBlank { stringResource(R.string.my_partner) }
                    ?: relationship?.partnerName?.ifBlank { stringResource(R.string.my_partner) }
                    ?: stringResource(R.string.my_partner),
                partnerPhoto = currentUser?.partnerPhotoUrl ?: "",
                partnerStatus = currentUser?.partnerDailyStatus ?: "",
                partnerStatusEmoji = currentUser?.partnerDailyStatusEmoji ?: "❤️"
            )

            // Messages List (reversed order for standard chat: newest at bottom)
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                reverseLayout = true,
                contentPadding = PaddingValues(vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (letters.isEmpty()) {
                    item {
                        EmptyChatPlaceholder()
                    }
                } else {
                    items(letters, key = { it.firestoreId.ifBlank { it.id.toString() } }) { letter ->
                        val isMe = (letter.senderUid == currentUser?.firebaseUid) ||
                                (letter.senderName == currentUser?.name && letter.senderUid.isBlank())

                        ChatMessageBubble(
                            letter = letter,
                            isMe = isMe,
                            onDeleteClick = {
                                letterToDelete = letter
                            }
                        )
                    }
                }
            }

            // Quick Romantic Phrases Strip
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0x33140510))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(quickPhrases) { phrase ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0x332B1020))
                            .border(1.dp, Color(0x33FF4D79), RoundedCornerShape(16.dp))
                            .clickable {
                                messageText = phrase
                            }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = phrase,
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                            color = SoftBlush
                        )
                    }
                }
            }

            // Chat Input Bar
            ChatInputBar(
                text = messageText,
                onTextChange = { messageText = it },
                onSend = {
                    if (messageText.isNotBlank()) {
                        viewModel.sendLoveLetter(
                            title = "",
                            message = messageText.trim(),
                            themeIndex = 0
                        )
                        messageText = ""
                    }
                }
            )
        }

        // Delete Confirmation Dialog (Real-time delete for both sides)
        if (letterToDelete != null) {
            AlertDialog(
                onDismissRequest = { letterToDelete = null },
                title = {
                    Text(
                        text = stringResource(R.string.delete_message_title),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = SoftBlush
                    )
                },
                text = {
                    Text(
                        text = stringResource(R.string.delete_for_both_warning),
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            letterToDelete?.let {
                                viewModel.deleteLoveLetter(it.firestoreId)
                            }
                            letterToDelete = null
                        }
                    ) {
                        Text(
                            text = stringResource(R.string.delete_for_both),
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                dismissButton = {
                    TextButton(onClick = { letterToDelete = null }) {
                        Text(text = stringResource(R.string.cancel), color = RoseGold)
                    }
                },
                containerColor = Color(0xFF200918),
                shape = RoundedCornerShape(20.dp)
            )
        }
    }
}

@Composable
private fun ChatHeader(
    partnerName: String,
    partnerPhoto: String,
    partnerStatus: String,
    partnerStatusEmoji: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xEE160712))
            .border(1.dp, Color(0x33FF4D79), RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp))
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        RomanticAvatar(
            photoUrl = partnerPhoto,
            avatarRes = "avatar_2",
            size = 44.dp,
            borderColor = CrimsonPrimary,
            borderWidth = 1.5.dp
        )

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = partnerName,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = SoftBlush
            )
            if (partnerStatus.isNotBlank()) {
                Text(
                    text = "$partnerStatusEmoji $partnerStatus",
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = RoseGold
                )
            } else {
                Text(
                    text = stringResource(R.string.chat_header_subtitle),
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = RoseGold.copy(alpha = 0.7f)
                )
            }
        }

        Box(
            modifier = Modifier
                .size(34.dp)
                .background(CrimsonPrimary.copy(alpha = 0.15f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Favorite,
                contentDescription = null,
                tint = CrimsonPrimary,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
private fun ChatMessageBubble(
    letter: LoveLetterEntity,
    isMe: Boolean,
    onDeleteClick: () -> Unit
) {
    val timeFormat = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }
    val formattedTime = remember(letter.dateMillis) { timeFormat.format(Date(letter.dateMillis)) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("chat_message_item"),
        horizontalArrangement = if (isMe) Arrangement.End else Arrangement.Start
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.82f)
                .clip(
                    RoundedCornerShape(
                        topStart = 18.dp,
                        topEnd = 18.dp,
                        bottomStart = if (isMe) 18.dp else 4.dp,
                        bottomEnd = if (isMe) 4.dp else 18.dp
                    )
                )
                .background(
                    if (isMe) Color(0xDD7A1838) else Color(0xDD2A1222)
                )
                .border(
                    1.dp,
                    if (isMe) CrimsonPrimary.copy(alpha = 0.5f) else Color(0x33FF4D79),
                    RoundedCornerShape(
                        topStart = 18.dp,
                        topEnd = 18.dp,
                        bottomStart = if (isMe) 18.dp else 4.dp,
                        bottomEnd = if (isMe) 4.dp else 18.dp
                    )
                )
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Column {
                if (letter.title.isNotBlank()) {
                    Text(
                        text = letter.title,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = RoseGold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                }

                Text(
                    text = letter.message,
                    style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 20.sp),
                    color = SoftBlush
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = formattedTime,
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                        color = Color.White.copy(alpha = 0.5f)
                    )

                    // Delete button (Real-time delete for both sides)
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Delete for both",
                        tint = RoseGold.copy(alpha = 0.6f),
                        modifier = Modifier
                            .size(16.dp)
                            .clickable { onDeleteClick() }
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyChatPlaceholder() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.Favorite,
            contentDescription = null,
            tint = CrimsonPrimary.copy(alpha = 0.4f),
            modifier = Modifier.size(54.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = stringResource(R.string.no_messages_yet),
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = SoftBlush
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = stringResource(R.string.start_chat_prompt),
            style = MaterialTheme.typography.bodySmall,
            color = RoseGold
        )
    }
}

@Composable
private fun ChatInputBar(
    text: String,
    onTextChange: (String) -> Unit,
    onSend: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xEE160712))
            .border(1.dp, Color(0x33FF4D79), RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        OutlinedTextField(
            value = text,
            onValueChange = onTextChange,
            placeholder = {
                Text(
                    text = stringResource(R.string.write_message_hint),
                    color = Color.White.copy(alpha = 0.4f),
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            modifier = Modifier
                .weight(1f)
                .testTag("chat_input_text_field"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = SoftBlush,
                unfocusedTextColor = SoftBlush,
                focusedBorderColor = CrimsonPrimary,
                unfocusedBorderColor = Color(0x33FF4D79),
                focusedContainerColor = Color(0x332B1020),
                unfocusedContainerColor = Color(0x222B1020)
            ),
            shape = RoundedCornerShape(24.dp),
            maxLines = 4
        )

        IconButton(
            onClick = onSend,
            enabled = text.isNotBlank(),
            modifier = Modifier
                .size(46.dp)
                .background(
                    if (text.isNotBlank()) CrimsonPrimary else Color(0x33FF4D79),
                    CircleShape
                )
                .testTag("btn_send_chat_message")
        ) {
            Icon(
                imageVector = Icons.Default.Send,
                contentDescription = "Send",
                tint = SoftBlush,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}
