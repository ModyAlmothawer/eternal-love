package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = CrimsonPrimary,
    onPrimary = Color.White,
    primaryContainer = ModernDarkSurfaceElevated,
    onPrimaryContainer = SoftBlush,
    secondary = RoseGold,
    onSecondary = Color(0xFF1E1408),
    secondaryContainer = Color(0xFF332514),
    onSecondaryContainer = RoseGold,
    tertiary = CrimsonPrimaryLight,
    onTertiary = Color.White,
    background = ModernDarkBackground,
    onBackground = WarmWhite,
    surface = ModernDarkSurface,
    onSurface = WarmWhite,
    surfaceVariant = ModernDarkSurfaceElevated,
    onSurfaceVariant = MutedRose,
    outline = ModernDarkSurfaceBorder
)

@Composable
fun EternalLoveTheme(
    darkTheme: Boolean = true, // Always Dark Romantic Theme
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
