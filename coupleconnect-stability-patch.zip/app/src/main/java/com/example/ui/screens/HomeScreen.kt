package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.AchievementItem
import com.example.data.model.GoalEntity
import com.example.data.model.LoveLetterEntity
import com.example.data.model.MemoryEntity
import com.example.data.model.RelationshipEntity
import com.example.data.model.SpecialDateEntity
import com.example.data.model.UserEntity
import com.example.ui.components.FloatingHeartsBackground
import com.example.ui.components.GlassCard
import com.example.ui.components.RomanticAvatar
import com.example.ui.components.RomanticButton
import com.example.ui.components.RomanticTextField
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.DarkBurgundy
import com.example.ui.theme.DeepMidnight
import com.example.ui.theme.RomanticGradient
import com.example.ui.theme.RoseGold
import com.example.ui.theme.SoftBlush
import com.example.ui.viewmodel.MainTab
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.RelationshipDuration
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val relationship by viewModel.currentRelationship.collectAsState()
    val duration by viewModel.relationshipDuration.collectAsState()
    val memories by viewModel.memories.collectAsState()
    val letters by viewModel.loveLetters.collectAsState()
    val goals by viewModel.goals.collectAsState()
    val specialDates by viewModel.specialDates.collectAsState()
    val achievements by viewModel.achievements.collectAsState()
    val notifications by viewModel.notifications.collectAsState()
    val isUpdatingStatus by viewModel.isUpdatingStatus.collectAsState()

    val unreadNotifications = notifications.count { !it.isRead }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(RomanticGradient)
            .testTag("home_screen")
    ) {
        FloatingHeartsBackground(heartCount = 10)

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(10.dp))
                // Top Header Row
                HomeHeaderRow(
                    relationship = relationship,
                    unreadCount = unreadNotifications,
                    onNotificationsClick = { viewModel.isViewingNotifications.value = true },
                    onSettingsClick = { viewModel.selectTab(MainTab.PROFILE) }
                )
            }

            item {
                // Romantic Couple Avatars & Daily Feelings
                CoupleHeaderCard(
                    user = currentUser,
                    relationship = relationship,
                    onUpdateUserStatus = { viewModel.isUpdatingStatus.value = true }
                )
            }

            item {
                // Live Counter Clock Card
                LiveCounterCard(
                    duration = duration,
                    startDateMillis = relationship?.startDateMillis ?: System.currentTimeMillis()
                )
            }

            item {
                // Quick Navigation Cards (Story, Special Dates, Notes, Achievements)
                QuickFeaturesGrid(
                    onStoryClick = { viewModel.isViewingStory.value = true },
                    onDatesClick = { viewModel.isViewingSpecialDates.value = true },
                    onNotesClick = { viewModel.isViewingNotes.value = true },
                    onMemoriesClick = { viewModel.selectTab(MainTab.MEMORIES) }
                )
            }

            item {
                // Daily Romantic Quote Card
                DailyQuoteCard()
            }

            if (specialDates.isNotEmpty()) {
                item {
                    SpecialDatesPreviewSection(
                        dates = specialDates.take(3),
                        onViewAll = { viewModel.isViewingSpecialDates.value = true }
                    )
                }
            }

            if (achievements.isNotEmpty()) {
                item {
                    AchievementsHorizontalSection(achievements = achievements)
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }

    if (isUpdatingStatus) {
        DailyStatusDialog(
            currentStatus = currentUser?.dailyStatus ?: "",
            currentEmoji = currentUser?.dailyStatusEmoji ?: "❤️",
            onDismiss = { viewModel.isUpdatingStatus.value = false },
            onConfirm = { status, emoji ->
                viewModel.updateDailyStatus(status, emoji)
            }
        )
    }
}

@Composable
private fun HomeHeaderRow(
    relationship: RelationshipEntity?,
    unreadCount: Int,
    onNotificationsClick: () -> Unit,
    onSettingsClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = relationship?.relationshipName?.ifBlank { stringResource(R.string.our_story) }
                    ?: stringResource(R.string.our_story),
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                color = SoftBlush
            )
            Text(
                text = stringResource(R.string.home_welcome_phrase),
                style = MaterialTheme.typography.bodySmall,
                color = RoseGold
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            IconButton(
                onClick = onNotificationsClick,
                modifier = Modifier
                    .size(42.dp)
                    .background(Color(0x332B1020), CircleShape)
                    .border(1.dp, Color(0x33FF4D79), CircleShape)
                    .testTag("btn_home_notifications")
            ) {
                BadgedBox(
                    badge = {
                        if (unreadCount > 0) {
                            Badge(
                                containerColor = CrimsonPrimary,
                                contentColor = SoftBlush
                            ) {
                                Text(text = "$unreadCount")
                            }
                        }
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = "Notifications",
                        tint = SoftBlush,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            IconButton(
                onClick = onSettingsClick,
                modifier = Modifier
                    .size(42.dp)
                    .background(Color(0x332B1020), CircleShape)
                    .border(1.dp, Color(0x33FF4D79), CircleShape)
                    .testTag("btn_home_settings")
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = SoftBlush,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
private fun CoupleHeaderCard(
    user: UserEntity?,
    relationship: RelationshipEntity?,
    onUpdateUserStatus: () -> Unit
) {
    val isCreator = (user?.firebaseUid == relationship?.creatorId)
    val userName = user?.name ?: stringResource(R.string.you)
    val userPhoto = user?.photoUrl ?: ""
    val userAvatar = user?.avatarRes ?: "avatar_1"
    val userStatus = user?.dailyStatus ?: ""
    val userEmoji = user?.dailyStatusEmoji ?: "❤️"

    val partnerName = if (isCreator) {
        relationship?.partnerName?.ifBlank { stringResource(R.string.my_partner) }
            ?: user?.partnerName?.ifBlank { stringResource(R.string.my_partner) }
            ?: stringResource(R.string.my_partner)
    } else {
        relationship?.creatorName?.ifBlank { stringResource(R.string.my_partner) }
            ?: user?.partnerName?.ifBlank { stringResource(R.string.my_partner) }
            ?: stringResource(R.string.my_partner)
    }

    val partnerPhoto = if (isCreator) {
        relationship?.partnerPhoto?.ifBlank { user?.partnerPhotoUrl ?: "" } ?: ""
    } else {
        relationship?.creatorPhoto?.ifBlank { user?.partnerPhotoUrl ?: "" } ?: ""
    }

    val partnerStatus = if (isCreator) {
        relationship?.partnerStatus?.ifBlank { user?.partnerDailyStatus ?: "" } ?: ""
    } else {
        relationship?.creatorStatus?.ifBlank { user?.partnerDailyStatus ?: "" } ?: ""
    }

    val partnerEmoji = if (isCreator) {
        relationship?.partnerStatusEmoji?.ifBlank { user?.partnerDailyStatusEmoji ?: "❤️" } ?: "❤️"
    } else {
        relationship?.creatorStatusEmoji?.ifBlank { user?.partnerDailyStatusEmoji ?: "❤️" } ?: "❤️"
    }

    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // User Column
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    RomanticAvatar(
                        photoUrl = userPhoto,
                        avatarRes = userAvatar,
                        size = 68.dp,
                        borderColor = CrimsonPrimary,
                        borderWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = userName,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = SoftBlush,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    // User Status Badge (Clickable to edit)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0x33FF4D79))
                            .border(1.dp, Color(0x44FF4D79), RoundedCornerShape(12.dp))
                            .clickable { onUpdateUserStatus() }
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(text = userEmoji, fontSize = 13.sp)
                        Text(
                            text = userStatus.ifBlank { stringResource(R.string.tap_to_set_status) },
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = SoftBlush,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit status",
                            tint = RoseGold,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }

                // Heart Bridge
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(horizontal = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(CrimsonPrimary.copy(alpha = 0.2f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Favorite,
                            contentDescription = null,
                            tint = CrimsonPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // Partner Column
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    RomanticAvatar(
                        photoUrl = partnerPhoto,
                        avatarRes = "avatar_2",
                        size = 68.dp,
                        borderColor = RoseGold,
                        borderWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = partnerName,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = RoseGold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    // Partner Status Badge
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0x33D4AF37))
                            .border(1.dp, Color(0x44D4AF37), RoundedCornerShape(12.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(text = partnerEmoji, fontSize = 13.sp)
                        Text(
                            text = partnerStatus.ifBlank { stringResource(R.string.waiting_partner_status) },
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = SoftBlush,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LiveCounterCard(
    duration: RelationshipDuration,
    startDateMillis: Long
) {
    val dateFormat = remember { SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()) }
    val formattedStartDate = remember(startDateMillis) { dateFormat.format(Date(startDateMillis)) }

    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        backgroundColor = Color(0xDD1B0915)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Favorite,
                    contentDescription = null,
                    tint = CrimsonPrimary,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = stringResource(R.string.together_for),
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = RoseGold
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Main Counter Units (Years, Months, Days)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                CounterUnitBox(
                    value = duration.years.toString(),
                    label = stringResource(R.string.years)
                )
                CounterUnitBox(
                    value = duration.months.toString(),
                    label = stringResource(R.string.months)
                )
                CounterUnitBox(
                    value = duration.days.toString(),
                    label = stringResource(R.string.days)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Live Seconds & Minutes Strip
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0x332B1020))
                    .border(1.dp, Color(0x33FF4D79), RoundedCornerShape(14.dp))
                    .padding(vertical = 10.dp, horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = String.format("%02d", duration.hours),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = SoftBlush
                    )
                    Text(
                        text = stringResource(R.string.hours_short),
                        style = MaterialTheme.typography.bodySmall,
                        color = RoseGold
                    )
                }

                Text(text = "•", color = CrimsonPrimary)

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = String.format("%02d", duration.minutes),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = SoftBlush
                    )
                    Text(
                        text = stringResource(R.string.minutes_short),
                        style = MaterialTheme.typography.bodySmall,
                        color = RoseGold
                    )
                }

                Text(text = "•", color = CrimsonPrimary)

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = String.format("%02d", duration.seconds),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = CrimsonPrimary
                    )
                    Text(
                        text = stringResource(R.string.seconds_short),
                        style = MaterialTheme.typography.bodySmall,
                        color = RoseGold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = stringResource(R.string.since_date, formattedStartDate),
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                color = Color.White.copy(alpha = 0.6f)
            )
        }
    }
}

@Composable
private fun CounterUnitBox(value: String, label: String) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x442B1020))
            .border(1.dp, Color(0x33FF4D79), RoundedCornerShape(16.dp))
            .padding(horizontal = 20.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = value,
            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold),
            color = SoftBlush
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
            color = RoseGold
        )
    }
}

@Composable
private fun QuickFeaturesGrid(
    onStoryClick: () -> Unit,
    onDatesClick: () -> Unit,
    onNotesClick: () -> Unit,
    onMemoriesClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        QuickActionCard(
            title = stringResource(R.string.our_story),
            icon = Icons.Default.MenuBook,
            color = CrimsonPrimary,
            onClick = onStoryClick,
            modifier = Modifier.weight(1f)
        )
        QuickActionCard(
            title = stringResource(R.string.special_dates),
            icon = Icons.Default.CalendarMonth,
            color = RoseGold,
            onClick = onDatesClick,
            modifier = Modifier.weight(1f)
        )
        QuickActionCard(
            title = stringResource(R.string.notes),
            icon = Icons.Default.FormatQuote,
            color = Color(0xFFFF7597),
            onClick = onNotesClick,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun QuickActionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    GlassCard(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .background(color.copy(alpha = 0.2f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = color,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, fontSize = 11.sp),
                color = SoftBlush,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun DailyQuoteCard() {
    val quotes = listOf(
        "أنت لست في قلبي، بل قلبي أصبح أنت.",
        "وفي عينيك أرى كل أوطاني.",
        "حبك هو النعمة التي أشكر الله عليها كل يوم.",
        "كل لحظة معك هي حكاية لا تنتهي."
    )
    val randomQuote = remember { quotes.random() }

    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        backgroundColor = Color(0x332B1020)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = Icons.Default.FormatQuote,
                contentDescription = null,
                tint = RoseGold,
                modifier = Modifier.size(28.dp)
            )
            Text(
                text = randomQuote,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                    lineHeight = 18.sp
                ),
                color = SoftBlush,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun SpecialDatesPreviewSection(
    dates: List<SpecialDateEntity>,
    onViewAll: () -> Unit
) {
    val sdf = remember { SimpleDateFormat("dd MMMM", Locale.getDefault()) }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = stringResource(R.string.special_dates),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = SoftBlush
            )
            Text(
                text = stringResource(R.string.view_all),
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                color = RoseGold,
                modifier = Modifier.clickable { onViewAll() }
            )
        }

        dates.forEach { date ->
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(RoseGold.copy(alpha = 0.2f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CalendarMonth,
                                contentDescription = null,
                                tint = RoseGold,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Column {
                            Text(
                                text = date.title,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = SoftBlush
                            )
                            Text(
                                text = sdf.format(Date(date.dateMillis)),
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                color = Color.White.copy(alpha = 0.6f)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AchievementsHorizontalSection(achievements: List<AchievementItem>) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = stringResource(R.string.achievements),
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = SoftBlush
        )

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(achievements) { item ->
                GlassCard(
                    modifier = Modifier.width(130.dp),
                    shape = RoundedCornerShape(18.dp),
                    backgroundColor = if (item.isUnlocked) Color(0x442B1020) else Color(0x22150810)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = item.icon,
                            fontSize = 28.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = stringResource(item.titleRes),
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center
                            ),
                            color = if (item.isUnlocked) SoftBlush else Color.White.copy(alpha = 0.4f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (item.isUnlocked) stringResource(R.string.achievement_unlocked) else stringResource(R.string.achievement_locked),
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 9.sp),
                            color = if (item.isUnlocked) CrimsonPrimary else RoseGold.copy(alpha = 0.5f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DailyStatusDialog(
    currentStatus: String,
    currentEmoji: String,
    onDismiss: () -> Unit,
    onConfirm: (String, String) -> Unit
) {
    var statusText by remember { mutableStateOf(currentStatus) }
    var selectedEmoji by remember { mutableStateOf(currentEmoji) }

    val emojis = listOf("❤️", "🥰", "🌸", "✨", "👑", "🥺", "☕", "🎉", "💍", "🕊️")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = stringResource(R.string.update_daily_status),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = SoftBlush
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(
                    text = stringResource(R.string.choose_status_emoji),
                    style = MaterialTheme.typography.bodySmall,
                    color = RoseGold
                )

                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(emojis) { emoji ->
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(
                                    if (selectedEmoji == emoji) CrimsonPrimary.copy(alpha = 0.4f) else Color(0x332B1020)
                                )
                                .border(
                                    1.dp,
                                    if (selectedEmoji == emoji) CrimsonPrimary else Color(0x22FF4D79),
                                    CircleShape
                                )
                                .clickable { selectedEmoji = emoji },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = emoji, fontSize = 20.sp)
                        }
                    }
                }

                RomanticTextField(
                    value = statusText,
                    onValueChange = { statusText = it },
                    label = stringResource(R.string.status_text_label),
                    placeholder = stringResource(R.string.status_placeholder),
                    leadingIcon = Icons.Default.EmojiEmotions,
                    testTag = "input_daily_status"
                )
            }
        },
        confirmButton = {
            RomanticButton(
                text = stringResource(R.string.save),
                onClick = { onConfirm(statusText.trim(), selectedEmoji) },
                modifier = Modifier.padding(horizontal = 8.dp),
                testTag = "btn_save_daily_status"
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(text = stringResource(R.string.cancel), color = RoseGold)
            }
        },
        containerColor = Color(0xFF200918),
        shape = RoundedCornerShape(20.dp)
    )
}
