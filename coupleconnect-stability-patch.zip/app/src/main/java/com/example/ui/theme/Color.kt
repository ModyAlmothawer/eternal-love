package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Modern Dark Palette (Clean, Charcoal Slate, Romantic Crimson & Rose Gold)
val ModernDarkBackground = Color(0xFF0F040C)
val ModernDarkSurface = Color(0xFF180814)
val ModernDarkSurfaceElevated = Color(0xFF220C1D)
val ModernDarkSurfaceBorder = Color(0xFF38142F)

val DarkBurgundy = Color(0xFF220718)
val DeepMidnight = Color(0xFF0F040C)

// Modern Primary Coral/Rose (Refined, Elegant)
val CrimsonPrimary = Color(0xFFE54861)
val CrimsonPrimaryLight = Color(0xFFF0657D)
val CrimsonPrimaryDark = Color(0xFFC7364D)

// Warm Champagne & Accent
val RoseGold = Color(0xFFE8BA8B)
val RoseGoldDark = Color(0xFFB07D4F)
val SoftBlush = Color(0xFFFDE8EC)
val WarmWhite = Color(0xFFF9FAFB)
val MutedRose = Color(0xFF9CA3AF)
val GlassCardBackground = Color(0x22181A22)
val GlassCardBorder = Color(0x332E3240)

// Modern Gradients
val ModernBackgroundGradient = Brush.verticalGradient(
    colors = listOf(
        Color(0xFF1B0515),
        Color(0xFF10030C),
        Color(0xFF080206)
    )
)
val RomanticGradient = ModernBackgroundGradient

val ModernCardGradient = Brush.linearGradient(
    colors = listOf(
        Color(0x33222530),
        Color(0x1A181A22)
    )
)
val RomanticCardGradient = ModernCardGradient

val CrimsonButtonGradient = Brush.horizontalGradient(
    colors = listOf(
        Color(0xFFE54861),
        Color(0xFFF0657D)
    )
)

val GoldAccentGradient = Brush.horizontalGradient(
    colors = listOf(
        Color(0xFFE8BA8B),
        Color(0xFFD49B6A)
    )
)
