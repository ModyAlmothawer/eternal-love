package com.example.ui.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.AchievementItem
import com.example.data.model.GoalEntity
import com.example.data.model.LoveLetterEntity
import com.example.data.model.MemoryEntity
import com.example.data.model.NoteEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.RelationshipEntity
import com.example.data.model.SpecialDateEntity
import com.example.data.model.UserEntity
import com.example.data.repository.LoveRepository
import com.example.util.NotificationHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.TimeZone

data class RelationshipDuration(
    val years: Long = 0,
    val months: Long = 0,
    val days: Long = 0,
    val hours: Long = 0,
    val minutes: Long = 0,
    val seconds: Long = 0,
    val totalDays: Long = 0,
    val totalMonths: Long = 0,
    val totalHours: Long = 0
)

enum class MainTab {
    HOME,
    MEMORIES,
    LETTERS, // Chat / الدردشة
    GOALS,
    PROFILE
}

class MainViewModel(
    private val repository: LoveRepository
) : ViewModel() {

    val isDarkMode: StateFlow<Boolean> = repository.isDarkMode
    val currentLanguage: StateFlow<String> = repository.currentLanguage
    val partnerIsTyping: StateFlow<Boolean> = repository.partnerIsTyping

    val currentUser: StateFlow<UserEntity?> = repository.currentUserFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val currentRelationship: StateFlow<RelationshipEntity?> = repository.currentRelationshipFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _currentTab = MutableStateFlow(MainTab.HOME)
    val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

    // Real-time dynamic counter ticker
    private val _relationshipDuration = MutableStateFlow(RelationshipDuration())
    val relationshipDuration: StateFlow<RelationshipDuration> = _relationshipDuration.asStateFlow()

    // Active sub-screen/dialog states
    val selectedMemory = MutableStateFlow<MemoryEntity?>(null)
    val selectedLoveLetter = MutableStateFlow<LoveLetterEntity?>(null)
    val isWritingLetter = MutableStateFlow(false)
    val isAddingMemory = MutableStateFlow(false)
    val isAddingNote = MutableStateFlow(false)
    val isAddingGoal = MutableStateFlow(false)
    val isAddingSpecialDate = MutableStateFlow(false)
    val isViewingNotes = MutableStateFlow(false)
    val isViewingSpecialDates = MutableStateFlow(false)
    val isViewingNotifications = MutableStateFlow(false)
    val isViewingStory = MutableStateFlow(false)
    val isEditingProfile = MutableStateFlow(false)
    val isEditingRelationship = MutableStateFlow(false)
    val showDisconnectConfirmation = MutableStateFlow(false)
    val isUpdatingStatus = MutableStateFlow(false)

    // Data streams based on connected relationship
    val memories: StateFlow<List<MemoryEntity>> = currentRelationship.flatMapLatest { rel ->
        val firestoreId = rel?.firestoreId?.takeIf { it.isNotBlank() } ?: ""
        val localId = rel?.id?.toString() ?: ""
        val primaryId = firestoreId.ifBlank { localId }
        if (primaryId.isNotBlank()) repository.getMemories(primaryId, localId) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val loveLetters: StateFlow<List<LoveLetterEntity>> = currentRelationship.flatMapLatest { rel ->
        val firestoreId = rel?.firestoreId?.takeIf { it.isNotBlank() } ?: ""
        val localId = rel?.id?.toString() ?: ""
        val primaryId = firestoreId.ifBlank { localId }
        if (primaryId.isNotBlank()) repository.getLoveLetters(primaryId, localId) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notes: StateFlow<List<NoteEntity>> = currentRelationship.flatMapLatest { rel ->
        val relId = rel?.firestoreId?.takeIf { it.isNotBlank() } ?: rel?.id?.toString()
        if (relId != null) repository.getNotes(relId) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val goals: StateFlow<List<GoalEntity>> = currentRelationship.flatMapLatest { rel ->
        val relId = rel?.firestoreId?.takeIf { it.isNotBlank() } ?: rel?.id?.toString()
        if (relId != null) repository.getGoals(relId) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val specialDates: StateFlow<List<SpecialDateEntity>> = currentRelationship.flatMapLatest { rel ->
        val relId = rel?.firestoreId?.takeIf { it.isNotBlank() } ?: rel?.id?.toString()
        if (relId != null) repository.getSpecialDates(relId) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<NotificationEntity>> = currentRelationship.flatMapLatest { rel ->
        val relId = rel?.firestoreId?.takeIf { it.isNotBlank() } ?: rel?.id?.toString()
        if (relId != null) repository.getNotifications(relId) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val achievements: StateFlow<List<AchievementItem>> = combine(
        currentRelationship,
        loveLetters,
        memories,
        goals
    ) { rel, letters, mems, gls ->
        repository.getAchievements(
            relationship = rel,
            memoriesCount = mems.size,
            lettersCount = letters.size,
            goalsDoneCount = gls.count { it.isCompleted }
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Start real-time ticker
        viewModelScope.launch {
            while (isActive) {
                updateDuration()
                delay(1000)
            }
        }
    }

    private fun updateDuration() {
        val rel = currentRelationship.value ?: return
        val startMillis = rel.startDateMillis
        val nowMillis = System.currentTimeMillis()

        if (nowMillis < startMillis) {
            _relationshipDuration.value = RelationshipDuration()
            return
        }

        val startCal = Calendar.getInstance(TimeZone.getDefault()).apply { timeInMillis = startMillis }
        val nowCal = Calendar.getInstance(TimeZone.getDefault()).apply { timeInMillis = nowMillis }

        var years = nowCal.get(Calendar.YEAR) - startCal.get(Calendar.YEAR)
        var months = nowCal.get(Calendar.MONTH) - startCal.get(Calendar.MONTH)
        var days = nowCal.get(Calendar.DAY_OF_MONTH) - startCal.get(Calendar.DAY_OF_MONTH)

        if (days < 0) {
            months -= 1
            val tempCal = Calendar.getInstance().apply {
                timeInMillis = nowMillis
                add(Calendar.MONTH, -1)
            }
            days += tempCal.getActualMaximum(Calendar.DAY_OF_MONTH)
        }

        if (months < 0) {
            years -= 1
            months += 12
        }

        val totalDiffMillis = nowMillis - startMillis
        val totalDays = totalDiffMillis / (1000 * 60 * 60 * 24)
        val totalHours = totalDiffMillis / (1000 * 60 * 60)
        val totalMonths = (years * 12) + months

        val hours = (totalDiffMillis / (1000 * 60 * 60)) % 24
        val minutes = (totalDiffMillis / (1000 * 60)) % 60
        val seconds = (totalDiffMillis / 1000) % 60

        _relationshipDuration.value = RelationshipDuration(
            years = maxOf(0, years.toLong()),
            months = maxOf(0, months.toLong()),
            days = maxOf(0, days.toLong()),
            hours = maxOf(0, hours),
            minutes = maxOf(0, minutes),
            seconds = maxOf(0, seconds),
            totalDays = maxOf(0, totalDays),
            totalMonths = maxOf(0, totalMonths.toLong()),
            totalHours = maxOf(0, totalHours)
        )
    }

    fun selectTab(tab: MainTab) {
        _currentTab.value = tab
    }

    fun toggleDarkMode(enabled: Boolean) {
        viewModelScope.launch {
            repository.setDarkMode(enabled)
        }
    }

    fun setLanguage(lang: String) {
        viewModelScope.launch {
            repository.setLanguage(lang)
        }
    }

    // Daily Mood / Status
    fun updateDailyStatus(status: String, emoji: String) {
        viewModelScope.launch {
            repository.updateDailyStatus(status, emoji)
            isUpdatingStatus.value = false
        }
    }

    val isUploadingMemory = MutableStateFlow(false)

    fun addMemory(
        title: String,
        description: String,
        dateMillis: Long,
        imageUri: Uri?,
        location: String
    ) {
        isAddingMemory.value = false
        val rel = currentRelationship.value
        val relId = rel?.firestoreId?.takeIf { it.isNotBlank() }
            ?: (currentUser.value?.connectedRelationshipId?.takeIf { it.isNotBlank() } ?: "")
        val user = currentUser.value
        val authorName = user?.name ?: ""

        viewModelScope.launch {
            isUploadingMemory.value = true
            try {
                repository.addMemory(
                    relationshipId = relId,
                    title = title,
                    description = description,
                    dateMillis = dateMillis,
                    imageUri = imageUri,
                    location = location,
                    authorName = authorName
                )
            } finally {
                isUploadingMemory.value = false
            }
        }
    }

    fun deleteMemory(firestoreId: String) {
        val rel = currentRelationship.value
        val relId = rel?.firestoreId?.takeIf { it.isNotBlank() }
            ?: (currentUser.value?.connectedRelationshipId?.takeIf { it.isNotBlank() } ?: "")
        viewModelScope.launch {
            repository.deleteMemory(firestoreId, relId)
            if (selectedMemory.value?.firestoreId == firestoreId) {
                selectedMemory.value = null
            }
        }
    }

    fun enterChatScreen(context: Context) {
        val rel = currentRelationship.value
        val user = currentUser.value
        val relId = rel?.firestoreId?.takeIf { it.isNotBlank() }
            ?: (user?.connectedRelationshipId?.takeIf { it.isNotBlank() } ?: (rel?.id?.toString() ?: ""))
        NotificationHelper.isChatScreenActive = true
        NotificationHelper.activeChatRelationshipId = relId
        NotificationHelper.clearChatNotifications(context)
        viewModelScope.launch {
            if (relId.isNotBlank()) {
                repository.markAllMessagesAsRead(relId)
            }
        }
    }

    fun leaveChatScreen() {
        NotificationHelper.isChatScreenActive = false
        NotificationHelper.activeChatRelationshipId = null
        viewModelScope.launch {
            repository.setTyping(false)
        }
    }

    fun markAllMessagesAsRead() {
        val rel = currentRelationship.value
        val user = currentUser.value
        val relId = rel?.firestoreId?.takeIf { it.isNotBlank() }
            ?: (user?.connectedRelationshipId?.takeIf { it.isNotBlank() } ?: (rel?.id?.toString() ?: ""))
        if (relId.isNotBlank()) {
            viewModelScope.launch {
                repository.markAllMessagesAsRead(relId)
            }
        }
    }

    fun setTyping(isTyping: Boolean) {
        viewModelScope.launch {
            repository.setTyping(isTyping)
        }
    }

    fun sendLoveLetter(
        title: String,
        message: String,
        themeIndex: Int,
        replyToId: String? = null,
        replyToSenderName: String? = null,
        replyToText: String? = null
    ) {
        val rel = currentRelationship.value ?: return
        val relId = rel.firestoreId.takeIf { it.isNotBlank() } ?: rel.id.toString()
        val user = currentUser.value ?: return
        viewModelScope.launch {
            repository.sendLoveLetter(
                relationshipId = relId,
                senderName = user.name,
                title = title,
                message = message,
                themeIndex = themeIndex,
                replyToId = replyToId,
                replyToSenderName = replyToSenderName,
                replyToText = replyToText
            )
            repository.setTyping(false)
            isWritingLetter.value = false
        }
    }

    fun editLoveLetter(messageId: String, newText: String) {
        if (messageId.isBlank() || newText.isBlank()) return
        val rel = currentRelationship.value
        val relId = rel?.firestoreId ?: ""
        viewModelScope.launch {
            repository.editLoveLetter(relId, messageId, newText)
        }
    }

    fun updateMyBirthday(myBirthdayMillis: Long) {
        viewModelScope.launch {
            repository.updateMyBirthday(myBirthdayMillis)
        }
    }

    fun updateBirthdays(myBirthdayMillis: Long? = null, partnerBirthdayMillis: Long? = null) {
        viewModelScope.launch {
            repository.updateBirthdays(myBirthdayMillis, partnerBirthdayMillis)
        }
    }

    fun openLoveLetter(letter: LoveLetterEntity) {
        selectedLoveLetter.value = letter
        markLoveLetterAsRead(letter.firestoreId)
    }

    fun markLoveLetterAsRead(firestoreId: String) {
        if (firestoreId.isBlank()) return
        val rel = currentRelationship.value
        val relId = rel?.firestoreId ?: ""
        viewModelScope.launch {
            repository.markLoveLetterAsRead(firestoreId, relId)
        }
    }

    fun deleteLoveLetter(firestoreId: String) {
        val rel = currentRelationship.value
        val relId = rel?.firestoreId ?: ""
        viewModelScope.launch {
            repository.deleteLoveLetter(firestoreId, relId)
            if (selectedLoveLetter.value?.firestoreId == firestoreId) {
                selectedLoveLetter.value = null
            }
        }
    }

    fun addNote(title: String, content: String, category: String) {
        val rel = currentRelationship.value ?: return
        val relId = rel.firestoreId.takeIf { it.isNotBlank() } ?: rel.id.toString()
        val user = currentUser.value ?: return
        viewModelScope.launch {
            repository.addNote(
                relationshipId = relId,
                title = title,
                content = content,
                category = category,
                authorName = user.name
            )
            isAddingNote.value = false
        }
    }

    fun deleteNote(firestoreId: String) {
        val rel = currentRelationship.value
        val relId = rel?.firestoreId ?: ""
        viewModelScope.launch {
            repository.deleteNote(firestoreId, relId)
        }
    }

    fun addGoal(title: String, description: String, targetDate: String, category: String) {
        val rel = currentRelationship.value ?: return
        val relId = rel.firestoreId.takeIf { it.isNotBlank() } ?: rel.id.toString()
        viewModelScope.launch {
            repository.addGoal(
                relationshipId = relId,
                title = title,
                description = description,
                targetDate = targetDate,
                category = category
            )
            isAddingGoal.value = false
        }
    }

    fun updateGoalProgress(goal: GoalEntity, progress: Int, completed: Boolean) {
        viewModelScope.launch {
            repository.updateGoalProgress(goal, progress, completed)
        }
    }

    fun deleteGoal(firestoreId: String) {
        val rel = currentRelationship.value
        val relId = rel?.firestoreId ?: ""
        viewModelScope.launch {
            repository.deleteGoal(firestoreId, relId)
        }
    }

    fun addSpecialDate(title: String, dateMillis: Long, type: String) {
        val rel = currentRelationship.value ?: return
        val relId = rel.firestoreId.takeIf { it.isNotBlank() } ?: rel.id.toString()
        viewModelScope.launch {
            repository.addSpecialDate(
                relationshipId = relId,
                title = title,
                dateMillis = dateMillis,
                type = type,
                iconName = "calendar"
            )
            isAddingSpecialDate.value = false
        }
    }

    fun deleteSpecialDate(id: Long) {
        viewModelScope.launch {
            repository.deleteSpecialDate(id)
        }
    }

    fun updateProfile(name: String, avatarRes: String, photoUrl: String = "") {
        viewModelScope.launch {
            val currentPhoto = currentUser.value?.photoUrl ?: ""
            val finalPhotoUrl = if (photoUrl.isNotBlank()) photoUrl else currentPhoto
            repository.updateUserProfile(name, avatarRes, finalPhotoUrl)
            isEditingProfile.value = false
        }
    }

    fun uploadProfileImage(uri: Uri) {
        viewModelScope.launch {
            repository.uploadProfileImageUri(uri)
        }
    }

    fun updateRelationship(name: String, startDateMillis: Long) {
        viewModelScope.launch {
            repository.updateRelationshipDetails(name, startDateMillis)
            isEditingRelationship.value = false
        }
    }

    fun disconnectRelationship(onDisconnected: () -> Unit) {
        viewModelScope.launch {
            repository.disconnectRelationship()
            showDisconnectConfirmation.value = false
            onDisconnected()
        }
    }

    // --- Voice Notes ---
    fun sendVoiceNote(audioBytes: ByteArray, durationSeconds: Int) {
        val rel = currentRelationship.value ?: return
        val relId = rel.firestoreId.takeIf { it.isNotBlank() } ?: rel.id.toString()
        val user = currentUser.value ?: return
        viewModelScope.launch {
            repository.sendVoiceMessage(
                relationshipId = relId,
                senderName = user.name,
                audioBytes = audioBytes,
                durationSeconds = durationSeconds
            )
        }
    }

    // --- Reactions ---
    fun toggleMessageReaction(messageId: String, emoji: String) {
        val rel = currentRelationship.value ?: return
        val relId = rel.firestoreId.takeIf { it.isNotBlank() } ?: rel.id.toString()
        viewModelScope.launch {
            repository.toggleMessageReaction(relId, messageId, emoji)
        }
    }

    // --- Presence ---
    fun setOnlinePresence(isOnline: Boolean) {
        viewModelScope.launch {
            repository.setUserPresence(isOnline)
        }
    }

    // --- App Update Check ---
    val appUpdateInfo = MutableStateFlow<com.example.data.model.AppUpdateInfo?>(null)

    fun checkForAppUpdates() {
        viewModelScope.launch {
            val info = repository.checkAppUpdate()
            appUpdateInfo.value = info
        }
    }

    // --- Calling (WebRTC Audio & Video) ---
    val webRtcManager = repository.webRtcManager
    val callState = webRtcManager.callState
    val activeCallSession = webRtcManager.activeSession
    val activeCall = activeCallSession
    val incomingCall = repository.incomingCall
    val localVideoTrack = webRtcManager.localVideo
    val remoteVideoTrack = webRtcManager.remoteVideo
    val isMicMuted = webRtcManager.isMicMuted
    val isCameraEnabled = webRtcManager.isCameraEnabled
    val isSpeakerphoneOn = webRtcManager.isSpeakerphoneOn
    val callDurationSeconds = webRtcManager.callDurationSeconds
    val callStatusMessage = webRtcManager.statusMessage

    fun initiateCall(type: String) {
        viewModelScope.launch {
            val user = currentUser.value
            val rel = currentRelationship.value
            val currentUid = user?.firebaseUid ?: ""
            val relId = user?.connectedRelationshipId?.takeIf { it.isNotBlank() && !it.all { c -> c.isDigit() } }
                ?: rel?.firestoreId?.takeIf { it.isNotBlank() }
                ?: user?.connectedRelationshipId
                ?: ""

            if (relId.isBlank()) {
                android.util.Log.w("MainViewModel", "Cannot initiate call: relId is blank")
                return@launch
            }

            val partnerUid = if (!user?.partnerUid.isNullOrBlank()) {
                user?.partnerUid ?: ""
            } else if (rel != null) {
                if (currentUid == rel.creatorId) rel.partnerId ?: "" else rel.creatorId
            } else {
                ""
            }

            val callerName = user?.name?.ifBlank { "أنا" } ?: "أنا"

            webRtcManager.startCall(
                relationshipId = relId,
                callerUid = currentUid,
                callerName = callerName,
                calleeUid = partnerUid,
                type = type
            )
        }
    }

    fun acceptCall(session: com.example.data.model.CallSession) {
        viewModelScope.launch {
            webRtcManager.acceptCall(session)
            repository.clearIncomingCall()
        }
    }

    fun declineIncomingCall(session: com.example.data.model.CallSession) {
        viewModelScope.launch {
            val user = currentUser.value
            val relId = user?.connectedRelationshipId ?: ""
            if (relId.isNotBlank()) {
                repository.updateCallStatus(session.callId, "declined")
            }
            webRtcManager.endCall()
            repository.clearIncomingCall()
        }
    }

    fun endCall() {
        webRtcManager.endCall()
        repository.clearIncomingCall()
    }

    fun toggleMic() {
        webRtcManager.toggleMic()
    }

    fun toggleCamera() {
        webRtcManager.toggleCamera()
    }

    fun switchCamera() {
        webRtcManager.switchCamera()
    }

    fun toggleSpeakerphone() {
        webRtcManager.toggleSpeakerphone()
    }
}

class MainViewModelFactory(private val repository: LoveRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return MainViewModel(repository) as T
    }
}
