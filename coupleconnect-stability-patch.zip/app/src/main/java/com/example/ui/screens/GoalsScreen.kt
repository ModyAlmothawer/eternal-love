package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.TrackChanges
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.GoalEntity
import com.example.ui.components.FloatingHeartsBackground
import com.example.ui.components.GlassCard
import com.example.ui.components.RomanticButton
import com.example.ui.components.RomanticTextField
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.RomanticGradient
import com.example.ui.theme.RoseGold
import com.example.ui.theme.SoftBlush
import com.example.ui.viewmodel.MainViewModel

@Composable
fun GoalsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val goals by viewModel.goals.collectAsState()
    val isAddingGoal by viewModel.isAddingGoal.collectAsState()
    var goalToDelete by remember { mutableStateOf<GoalEntity?>(null) }

    val completedCount = goals.count { it.isCompleted }
    val totalCount = goals.size
    val overallProgress = if (totalCount > 0) completedCount.toFloat() / totalCount else 0f

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(RomanticGradient)
            .testTag("goals_screen")
    ) {
        FloatingHeartsBackground(heartCount = 8)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // Screen Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = stringResource(R.string.tab_goals),
                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                        color = SoftBlush
                    )
                    Text(
                        text = stringResource(R.string.goals_subtitle),
                        style = MaterialTheme.typography.bodySmall,
                        color = RoseGold
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0x332B1020))
                        .border(1.dp, Color(0x33FF4D79), RoundedCornerShape(16.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "$completedCount / $totalCount",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                        color = SoftBlush
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Overall Progress Summary Card
            if (totalCount > 0) {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    backgroundColor = Color(0x442B1020)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = stringResource(R.string.overall_progress),
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = SoftBlush
                            )
                            Text(
                                text = "${(overallProgress * 100).toInt()}%",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = CrimsonPrimary
                            )
                        }

                        LinearProgressIndicator(
                            progress = { overallProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = CrimsonPrimary,
                            trackColor = Color(0x33FF4D79)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }

            // Goals List
            if (goals.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.TrackChanges,
                            contentDescription = null,
                            tint = CrimsonPrimary.copy(alpha = 0.4f),
                            modifier = Modifier.size(64.dp)
                        )
                        Text(
                            text = stringResource(R.string.no_goals_yet),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = SoftBlush
                        )
                        Text(
                            text = stringResource(R.string.add_first_goal_hint),
                            style = MaterialTheme.typography.bodySmall,
                            color = RoseGold
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(bottom = 80.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(goals, key = { it.firestoreId.ifBlank { it.id.toString() } }) { goal ->
                        GoalItemCard(
                            goal = goal,
                            onToggleComplete = {
                                val nextCompleted = !goal.isCompleted
                                val nextProgress = if (nextCompleted) 100 else 0
                                viewModel.updateGoalProgress(goal, nextProgress, nextCompleted)
                            },
                            onDelete = {
                                goalToDelete = goal
                            }
                        )
                    }
                }
            }
        }

        // FAB to add goal
        FloatingActionButton(
            onClick = { viewModel.isAddingGoal.value = true },
            containerColor = CrimsonPrimary,
            contentColor = SoftBlush,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 24.dp, end = 20.dp)
                .testTag("btn_add_goal_fab")
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = stringResource(R.string.add_goal)
            )
        }

        // Add Goal Dialog
        if (isAddingGoal) {
            AddGoalDialog(
                onDismiss = { viewModel.isAddingGoal.value = false },
                onAdd = { title, desc, targetDate, category ->
                    viewModel.addGoal(title, desc, targetDate, category)
                }
            )
        }

        // Delete Confirmation Dialog (Real-time delete for both sides)
        goalToDelete?.let { goal ->
            AlertDialog(
                onDismissRequest = { goalToDelete = null },
                title = {
                    Text(
                        text = stringResource(R.string.delete_goal_title),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = SoftBlush
                    )
                },
                text = {
                    Text(
                        text = stringResource(R.string.delete_for_both_warning),
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            viewModel.deleteGoal(goal.firestoreId)
                            goalToDelete = null
                        }
                    ) {
                        Text(
                            text = stringResource(R.string.delete_for_both),
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                dismissButton = {
                    TextButton(onClick = { goalToDelete = null }) {
                        Text(text = stringResource(R.string.cancel), color = RoseGold)
                    }
                },
                containerColor = Color(0xFF200918),
                shape = RoundedCornerShape(20.dp)
            )
        }
    }
}

@Composable
private fun GoalItemCard(
    goal: GoalEntity,
    onToggleComplete: () -> Unit,
    onDelete: () -> Unit
) {
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("goal_item_card"),
        shape = RoundedCornerShape(20.dp),
        backgroundColor = if (goal.isCompleted) Color(0x222B1020) else Color(0x332B1020)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                IconButton(
                    onClick = onToggleComplete,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = if (goal.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                        contentDescription = "Toggle completion",
                        tint = if (goal.isCompleted) CrimsonPrimary else RoseGold.copy(alpha = 0.6f),
                        modifier = Modifier.size(28.dp)
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(
                        text = goal.title,
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            textDecoration = if (goal.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                        ),
                        color = if (goal.isCompleted) Color.White.copy(alpha = 0.5f) else SoftBlush,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    if (goal.createdByName.isNotBlank()) {
                        Text(
                            text = "هدف ${goal.createdByName}",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = RoseGold
                        )
                    }
                }
            }

            IconButton(
                onClick = onDelete,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteOutline,
                    contentDescription = "Delete Goal",
                    tint = RoseGold.copy(alpha = 0.6f),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun AddGoalDialog(
    onDismiss: () -> Unit,
    onAdd: (title: String, desc: String, targetDate: String, category: String) -> Unit
) {
    var title by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = stringResource(R.string.add_goal),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = SoftBlush
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                RomanticTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = stringResource(R.string.goal_title_label),
                    placeholder = stringResource(R.string.goal_title_placeholder),
                    testTag = "input_goal_title"
                )
            }
        },
        confirmButton = {
            RomanticButton(
                text = stringResource(R.string.save),
                onClick = {
                    if (title.isNotBlank()) {
                        onAdd(title.trim(), "", "", "عام")
                    }
                },
                modifier = Modifier.padding(horizontal = 8.dp),
                testTag = "btn_save_goal"
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(text = stringResource(R.string.cancel), color = RoseGold)
            }
        },
        containerColor = Color(0xFF200918),
        shape = RoundedCornerShape(22.dp)
    )
}
