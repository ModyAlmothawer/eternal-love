package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.FloatingHeartsBackground
import com.example.ui.components.GlassCard
import com.example.ui.components.RomanticAvatar
import com.example.ui.components.RomanticButton
import com.example.ui.components.RomanticOutlinedButton
import com.example.ui.components.RomanticTextField
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.RomanticGradient
import com.example.ui.theme.RoseGold
import com.example.ui.theme.SoftBlush
import com.example.ui.viewmodel.MainTab
import com.example.ui.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun ProfileAndSettingsScreen(
    viewModel: MainViewModel,
    onLogout: () -> Unit,
    onDisconnected: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentUser by viewModel.currentUser.collectAsState()
    val relationship by viewModel.currentRelationship.collectAsState()
    val isDark by viewModel.isDarkMode.collectAsState()
    val currentLang by viewModel.currentLanguage.collectAsState()

    val isEditingProfile by viewModel.isEditingProfile.collectAsState()
    val isEditingRelationship by viewModel.isEditingRelationship.collectAsState()
    val showDisconnectConfirmation by viewModel.showDisconnectConfirmation.collectAsState()
    var showBirthdaysDialog by remember { mutableStateOf(false) }
    var isEmailVisible by remember { mutableStateOf(false) }

    val fallbackPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.uploadProfileImage(uri)
        }
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.uploadProfileImage(uri)
        }
    }

    BackHandler {
        viewModel.selectTab(MainTab.HOME)
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(RomanticGradient)
            .testTag("profile_screen")
    ) {
        FloatingHeartsBackground(heartCount = 8)

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    IconButton(
                        onClick = { viewModel.selectTab(MainTab.HOME) },
                        modifier = Modifier
                            .size(38.dp)
                            .background(Color(0x332B1020), CircleShape)
                            .border(1.dp, Color(0x33FF4D79), CircleShape)
                            .testTag("btn_back_from_settings")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = SoftBlush,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Text(
                        text = stringResource(R.string.tab_profile),
                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                        color = SoftBlush
                    )
                }
            }

            // User Profile Card
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(contentAlignment = Alignment.BottomEnd) {
                            RomanticAvatar(
                                photoUrl = currentUser?.photoUrl ?: "",
                                avatarRes = currentUser?.avatarRes ?: "avatar_1",
                                size = 84.dp,
                                borderColor = CrimsonPrimary,
                                borderWidth = 3.dp
                            )

                            // Pick Photo Button (No crash with safe ImageUtils compression)
                            Box(
                                modifier = Modifier
                                    .size(30.dp)
                                    .clip(CircleShape)
                                    .background(CrimsonPrimary)
                                    .clickable {
                                        try {
                                            photoPickerLauncher.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        } catch (e: Exception) {
                                            try {
                                                fallbackPickerLauncher.launch("image/*")
                                            } catch (_: Exception) {}
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CameraAlt,
                                    contentDescription = "Upload photo",
                                    tint = SoftBlush,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = currentUser?.name ?: stringResource(R.string.you),
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = SoftBlush
                        )

                        val rawEmail = currentUser?.email ?: ""
                        if (rawEmail.isNotBlank()) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { isEmailVisible = !isEmailVisible }
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (isEmailVisible) rawEmail else maskEmailAddress(rawEmail),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = RoseGold
                                )
                                Icon(
                                    imageVector = if (isEmailVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = if (isEmailVisible) "Hide email" else "Show email",
                                    tint = RoseGold.copy(alpha = 0.7f),
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        RomanticOutlinedButton(
                            text = stringResource(R.string.edit_profile),
                            onClick = { viewModel.isEditingProfile.value = true },
                            icon = Icons.Default.Edit,
                            testTag = "btn_edit_profile"
                        )
                    }
                }
            }

            // Relationship Info Card
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = stringResource(R.string.relationship_details_title),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = SoftBlush
                            )

                            IconButton(
                                onClick = { viewModel.isEditingRelationship.value = true },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Edit Relationship",
                                    tint = RoseGold,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        // Code Section
                        val code = relationship?.code?.takeIf { it.isNotBlank() } ?: currentUser?.relationshipCode?.takeIf { it.isNotBlank() }
                        if (!code.isNullOrBlank()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(Color(0x332B1020))
                                    .border(1.dp, Color(0x33FF4D79), RoundedCornerShape(14.dp))
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = stringResource(R.string.your_love_code),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = RoseGold
                                    )
                                    Text(
                                        text = code,
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            letterSpacing = 2.sp
                                        ),
                                        color = SoftBlush
                                    )
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    IconButton(
                                        onClick = {
                                            try {
                                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                                val clip = ClipData.newPlainText("Love Code", code)
                                                clipboard.setPrimaryClip(clip)
                                                Toast.makeText(context, context.getString(R.string.code_copied), Toast.LENGTH_SHORT).show()
                                            } catch (e: Exception) {
                                                Log.w("ProfileScreen", "Failed to copy code: ${e.message}")
                                            }
                                        },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ContentCopy,
                                            contentDescription = "Copy code",
                                            tint = SoftBlush,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }

                                    IconButton(
                                        onClick = {
                                            try {
                                                val sendIntent: Intent = Intent().apply {
                                                    action = Intent.ACTION_SEND
                                                    putExtra(Intent.EXTRA_TEXT, context.getString(R.string.share_code_text, code))
                                                    type = "text/plain"
                                                }
                                                val chooser = Intent.createChooser(sendIntent, context.getString(R.string.share_chooser_title)).apply {
                                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                                }
                                                context.startActivity(chooser)
                                            } catch (e: Exception) {
                                                Log.w("ProfileScreen", "Failed to share code: ${e.message}")
                                            }
                                        },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Share,
                                            contentDescription = "Share code",
                                            tint = SoftBlush,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Birthdays & Age Difference Card
            item {
                val isCreator = (relationship?.creatorId == currentUser?.firebaseUid)
                val myBirthday = currentUser?.birthdayMillis?.takeIf { it > 0L }
                    ?: (if (isCreator) relationship?.creatorBirthdayMillis else relationship?.partnerBirthdayMillis)?.takeIf { (it ?: 0L) > 0L } ?: 0L
                val partnerBirthday = currentUser?.partnerBirthdayMillis?.takeIf { it > 0L }
                    ?: (if (isCreator) relationship?.partnerBirthdayMillis else relationship?.creatorBirthdayMillis)?.takeIf { (it ?: 0L) > 0L } ?: 0L
                val partnerDisplayName = currentUser?.partnerName?.ifBlank { stringResource(R.string.my_partner) }
                    ?: relationship?.partnerName?.ifBlank { stringResource(R.string.my_partner) }
                    ?: stringResource(R.string.my_partner)

                val bdayDateFormat = remember { SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()) }

                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Cake,
                                    contentDescription = null,
                                    tint = CrimsonPrimary,
                                    modifier = Modifier.size(22.dp)
                                )
                                Text(
                                    text = if (currentLang == "ar") "أعياد الميلاد وفرق السن" else "Birthdays & Age",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = SoftBlush
                                )
                            }

                            IconButton(
                                onClick = { showBirthdaysDialog = true },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Edit Birthdays",
                                    tint = RoseGold,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        // My Birthday Box
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0x332B1020))
                                .border(1.dp, Color(0x33FF4D79), RoundedCornerShape(14.dp))
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (currentLang == "ar") "عيد ميلادي" else "My Birthday",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = RoseGold
                                )
                                Text(
                                    text = if (myBirthday > 0L) bdayDateFormat.format(Date(myBirthday)) else (if (currentLang == "ar") "لم يُحدد بعد" else "Not set"),
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = SoftBlush
                                )
                            }
                            if (myBirthday > 0L) {
                                val daysLeft = getDaysUntilNextBirthday(myBirthday)
                                Text(
                                    text = if (daysLeft == 0L) (if (currentLang == "ar") "اليوم! 🎉🎂" else "Today! 🎉🎂")
                                    else (if (currentLang == "ar") "باقي $daysLeft يوم 🎉" else "$daysLeft days left 🎉"),
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                                    color = CrimsonPrimary
                                )
                            }
                        }

                        // Partner Birthday Box
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0x332B1020))
                                .border(1.dp, Color(0x33FF4D79), RoundedCornerShape(14.dp))
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (currentLang == "ar") "عيد ميلاد $partnerDisplayName" else "$partnerDisplayName's Birthday",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = RoseGold
                                )
                                Text(
                                    text = if (partnerBirthday > 0L) bdayDateFormat.format(Date(partnerBirthday)) else (if (currentLang == "ar") "لم يُحدد بعد" else "Not set"),
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = SoftBlush
                                )
                            }
                            if (partnerBirthday > 0L) {
                                val partnerDaysLeft = getDaysUntilNextBirthday(partnerBirthday)
                                Text(
                                    text = if (partnerDaysLeft == 0L) (if (currentLang == "ar") "اليوم! 🌸🎂" else "Today! 🌸🎂")
                                    else (if (currentLang == "ar") "باقي $partnerDaysLeft يوم 🌸" else "$partnerDaysLeft days left 🌸"),
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                                    color = RoseGold
                                )
                            }
                        }

                        // Age Difference & Egyptian teasing note
                        if (myBirthday > 0L && partnerBirthday > 0L) {
                            val ageDiff = calculateAgeDifference(myBirthday, partnerBirthday, partnerDisplayName, currentLang)
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(Color(0x447A1838))
                                    .border(1.dp, CrimsonPrimary.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                                    .padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Favorite,
                                        contentDescription = null,
                                        tint = CrimsonPrimary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = if (currentLang == "ar") "فرق السن بينكم:" else "Age Difference:",
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                        color = SoftBlush
                                    )
                                }
                                Text(
                                    text = ageDiff.teasingNote,
                                    style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp),
                                    color = SoftBlush
                                )
                            }
                        } else {
                            Text(
                                text = if (currentLang == "ar") "سجّلوا أعياد ميلادكم لمعرفة فرق السن وحساب الأيام المتبقية مع لمسة دلع وهزار مصري لطيف! 🎂✨"
                                else "Set your birthdays to see your age difference and countdowns! 🎂✨",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                                color = RoseGold.copy(alpha = 0.8f)
                            )
                        }
                    }
                }
            }

            // Settings & Preferences Card
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.settings_title),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = SoftBlush
                        )

                        // Language Toggle
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0x332B1020))
                                .clickable {
                                    val nextLang = if (currentLang == "ar") "en" else "ar"
                                    viewModel.setLanguage(nextLang)
                                }
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Language,
                                    contentDescription = "Language",
                                    tint = RoseGold,
                                    modifier = Modifier.size(22.dp)
                                )
                                Text(
                                    text = stringResource(R.string.language),
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                                    color = SoftBlush
                                )
                            }
                            Text(
                                text = if (currentLang == "ar") "العربية (مصر)" else "English",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                color = CrimsonPrimary
                            )
                        }

                        // Romantic Dark Theme (Permanent)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0x332B1020))
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DarkMode,
                                    contentDescription = "Dark Mode",
                                    tint = RoseGold,
                                    modifier = Modifier.size(22.dp)
                                )
                                Text(
                                    text = stringResource(R.string.romantic_dark_theme),
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                                    color = SoftBlush
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(CrimsonPrimary.copy(alpha = 0.2f))
                                    .border(1.dp, CrimsonPrimary.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "مفعل دائماً ✨",
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                    color = SoftBlush
                                )
                            }
                        }
                    }
                }
            }

            // Danger & Account Actions
            item {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    RomanticOutlinedButton(
                        text = stringResource(R.string.disconnect_relationship),
                        onClick = { viewModel.showDisconnectConfirmation.value = true },
                        icon = Icons.Default.LinkOff,
                        borderColor = MaterialTheme.colorScheme.error.copy(alpha = 0.5f),
                        textColor = MaterialTheme.colorScheme.error,
                        testTag = "btn_disconnect_relationship"
                    )

                    RomanticOutlinedButton(
                        text = stringResource(R.string.logout),
                        onClick = onLogout,
                        icon = Icons.Default.ExitToApp,
                        testTag = "btn_logout"
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }

        // Edit Profile Dialog
        if (isEditingProfile) {
            EditProfileDialog(
                currentName = currentUser?.name ?: "",
                currentAvatar = currentUser?.avatarRes ?: "avatar_1",
                onDismiss = { viewModel.isEditingProfile.value = false },
                onSave = { name, avatar ->
                    viewModel.updateProfile(name, avatar)
                }
            )
        }

        // Edit Relationship Dialog
        if (isEditingRelationship) {
            EditRelationshipDialog(
                currentName = relationship?.relationshipName ?: "قصتنا",
                currentStartDateMillis = if ((relationship?.startDateMillis ?: 0L) > 0L) (relationship?.startDateMillis ?: System.currentTimeMillis()) else System.currentTimeMillis(),
                onDismiss = { viewModel.isEditingRelationship.value = false },
                onSave = { name, startMillis ->
                    viewModel.updateRelationship(name, startMillis)
                }
            )
        }

        // Edit Birthday Dialog (Each partner edits ONLY their own birthday)
        if (showBirthdaysDialog) {
            val isCreator = (relationship?.creatorId == currentUser?.firebaseUid)
            val currentMyBirthday = currentUser?.birthdayMillis?.takeIf { it > 0L }
                ?: (if (isCreator) relationship?.creatorBirthdayMillis else relationship?.partnerBirthdayMillis)?.takeIf { (it ?: 0L) > 0L } ?: 0L
            val currentPartnerBirthday = currentUser?.partnerBirthdayMillis?.takeIf { it > 0L }
                ?: (if (isCreator) relationship?.partnerBirthdayMillis else relationship?.creatorBirthdayMillis)?.takeIf { (it ?: 0L) > 0L } ?: 0L
            val partnerDisplayName = currentUser?.partnerName?.ifBlank { stringResource(R.string.my_partner) }
                ?: relationship?.partnerName?.ifBlank { stringResource(R.string.my_partner) }
                ?: stringResource(R.string.my_partner)

            EditMyBirthdayDialog(
                currentMyBirthdayMillis = currentMyBirthday,
                partnerBirthdayMillis = currentPartnerBirthday,
                partnerName = partnerDisplayName,
                currentLang = currentLang,
                onDismiss = { showBirthdaysDialog = false },
                onSave = { myBday ->
                    viewModel.updateMyBirthday(myBday)
                    showBirthdaysDialog = false
                }
            )
        }

        // Disconnect Confirmation Dialog
        if (showDisconnectConfirmation) {
            AlertDialog(
                onDismissRequest = { viewModel.showDisconnectConfirmation.value = false },
                title = {
                    Text(
                        text = stringResource(R.string.disconnect_title),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = SoftBlush
                    )
                },
                text = {
                    Text(
                        text = stringResource(R.string.disconnect_warning),
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            viewModel.disconnectRelationship(onDisconnected)
                        }
                    ) {
                        Text(
                            text = stringResource(R.string.disconnect_relationship),
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                dismissButton = {
                    TextButton(onClick = { viewModel.showDisconnectConfirmation.value = false }) {
                        Text(text = stringResource(R.string.cancel), color = RoseGold)
                    }
                },
                containerColor = Color(0xFF200918),
                shape = RoundedCornerShape(20.dp)
            )
        }
    }
}

@Composable
fun EditProfileDialog(
    currentName: String,
    currentAvatar: String,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var name by remember { mutableStateOf(currentName) }
    var selectedAvatar by remember { mutableStateOf(currentAvatar) }

    val avatars = listOf("avatar_1", "avatar_2", "avatar_3", "avatar_4")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = stringResource(R.string.edit_profile),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = SoftBlush
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                RomanticTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = stringResource(R.string.name),
                    placeholder = stringResource(R.string.name_placeholder),
                    testTag = "input_edit_name"
                )

                Text(
                    text = stringResource(R.string.choose_avatar),
                    style = MaterialTheme.typography.bodySmall,
                    color = RoseGold
                )

                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(avatars) { av ->
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .border(
                                    2.dp,
                                    if (selectedAvatar == av) CrimsonPrimary else Color.Transparent,
                                    CircleShape
                                )
                                .clickable { selectedAvatar = av }
                                .padding(4.dp)
                        ) {
                            RomanticAvatar(
                                photoUrl = "",
                                avatarRes = av,
                                size = 52.dp
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            RomanticButton(
                text = stringResource(R.string.save),
                onClick = { onSave(name.trim(), selectedAvatar) },
                modifier = Modifier.padding(horizontal = 8.dp),
                testTag = "btn_save_edit_profile"
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(text = stringResource(R.string.cancel), color = RoseGold)
            }
        },
        containerColor = Color(0xFF200918),
        shape = RoundedCornerShape(22.dp)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditRelationshipDialog(
    currentName: String,
    currentStartDateMillis: Long,
    onDismiss: () -> Unit,
    onSave: (String, Long) -> Unit
) {
    val safeInitialMillis = if (currentStartDateMillis > 0L) currentStartDateMillis else System.currentTimeMillis()
    var name by remember { mutableStateOf(currentName) }
    var selectedDateMillis by remember { mutableLongStateOf(safeInitialMillis) }
    var showDatePicker by remember { mutableStateOf(false) }

    val datePickerState = rememberDatePickerState(
        initialSelectedDateMillis = safeInitialMillis
    )

    val dateFormat = remember { SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()) }
    val formattedDate = remember(selectedDateMillis) { dateFormat.format(Date(selectedDateMillis)) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = stringResource(R.string.edit_relationship_title),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = SoftBlush
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                RomanticTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = stringResource(R.string.relationship_name_label),
                    placeholder = "قصتنا",
                    testTag = "input_edit_rel_name"
                )

                // Date Picker field
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0x332B1020))
                        .border(1.dp, Color(0x33FF4D79), RoundedCornerShape(14.dp))
                        .clickable { showDatePicker = true }
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CalendarMonth,
                            contentDescription = null,
                            tint = CrimsonPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = formattedDate,
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            color = SoftBlush
                        )
                    }
                    Text(
                        text = stringResource(R.string.edit),
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                        color = RoseGold
                    )
                }
            }
        },
        confirmButton = {
            RomanticButton(
                text = stringResource(R.string.save),
                onClick = { onSave(name.trim(), selectedDateMillis) },
                modifier = Modifier.padding(horizontal = 8.dp),
                testTag = "btn_save_edit_relationship"
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(text = stringResource(R.string.cancel), color = RoseGold)
            }
        },
        containerColor = Color(0xFF200918),
        shape = RoundedCornerShape(22.dp)
    )

    if (showDatePicker) {
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        datePickerState.selectedDateMillis?.let {
                            selectedDateMillis = it
                        }
                        showDatePicker = false
                    }
                ) {
                    Text(text = stringResource(R.string.save), color = CrimsonPrimary, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) {
                    Text(text = stringResource(R.string.cancel), color = RoseGold)
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }
}

fun maskEmailAddress(email: String): String {
    if (email.isBlank()) return ""
    val atIdx = email.indexOf('@')
    if (atIdx <= 1) return email
    val name = email.substring(0, atIdx)
    val domain = email.substring(atIdx)
    val maskedName = if (name.length <= 3) {
        "${name.first()}***"
    } else {
        "${name.first()}***${name.last()}"
    }
    return "$maskedName$domain"
}

data class AgeDiffResult(
    val years: Int,
    val months: Int,
    val days: Int,
    val isUserOlder: Boolean,
    val isExactSameDay: Boolean,
    val teasingNote: String
)

fun getDaysUntilNextBirthday(birthdayMillis: Long): Long {
    if (birthdayMillis <= 0L) return 0L
    val birthCal = Calendar.getInstance().apply { timeInMillis = birthdayMillis }
    val today = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }
    val birthMonth = birthCal.get(Calendar.MONTH)
    val birthDay = birthCal.get(Calendar.DAY_OF_MONTH)

    fun createBirthdayCalendar(year: Int): Calendar {
        return Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, birthMonth)
            val maxDay = getActualMaximum(Calendar.DAY_OF_MONTH)
            set(Calendar.DAY_OF_MONTH, birthDay.coerceAtMost(maxDay))
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
    }

    var nextBday = createBirthdayCalendar(today.get(Calendar.YEAR))
    if (nextBday.before(today)) {
        nextBday = createBirthdayCalendar(today.get(Calendar.YEAR) + 1)
    }

    val diff = nextBday.timeInMillis - today.timeInMillis
    return java.util.concurrent.TimeUnit.MILLISECONDS.toDays(diff).coerceAtLeast(0L)
}

fun calculateAgeDifference(myBday: Long, partnerBday: Long, partnerName: String, lang: String): AgeDiffResult {
    val olderBday = if (myBday < partnerBday) myBday else partnerBday
    val youngerBday = if (myBday < partnerBday) partnerBday else myBday
    val isUserOlder = myBday < partnerBday

    val olderCal = Calendar.getInstance().apply { timeInMillis = olderBday }
    val youngerCal = Calendar.getInstance().apply { timeInMillis = youngerBday }

    var years = youngerCal.get(Calendar.YEAR) - olderCal.get(Calendar.YEAR)
    var months = youngerCal.get(Calendar.MONTH) - olderCal.get(Calendar.MONTH)
    var days = youngerCal.get(Calendar.DAY_OF_MONTH) - olderCal.get(Calendar.DAY_OF_MONTH)

    if (days < 0) {
        months -= 1
        val prevMonthCal = (youngerCal.clone() as Calendar).apply { add(Calendar.MONTH, -1) }
        days += prevMonthCal.getActualMaximum(Calendar.DAY_OF_MONTH)
    }
    if (months < 0) {
        years -= 1
        months += 12
    }

    val isSame = (years == 0 && months == 0 && days == 0)

    val teasingNote = if (lang == "ar") {
        when {
            isSame -> "توأم روح باليوم والساعة! مفيش صدفة أحلى من كدة في الدنيا كلها ✨❤️"
            isUserOlder -> {
                if (years >= 1) {
                    "أنت أكبر بـ $years سنة${if (months > 0) " و $months شهر" else ""}.. يا عمنا الكبير وسيد الكل، الكبير مقامه عالي في البيت والقلب 👑😉"
                } else {
                    "أنت أكبر بكام شهر بس! يعني جيل واحد وروح واحدة، بس برضه كلمتك تمشي يا كبير 😉❤️"
                }
            }
            else -> {
                if (years >= 1) {
                    "$partnerName أكبر منك بـ $years سنة${if (months > 0) " و $months شهر" else ""}.. يا بختك بالدلع والاهتمام يا سكر يا صغنن انت! الدلع كله ليك 🌸🥰"
                } else {
                    "$partnerName أكبر بكام شهر بس! متقاربين في السن ومتطابقين في الروح وعايشين في قلب بعض 💕✨"
                }
            }
        }
    } else {
        when {
            isSame -> "Born on the exact same day! True soulmates ✨❤️"
            isUserOlder -> "You are older by $years years${if (months > 0) " and $months months" else ""}! Wisdom and grace lead the way 👑😉"
            else -> "$partnerName is older by $years years${if (months > 0) " and $months months" else ""}! Enjoy being pampered and loved 🌸🥰"
        }
    }

    return AgeDiffResult(years, months, days, isUserOlder, isSame, teasingNote)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditMyBirthdayDialog(
    currentMyBirthdayMillis: Long,
    partnerBirthdayMillis: Long,
    partnerName: String,
    currentLang: String,
    onDismiss: () -> Unit,
    onSave: (Long) -> Unit
) {
    var myBirthday by remember { mutableLongStateOf(currentMyBirthdayMillis) }
    var showDatePicker by remember { mutableStateOf(false) }

    val dateFormat = remember { SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()) }

    val myPickerState = rememberDatePickerState(
        initialSelectedDateMillis = if (currentMyBirthdayMillis > 0L) currentMyBirthdayMillis else 946684800000L // Year 2000
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Cake,
                    contentDescription = null,
                    tint = CrimsonPrimary,
                    modifier = Modifier.size(24.dp)
                )
                Text(
                    text = if (currentLang == "ar") "تحديد تاريخ ميلادي" else "Set My Birthday",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = SoftBlush
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(
                    text = if (currentLang == "ar") 
                        "لحفظ الخصوصية ودقة البيانات المشتركة، يمكنك تعديل تاريخ ميلادك أنت فقط. شريكك يحدد تاريخ ميلاده من جهازه الخاص."
                    else 
                        "For privacy and accuracy, each partner manages only their own birthday from their own device.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.8f)
                )

                // 1. My Birthday field (Editable)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = if (currentLang == "ar") "تاريخ ميلادي (قابل للتعديل)" else "My Birthday (Editable)",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                        color = CrimsonPrimary
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0x332B1020))
                            .border(1.5.dp, CrimsonPrimary, RoundedCornerShape(14.dp))
                            .clickable { showDatePicker = true }
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Cake,
                                contentDescription = null,
                                tint = CrimsonPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = if (myBirthday > 0L) dateFormat.format(Date(myBirthday)) else (if (currentLang == "ar") "اضغط لتحديد تاريخ ميلادك" else "Tap to select your birthday"),
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                color = SoftBlush
                            )
                        }
                        Text(
                            text = if (currentLang == "ar") "تعديل" else "Edit",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, fontWeight = FontWeight.Bold),
                            color = RoseGold
                        )
                    }
                }

                // 2. Partner Birthday field (Read-only / Locked)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = RoseGold.copy(alpha = 0.8f),
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = if (currentLang == "ar") "تاريخ ميلاد $partnerName (للقراءة فقط)" else "$partnerName's Birthday (Read-only)",
                            style = MaterialTheme.typography.labelSmall,
                            color = RoseGold.copy(alpha = 0.8f)
                        )
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0x1AFFFFFF))
                            .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(14.dp))
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = Color.Gray,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = if (partnerBirthdayMillis > 0L) dateFormat.format(Date(partnerBirthdayMillis)) 
                                    else (if (currentLang == "ar") "لم يحدده الشريك بعد" else "Not set yet by partner"),
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = if (partnerBirthdayMillis > 0L) FontWeight.Medium else FontWeight.Normal,
                                    color = if (partnerBirthdayMillis > 0L) SoftBlush.copy(alpha = 0.9f) else Color.Gray
                                )
                            )
                        }
                        Text(
                            text = if (currentLang == "ar") "خاص بالشريك 🔒" else "Partner's device 🔒",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                            color = RoseGold.copy(alpha = 0.7f)
                        )
                    }
                }
            }
        },
        confirmButton = {
            RomanticButton(
                text = if (currentLang == "ar") "حفظ تاريخ ميلادي" else "Save My Birthday",
                onClick = {
                    if (myBirthday > 0L) {
                        onSave(myBirthday)
                    } else {
                        onDismiss()
                    }
                },
                modifier = Modifier.padding(horizontal = 8.dp),
                testTag = "btn_save_my_birthday"
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(text = if (currentLang == "ar") "إلغاء" else "Cancel", color = RoseGold)
            }
        },
        containerColor = Color(0xFF200918),
        shape = RoundedCornerShape(22.dp)
    )

    if (showDatePicker) {
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        myPickerState.selectedDateMillis?.let {
                            myBirthday = it
                        }
                        showDatePicker = false
                    }
                ) {
                    Text(text = if (currentLang == "ar") "تأكيد" else "Confirm", color = CrimsonPrimary, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) {
                    Text(text = if (currentLang == "ar") "إلغاء" else "Cancel", color = RoseGold)
                }
            }
        ) {
            DatePicker(state = myPickerState)
        }
    }
}
