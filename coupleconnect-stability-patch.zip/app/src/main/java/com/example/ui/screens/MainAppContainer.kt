package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.TrackChanges
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.RoseGold
import com.example.ui.theme.SoftBlush
import com.example.ui.viewmodel.MainTab
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MainAppContainer(
    viewModel: MainViewModel,
    onLogout: () -> Unit,
    onDisconnected: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentTab by viewModel.currentTab.collectAsState()
    val letters by viewModel.loveLetters.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val isViewingNotes by viewModel.isViewingNotes.collectAsState()
    val isViewingSpecialDates by viewModel.isViewingSpecialDates.collectAsState()
    val isViewingNotifications by viewModel.isViewingNotifications.collectAsState()
    val isViewingStory by viewModel.isViewingStory.collectAsState()

    val currentUid = currentUser?.firebaseUid ?: ""
    val unreadLettersCount = letters.count { !it.isRead && it.senderUid.isNotBlank() && it.senderUid != currentUid }

    LaunchedEffect(currentTab, letters) {
        if (currentTab == MainTab.LETTERS) {
            val unreadPartnerLetters = letters.filter { !it.isRead && it.senderUid.isNotBlank() && it.senderUid != currentUid }
            unreadPartnerLetters.forEach { letter ->
                viewModel.markLoveLetterAsRead(letter.firestoreId)
            }
        }
    }

    val isKeyboardOpen = WindowInsets.isImeVisible

    Scaffold(
        bottomBar = {
            if (!isKeyboardOpen) {
                RomanticBottomNavigationBar(
                    currentTab = currentTab,
                    onTabSelect = { viewModel.selectTab(it) },
                    unreadLettersCount = unreadLettersCount
                )
            }
        },
        contentWindowInsets = WindowInsets.statusBars,
        containerColor = Color(0xFF0F040C),
        modifier = modifier
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .consumeWindowInsets(innerPadding)
        ) {
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "tab_transition"
            ) { tab ->
                when (tab) {
                    MainTab.HOME -> HomeScreen(viewModel = viewModel)
                    MainTab.MEMORIES -> MemoriesScreen(viewModel = viewModel)
                    MainTab.LETTERS -> LoveLettersScreen(viewModel = viewModel)
                    MainTab.GOALS -> GoalsScreen(viewModel = viewModel)
                    MainTab.PROFILE -> ProfileAndSettingsScreen(
                        viewModel = viewModel,
                        onLogout = onLogout,
                        onDisconnected = onDisconnected
                    )
                }
            }

            // Secondary Dialogs/Overlays
            if (isViewingNotes) {
                NotesDialog(
                    viewModel = viewModel,
                    onDismiss = { viewModel.isViewingNotes.value = false }
                )
            }

            if (isViewingSpecialDates) {
                SpecialDatesDialog(
                    viewModel = viewModel,
                    onDismiss = { viewModel.isViewingSpecialDates.value = false }
                )
            }

            if (isViewingNotifications) {
                NotificationsDialog(
                    viewModel = viewModel,
                    onDismiss = { viewModel.isViewingNotifications.value = false }
                )
            }

            if (isViewingStory) {
                StoryTimelineDialog(
                    viewModel = viewModel,
                    onDismiss = { viewModel.isViewingStory.value = false }
                )
            }
        }
    }
}

@Composable
private fun RomanticBottomNavigationBar(
    currentTab: MainTab,
    onTabSelect: (MainTab) -> Unit,
    unreadLettersCount: Int
) {
    NavigationBar(
        containerColor = Color(0xEE160712),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
            .border(1.dp, Color(0x33FF4D79), RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
    ) {
        // Tab 1: Home
        NavigationBarItem(
            selected = currentTab == MainTab.HOME,
            onClick = { onTabSelect(MainTab.HOME) },
            icon = {
                Icon(
                    imageVector = Icons.Default.Home,
                    contentDescription = stringResource(R.string.tab_home),
                    modifier = Modifier.size(24.dp)
                )
            },
            label = {
                Text(
                    text = stringResource(R.string.tab_home),
                    fontSize = 10.sp,
                    fontWeight = if (currentTab == MainTab.HOME) FontWeight.Bold else FontWeight.Normal
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = CrimsonPrimary,
                selectedTextColor = SoftBlush,
                indicatorColor = CrimsonPrimary.copy(alpha = 0.2f),
                unselectedIconColor = RoseGold.copy(alpha = 0.6f),
                unselectedTextColor = RoseGold.copy(alpha = 0.6f)
            ),
            modifier = Modifier.testTag("tab_home")
        )

        // Tab 2: Memories
        NavigationBarItem(
            selected = currentTab == MainTab.MEMORIES,
            onClick = { onTabSelect(MainTab.MEMORIES) },
            icon = {
                Icon(
                    imageVector = Icons.Default.PhotoLibrary,
                    contentDescription = stringResource(R.string.tab_memories),
                    modifier = Modifier.size(24.dp)
                )
            },
            label = {
                Text(
                    text = stringResource(R.string.tab_memories),
                    fontSize = 10.sp,
                    fontWeight = if (currentTab == MainTab.MEMORIES) FontWeight.Bold else FontWeight.Normal
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = CrimsonPrimary,
                selectedTextColor = SoftBlush,
                indicatorColor = CrimsonPrimary.copy(alpha = 0.2f),
                unselectedIconColor = RoseGold.copy(alpha = 0.6f),
                unselectedTextColor = RoseGold.copy(alpha = 0.6f)
            ),
            modifier = Modifier.testTag("tab_memories")
        )

        // Tab 3: Chat / Letters (الدردشة)
        NavigationBarItem(
            selected = currentTab == MainTab.LETTERS,
            onClick = { onTabSelect(MainTab.LETTERS) },
            icon = {
                BadgedBox(
                    badge = {
                        if (unreadLettersCount > 0) {
                            Badge(
                                containerColor = CrimsonPrimary,
                                contentColor = SoftBlush
                            ) {
                                Text(text = "$unreadLettersCount")
                            }
                        }
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.Chat,
                        contentDescription = stringResource(R.string.tab_chat),
                        modifier = Modifier.size(24.dp)
                    )
                }
            },
            label = {
                Text(
                    text = stringResource(R.string.tab_chat),
                    fontSize = 10.sp,
                    fontWeight = if (currentTab == MainTab.LETTERS) FontWeight.Bold else FontWeight.Normal
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = CrimsonPrimary,
                selectedTextColor = SoftBlush,
                indicatorColor = CrimsonPrimary.copy(alpha = 0.2f),
                unselectedIconColor = RoseGold.copy(alpha = 0.6f),
                unselectedTextColor = RoseGold.copy(alpha = 0.6f)
            ),
            modifier = Modifier.testTag("tab_chat")
        )

        // Tab 4: Goals
        NavigationBarItem(
            selected = currentTab == MainTab.GOALS,
            onClick = { onTabSelect(MainTab.GOALS) },
            icon = {
                Icon(
                    imageVector = Icons.Default.TrackChanges,
                    contentDescription = stringResource(R.string.tab_goals),
                    modifier = Modifier.size(24.dp)
                )
            },
            label = {
                Text(
                    text = stringResource(R.string.tab_goals),
                    fontSize = 10.sp,
                    fontWeight = if (currentTab == MainTab.GOALS) FontWeight.Bold else FontWeight.Normal
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = CrimsonPrimary,
                selectedTextColor = SoftBlush,
                indicatorColor = CrimsonPrimary.copy(alpha = 0.2f),
                unselectedIconColor = RoseGold.copy(alpha = 0.6f),
                unselectedTextColor = RoseGold.copy(alpha = 0.6f)
            ),
            modifier = Modifier.testTag("tab_goals")
        )

        // Tab 5: Profile
        NavigationBarItem(
            selected = currentTab == MainTab.PROFILE,
            onClick = { onTabSelect(MainTab.PROFILE) },
            icon = {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = stringResource(R.string.tab_profile),
                    modifier = Modifier.size(24.dp)
                )
            },
            label = {
                Text(
                    text = stringResource(R.string.tab_profile),
                    fontSize = 10.sp,
                    fontWeight = if (currentTab == MainTab.PROFILE) FontWeight.Bold else FontWeight.Normal
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = CrimsonPrimary,
                selectedTextColor = SoftBlush,
                indicatorColor = CrimsonPrimary.copy(alpha = 0.2f),
                unselectedIconColor = RoseGold.copy(alpha = 0.6f),
                unselectedTextColor = RoseGold.copy(alpha = 0.6f)
            ),
            modifier = Modifier.testTag("tab_profile")
        )
    }
}
