package com.example.util

import android.media.AudioAttributes
import android.media.MediaPlayer
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

object AudioPlayerHelper {

    private var mediaPlayer: MediaPlayer? = null
    private var progressJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main)

    private val _currentlyPlayingUrl = MutableStateFlow<String?>(null)
    val currentlyPlayingUrl: StateFlow<String?> = _currentlyPlayingUrl.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _progressPercent = MutableStateFlow(0f)
    val progressPercent: StateFlow<Float> = _progressPercent.asStateFlow()

    private val _currentPositionSeconds = MutableStateFlow(0)
    val currentPositionSeconds: StateFlow<Int> = _currentPositionSeconds.asStateFlow()

    fun playAudio(url: String) {
        if (url.isBlank()) return

        // If already playing this audio, pause it
        if (_currentlyPlayingUrl.value == url && _isPlaying.value) {
            pauseAudio()
            return
        }

        // If paused on same audio, resume
        if (_currentlyPlayingUrl.value == url && mediaPlayer != null) {
            mediaPlayer?.start()
            _isPlaying.value = true
            startProgressTracking()
            return
        }

        // Stop any previous playback
        stopAudio()

        try {
            val player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(url)
                setOnPreparedListener { mp ->
                    mp.start()
                    _currentlyPlayingUrl.value = url
                    _isPlaying.value = true
                    startProgressTracking()
                }
                setOnCompletionListener {
                    stopAudio()
                }
                setOnErrorListener { _, what, extra ->
                    Log.e("AudioPlayerHelper", "MediaPlayer error: what=$what, extra=$extra")
                    stopAudio()
                    true
                }
                prepareAsync()
            }
            mediaPlayer = player
        } catch (e: Exception) {
            Log.e("AudioPlayerHelper", "Failed to start audio playback: ${e.message}", e)
            stopAudio()
        }
    }

    fun pauseAudio() {
        try {
            mediaPlayer?.pause()
            _isPlaying.value = false
            progressJob?.cancel()
        } catch (e: Exception) {
            Log.w("AudioPlayerHelper", "Error pausing audio: ${e.message}")
        }
    }

    fun stopAudio() {
        try {
            progressJob?.cancel()
            mediaPlayer?.apply {
                if (isPlaying) {
                    stop()
                }
                release()
            }
        } catch (e: Exception) {
            Log.w("AudioPlayerHelper", "Error stopping audio: ${e.message}")
        } finally {
            mediaPlayer = null
            _isPlaying.value = false
            _currentlyPlayingUrl.value = null
            _progressPercent.value = 0f
            _currentPositionSeconds.value = 0
        }
    }

    private fun startProgressTracking() {
        progressJob?.cancel()
        progressJob = scope.launch {
            while (isActive && _isPlaying.value) {
                val player = mediaPlayer
                if (player != null && player.isPlaying) {
                    val duration = player.duration
                    val current = player.currentPosition
                    if (duration > 0) {
                        _progressPercent.value = (current.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
                        _currentPositionSeconds.value = current / 1000
                    }
                }
                delay(100)
            }
        }
    }
}
