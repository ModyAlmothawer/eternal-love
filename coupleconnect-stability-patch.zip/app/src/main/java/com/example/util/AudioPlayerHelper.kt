package com.example.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.util.Log
import com.example.EternalLoveApplication
import com.example.data.remote.MediaUrlResolver
import com.example.data.remote.SupabaseConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

object AudioPlayerHelper {
    private var mediaPlayer: MediaPlayer? = null
    private var progressJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main)

    private val _currentlyPlayingUrl = MutableStateFlow<String?>(null)
    val currentlyPlayingUrl: StateFlow<String?> = _currentlyPlayingUrl.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _isBuffering = MutableStateFlow(false)
    val isBuffering: StateFlow<Boolean> = _isBuffering.asStateFlow()

    private val _progressPercent = MutableStateFlow(0f)
    val progressPercent: StateFlow<Float> = _progressPercent.asStateFlow()

    private val _currentPositionSeconds = MutableStateFlow(0)
    val currentPositionSeconds: StateFlow<Int> = _currentPositionSeconds.asStateFlow()

    private val _playbackErrorUrl = MutableStateFlow<String?>(null)
    val playbackErrorUrl: StateFlow<String?> = _playbackErrorUrl.asStateFlow()

    private var audioFocusRequest: AudioFocusRequest? = null

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .followRedirects(true)
            .build()
    }

    private fun requestAudioFocus(context: Context?): Boolean {
        val ctx = context ?: EternalLoveApplication.instance ?: return true
        val audioManager = ctx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return true
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val focusReq = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .setOnAudioFocusChangeListener { focusChange ->
                        if (focusChange == AudioManager.AUDIOFOCUS_LOSS || focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                            pauseAudio()
                        }
                    }
                    .build()
                audioFocusRequest = focusReq
                audioManager.requestAudioFocus(focusReq) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
            } else {
                @Suppress("DEPRECATION")
                audioManager.requestAudioFocus(
                    { focusChange ->
                        if (focusChange == AudioManager.AUDIOFOCUS_LOSS || focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                            pauseAudio()
                        }
                    },
                    AudioManager.STREAM_MUSIC,
                    AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
                ) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
            }
        } catch (_: Exception) {
            true
        }
    }

    private fun abandonAudioFocus(context: Context?) {
        val ctx = context ?: EternalLoveApplication.instance ?: return
        val audioManager = ctx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioFocusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
            } else {
                @Suppress("DEPRECATION")
                audioManager.abandonAudioFocus(null)
            }
        } catch (_: Exception) {}
    }

    fun playAudio(url: String, context: Context? = null) {
        if (url.isBlank()) return

        // Clear error for this url on fresh attempt
        if (_playbackErrorUrl.value == url) {
            _playbackErrorUrl.value = null
        }

        // If already playing this audio, pause it
        if (_currentlyPlayingUrl.value == url && _isPlaying.value) {
            pauseAudio()
            return
        }

        // If paused on same audio, resume
        if (_currentlyPlayingUrl.value == url && mediaPlayer != null && !_isBuffering.value) {
            try {
                requestAudioFocus(context)
                mediaPlayer?.start()
                _isPlaying.value = true
                startProgressTracking()
                return
            } catch (e: Exception) {
                Log.w("AudioPlayerHelper", "Failed to resume: ${e.message}")
            }
        }

        // Stop any previous playback
        stopAudio(context)

        _currentlyPlayingUrl.value = url
        _isBuffering.value = true

        scope.launch {
            try {
                val effectiveContext = context ?: try {
                    EternalLoveApplication.instance
                } catch (_: Throwable) {
                    null
                }

                // Resolve private Supabase reference to signed URL if needed
                val playUrl = if (MediaUrlResolver.isSupabaseReference(url)) {
                    MediaUrlResolver.resolveMediaUrl(url)
                } else {
                    url
                }

                if (playUrl.isBlank()) {
                    _playbackErrorUrl.value = url
                    stopAudio(context)
                    return@launch
                }

                // Download / cache to file for 100% reliable local playback
                val sourcePath = if (effectiveContext != null && (playUrl.startsWith("http://") || playUrl.startsWith("https://"))) {
                    getOrDownloadCachedFile(effectiveContext, playUrl, cacheKey = url) ?: playUrl
                } else {
                    playUrl
                }

                startMediaPlayer(sourcePath, url, effectiveContext)
            } catch (e: Exception) {
                Log.e("AudioPlayerHelper", "Failed to prepare audio playback: ${e.message}", e)
                _playbackErrorUrl.value = url
                stopAudio(context)
            }
        }
    }

    fun seekTo(percent: Float) {
        val player = mediaPlayer ?: return
        try {
            val duration = player.duration
            if (duration > 0) {
                val targetMs = (percent.coerceIn(0f, 1f) * duration).toInt()
                player.seekTo(targetMs)
                _progressPercent.value = percent.coerceIn(0f, 1f)
                _currentPositionSeconds.value = targetMs / 1000
            }
        } catch (e: Exception) {
            Log.w("AudioPlayerHelper", "Failed to seek: ${e.message}")
        }
    }

    private fun startMediaPlayer(dataSource: String, originalUrl: String, context: Context?) {
        try {
            val player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(dataSource)
                setOnPreparedListener { mp ->
                    _isBuffering.value = false
                    _isPlaying.value = true
                    _currentlyPlayingUrl.value = originalUrl
                    try {
                        requestAudioFocus(context)
                        mp.start()
                        startProgressTracking()
                    } catch (e: Exception) {
                        Log.e("AudioPlayerHelper", "Failed to start player: ${e.message}")
                        _playbackErrorUrl.value = originalUrl
                        stopAudio(context)
                    }
                }
                setOnCompletionListener {
                    stopAudio(context)
                }
                setOnErrorListener { _, what, extra ->
                    Log.e("AudioPlayerHelper", "MediaPlayer error: what=$what, extra=$extra")
                    _playbackErrorUrl.value = originalUrl
                    stopAudio(context)
                    true
                }
                prepareAsync()
            }
            mediaPlayer = player
        } catch (e: Exception) {
            Log.e("AudioPlayerHelper", "Failed in startMediaPlayer: ${e.message}", e)
            _playbackErrorUrl.value = originalUrl
            stopAudio(context)
        }
    }

    fun pauseAudio() {
        try {
            if (mediaPlayer?.isPlaying == true) {
                mediaPlayer?.pause()
            }
            _isPlaying.value = false
            progressJob?.cancel()
            progressJob = null
        } catch (e: Exception) {
            Log.w("AudioPlayerHelper", "Failed to pause: ${e.message}")
        }
    }

    fun stopAudio(context: Context? = null) {
        try {
            progressJob?.cancel()
            progressJob = null
            mediaPlayer?.apply {
                if (isPlaying) {
                    stop()
                }
                reset()
                release()
            }
            mediaPlayer = null
        } catch (e: Exception) {
            Log.w("AudioPlayerHelper", "Error releasing MediaPlayer: ${e.message}")
        } finally {
            mediaPlayer = null
            _isPlaying.value = false
            _isBuffering.value = false
            _currentlyPlayingUrl.value = null
            _progressPercent.value = 0f
            _currentPositionSeconds.value = 0
            abandonAudioFocus(context)
        }
    }

    private fun startProgressTracking() {
        progressJob?.cancel()
        progressJob = scope.launch {
            while (isActive) {
                val player = mediaPlayer
                if (player != null && player.isPlaying) {
                    val duration = player.duration
                    val current = player.currentPosition
                    if (duration > 0) {
                        _progressPercent.value = (current.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
                        _currentPositionSeconds.value = current / 1000
                    }
                }
                delay(100)
            }
        }
    }

    private suspend fun getOrDownloadCachedFile(context: Context, downloadUrl: String, cacheKey: String = downloadUrl): String? = withContext(Dispatchers.IO) {
        try {
            val cacheDir = File(context.cacheDir, "voice_cache").apply { if (!exists()) mkdirs() }
            val stableKey = cacheKey.substringBefore("?")
            val hash = md5(stableKey)
            val cachedFile = File(cacheDir, "voice_$hash.m4a")

            if (cachedFile.exists() && cachedFile.length() > 0) {
                return@withContext cachedFile.absolutePath
            }

            val requestBuilder = Request.Builder().url(downloadUrl)
            val pubKey = SupabaseConfig.publishableKey
            if (pubKey.isNotBlank()) {
                requestBuilder.header("apikey", pubKey)
            }

            httpClient.newCall(requestBuilder.build()).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body ?: return@withContext null
                    val tempFile = File(cacheDir, "voice_${hash}_temp.m4a")
                    FileOutputStream(tempFile).use { fos ->
                        body.byteStream().use { input ->
                            input.copyTo(fos)
                        }
                    }
                    if (tempFile.length() > 0 && tempFile.renameTo(cachedFile)) {
                        return@withContext cachedFile.absolutePath
                    } else if (tempFile.length() > 0) {
                        return@withContext tempFile.absolutePath
                    }
                } else {
                    Log.w("AudioPlayerHelper", "Download failed HTTP ${response.code} for $downloadUrl")
                }
            }
            null
        } catch (e: Exception) {
            Log.w("AudioPlayerHelper", "Failed to cache audio file: ${e.message}")
            null
        }
    }

    private fun md5(input: String): String {
        val md = MessageDigest.getInstance("MD5")
        return md.digest(input.toByteArray()).joinToString("") { "%02x".format(it) }
    }
}
