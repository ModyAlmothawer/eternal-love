package com.example.util

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import android.util.Log
import java.io.File
import java.io.IOException

class AudioRecorderHelper(private val context: Context) {

    private var recorder: MediaRecorder? = null
    private var currentOutputFile: File? = null
    private var recordStartTimeMillis: Long = 0L

    var isRecording: Boolean = false
        private set

    fun startRecording(): File? {
        if (isRecording) {
            stopRecording()
        }

        return try {
            val audioDir = File(context.cacheDir, "voice_notes")
            if (!audioDir.exists()) {
                audioDir.mkdirs()
            }
            val outputFile = File(audioDir, "rec_${System.currentTimeMillis()}.m4a")
            currentOutputFile = outputFile

            val newRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }

            newRecorder.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioSamplingRate(44100)
                setAudioEncodingBitRate(64000)
                setOutputFile(outputFile.absolutePath)
                prepare()
                start()
            }

            recorder = newRecorder
            isRecording = true
            recordStartTimeMillis = System.currentTimeMillis()
            outputFile
        } catch (e: Exception) {
            Log.e("AudioRecorderHelper", "Failed to start recording: ${e.message}", e)
            cleanup()
            null
        }
    }

    fun stopRecording(): Pair<File?, Int> {
        if (!isRecording) return Pair(null, 0)

        val durationSeconds = ((System.currentTimeMillis() - recordStartTimeMillis) / 1000).toInt()
        val file = currentOutputFile

        try {
            recorder?.apply {
                stop()
                release()
            }
        } catch (e: Exception) {
            Log.w("AudioRecorderHelper", "Error stopping recorder: ${e.message}")
        } finally {
            recorder = null
            isRecording = false
            currentOutputFile = null
        }

        return Pair(file, durationSeconds)
    }

    fun cancelRecording() {
        try {
            recorder?.apply {
                stop()
                release()
            }
        } catch (e: Exception) {
            Log.w("AudioRecorderHelper", "Error cancelling recorder: ${e.message}")
        } finally {
            currentOutputFile?.delete()
            cleanup()
        }
    }

    private fun cleanup() {
        recorder = null
        isRecording = false
        currentOutputFile = null
    }
}
