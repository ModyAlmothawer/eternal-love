package com.example

import android.Manifest
import android.content.ContextWrapper
import android.content.pm.PackageManager
import android.content.res.AssetManager
import android.content.res.Configuration
import android.content.res.Resources
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.LocalActivityResultRegistryOwner
import androidx.activity.compose.LocalOnBackPressedDispatcherOwner
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.local.LoveDatabase
import com.example.data.repository.LoveRepository
import com.example.ui.screens.CelebrationScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.MainAppContainer
import com.example.ui.screens.RegisterScreen
import com.example.ui.screens.RelationshipSetupScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.WelcomeScreen
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.EternalLoveTheme
import com.example.ui.theme.RoseGold
import com.example.ui.theme.SoftBlush
import com.example.ui.viewmodel.AuthScreenState
import com.example.ui.viewmodel.AuthViewModel
import com.example.ui.viewmodel.AuthViewModelFactory
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.MainViewModelFactory
import java.util.Locale

class MainActivity : ComponentActivity() {

    private lateinit var repository: LoveRepository

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        // Notification permission result handled safely
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = LoveDatabase.getDatabase(applicationContext)
        repository = LoveRepository(
            loveDao = database.loveDao(),
            firebaseService = com.example.data.remote.FirebaseLoveService(),
            context = applicationContext
        )

        val authViewModel: AuthViewModel by viewModels {
            AuthViewModelFactory(repository)
        }

        val mainViewModel: MainViewModel by viewModels {
            MainViewModelFactory(repository)
        }

        // Request POST_NOTIFICATIONS on Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        setContent {
            val isDark by repository.isDarkMode.collectAsState()
            val currentLanguage by repository.currentLanguage.collectAsState()
            val isRtl = currentLanguage == "ar"
            val layoutDirection = if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr

            val activity = this@MainActivity
            val localizedContext = remember(currentLanguage, activity) {
                val locale = Locale(currentLanguage)
                Locale.setDefault(locale)
                val config = Configuration(activity.resources.configuration)
                config.setLocale(locale)
                config.setLayoutDirection(locale)
                val configContext = activity.createConfigurationContext(config)
                object : ContextWrapper(activity) {
                    override fun getResources(): Resources = configContext.resources
                    override fun getAssets(): AssetManager = configContext.assets
                }
            }

            CompositionLocalProvider(
                LocalLayoutDirection provides layoutDirection,
                LocalContext provides localizedContext,
                LocalActivityResultRegistryOwner provides activity,
                LocalOnBackPressedDispatcherOwner provides activity
            ) {
                // Application ALWAYS uses dark romantic theme
                EternalLoveTheme(darkTheme = true) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        EternalLoveApp(
                            authViewModel = authViewModel,
                            mainViewModel = mainViewModel
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun EternalLoveApp(
    authViewModel: AuthViewModel,
    mainViewModel: MainViewModel
) {
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START, Lifecycle.Event.ON_RESUME -> {
                    mainViewModel.setOnlinePresence(true)
                }
                Lifecycle.Event.ON_STOP, Lifecycle.Event.ON_PAUSE -> {
                    mainViewModel.setOnlinePresence(false)
                }
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            mainViewModel.setOnlinePresence(false)
        }
    }

    val context = LocalContext.current
    val appUpdateInfo by mainViewModel.appUpdateInfo.collectAsState()
    var showUpdateDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        mainViewModel.checkForAppUpdates()
    }

    LaunchedEffect(appUpdateInfo) {
        appUpdateInfo?.let { info ->
            if (info.latestVersionCode > 1) { // 1 is default BuildConfig.VERSION_CODE
                showUpdateDialog = true
            }
        }
    }

    val authScreenState by authViewModel.screenState.collectAsState()
    val isLoading by authViewModel.isLoading.collectAsState()
    val errorMessage by authViewModel.errorMessage.collectAsState()
    val successMessage by authViewModel.successMessage.collectAsState()
    val generatedCode by authViewModel.generatedCode.collectAsState()
    val currentUser by authViewModel.currentUser.collectAsState()
    val currentRelationship by authViewModel.currentRelationship.collectAsState()
    val currentLanguage by authViewModel.currentLanguage.collectAsState()
    val showForgotPasswordDialog by authViewModel.showForgotPasswordDialog.collectAsState()

    if (showUpdateDialog && appUpdateInfo != null) {
        val info = appUpdateInfo!!
        AlertDialog(
            onDismissRequest = {
                if (!info.isMandatory) showUpdateDialog = false
            },
            title = {
                Text(
                    text = "تحديث جديد متاح لتطبيق حكايتنا 🌸",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = SoftBlush
                )
            },
            text = {
                Text(
                    text = if (info.releaseNotesAr.isNotBlank()) info.releaseNotesAr else "في إصدار أحدث جاهز للتحميل عشان تجربة أحسن وأجمل ليكم سوا.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SoftBlush.copy(alpha = 0.85f)
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (info.downloadUrl.isNotBlank()) {
                            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(info.downloadUrl))
                            context.startActivity(intent)
                        }
                    }
                ) {
                    Text(text = "تحميل التحديث", color = CrimsonPrimary, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = if (!info.isMandatory) {
                {
                    TextButton(onClick = { showUpdateDialog = false }) {
                        Text(text = "لاحقاً", color = RoseGold)
                    }
                }
            } else null,
            containerColor = Color(0xFF200918),
            shape = RoundedCornerShape(20.dp)
        )
    }

    AnimatedContent(
        targetState = authScreenState,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "auth_screen_transition"
    ) { screen ->
        when (screen) {
            AuthScreenState.Splash -> {
                SplashScreen()
            }
            AuthScreenState.Welcome -> {
                WelcomeScreen(
                    onGetStarted = { authViewModel.navigateTo(AuthScreenState.Register) },
                    onLogin = { authViewModel.navigateTo(AuthScreenState.Login) },
                    currentLanguage = currentLanguage,
                    onLanguageChange = { authViewModel.setLanguage(it) }
                )
            }
            AuthScreenState.Login -> {
                LoginScreen(
                    onLogin = { email, pass ->
                        authViewModel.login(email, pass)
                    },
                    onNavigateToRegister = {
                        authViewModel.navigateTo(AuthScreenState.Register)
                    },
                    onForgotPassword = { email ->
                        authViewModel.sendPasswordReset(email)
                    },
                    isLoading = isLoading,
                    errorMessage = errorMessage,
                    successMessage = successMessage,
                    showForgotDialog = showForgotPasswordDialog,
                    onShowForgotDialog = { authViewModel.showForgotPassword(it) }
                )
            }
            AuthScreenState.Register -> {
                RegisterScreen(
                    onRegister = { name, email, pass, confirmPass ->
                        authViewModel.register(name, email, pass, confirmPass)
                    },
                    onNavigateToLogin = {
                        authViewModel.navigateTo(AuthScreenState.Login)
                    },
                    isLoading = isLoading,
                    errorMessage = errorMessage
                )
            }
            AuthScreenState.SetupRelationship -> {
                RelationshipSetupScreen(
                    onCreateRelationship = { startDateMillis ->
                        authViewModel.createRelationship(startDateMillis)
                    },
                    onJoinRelationship = { code ->
                        authViewModel.joinRelationship(code)
                    },
                    isLoading = isLoading,
                    errorMessage = errorMessage,
                    generatedCode = generatedCode
                )
            }
            AuthScreenState.Celebration -> {
                CelebrationScreen(
                    userName = currentUser?.name ?: "You",
                    partnerName = currentUser?.partnerName?.ifBlank { "My Love" }
                        ?: currentRelationship?.partnerName?.ifBlank { "My Love" }
                        ?: "My Love",
                    loveCode = generatedCode ?: currentRelationship?.code,
                    onContinue = {
                        authViewModel.proceedToMain()
                    }
                )
            }
            AuthScreenState.Main -> {
                MainAppContainer(
                    viewModel = mainViewModel,
                    onLogout = {
                        authViewModel.logout()
                    },
                    onDisconnected = {
                        authViewModel.navigateTo(AuthScreenState.SetupRelationship)
                    }
                )
            }
        }
    }
}
