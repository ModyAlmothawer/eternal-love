package com.example

import android.content.Context
import androidx.activity.compose.LocalActivityResultRegistryOwner
import androidx.activity.compose.LocalOnBackPressedDispatcherOwner
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.LoveDatabase
import com.example.data.remote.FirebaseLoveService
import com.example.data.repository.LoveRepository
import com.example.ui.screens.MemoriesScreen
import com.example.ui.screens.ProfileAndSettingsScreen
import com.example.ui.theme.EternalLoveTheme
import com.example.ui.viewmodel.MainViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @get:Rule
  val composeTestRule = createComposeRule()

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Любовь", appName)
  }

  @Test
  fun `launch MainActivity`() {
    val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
    val activity = controller.get()
    assertNotNull(activity)
  }

  @Test
  fun `render MemoriesScreen`() {
    val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
    val activity = controller.get()
    val database = LoveDatabase.getDatabase(activity)
    val repo = LoveRepository(
        loveDao = database.loveDao(),
        firebaseService = FirebaseLoveService(),
        context = activity
    )
    val viewModel = MainViewModel(repo)

    composeTestRule.mainClock.autoAdvance = false

    composeTestRule.setContent {
      CompositionLocalProvider(
        LocalActivityResultRegistryOwner provides activity,
        LocalOnBackPressedDispatcherOwner provides activity
      ) {
        EternalLoveTheme {
          MemoriesScreen(viewModel = viewModel)
        }
      }
    }
  }

  @Test
  fun `render ProfileAndSettingsScreen`() {
    val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
    val activity = controller.get()
    val database = LoveDatabase.getDatabase(activity)
    val repo = LoveRepository(
        loveDao = database.loveDao(),
        firebaseService = FirebaseLoveService(),
        context = activity
    )
    val viewModel = MainViewModel(repo)

    composeTestRule.mainClock.autoAdvance = false

    composeTestRule.setContent {
      CompositionLocalProvider(
        LocalActivityResultRegistryOwner provides activity,
        LocalOnBackPressedDispatcherOwner provides activity
      ) {
        EternalLoveTheme {
          ProfileAndSettingsScreen(
              viewModel = viewModel,
              onLogout = {},
              onDisconnected = {}
          )
        }
      }
    }
  }
}
