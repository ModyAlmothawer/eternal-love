package com.example

import android.app.Application
import android.util.Log
import coil.ImageLoader
import coil.ImageLoaderFactory
import com.example.ui.coil.SupabaseMediaInterceptor
import com.google.firebase.FirebaseApp

class EternalLoveApplication : Application(), ImageLoaderFactory {

    companion object {
        lateinit var instance: EternalLoveApplication
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        initializeFirebase()
    }

    override fun newImageLoader(): ImageLoader {
        return ImageLoader.Builder(this)
            .components {
                add(SupabaseMediaInterceptor())
            }
            .crossfade(true)
            .build()
    }

    private fun initializeFirebase() {

        try {
            if (FirebaseApp.getApps(this).isEmpty()) {
                val app = FirebaseApp.initializeApp(this)
                if (app != null) {
                    Log.i("EternalLoveApplication", "FirebaseApp successfully initialized from google-services.json")
                } else {
                    Log.w("EternalLoveApplication", "FirebaseApp.initializeApp returned null")
                }
            } else {
                Log.i("EternalLoveApplication", "FirebaseApp is already initialized")
            }
        } catch (e: Exception) {
            Log.e("EternalLoveApplication", "Error initializing Firebase: ${e.message}", e)
        }
    }
}
