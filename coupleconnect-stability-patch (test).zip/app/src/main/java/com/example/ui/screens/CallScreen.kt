package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.R
import com.example.data.model.CallSession
import com.example.ui.components.RomanticAvatar
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.RoseGold
import com.example.ui.theme.SoftBlush
import com.example.ui.viewmodel.MainViewModel
import com.example.util.CallState
import org.webrtc.RendererCommon
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack
import java.util.Locale

@Composable
fun CallHostOverlay(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val callState by viewModel.callState.collectAsState()
    val incomingCall by viewModel.incomingCall.collectAsState()
    val activeSession by viewModel.activeCallSession.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    // 1. Incoming Call Prompt
    if (callState == CallState.IDLE && incomingCall != null) {
        val session = incomingCall!!
        IncomingCallDialog(
            session = session,
            partnerName = session.callerName.ifBlank { "شريك حياتك" },
            partnerPhoto = currentUser?.partnerPhotoUrl ?: "",
            onAccept = {
                viewModel.acceptCall(session)
            },
            onDecline = {
                viewModel.declineIncomingCall(session)
            }
        )
    }

    // 2. Active Outgoing or Connected Call View
    if (callState != CallState.IDLE) {
        val session = activeSession
        val partnerName = if (session?.callerUid == currentUser?.firebaseUid) {
            currentUser?.partnerName ?: "حبيبي"
        } else {
            session?.callerName ?: "حبيبي"
        }
        val partnerPhoto = currentUser?.partnerPhotoUrl ?: ""

        ActiveCallScreen(
            viewModel = viewModel,
            partnerName = partnerName,
            partnerPhoto = partnerPhoto,
            modifier = modifier
        )
    }
}

@Composable
fun IncomingCallDialog(
    session: CallSession,
    partnerName: String,
    partnerPhoto: String,
    onAccept: () -> Unit,
    onDecline: () -> Unit
) {
    val context = LocalContext.current
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val recordAudioGranted = permissions[Manifest.permission.RECORD_AUDIO] ?: false
        val cameraGranted = if (session.type == "video") {
            permissions[Manifest.permission.CAMERA] ?: false
        } else true

        if (recordAudioGranted && cameraGranted) {
            onAccept()
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "pulse_ring")
    val scaleAnim by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    AlertDialog(
        onDismissRequest = onDecline,
        title = null,
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.scale(scaleAnim)
                ) {
                    Box(
                        modifier = Modifier
                            .size(105.dp)
                            .background(CrimsonPrimary.copy(alpha = 0.25f), CircleShape)
                    )
                    RomanticAvatar(
                        photoUrl = partnerPhoto,
                        avatarRes = "avatar_2",
                        size = 85.dp,
                        borderColor = CrimsonPrimary,
                        borderWidth = 3.dp
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                Text(
                    text = partnerName,
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = SoftBlush
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = if (session.type == "video") "مكالمة فيديو واردة 📹" else "مكالمة صوتية واردة 📞",
                    style = MaterialTheme.typography.bodyMedium,
                    color = RoseGold
                )

                Spacer(modifier = Modifier.height(28.dp))

                // Action Buttons: Decline (Red) and Accept (Green)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Decline
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        IconButton(
                            onClick = onDecline,
                            modifier = Modifier
                                .size(56.dp)
                                .background(Color(0xFFE53935), CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CallEnd,
                                contentDescription = "رفض",
                                tint = Color.White,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Text(
                            text = "رفض",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = SoftBlush
                        )
                    }

                    // Accept
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        IconButton(
                            onClick = {
                                val neededPermissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
                                if (session.type == "video") {
                                    neededPermissions.add(Manifest.permission.CAMERA)
                                }
                                val allGranted = neededPermissions.all {
                                    ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
                                }
                                if (allGranted) {
                                    onAccept()
                                } else {
                                    permissionLauncher.launch(neededPermissions.toTypedArray())
                                }
                            },
                            modifier = Modifier
                                .size(56.dp)
                                .background(Color(0xFF43A047), CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Call,
                                contentDescription = "رد",
                                tint = Color.White,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Text(
                            text = "رد",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = SoftBlush
                        )
                    }
                }
            }
        },
        confirmButton = {},
        containerColor = Color(0xFF1B0716),
        shape = RoundedCornerShape(28.dp)
    )
}

@Composable
fun ActiveCallScreen(
    viewModel: MainViewModel,
    partnerName: String,
    partnerPhoto: String,
    modifier: Modifier = Modifier
) {
    val session by viewModel.activeCallSession.collectAsState()
    val callState by viewModel.callState.collectAsState()
    val isMicMuted by viewModel.isMicMuted.collectAsState()
    val isCameraEnabled by viewModel.isCameraEnabled.collectAsState()
    val isSpeakerOn by viewModel.isSpeakerphoneOn.collectAsState()
    val durationSeconds by viewModel.callDurationSeconds.collectAsState()
    val statusMessage by viewModel.callStatusMessage.collectAsState()

    val localVideo by viewModel.localVideoTrack.collectAsState()
    val remoteVideo by viewModel.remoteVideoTrack.collectAsState()

    val isVideoCall = session?.type == "video"

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F040E))
    ) {
        if (isVideoCall) {
            // Fullscreen Remote Video
            if (remoteVideo != null && callState == CallState.CONNECTED) {
                WebRtcVideoView(
                    videoTrack = remoteVideo,
                    isMirror = false,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                // Video connecting placeholder
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0xFF1F0819), Color(0xFF0D020B))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        RomanticAvatar(
                            photoUrl = partnerPhoto,
                            avatarRes = "avatar_2",
                            size = 110.dp,
                            borderColor = CrimsonPrimary,
                            borderWidth = 3.dp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = partnerName,
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = SoftBlush
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = statusMessage.ifBlank { "جاري توصيل الفيديو..." },
                            style = MaterialTheme.typography.bodyMedium,
                            color = RoseGold
                        )
                    }
                }
            }

            // Picture-in-Picture Local Camera View
            if (localVideo != null && isCameraEnabled) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 48.dp, end = 16.dp)
                        .width(110.dp)
                        .height(160.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .border(2.dp, CrimsonPrimary, RoundedCornerShape(16.dp))
                        .background(Color.Black)
                ) {
                    WebRtcVideoView(
                        videoTrack = localVideo,
                        isMirror = true,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        } else {
            // Pure Voice Call Visuals
            VoiceCallView(
                partnerName = partnerName,
                partnerPhoto = partnerPhoto,
                statusMessage = statusMessage,
                durationSeconds = durationSeconds,
                callState = callState,
                modifier = Modifier.fillMaxSize()
            )
        }

        // Top Status Header (Timer / Status)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 48.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (isVideoCall) {
                Text(
                    text = partnerName,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = SoftBlush
                )
                Spacer(modifier = Modifier.height(4.dp))
            }

            val timerText = if (callState == CallState.CONNECTED && durationSeconds > 0) {
                val mins = durationSeconds / 60
                val secs = durationSeconds % 60
                String.format(Locale.US, "%02d:%02d", mins, secs)
            } else {
                statusMessage.ifBlank { if (callState == CallState.OUTGOING_RINGING) "جاري الاتصال..." else "" }
            }

            if (timerText.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0x99000000))
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = timerText,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                }
            }
        }

        // Bottom Controls Bar
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Color(0xDD0A0108))
                    )
                )
                .padding(horizontal = 24.dp, vertical = 36.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Mute / Unmute Mic
            IconButton(
                onClick = { viewModel.toggleMic() },
                modifier = Modifier
                    .size(52.dp)
                    .background(if (isMicMuted) Color(0x66FF4D79) else Color(0x33FFFFFF), CircleShape)
            ) {
                Icon(
                    imageVector = if (isMicMuted) Icons.Default.MicOff else Icons.Default.Mic,
                    contentDescription = if (isMicMuted) "إلغاء كتم الصوت" else "كتم الصوت",
                    tint = SoftBlush,
                    modifier = Modifier.size(24.dp)
                )
            }

            if (isVideoCall) {
                // Switch Camera
                IconButton(
                    onClick = { viewModel.switchCamera() },
                    modifier = Modifier
                        .size(52.dp)
                        .background(Color(0x33FFFFFF), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Cameraswitch,
                        contentDescription = "تبديل الكاميرا",
                        tint = SoftBlush,
                        modifier = Modifier.size(24.dp)
                    )
                }

                // Camera On / Off
                IconButton(
                    onClick = { viewModel.toggleCamera() },
                    modifier = Modifier
                        .size(52.dp)
                        .background(if (!isCameraEnabled) Color(0x66FF4D79) else Color(0x33FFFFFF), CircleShape)
                ) {
                    Icon(
                        imageVector = if (isCameraEnabled) Icons.Default.Videocam else Icons.Default.VideocamOff,
                        contentDescription = if (isCameraEnabled) "إيقاف الكاميرا" else "تشغيل الكاميرا",
                        tint = SoftBlush,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            // Speakerphone Toggle
            IconButton(
                onClick = { viewModel.toggleSpeakerphone() },
                modifier = Modifier
                    .size(52.dp)
                    .background(if (isSpeakerOn) Color(0x66FF4D79) else Color(0x33FFFFFF), CircleShape)
            ) {
                Icon(
                    imageVector = if (isSpeakerOn) Icons.Default.VolumeUp else Icons.Default.VolumeDown,
                    contentDescription = if (isSpeakerOn) "مكبر الصوت يعمل" else "تشغيل مكبر الصوت",
                    tint = SoftBlush,
                    modifier = Modifier.size(24.dp)
                )
            }

            // End Call Button (Red)
            IconButton(
                onClick = { viewModel.endCall() },
                modifier = Modifier
                    .size(64.dp)
                    .background(Color(0xFFE53935), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.CallEnd,
                    contentDescription = "إنهاء المكالمة",
                    tint = Color.White,
                    modifier = Modifier.size(32.dp)
                )
            }
        }
    }
}

@Composable
private fun VoiceCallView(
    partnerName: String,
    partnerPhoto: String,
    statusMessage: String,
    durationSeconds: Int,
    callState: CallState,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_rings")
    val pulseAnim by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Box(
        modifier = modifier.background(
            Brush.verticalGradient(
                listOf(Color(0xFF22081C), Color(0xFF0E020C))
            )
        ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.scale(if (callState == CallState.CONNECTED) 1f else pulseAnim)
            ) {
                Box(
                    modifier = Modifier
                        .size(150.dp)
                        .background(CrimsonPrimary.copy(alpha = 0.2f), CircleShape)
                )
                Box(
                    modifier = Modifier
                        .size(130.dp)
                        .background(CrimsonPrimary.copy(alpha = 0.35f), CircleShape)
                )
                RomanticAvatar(
                    photoUrl = partnerPhoto,
                    avatarRes = "avatar_2",
                    size = 110.dp,
                    borderColor = CrimsonPrimary,
                    borderWidth = 4.dp
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = partnerName,
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                color = SoftBlush
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "مكالمة صوتية دافية ❤️",
                style = MaterialTheme.typography.bodyMedium,
                color = RoseGold
            )
        }
    }
}

@Composable
fun WebRtcVideoView(
    videoTrack: VideoTrack?,
    isMirror: Boolean,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val webRtcManager = remember { com.example.util.WebRtcManager.getInstance(context) }

    AndroidView(
        factory = { ctx ->
            SurfaceViewRenderer(ctx).apply {
                init(webRtcManager.eglBase.eglBaseContext, null)
                setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL)
                setMirror(isMirror)
                setEnableHardwareScaler(true)
                videoTrack?.addSink(this)
            }
        },
        update = { renderer ->
            videoTrack?.addSink(renderer)
        },
        modifier = modifier
    )

    DisposableEffect(videoTrack) {
        onDispose {
            // Note: renderer is released in factory's view detachment or by caller
        }
    }
}
