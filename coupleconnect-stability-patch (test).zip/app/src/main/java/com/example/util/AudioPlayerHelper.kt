package com.example.util

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.util.Log
import com.example.EternalLoveApplication
import com.example.data.remote.MediaUrlResolver
import kotlinx.coroutines.CoroutineScope

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

object AudioPlayerHelper {

    private var mediaPlayer: MediaPlayer? = null
    private var progressJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main)

    private val _currentlyPlayingUrl = MutableStateFlow<String?>(null)
    val currentlyPlayingUrl: StateFlow<String?> = _currentlyPlayingUrl.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _isBuffering = MutableStateFlow(false)
    val isBuffering: StateFlow<Boolean> = _isBuffering.asStateFlow()

    private val _progressPercent = MutableStateFlow(0f)
    val progressPercent: StateFlow<Float> = _progressPercent.asStateFlow()

    private val _currentPositionSeconds = MutableStateFlow(0)
    val currentPositionSeconds: StateFlow<Int> = _currentPositionSeconds.asStateFlow()

    fun playAudio(url: String, context: Context? = null) {
        if (url.isBlank()) return

        // If already playing this audio, pause it
        if (_currentlyPlayingUrl.value == url && _isPlaying.value) {
            pauseAudio()
            return
        }

        // If paused on same audio, resume
        if (_currentlyPlayingUrl.value == url && mediaPlayer != null && !_isBuffering.value) {
            try {
                mediaPlayer?.start()
                _isPlaying.value = true
                startProgressTracking()
                return
            } catch (e: Exception) {
                Log.w("AudioPlayerHelper", "Failed to resume: ${e.message}")
            }
        }

        // Stop any previous playback
        stopAudio()

        _currentlyPlayingUrl.value = url
        _isBuffering.value = true

        scope.launch {
            try {
                val effectiveContext = context ?: try {
                    EternalLoveApplication.instance
                } catch (_: Throwable) {
                    null
                }

                // Resolve private Supabase reference to signed URL if needed
                val playUrl = if (MediaUrlResolver.isSupabaseReference(url)) {
                    MediaUrlResolver.resolveMediaUrl(url)
                } else {
                    url
                }

                // If it's a remote URL and context is provided, check or cache to file
                val sourcePath = if (effectiveContext != null && (playUrl.startsWith("http://") || playUrl.startsWith("https://"))) {
                    getOrDownloadCachedFile(effectiveContext, playUrl, cacheKey = url) ?: playUrl
                } else {
                    playUrl
                }

                startMediaPlayer(sourcePath, url)
            } catch (e: Exception) {
                Log.e("AudioPlayerHelper", "Failed to prepare audio playback: ${e.message}", e)
                stopAudio()
            }
        }
    }


    private fun startMediaPlayer(dataSource: String, originalUrl: String) {
        try {
            val player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(dataSource)
                setOnPreparedListener { mp ->
                    _isBuffering.value = false
                    _isPlaying.value = true
                    _currentlyPlayingUrl.value = originalUrl
                    try {
                        mp.start()
                        startProgressTracking()
                    } catch (e: Exception) {
                        Log.e("AudioPlayerHelper", "Failed to start player: ${e.message}")
                        stopAudio()
                    }
                }
                setOnCompletionListener {
                    stopAudio()
                }
                setOnErrorListener { _, what, extra ->
                    Log.e("AudioPlayerHelper", "MediaPlayer error: what=$what, extra=$extra")
                    stopAudio()
                    true
                }
                prepareAsync()
            }
            mediaPlayer = player
        } catch (e: Exception) {
            Log.e("AudioPlayerHelper", "Failed in startMediaPlayer: ${e.message}", e)
            stopAudio()
        }
    }

    fun pauseAudio() {
        try {
            mediaPlayer?.pause()
            _isPlaying.value = false
            progressJob?.cancel()
        } catch (e: Exception) {
            Log.w("AudioPlayerHelper", "Error pausing audio: ${e.message}")
        }
    }

    fun stopAudio() {
        try {
            progressJob?.cancel()
            mediaPlayer?.apply {
                if (isPlaying) {
                    stop()
                }
                release()
            }
        } catch (e: Exception) {
            Log.w("AudioPlayerHelper", "Error stopping audio: ${e.message}")
        } finally {
            mediaPlayer = null
            _isPlaying.value = false
            _isBuffering.value = false
            _currentlyPlayingUrl.value = null
            _progressPercent.value = 0f
            _currentPositionSeconds.value = 0
        }
    }

    private fun startProgressTracking() {
        progressJob?.cancel()
        progressJob = scope.launch {
            while (isActive && _isPlaying.value) {
                val player = mediaPlayer
                if (player != null && player.isPlaying) {
                    val duration = player.duration
                    val current = player.currentPosition
                    if (duration > 0) {
                        _progressPercent.value = (current.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
                        _currentPositionSeconds.value = current / 1000
                    }
                }
                delay(100)
            }
        }
    }

    private suspend fun getOrDownloadCachedFile(context: Context, downloadUrl: String, cacheKey: String = downloadUrl): String? = withContext(Dispatchers.IO) {
        try {
            val cacheDir = File(context.cacheDir, "voice_cache").apply { if (!exists()) mkdirs() }
            // Stable hash based on original canonical URL (stripping temporary token params)
            val stableKey = cacheKey.substringBefore("?")
            val hash = md5(stableKey)
            val cachedFile = File(cacheDir, "voice_$hash.m4a")

            if (cachedFile.exists() && cachedFile.length() > 0) {
                return@withContext cachedFile.absolutePath
            }

            val connection = (URL(downloadUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15000
                readTimeout = 20000
                instanceFollowRedirects = true
            }


            if (connection.responseCode in 200..299) {
                val tempFile = File(cacheDir, "voice_${hash}_temp.m4a")
                connection.inputStream.use { input ->
                    FileOutputStream(tempFile).use { output ->
                        input.copyTo(output)
                    }
                }
                if (tempFile.length() > 0 && tempFile.renameTo(cachedFile)) {
                    return@withContext cachedFile.absolutePath
                } else if (tempFile.length() > 0) {
                    return@withContext tempFile.absolutePath
                }
            }
            null
        } catch (e: Exception) {
            Log.w("AudioPlayerHelper", "Failed to cache audio file: ${e.message}")
            null
        }
    }

    private fun md5(input: String): String {
        val md = MessageDigest.getInstance("MD5")
        return md.digest(input.toByteArray()).joinToString("") { "%02x".format(it) }
    }
}
