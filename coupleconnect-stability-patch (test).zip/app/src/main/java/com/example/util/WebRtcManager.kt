package com.example.util

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.data.model.CallSession
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.webrtc.AudioSource
import org.webrtc.AudioTrack
import org.webrtc.Camera2Enumerator
import org.webrtc.CameraVideoCapturer
import org.webrtc.DataChannel
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpReceiver
import org.webrtc.RtpTransceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceTextureHelper
import org.webrtc.VideoSource
import org.webrtc.VideoTrack
import java.util.UUID

enum class CallState {
    IDLE,
    OUTGOING_RINGING,
    INCOMING_RINGING,
    CONNECTING,
    CONNECTED,
    ENDED,
    ERROR
}

class WebRtcManager(private val context: Context) {

    companion object {
        private const val TAG = "WebRtcManager"
        @Volatile
        private var instance: WebRtcManager? = null

        fun getInstance(context: Context): WebRtcManager {
            return instance ?: synchronized(this) {
                instance ?: WebRtcManager(context.applicationContext).also { instance = it }
            }
        }
    }

    private val firestore = FirebaseFirestore.getInstance()
    private val scope = CoroutineScope(Dispatchers.Main + Job())

    val eglBase: EglBase by lazy { EglBase.create() }

    private var peerConnectionFactory: PeerConnectionFactory? = null
    private var peerConnection: PeerConnection? = null

    private var localAudioSource: AudioSource? = null
    private var localAudioTrack: AudioTrack? = null

    private var localVideoSource: VideoSource? = null
    private var localVideoTrack: VideoTrack? = null
    private var videoCapturer: CameraVideoCapturer? = null
    private var surfaceTextureHelper: SurfaceTextureHelper? = null

    // State flows
    private val _callState = MutableStateFlow(CallState.IDLE)
    val callState: StateFlow<CallState> = _callState.asStateFlow()

    private val _activeSession = MutableStateFlow<CallSession?>(null)
    val activeSession: StateFlow<CallSession?> = _activeSession.asStateFlow()

    private val _localVideo = MutableStateFlow<VideoTrack?>(null)
    val localVideo: StateFlow<VideoTrack?> = _localVideo.asStateFlow()

    private val _remoteVideo = MutableStateFlow<VideoTrack?>(null)
    val remoteVideo: StateFlow<VideoTrack?> = _remoteVideo.asStateFlow()

    private val _isMicMuted = MutableStateFlow(false)
    val isMicMuted: StateFlow<Boolean> = _isMicMuted.asStateFlow()

    private val _isCameraEnabled = MutableStateFlow(true)
    val isCameraEnabled: StateFlow<Boolean> = _isCameraEnabled.asStateFlow()

    private val _isSpeakerphoneOn = MutableStateFlow(false)
    val isSpeakerphoneOn: StateFlow<Boolean> = _isSpeakerphoneOn.asStateFlow()

    private val _callDurationSeconds = MutableStateFlow(0)
    val callDurationSeconds: StateFlow<Int> = _callDurationSeconds.asStateFlow()

    private val _statusMessage = MutableStateFlow("")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    // Firestore listeners
    private var callDocListener: ListenerRegistration? = null
    private var candidatesListener: ListenerRegistration? = null
    private var durationJob: Job? = null

    // Audio focus management
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var previousAudioMode = AudioManager.MODE_NORMAL
    private var previousSpeakerState = false

    init {
        initPeerConnectionFactory()
    }

    private fun initPeerConnectionFactory() {
        try {
            val initOptions = PeerConnectionFactory.InitializationOptions.builder(context)
                .createInitializationOptions()
            PeerConnectionFactory.initialize(initOptions)

            val options = PeerConnectionFactory.Options()
            val encoderFactory = DefaultVideoEncoderFactory(eglBase.eglBaseContext, true, true)
            val decoderFactory = DefaultVideoDecoderFactory(eglBase.eglBaseContext)

            peerConnectionFactory = PeerConnectionFactory.builder()
                .setOptions(options)
                .setVideoEncoderFactory(encoderFactory)
                .setVideoDecoderFactory(decoderFactory)
                .createPeerConnectionFactory()
            Log.d(TAG, "PeerConnectionFactory initialized successfully")
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to initialize PeerConnectionFactory: ${e.message}", e)
        }

    }

    fun hasCallPermissions(type: String): Boolean {
        val audioGranted = ContextCompat.checkSelfPermission(
            context, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (type == "video") {
            val cameraGranted = ContextCompat.checkSelfPermission(
                context, Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
            return audioGranted && cameraGranted
        }
        return audioGranted
    }

    /**
     * Caller starts a call.
     */
    suspend fun startCall(
        relationshipId: String,
        callerUid: String,
        callerName: String,
        calleeUid: String,
        type: String // "voice" or "video"
    ): Result<String> = withContext(Dispatchers.IO) {
        if (!hasCallPermissions(type)) {
            val msg = if (type == "video") "يرجى منح إذن الميكروفون والكاميرا لبدء مكالمة الفيديو ❤️"
            else "يرجى منح إذن الميكروفون لبدء المكالمة الصوتية ❤️"
            return@withContext Result.failure(SecurityException(msg))
        }

        cleanupPeerConnection()

        val callId = UUID.randomUUID().toString()
        val session = CallSession(
            callId = callId,
            relationshipId = relationshipId,
            callerUid = callerUid,
            callerName = callerName,
            calleeUid = calleeUid,
            type = type,
            status = "calling",
            createdAtMillis = System.currentTimeMillis()
        )

        _activeSession.value = session
        _callState.value = CallState.OUTGOING_RINGING
        _statusMessage.value = "جاري الاتصال بحبيبك..."

        setupAudioManager(type == "video")

        try {
            // Write initial call doc to Firestore
            val initialData = hashMapOf(
                "callId" to callId,
                "relationshipId" to relationshipId,
                "callerUid" to callerUid,
                "callerName" to callerName,
                "calleeUid" to calleeUid,
                "type" to type,
                "status" to "calling",
                "createdAtMillis" to session.createdAtMillis
            )
            firestore.collection("relationships").document(relationshipId)
                .collection("calls").document(callId)
                .set(initialData).await()

            // Setup local WebRTC tracks
            setupMediaTracks(type)

            // Create PeerConnection
            createPeerConnection(relationshipId, callId, isCaller = true)

            // Create SDP Offer
            val sdpConstraints = MediaConstraints().apply {
                mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
                if (type == "video") {
                    mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "true"))
                }
            }

            peerConnection?.createOffer(object : SdpObserver {
                override fun onCreateSuccess(desc: SessionDescription?) {
                    if (desc == null) return
                    peerConnection?.setLocalDescription(object : SdpObserver {
                        override fun onCreateSuccess(p0: SessionDescription?) {}
                        override fun onSetSuccess() {
                            // Upload offer to Firestore
                            scope.launch(Dispatchers.IO) {
                                try {
                                    val offerMap = mapOf("type" to "offer", "sdp" to desc.description)
                                    firestore.collection("relationships").document(relationshipId)
                                        .collection("calls").document(callId)
                                        .update(mapOf("offer" to offerMap)).await()
                                    Log.d(TAG, "SDP Offer uploaded to Firestore")
                                } catch (e: Exception) {
                                    Log.e(TAG, "Error uploading SDP offer: ${e.message}", e)
                                }
                            }
                        }
                        override fun onCreateFailure(p0: String?) {}
                        override fun onSetFailure(err: String?) {
                            Log.e(TAG, "setLocalDescription failure: $err")
                        }
                    }, desc)
                }

                override fun onSetSuccess() {}
                override fun onCreateFailure(err: String?) {
                    Log.e(TAG, "createOffer failure: $err")
                }
                override fun onSetFailure(err: String?) {}
            }, sdpConstraints)

            // Listen for Callee's Answer and Status updates
            listenToCallDoc(relationshipId, callId, isCaller = true)

            // Listen for Callee's ICE candidates
            listenToRemoteCandidates(relationshipId, callId, isCaller = true)

            Result.success(callId)
        } catch (e: Exception) {
            Log.e(TAG, "Error starting call: ${e.message}", e)
            cleanupPeerConnection()
            _callState.value = CallState.ERROR
            _statusMessage.value = "تعذر بدء المكالمة. تأكد من اتصال الإنترنت."
            Result.failure(e)
        }
    }

    /**
     * Callee accepts incoming call.
     */
    suspend fun acceptCall(session: CallSession): Result<Unit> = withContext(Dispatchers.IO) {
        if (!hasCallPermissions(session.type)) {
            val msg = if (session.type == "video") "يرجى منح إذن الميكروفون والكاميرا للرد على المكالمة ❤️"
            else "يرجى منح إذن الميكروفون للرد على المكالمة ❤️"
            return@withContext Result.failure(SecurityException(msg))
        }

        cleanupPeerConnection()

        _activeSession.value = session.copy(status = "connected")
        _callState.value = CallState.CONNECTING
        _statusMessage.value = "جاري توصيل المكالمة..."

        setupAudioManager(session.type == "video")

        try {
            // Read offer from Firestore
            val callDoc = firestore.collection("relationships").document(session.relationshipId)
                .collection("calls").document(session.callId)
                .get().await()

            val offerMap = callDoc.get("offer") as? Map<*, *>
            val offerSdp = offerMap?.get("sdp") as? String

            if (offerSdp.isNullOrBlank()) {
                throw IllegalStateException("لم يتم العثور على بيانات الاتصال من الطرف الآخر.")
            }

            // Setup local media tracks
            setupMediaTracks(session.type)

            // Create PeerConnection
            createPeerConnection(session.relationshipId, session.callId, isCaller = false)

            // Set Remote Description (Offer)
            peerConnection?.setRemoteDescription(object : SdpObserver {
                override fun onCreateSuccess(p0: SessionDescription?) {}
                override fun onSetSuccess() {
                    // Create Answer
                    val sdpConstraints = MediaConstraints().apply {
                        mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
                        if (session.type == "video") {
                            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "true"))
                        }
                    }

                    peerConnection?.createAnswer(object : SdpObserver {
                        override fun onCreateSuccess(answerDesc: SessionDescription?) {
                            if (answerDesc == null) return
                            peerConnection?.setLocalDescription(object : SdpObserver {
                                override fun onCreateSuccess(p0: SessionDescription?) {}
                                override fun onSetSuccess() {
                                    scope.launch(Dispatchers.IO) {
                                        try {
                                            val answerMap = mapOf("type" to "answer", "sdp" to answerDesc.description)
                                            firestore.collection("relationships").document(session.relationshipId)
                                                .collection("calls").document(session.callId)
                                                .update(mapOf(
                                                    "answer" to answerMap,
                                                    "status" to "connected"
                                                )).await()
                                            Log.d(TAG, "SDP Answer uploaded, call connected")
                                            _callState.value = CallState.CONNECTED
                                            _statusMessage.value = "متصل ❤️"
                                            startDurationTimer()
                                        } catch (e: Exception) {
                                            Log.e(TAG, "Error uploading SDP answer: ${e.message}", e)
                                        }
                                    }
                                }
                                override fun onCreateFailure(p0: String?) {}
                                override fun onSetFailure(err: String?) {
                                    Log.e(TAG, "setLocalDescription answer failure: $err")
                                }
                            }, answerDesc)
                        }

                        override fun onSetSuccess() {}
                        override fun onCreateFailure(err: String?) {
                            Log.e(TAG, "createAnswer failure: $err")
                        }
                        override fun onSetFailure(err: String?) {}
                    }, sdpConstraints)
                }

                override fun onCreateFailure(p0: String?) {}
                override fun onSetFailure(err: String?) {
                    Log.e(TAG, "setRemoteDescription offer failure: $err")
                }
            }, SessionDescription(SessionDescription.Type.OFFER, offerSdp))

            // Listen for call status changes (e.g. ended by caller)
            listenToCallDoc(session.relationshipId, session.callId, isCaller = false)

            // Listen for caller's ICE candidates
            listenToRemoteCandidates(session.relationshipId, session.callId, isCaller = false)

            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error accepting call: ${e.message}", e)
            cleanupPeerConnection()
            _callState.value = CallState.ERROR
            _statusMessage.value = "تعذر الرد على المكالمة."
            Result.failure(e)
        }
    }

    /**
     * Reject or hang up call cleanly.
     */
    fun endCall() {
        val session = _activeSession.value
        val relId = session?.relationshipId ?: ""
        val callId = session?.callId ?: ""

        if (relId.isNotBlank() && callId.isNotBlank()) {
            scope.launch(Dispatchers.IO) {
                try {
                    firestore.collection("relationships").document(relId)
                        .collection("calls").document(callId)
                        .update("status", "ended").await()
                } catch (e: Exception) {
                    Log.w(TAG, "Error updating call status to ended: ${e.message}")
                }
            }
        }

        cleanupPeerConnection()
        _callState.value = CallState.ENDED
        _statusMessage.value = "تم إنهاء المكالمة"
        scope.launch {
            delay(1500)
            if (_callState.value == CallState.ENDED) {
                _callState.value = CallState.IDLE
                _activeSession.value = null
            }
        }
    }

    fun toggleMic() {
        val newMute = !_isMicMuted.value
        localAudioTrack?.setEnabled(!newMute)
        _isMicMuted.value = newMute
    }

    fun toggleCamera() {
        val newEnabled = !_isCameraEnabled.value
        localVideoTrack?.setEnabled(newEnabled)
        _isCameraEnabled.value = newEnabled
    }

    fun switchCamera() {
        videoCapturer?.switchCamera(null)
    }

    fun toggleSpeakerphone() {
        val newState = !_isSpeakerphoneOn.value
        audioManager.isSpeakerphoneOn = newState
        _isSpeakerphoneOn.value = newState
    }

    private fun setupMediaTracks(type: String) {
        val factory = peerConnectionFactory ?: return

        // 1. Audio Track
        try {
            val audioConstraints = MediaConstraints().apply {
                mandatory.add(MediaConstraints.KeyValuePair("googEchoCancellation", "true"))
                mandatory.add(MediaConstraints.KeyValuePair("googAutoGainControl", "true"))
                mandatory.add(MediaConstraints.KeyValuePair("googHighpassFilter", "true"))
                mandatory.add(MediaConstraints.KeyValuePair("googNoiseSuppression", "true"))
            }
            localAudioSource = factory.createAudioSource(audioConstraints)
            localAudioTrack = factory.createAudioTrack("ARDAMSa0", localAudioSource).apply {
                setEnabled(true)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error creating audio track: ${e.message}", e)
        }

        // 2. Video Track (if video call)
        if (type == "video") {
            try {
                val enumerator = Camera2Enumerator(context)
                val deviceNames = enumerator.deviceNames
                val frontDevice = deviceNames.firstOrNull { enumerator.isFrontFacing(it) } ?: deviceNames.firstOrNull()

                if (frontDevice != null) {
                    surfaceTextureHelper = SurfaceTextureHelper.create("CaptureThread", eglBase.eglBaseContext)
                    val capturer = enumerator.createCapturer(frontDevice, null)
                    videoCapturer = capturer

                    localVideoSource = factory.createVideoSource(capturer.isScreencast)
                    capturer.initialize(surfaceTextureHelper, context, localVideoSource?.capturerObserver)
                    capturer.startCapture(640, 480, 24)

                    val videoTrack = factory.createVideoTrack("ARDAMSv0", localVideoSource).apply {
                        setEnabled(true)
                    }
                    localVideoTrack = videoTrack
                    _localVideo.value = videoTrack
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error creating video track: ${e.message}", e)
            }
        }
    }

    private fun createPeerConnection(relId: String, callId: String, isCaller: Boolean) {
        val factory = peerConnectionFactory ?: return

        val iceServers = listOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun2.l.google.com:19302").createIceServer()
        )

        val rtcConfig = PeerConnection.RTCConfiguration(iceServers).apply {
            tcpCandidatePolicy = PeerConnection.TcpCandidatePolicy.DISABLED
            bundlePolicy = PeerConnection.BundlePolicy.MAXBUNDLE
            rtcpMuxPolicy = PeerConnection.RtcpMuxPolicy.REQUIRE
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
            keyType = PeerConnection.KeyType.ECDSA
        }

        val observer = object : PeerConnection.Observer {
            override fun onIceCandidate(candidate: IceCandidate?) {
                if (candidate == null) return
                // Write candidate to Firestore
                scope.launch(Dispatchers.IO) {
                    try {
                        val subCollection = if (isCaller) "callerCandidates" else "calleeCandidates"
                        val candidateData = hashMapOf(
                            "sdpMid" to candidate.sdpMid,
                            "sdpMLineIndex" to candidate.sdpMLineIndex,
                            "candidate" to candidate.sdp,
                            "serverUrl" to candidate.serverUrl,
                            "createdAt" to System.currentTimeMillis()
                        )
                        firestore.collection("relationships").document(relId)
                            .collection("calls").document(callId)
                            .collection(subCollection).add(candidateData).await()
                    } catch (e: Exception) {
                        Log.w(TAG, "Error sending ICE candidate: ${e.message}")
                    }
                }
            }

            override fun onTrack(transceiver: RtpTransceiver?) {
                val track = transceiver?.receiver?.track()
                if (track is VideoTrack) {
                    _remoteVideo.value = track
                }
            }

            override fun onAddTrack(receiver: RtpReceiver?, mediaStreams: Array<out MediaStream>?) {
                val track = receiver?.track()
                if (track is VideoTrack) {
                    _remoteVideo.value = track
                }
            }

            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {
                Log.d(TAG, "ICE Connection State: $state")
                when (state) {
                    PeerConnection.IceConnectionState.CONNECTED -> {
                        _callState.value = CallState.CONNECTED
                        _statusMessage.value = "متصل ❤️"
                        startDurationTimer()
                    }
                    PeerConnection.IceConnectionState.DISCONNECTED,
                    PeerConnection.IceConnectionState.FAILED -> {
                        _statusMessage.value = "انقطع الاتصال..."
                    }
                    PeerConnection.IceConnectionState.CLOSED -> {
                        endCall()
                    }
                    else -> {}
                }
            }

            override fun onSignalingChange(p0: PeerConnection.SignalingState?) {}
            override fun onIceConnectionReceivingChange(p0: Boolean) {}
            override fun onIceGatheringChange(p0: PeerConnection.IceGatheringState?) {}
            override fun onIceCandidatesRemoved(p0: Array<out IceCandidate>?) {}
            override fun onAddStream(stream: MediaStream?) {
                val videoTracks = stream?.videoTracks
                if (!videoTracks.isNullOrEmpty()) {
                    _remoteVideo.value = videoTracks[0]
                }
            }
            override fun onRemoveStream(p0: MediaStream?) {}
            override fun onDataChannel(p0: DataChannel?) {}
            override fun onRenegotiationNeeded() {}
        }

        val pc = factory.createPeerConnection(rtcConfig, observer)
        peerConnection = pc

        // Attach local tracks
        localAudioTrack?.let { pc?.addTrack(it, listOf("ARDAMS")) }
        localVideoTrack?.let { pc?.addTrack(it, listOf("ARDAMS")) }
    }

    private fun listenToCallDoc(relId: String, callId: String, isCaller: Boolean) {
        callDocListener?.remove()
        callDocListener = firestore.collection("relationships").document(relId)
            .collection("calls").document(callId)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null || !snapshot.exists()) return@addSnapshotListener

                val status = snapshot.getString("status") ?: "calling"
                if (status == "ended" || status == "declined") {
                    _callState.value = CallState.ENDED
                    _statusMessage.value = if (status == "declined") "تم رفض المكالمة" else "انتهت المكالمة"
                    cleanupPeerConnection()
                    scope.launch {
                        delay(1500)
                        _callState.value = CallState.IDLE
                        _activeSession.value = null
                    }
                    return@addSnapshotListener
                }

                // If Caller, watch for Answer
                if (isCaller && _callState.value == CallState.OUTGOING_RINGING) {
                    val answerMap = snapshot.get("answer") as? Map<*, *>
                    val answerSdp = answerMap?.get("sdp") as? String
                    if (!answerSdp.isNullOrBlank() && peerConnection?.remoteDescription == null) {
                        peerConnection?.setRemoteDescription(object : SdpObserver {
                            override fun onCreateSuccess(p0: SessionDescription?) {}
                            override fun onSetSuccess() {
                                Log.d(TAG, "Caller setRemoteDescription(answer) success")
                                _callState.value = CallState.CONNECTED
                                _statusMessage.value = "متصل ❤️"
                                startDurationTimer()
                            }
                            override fun onCreateFailure(p0: String?) {}
                            override fun onSetFailure(err: String?) {
                                Log.e(TAG, "Caller setRemoteDescription error: $err")
                            }
                        }, SessionDescription(SessionDescription.Type.ANSWER, answerSdp))
                    }
                }
            }
    }

    private fun listenToRemoteCandidates(relId: String, callId: String, isCaller: Boolean) {
        candidatesListener?.remove()
        val targetCollection = if (isCaller) "calleeCandidates" else "callerCandidates"

        candidatesListener = firestore.collection("relationships").document(relId)
            .collection("calls").document(callId)
            .collection(targetCollection)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) return@addSnapshotListener
                for (doc in snapshot.documentChanges) {
                    if (doc.type == com.google.firebase.firestore.DocumentChange.Type.ADDED) {
                        val d = doc.document
                        val sdpMid = d.getString("sdpMid") ?: ""
                        val sdpMLineIndex = (d.getLong("sdpMLineIndex") ?: 0L).toInt()
                        val sdp = d.getString("candidate") ?: ""
                        if (sdp.isNotBlank()) {
                            val candidate = IceCandidate(sdpMid, sdpMLineIndex, sdp)
                            peerConnection?.addIceCandidate(candidate)
                        }
                    }
                }
            }
    }

    private fun setupAudioManager(isVideo: Boolean) {
        try {
            previousAudioMode = audioManager.mode
            previousSpeakerState = audioManager.isSpeakerphoneOn

            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
            audioManager.isSpeakerphoneOn = isVideo
            _isSpeakerphoneOn.value = isVideo
            audioManager.isMicrophoneMute = false
            _isMicMuted.value = false
        } catch (e: Exception) {
            Log.w(TAG, "Error setting up AudioManager: ${e.message}")
        }
    }

    private fun resetAudioManager() {
        try {
            audioManager.mode = previousAudioMode
            audioManager.isSpeakerphoneOn = previousSpeakerState
            audioManager.isMicrophoneMute = false
        } catch (e: Exception) {
            Log.w(TAG, "Error resetting AudioManager: ${e.message}")
        }
    }

    private fun startDurationTimer() {
        durationJob?.cancel()
        _callDurationSeconds.value = 0
        durationJob = scope.launch {
            while (isActive && _callState.value == CallState.CONNECTED) {
                delay(1000)
                _callDurationSeconds.value += 1
            }
        }
    }

    fun cleanupPeerConnection() {
        durationJob?.cancel()
        durationJob = null
        _callDurationSeconds.value = 0

        callDocListener?.remove()
        callDocListener = null

        candidatesListener?.remove()
        candidatesListener = null

        try {
            videoCapturer?.stopCapture()
        } catch (_: Exception) {}
        try {
            videoCapturer?.dispose()
        } catch (_: Exception) {}
        videoCapturer = null

        try {
            surfaceTextureHelper?.dispose()
        } catch (_: Exception) {}
        surfaceTextureHelper = null

        localVideoTrack?.dispose()
        localVideoTrack = null
        _localVideo.value = null

        localVideoSource?.dispose()
        localVideoSource = null

        localAudioTrack?.dispose()
        localAudioTrack = null

        localAudioSource?.dispose()
        localAudioSource = null

        _remoteVideo.value = null

        try {
            peerConnection?.close()
            peerConnection?.dispose()
        } catch (e: Exception) {
            Log.w(TAG, "Error closing peer connection: ${e.message}")
        }
        peerConnection = null

        resetAudioManager()
    }
}
