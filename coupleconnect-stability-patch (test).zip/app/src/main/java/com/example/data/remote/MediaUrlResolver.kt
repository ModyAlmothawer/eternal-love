package com.example.data.remote

import android.util.Log
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

/**
 * Resolves persistent private Supabase Storage references into temporary signed URLs
 * with in-memory caching and automatic expiration refresh.
 *
 * Firebase Authentication ID token is passed during signing requests, ensuring
 * that only authorized users can access the private bucket.
 */
object MediaUrlResolver {
    private const val TAG = "MediaUrlResolver"

    private data class CachedSignedUrl(
        val signedUrl: String,
        val expiresAtEpochMs: Long
    )

    private val cache = ConcurrentHashMap<String, CachedSignedUrl>()

    /**
     * Checks if a given URL or reference string points to a Supabase Storage object.
     */
    fun isSupabaseReference(reference: String?): Boolean {
        if (reference.isNullOrBlank()) return false
        val trimmed = reference.trim()
        return trimmed.contains("supabase.co/storage/v1/object") ||
                trimmed.startsWith("supabase://") ||
                trimmed.startsWith("app-media/")
    }

    /**
     * Extracts the relative path within the 'app-media' bucket.
     * Examples:
     * - https://epaebeouojogosygfxrv.supabase.co/storage/v1/object/app-media/users/123/profile/avatar.jpg
     *   -> users/123/profile/avatar.jpg
     * - supabase://app-media/relationships/abc/memories/mem.jpg
     *   -> relationships/abc/memories/mem.jpg
     * - app-media/relationships/abc/voice/v.m4a
     *   -> relationships/abc/voice/v.m4a
     */
    fun extractCleanPath(reference: String?): String? {
        if (reference.isNullOrBlank()) return null
        val trimmed = reference.trim()

        return when {
            trimmed.startsWith("supabase://app-media/") -> {
                trimmed.removePrefix("supabase://app-media/")
            }
            trimmed.startsWith("supabase://") -> {
                val afterScheme = trimmed.removePrefix("supabase://")
                afterScheme.substringAfter("/", "")
            }
            trimmed.startsWith("app-media/") -> {
                trimmed.removePrefix("app-media/")
            }
            trimmed.contains("/storage/v1/object/") -> {
                val afterObject = trimmed.substringAfter("/storage/v1/object/")
                    .removePrefix("authenticated/")
                    .removePrefix("public/")
                    .removePrefix("sign/")
                    .substringBefore("?") // Strip existing tokens/queries

                if (afterObject.startsWith("${SupabaseConfig.BUCKET_NAME}/")) {
                    afterObject.removePrefix("${SupabaseConfig.BUCKET_NAME}/")
                } else if (afterObject.contains("/")) {
                    afterObject.substringAfter("/")
                } else {
                    null
                }
            }
            else -> null
        }?.takeIf { it.isNotBlank() }
    }

    /**
     * Resolves a media reference into an authorized URL that Coil or MediaPlayer can load.
     * If the reference is a private Supabase object, a signed URL is returned from cache or fetched fresh.
     * Legacy Firebase Storage URLs and local file/content URIs are returned untouched.
     */
    suspend fun resolveMediaUrl(
        reference: String?,
        forceRefresh: Boolean = false
    ): String = withContext(Dispatchers.IO) {
        if (reference.isNullOrBlank()) return@withContext ""
        val trimmed = reference.trim()

        // 1. If it's a local file, content URI, or legacy Firebase URL, no Supabase signing needed
        if (!isSupabaseReference(trimmed)) {
            return@withContext trimmed
        }

        // 2. If it's already an active signed URL with a valid token parameter
        if (trimmed.contains("token=") && trimmed.contains("/sign/")) {
            return@withContext trimmed
        }

        val cleanPath = extractCleanPath(trimmed) ?: return@withContext trimmed
        val now = System.currentTimeMillis()

        // 3. Check in-memory cache (require at least 3 minutes of validity remaining)
        val cached = cache[cleanPath]
        if (!forceRefresh && cached != null && (cached.expiresAtEpochMs - now) > 180_000L) {
            return@withContext cached.signedUrl
        }

        // 4. Request a fresh 1-hour signed URL from Supabase
        val freshSignedUrl = SupabaseStorageService.getInstance().createSignedUrl(
            cleanPath = cleanPath,
            expiresInSeconds = 3600
        )

        if (!freshSignedUrl.isNullOrBlank()) {
            // Cache for ~58 minutes (3500 seconds)
            cache[cleanPath] = CachedSignedUrl(
                signedUrl = freshSignedUrl,
                expiresAtEpochMs = now + 3500_000L
            )
            Log.d(TAG, "Resolved signed URL for $cleanPath (expires in 1h)")
            return@withContext freshSignedUrl
        } else {
            // If signing failed, return cached if present (even if slightly old) or fallback to raw
            Log.w(TAG, "Signing failed for $cleanPath; attempting fallback")
            return@withContext cached?.signedUrl ?: trimmed
        }
    }

    /**
     * Evicts an item from the in-memory cache, e.g. when photo is updated.
     */
    fun invalidateCache(reference: String?) {
        val cleanPath = extractCleanPath(reference) ?: return
        cache.remove(cleanPath)
    }

    /**
     * Clears all cached signed URLs.
     */
    fun clearCache() {
        cache.clear()
    }
}

/**
 * Composable helper that dynamically resolves private Supabase references into signed URLs.
 */
@Composable
fun rememberResolvedMediaUrl(rawUrl: String): String {
    var resolvedUrl by remember(rawUrl) { mutableStateOf(rawUrl) }

    LaunchedEffect(rawUrl) {
        if (MediaUrlResolver.isSupabaseReference(rawUrl)) {
            val resolved = MediaUrlResolver.resolveMediaUrl(rawUrl)
            if (resolved.isNotBlank()) {
                resolvedUrl = resolved
            }
        } else {
            resolvedUrl = rawUrl
        }
    }

    return resolvedUrl
}
