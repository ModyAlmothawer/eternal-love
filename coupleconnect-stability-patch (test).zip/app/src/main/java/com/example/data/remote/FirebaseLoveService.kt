package com.example.data.remote

import android.net.Uri
import android.util.Log
import com.example.data.model.GoalEntity
import com.example.data.model.LoveLetterEntity
import com.example.data.model.MemoryEntity
import com.example.data.model.NoteEntity
import com.example.data.model.RelationshipEntity
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import java.util.UUID

class FirebaseLoveService {

    companion object {
        const val AUTH_TIMEOUT_MILLIS = 15_000L
        const val FIRESTORE_TIMEOUT_MILLIS = 12_000L

        fun mapFirebaseException(e: Throwable, language: String = "ar"): String {
            return when (e) {
                is FirebaseAuthUserCollisionException -> {
                    if (language == "ar") "هذا الحساب مسجل بالفعل، برجاء تسجيل الدخول أو استخدام بريد آخر."
                    else "This email address is already registered. Please log in or use another email."
                }
                is FirebaseAuthWeakPasswordException -> {
                    if (language == "ar") "كلمة السر ضعيفة، برجاء استخدام 6 خانات على الأقل."
                    else "Password is too weak. Please use at least 6 characters."
                }
                is FirebaseAuthInvalidCredentialsException -> {
                    if (language == "ar") "البريد الإلكتروني أو كلمة السر غير صحيحة."
                    else "The email address or password entered is incorrect."
                }
                is FirebaseAuthInvalidUserException -> {
                    if (language == "ar") "هذا الحساب غير موجود."
                    else "This account does not exist or has been disabled."
                }
                is FirebaseNetworkException -> {
                    if (language == "ar") "مشكلة في الاتصال بالإنترنت، يرجى المحاولة مرة أخرى."
                    else "Network connection issue. Please check your connection and try again."
                }
                is FirebaseTooManyRequestsException -> {
                    if (language == "ar") "محاولات كثيرة، يرجى الانتظار قليلاً والمحاولة لاحقاً."
                    else "Too many requests. Please wait a moment and try again."
                }
                is TimeoutCancellationException -> {
                    if (language == "ar") "انتهى وقت العملية، يرجى التأكد من اتصال الإنترنت."
                    else "The operation timed out. Please check your internet connection."
                }
                is FirebaseFirestoreException -> {
                    if (e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED) {
                        if (language == "ar") "لا تملك الصلاحية للوصول للبيانات."
                        else "Permission denied on cloud database."
                    } else if (e.code == FirebaseFirestoreException.Code.UNAVAILABLE) {
                        if (language == "ar") "الخدمة السحابية غير متاحة حالياً، يرجى المحاولة لاحقاً."
                        else "Cloud service is currently unavailable. Please try again shortly."
                    } else {
                        val msg = e.localizedMessage ?: ""
                        if (language == "ar") {
                            if (msg.contains("permission", ignoreCase = true)) "لا تملك الصلاحية للوصول."
                            else "حدث خطأ في قاعدة البيانات السحابية."
                        } else {
                            msg.ifBlank { "Cloud database error" }
                        }
                    }
                }
                else -> {
                    val msg = e.localizedMessage ?: e.message ?: ""
                    if (msg.contains("API key not valid", ignoreCase = true)) {
                        if (language == "ar") "خطأ في تكوين المفتاح السحابي لـ Firebase."
                        else "Firebase API key is invalid. Please check your Firebase configuration."
                    } else if (msg.contains("The email address is already in use", ignoreCase = true)) {
                        if (language == "ar") "هذا البريد الإلكتروني مسجل بالفعل."
                        else "This email address is already in use by another account."
                    } else if (msg.contains("Password should be at least", ignoreCase = true)) {
                        if (language == "ar") "كلمة السر يجب أن تكون 6 أحرف أو أرقام على الأقل."
                        else "Password should be at least 6 characters."
                    } else if (msg.contains("network error", ignoreCase = true) || msg.contains("timeout", ignoreCase = true)) {
                        if (language == "ar") "خطأ في الشبكة، برجاء التأكد من اتصال الإنترنت."
                        else "Network error. Please check your internet connection."
                    } else {
                        msg.ifBlank { if (language == "ar") "حدث خطأ غير متوقع، برجاء المحاولة لاحقاً." else "An unexpected error occurred. Please try again." }
                    }
                }
            }
        }
    }

    private val auth: FirebaseAuth
        get() = try {
            FirebaseAuth.getInstance()
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "FirebaseAuth instance error: ${e.message}")
            FirebaseAuth.getInstance()
        }

    private val firestore: FirebaseFirestore
        get() = try {
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "FirebaseFirestore instance error: ${e.message}")
            FirebaseFirestore.getInstance()
        }

    private val storage: FirebaseStorage
        get() = try {
            FirebaseStorage.getInstance("gs://lyubov-c1aab.firebasestorage.app")
        } catch (e: Exception) {
            try {
                FirebaseStorage.getInstance()
            } catch (e2: Exception) {
                Log.e("FirebaseLoveService", "FirebaseStorage instance error: ${e2.message}")
                FirebaseStorage.getInstance()
            }
        }

    private var relationshipListener: ListenerRegistration? = null
    private var partnerProfileListener: ListenerRegistration? = null
    private var currentListeningPartnerUid: String? = null
    private var messagesListener: ListenerRegistration? = null
    private var memoriesListener: ListenerRegistration? = null
    private var goalsListener: ListenerRegistration? = null
    private var notesListener: ListenerRegistration? = null

    val currentFirebaseUser: FirebaseUser?
        get() = try {
            auth.currentUser
        } catch (e: Exception) {
            null
        }

    suspend fun registerWithFirebase(email: String, pass: String): Result<String> {
        return try {
            withTimeout(AUTH_TIMEOUT_MILLIS) {
                val authResult = auth.createUserWithEmailAndPassword(email.trim(), pass).await()
                val uid = authResult.user?.uid
                if (!uid.isNullOrBlank()) {
                    Result.success(uid)
                } else {
                    Result.failure(Exception("Could not retrieve user ID from Firebase Authentication"))
                }
            }
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "FirebaseAuth register error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun loginWithFirebase(email: String, pass: String): Result<String> {
        return try {
            withTimeout(AUTH_TIMEOUT_MILLIS) {
                val authResult = auth.signInWithEmailAndPassword(email.trim(), pass).await()
                val uid = authResult.user?.uid
                if (!uid.isNullOrBlank()) {
                    Result.success(uid)
                } else {
                    Result.failure(Exception("Could not retrieve user ID from Firebase Authentication"))
                }
            }
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "FirebaseAuth login error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun sendPasswordResetEmail(email: String): Result<Unit> {
        return try {
            withTimeout(AUTH_TIMEOUT_MILLIS) {
                auth.sendPasswordResetEmail(email.trim()).await()
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "sendPasswordResetEmail error: ${e.message}", e)
            Result.failure(e)
        }
    }

    fun signOut() {
        try {
            stopAllListeners()
            auth.signOut()
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "SignOut error: ${e.message}")
        }
    }

    // --- User Profile Cloud Sync ---

    suspend fun syncUserProfileOnline(
        uid: String,
        name: String,
        email: String,
        avatarRes: String = "avatar_1",
        photoUrl: String = "",
        relationshipId: String? = null
    ): Result<Unit> {
        if (uid.isBlank()) return Result.failure(Exception("UID is empty"))
        return try {
            withTimeout(FIRESTORE_TIMEOUT_MILLIS) {
                val data = mutableMapOf<String, Any>(
                    "uid" to uid,
                    "displayName" to name,
                    "name" to name,
                    "email" to email,
                    "avatarRes" to avatarRes,
                    "photoUrl" to photoUrl,
                    "updatedAtMillis" to System.currentTimeMillis()
                )
                if (relationshipId != null) {
                    data["relationshipId"] = relationshipId
                }
                firestore.collection("users").document(uid)
                    .set(data, SetOptions.merge())
                    .await()
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error syncing user profile online: ${e.message}")
            Result.failure(e)
        }
    }

    suspend fun fetchUserProfileOnline(uid: String): Map<String, Any?>? {
        if (uid.isBlank()) return null
        return try {
            withTimeout(FIRESTORE_TIMEOUT_MILLIS) {
                val doc = firestore.collection("users").document(uid).get().await()
                if (doc.exists()) doc.data else null
            }
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error fetching user profile: ${e.message}")
            null
        }
    }

    suspend fun uploadProfileImageBytes(uid: String, bytes: ByteArray): String? {
        if (uid.isBlank() || bytes.isEmpty()) return null
        return try {
            withTimeout(35_000L) {
                val path = "users/$uid/profile/avatar_${System.currentTimeMillis()}.jpg"
                val storageUrl = SupabaseStorageService.getInstance().uploadMedia(
                    path = path,
                    bytes = bytes,
                    mimeType = "image/jpeg"
                )
                if (!storageUrl.isNullOrBlank()) {
                    val updates = mapOf<String, Any>(
                        "photoUrl" to storageUrl,
                        "updatedAtMillis" to System.currentTimeMillis()
                    )
                    firestore.collection("users").document(uid)
                        .set(updates, SetOptions.merge())
                        .await()
                    MediaUrlResolver.invalidateCache(storageUrl)
                    storageUrl
                } else {
                    null
                }
            }
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "Error uploading profile image bytes to Supabase: ${e.message}", e)
            null
        }
    }

    suspend fun uploadMemoryImageBytes(relId: String, uid: String, bytes: ByteArray): String? {
        if (bytes.isEmpty()) return null
        return try {
            withTimeout(35_000L) {
                val safeRelId = relId.ifBlank { "general" }
                val path = "relationships/$safeRelId/memories/mem_${UUID.randomUUID()}.jpg"
                SupabaseStorageService.getInstance().uploadMedia(
                    path = path,
                    bytes = bytes,
                    mimeType = "image/jpeg"
                )
            }
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "Error uploading memory image bytes to Supabase: ${e.message}", e)
            null
        }
    }


    // --- Relationship Creation & Connection using invites/{code} ---

    suspend fun createFirestoreRelationship(
        creatorUid: String,
        creatorName: String,
        creatorPhoto: String,
        startDateMillis: Long,
        code: String
    ): String {
        val relId = UUID.randomUUID().toString().take(12)
        val relData = hashMapOf(
            "id" to relId,
            "code" to code.trim(),
            "creatorUid" to creatorUid,
            "creatorName" to creatorName,
            "creatorPhoto" to creatorPhoto,
            "creatorStatus" to "",
            "creatorStatusEmoji" to "",
            "partnerUid" to "",
            "partnerName" to "",
            "partnerPhoto" to "",
            "partnerStatus" to "",
            "partnerStatusEmoji" to "",
            "startDateMillis" to startDateMillis,
            "relationshipName" to "قصتنا",
            "status" to "pending",
            "createdAtMillis" to System.currentTimeMillis()
        )

        val inviteData = hashMapOf(
            "relationshipId" to relId,
            "creatorUid" to creatorUid,
            "creatorName" to creatorName,
            "creatorPhoto" to creatorPhoto,
            "startDateMillis" to startDateMillis,
            "status" to "pending",
            "createdAtMillis" to System.currentTimeMillis()
        )

        withTimeout(FIRESTORE_TIMEOUT_MILLIS) {
            firestore.collection("relationships").document(relId).set(relData).await()
            firestore.collection("invites").document(code.trim()).set(inviteData).await()

            if (creatorUid.isNotBlank()) {
                firestore.collection("users").document(creatorUid).set(
                    mapOf(
                        "relationshipId" to relId,
                        "relationshipCode" to code.trim()
                    ),
                    SetOptions.merge()
                ).await()
            }
        }
        return relId
    }

    suspend fun joinFirestoreRelationship(
        code: String,
        partnerUid: String,
        partnerName: String,
        partnerPhoto: String,
        language: String = "ar"
    ): Pair<String, Map<String, Any?>> {
        val cleanCode = code.trim()
        if (cleanCode.length != 6 || !cleanCode.all { it.isDigit() }) {
            val msg = if (language == "ar") "كود الدعوة يجب أن يتكون من 6 أرقام." else "Invitation code must be 6 digits."
            throw IllegalArgumentException(msg)
        }

        try {
            return withTimeout(FIRESTORE_TIMEOUT_MILLIS) {
                val inviteDoc = firestore.collection("invites").document(cleanCode).get().await()
                if (!inviteDoc.exists()) {
                    val msg = if (language == "ar") "كود الدعوة غير صحيح أو غير موجود." else "Invalid or non-existent invitation code."
                    throw IllegalArgumentException(msg)
                }

                val creatorUid = inviteDoc.getString("creatorUid") ?: ""
                val relId = inviteDoc.getString("relationshipId") ?: ""

                if (creatorUid == partnerUid) {
                    // The creator is reconnecting to their own existing relationship!
                    val relDoc = firestore.collection("relationships").document(relId).get().await()
                    if (!relDoc.exists()) {
                        val msg = if (language == "ar") "لم يتم العثور على وثيقة الحكاية." else "Relationship document not found."
                        throw IllegalArgumentException(msg)
                    }
                    val existingPartnerUid = relDoc.getString("partnerUid") ?: ""
                    val existingPartnerName = relDoc.getString("partnerName") ?: ""
                    firestore.collection("users").document(partnerUid).set(
                        mapOf(
                            "relationshipId" to relId,
                            "partnerUid" to existingPartnerUid,
                            "partnerName" to existingPartnerName,
                            "relationshipCode" to cleanCode
                        ),
                        SetOptions.merge()
                    ).await()
                    return@withTimeout Pair(relId, relDoc.data ?: emptyMap())
                }

                if (relId.isBlank()) {
                    val msg = if (language == "ar") "لم يتم العثور على الحكاية المرتبطة بهذا الكود." else "Relationship associated with this code was not found."
                    throw IllegalArgumentException(msg)
                }

                val relDoc = firestore.collection("relationships").document(relId).get().await()
                if (!relDoc.exists()) {
                    val msg = if (language == "ar") "لم يتم العثور على وثيقة الحكاية." else "Relationship document not found or deleted."
                    throw IllegalArgumentException(msg)
                }

                val currentPartnerUid = relDoc.getString("partnerUid")
                if (!currentPartnerUid.isNullOrBlank() && currentPartnerUid != partnerUid) {
                    val msg = if (language == "ar") "هذه الحكاية مكتملة بالفعل بوجود شريكين." else "This relationship already has two connected partners."
                    throw IllegalArgumentException(msg)
                }

                val creatorName = relDoc.getString("creatorName") ?: inviteDoc.getString("creatorName") ?: (if (language == "ar") "حبيبي" else "My Love")

                val updateRelData = mapOf<String, Any>(
                    "partnerUid" to partnerUid,
                    "partnerName" to partnerName,
                    "partnerPhoto" to partnerPhoto,
                    "status" to "connected"
                )
                firestore.collection("relationships").document(relId).update(updateRelData).await()

                firestore.collection("invites").document(cleanCode).update(
                    mapOf<String, Any>(
                        "status" to "connected",
                        "partnerUid" to partnerUid
                    )
                ).await()

                if (partnerUid.isNotBlank()) {
                    firestore.collection("users").document(partnerUid).set(
                        mapOf(
                            "relationshipId" to relId,
                            "partnerUid" to creatorUid,
                            "partnerName" to creatorName,
                            "relationshipCode" to cleanCode
                        ),
                        SetOptions.merge()
                    ).await()
                }

                if (creatorUid.isNotBlank()) {
                    firestore.collection("users").document(creatorUid).set(
                        mapOf(
                            "partnerUid" to partnerUid,
                            "partnerName" to partnerName
                        ),
                        SetOptions.merge()
                    ).await()
                }

                Pair(relId, relDoc.data ?: emptyMap())
            }
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "Error joining relationship with code $cleanCode: ${e.message}")
            throw e
        }
    }

    // --- Realtime Sync: Relationships, Messages (Chat), Memories, Goals, Notes ---

    fun startRealtimeListeners(
        relationshipId: String,
        currentUid: String = "",
        onRelationshipUpdate: (RelationshipEntity) -> Unit,
        onPartnerProfileUpdate: (name: String, photoUrl: String, avatarRes: String, status: String, statusEmoji: String) -> Unit = { _, _, _, _, _ -> },
        onPartnerTypingUpdate: (Boolean) -> Unit = {},
        onMessagesUpdate: (List<LoveLetterEntity>) -> Unit,
        onMemoriesUpdate: (List<MemoryEntity>) -> Unit,
        onGoalsUpdate: (List<GoalEntity>) -> Unit,
        onNotesUpdate: (List<NoteEntity>) -> Unit
    ) {
        stopAllListeners()
        try {
            // 1. Realtime Relationship Document Listener
            relationshipListener = firestore.collection("relationships")
                .document(relationshipId)
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null || !snapshot.exists()) {
                        return@addSnapshotListener
                    }

                    val creatorId = snapshot.getString("creatorUid") ?: ""
                    val partnerId = snapshot.getString("partnerUid") ?: ""
                    val creatorName = snapshot.getString("creatorName") ?: ""
                    val partnerName = snapshot.getString("partnerName") ?: ""
                    val creatorPhoto = snapshot.getString("creatorPhoto") ?: "avatar_1"
                    val partnerPhoto = snapshot.getString("partnerPhoto") ?: "avatar_2"
                    val creatorStatus = snapshot.getString("creatorStatus") ?: ""
                    val creatorStatusEmoji = snapshot.getString("creatorStatusEmoji") ?: ""
                    val partnerStatus = snapshot.getString("partnerStatus") ?: ""
                    val partnerStatusEmoji = snapshot.getString("partnerStatusEmoji") ?: ""
                    val creatorTyping = snapshot.getBoolean("creatorTyping") ?: false
                    val partnerTyping = snapshot.getBoolean("partnerTyping") ?: false

                    val isPartnerTyping = if (currentUid.isNotBlank() && currentUid == creatorId) {
                        partnerTyping
                    } else {
                        creatorTyping
                    }
                    onPartnerTypingUpdate(isPartnerTyping)

                    val entity = RelationshipEntity(
                        firestoreId = snapshot.id,
                        code = snapshot.getString("code") ?: "",
                        creatorId = creatorId,
                        creatorName = creatorName,
                        creatorPhoto = creatorPhoto,
                        creatorStatus = creatorStatus,
                        creatorStatusEmoji = creatorStatusEmoji,
                        partnerId = partnerId.takeIf { it.isNotBlank() },
                        partnerName = partnerName,
                        partnerPhoto = partnerPhoto,
                        partnerStatus = partnerStatus,
                        partnerStatusEmoji = partnerStatusEmoji,
                        startDateMillis = snapshot.getLong("startDateMillis") ?: System.currentTimeMillis(),
                        creatorBirthdayMillis = snapshot.getLong("creatorBirthdayMillis") ?: 0L,
                        partnerBirthdayMillis = snapshot.getLong("partnerBirthdayMillis") ?: 0L,
                        relationshipName = snapshot.getString("relationshipName") ?: "قصتنا",
                        status = snapshot.getString("status") ?: "connected",
                        createdAtMillis = snapshot.getLong("createdAtMillis") ?: System.currentTimeMillis()
                    )
                    onRelationshipUpdate(entity)

                    // Listen to partner profile doc in real time
                    val partnerUidToListen = if (currentUid.isNotBlank()) {
                        if (currentUid == creatorId) partnerId else creatorId
                    } else {
                        partnerId
                    }

                    if (partnerUidToListen.isNotBlank() && partnerUidToListen != currentListeningPartnerUid) {
                        partnerProfileListener?.remove()
                        currentListeningPartnerUid = partnerUidToListen
                        partnerProfileListener = firestore.collection("users")
                            .document(partnerUidToListen)
                            .addSnapshotListener { userDoc, userErr ->
                                if (userErr == null && userDoc != null && userDoc.exists()) {
                                    val name = userDoc.getString("displayName") ?: userDoc.getString("name") ?: ""
                                    val photo = userDoc.getString("photoUrl") ?: ""
                                    val avatar = userDoc.getString("avatarRes") ?: "avatar_2"
                                    val status = userDoc.getString("dailyStatus") ?: ""
                                    val emoji = userDoc.getString("dailyStatusEmoji") ?: ""
                                    onPartnerProfileUpdate(name, photo, avatar, status, emoji)
                                }
                            }
                    }
                }

            // 2. Realtime Chat Messages Listener
            messagesListener = firestore.collection("relationships")
                .document(relationshipId)
                .collection("messages")
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) {
                        return@addSnapshotListener
                    }
                    val list = snapshot.documents.mapNotNull { doc ->
                        val senderId = doc.getString("senderId") ?: doc.getString("senderUid") ?: ""
                        val text = doc.getString("text") ?: doc.getString("message") ?: ""
                        val timestamp = doc.getLong("timestamp") ?: doc.getLong("dateMillis") ?: System.currentTimeMillis()
                        val messageId = doc.getString("messageId") ?: doc.id
                        LoveLetterEntity(
                            firestoreId = messageId,
                            relationshipId = relationshipId,
                            senderUid = senderId,
                            senderName = doc.getString("senderName") ?: "",
                            title = doc.getString("title") ?: "",
                            message = text,
                            dateMillis = timestamp,
                            isRead = doc.getBoolean("isRead") ?: false,
                            themeColorIndex = (doc.getLong("themeColorIndex") ?: 0L).toInt(),
                            replyToId = doc.getString("replyToId"),
                            replyToSenderName = doc.getString("replyToSenderName"),
                            replyToText = doc.getString("replyToText"),
                            isEdited = doc.getBoolean("isEdited") ?: false,
                            mediaType = doc.getString("mediaType") ?: "text",
                            mediaUrl = doc.getString("mediaUrl") ?: "",
                            durationSeconds = (doc.getLong("durationSeconds") ?: 0L).toInt(),
                            reactions = doc.getString("reactions") ?: (doc.get("reactionsMap") as? Map<*, *>)?.entries?.joinToString(",") { "${it.key}:${it.value}" } ?: ""
                        )
                    }.sortedByDescending { it.dateMillis }
                    onMessagesUpdate(list)
                }

            // 3. Realtime Memories Listener
            memoriesListener = firestore.collection("relationships")
                .document(relationshipId)
                .collection("memories")
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) return@addSnapshotListener
                    val list = snapshot.documents.mapNotNull { doc ->
                        MemoryEntity(
                            firestoreId = doc.id,
                            relationshipId = relationshipId,
                            title = doc.getString("title") ?: "",
                            description = doc.getString("description") ?: "",
                            dateMillis = doc.getLong("dateMillis") ?: System.currentTimeMillis(),
                            imageUrl = doc.getString("imageUrl") ?: "",
                            imageDrawableName = doc.getString("imageDrawableName") ?: "",
                            location = doc.getString("location") ?: "",
                            createdByName = doc.getString("createdByName") ?: "",
                            createdByUid = doc.getString("createdByUid") ?: ""
                        )
                    }.sortedByDescending { it.dateMillis }
                    onMemoriesUpdate(list)
                }

            // 4. Realtime Goals Listener
            goalsListener = firestore.collection("relationships")
                .document(relationshipId)
                .collection("goals")
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) return@addSnapshotListener
                    val list = snapshot.documents.mapNotNull { doc ->
                        GoalEntity(
                            firestoreId = doc.id,
                            relationshipId = relationshipId,
                            title = doc.getString("title") ?: "",
                            description = doc.getString("description") ?: "",
                            progress = (doc.getLong("progress") ?: 0L).toInt(),
                            isCompleted = doc.getBoolean("isCompleted") ?: false,
                            targetDate = doc.getString("targetDate") ?: "",
                            category = doc.getString("category") ?: "عام",
                            createdByName = doc.getString("createdByName") ?: "",
                            createdByUid = doc.getString("createdByUid") ?: "",
                            createdAtMillis = doc.getLong("createdAtMillis") ?: System.currentTimeMillis()
                        )
                    }.sortedByDescending { it.createdAtMillis }
                    onGoalsUpdate(list)
                }

            // 5. Realtime Notes Listener
            notesListener = firestore.collection("relationships")
                .document(relationshipId)
                .collection("notes")
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) return@addSnapshotListener
                    val list = snapshot.documents.mapNotNull { doc ->
                        NoteEntity(
                            firestoreId = doc.id,
                            relationshipId = relationshipId,
                            title = doc.getString("title") ?: "",
                            content = doc.getString("content") ?: "",
                            category = doc.getString("category") ?: "عام",
                            authorName = doc.getString("authorName") ?: "",
                            authorUid = doc.getString("authorUid") ?: "",
                            updatedAtMillis = doc.getLong("updatedAtMillis") ?: System.currentTimeMillis()
                        )
                    }.sortedByDescending { it.updatedAtMillis }
                    onNotesUpdate(list)
                }
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Could not start Firestore listeners: ${e.message}")
        }
    }

    // --- Send & Delete Message (Chat) Online (Delete for both sides) ---

    suspend fun sendMessageOnline(relId: String, letter: LoveLetterEntity) {
        try {
            val messageId = letter.firestoreId.ifBlank { UUID.randomUUID().toString() }
            val messageData = hashMapOf(
                "messageId" to messageId,
                "senderId" to letter.senderUid,
                "senderName" to letter.senderName,
                "text" to letter.message,
                "timestamp" to letter.dateMillis,
                "title" to letter.title,
                "themeColorIndex" to letter.themeColorIndex,
                "isRead" to false,
                "replyToId" to (letter.replyToId ?: ""),
                "replyToSenderName" to (letter.replyToSenderName ?: ""),
                "replyToText" to (letter.replyToText ?: ""),
                "isEdited" to letter.isEdited,
                "mediaType" to letter.mediaType,
                "mediaUrl" to letter.mediaUrl,
                "durationSeconds" to letter.durationSeconds,
                "reactions" to letter.reactions
            )
            firestore.collection("relationships").document(relId)
                .collection("messages").document(messageId)
                .set(messageData).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error sending message online: ${e.message}")
        }
    }

    suspend fun editMessageOnline(relId: String, messageId: String, newText: String) {
        if (relId.isBlank() || messageId.isBlank()) return
        try {
            val updates = mapOf(
                "text" to newText,
                "isEdited" to true,
                "updatedAtMillis" to System.currentTimeMillis()
            )
            firestore.collection("relationships").document(relId)
                .collection("messages").document(messageId)
                .update(updates).await()
            Log.d("FirebaseLoveService", "Message $messageId edited online in $relId")
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error editing message online: ${e.message}")
        }
    }

    suspend fun updateTypingStatus(relId: String, isCreator: Boolean, isTyping: Boolean) {
        if (relId.isBlank()) return
        try {
            val field = if (isCreator) "creatorTyping" else "partnerTyping"
            firestore.collection("relationships").document(relId)
                .update(field, isTyping).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error updating typing status: ${e.message}")
        }
    }

    suspend fun updateUserBirthdayOnline(relId: String, uid: String, isCreator: Boolean, birthdayMillis: Long) {
        if (birthdayMillis <= 0L) return
        try {
            if (relId.isNotBlank()) {
                val field = if (isCreator) "creatorBirthdayMillis" else "partnerBirthdayMillis"
                firestore.collection("relationships").document(relId)
                    .update(field, birthdayMillis).await()
            }
            if (uid.isNotBlank()) {
                firestore.collection("users").document(uid)
                    .set(mapOf("birthdayMillis" to birthdayMillis), SetOptions.merge()).await()
            }
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error updating user birthday online: ${e.message}")
        }
    }

    suspend fun updateBirthdaysOnline(relId: String, creatorBirthdayMillis: Long, partnerBirthdayMillis: Long) {
        if (relId.isBlank()) return
        try {
            val updates = mutableMapOf<String, Any>()
            if (creatorBirthdayMillis > 0L) {
                updates["creatorBirthdayMillis"] = creatorBirthdayMillis
            }
            if (partnerBirthdayMillis > 0L) {
                updates["partnerBirthdayMillis"] = partnerBirthdayMillis
            }
            if (updates.isNotEmpty()) {
                firestore.collection("relationships").document(relId).update(updates).await()
            }
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error updating birthdays online: ${e.message}")
        }
    }

    suspend fun deleteMessageOnline(relId: String, messageId: String) {
        try {
            firestore.collection("relationships").document(relId)
                .collection("messages").document(messageId).delete().await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error deleting message online: ${e.message}")
        }
    }

    suspend fun markMessageReadOnline(relId: String, messageId: String) {
        if (relId.isBlank() || messageId.isBlank()) return
        try {
            firestore.collection("relationships").document(relId)
                .collection("messages").document(messageId)
                .update("isRead", true).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error marking message as read online: ${e.message}")
        }
    }

    suspend fun markAllMessagesReadOnline(relId: String, currentUid: String) {
        if (relId.isBlank()) return
        try {
            val unreadDocs = firestore.collection("relationships").document(relId)
                .collection("messages")
                .whereEqualTo("isRead", false)
                .get().await()

            val batch = firestore.batch()
            var count = 0
            for (doc in unreadDocs.documents) {
                val senderId = doc.getString("senderId") ?: doc.getString("senderUid") ?: ""
                if (senderId.isNotBlank() && senderId != currentUid) {
                    batch.update(doc.reference, "isRead", true)
                    count++
                }
            }
            if (count > 0) {
                batch.commit().await()
            }
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error marking all messages read online: ${e.message}")
        }
    }

    // --- Memories Online (Delete for both sides) ---

    suspend fun addMemoryOnline(relId: String, memory: MemoryEntity) {
        try {
            val docId = memory.firestoreId.ifBlank { UUID.randomUUID().toString() }
            val data = hashMapOf(
                "id" to docId,
                "title" to memory.title,
                "description" to memory.description,
                "dateMillis" to memory.dateMillis,
                "imageUrl" to memory.imageUrl,
                "imageDrawableName" to memory.imageDrawableName,
                "location" to memory.location,
                "createdByName" to memory.createdByName,
                "createdByUid" to memory.createdByUid,
                "createdAtMillis" to memory.createdAtMillis
            )
            firestore.collection("relationships").document(relId)
                .collection("memories").document(docId).set(data).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error adding memory online: ${e.message}")
        }
    }

    suspend fun deleteMemoryOnline(relId: String, memoryId: String, imageUrl: String = "") {
        try {
            firestore.collection("relationships").document(relId)
                .collection("memories").document(memoryId).delete().await()

            if (imageUrl.isNotBlank()) {
                if (MediaUrlResolver.isSupabaseReference(imageUrl)) {
                    SupabaseStorageService.getInstance().deleteMedia(imageUrl)
                    MediaUrlResolver.invalidateCache(imageUrl)
                } else if (imageUrl.contains("firebasestorage.googleapis.com")) {
                    try {
                        storage.getReferenceFromUrl(imageUrl).delete().await()
                    } catch (e: Exception) {
                        Log.w("FirebaseLoveService", "Could not delete legacy memory image from Firebase Storage: ${e.message}")
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error deleting memory online: ${e.message}")
        }
    }

    // --- Voice Notes Upload (Supabase Storage) ---
    suspend fun uploadVoiceNoteBytes(relId: String, bytes: ByteArray): String? {
        if (bytes.isEmpty()) return null
        return try {
            withTimeout(35_000L) {
                val safeRelId = relId.ifBlank { "general" }
                val path = "relationships/$safeRelId/voice/voice_${UUID.randomUUID()}.m4a"
                SupabaseStorageService.getInstance().uploadMedia(
                    path = path,
                    bytes = bytes,
                    mimeType = "audio/mp4"
                )
            }
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "Error uploading voice note bytes to Supabase: ${e.message}", e)
            null
        }
    }


    // --- Message Reactions ---
    suspend fun toggleMessageReaction(relId: String, messageId: String, userUid: String, emoji: String) {
        if (relId.isBlank() || messageId.isBlank() || userUid.isBlank() || emoji.isBlank()) return
        try {
            val docRef = firestore.collection("relationships").document(relId)
                .collection("messages").document(messageId)
            firestore.runTransaction { transaction ->
                val snapshot = transaction.get(docRef)
                val currentMap = (snapshot.get("reactionsMap") as? Map<*, *>)?.mapNotNull { (k, v) ->
                    if (k is String && v is String) k to v else null
                }?.toMap()?.toMutableMap() ?: mutableMapOf()

                if (currentMap[userUid] == emoji) {
                    currentMap.remove(userUid)
                } else {
                    currentMap[userUid] = emoji
                }

                val reactionsStr = currentMap.entries.joinToString(",") { "${it.key}:${it.value}" }
                transaction.update(docRef, mapOf(
                    "reactionsMap" to currentMap,
                    "reactions" to reactionsStr
                ))
            }.await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error toggling message reaction: ${e.message}")
        }
    }

    // --- Disconnect Relationship Online ---
    suspend fun disconnectRelationshipOnline(relId: String, userUid: String) {
        if (relId.isBlank() && userUid.isBlank()) return
        try {
            if (relId.isNotBlank()) {
                val relRef = firestore.collection("relationships").document(relId)
                val relDoc = relRef.get().await()
                if (relDoc.exists()) {
                    val creatorUid = relDoc.getString("creatorUid") ?: relDoc.getString("creatorId") ?: ""
                    val partnerUid = relDoc.getString("partnerUid") ?: relDoc.getString("partnerId") ?: ""
                    val code = relDoc.getString("code") ?: ""

                    if (userUid == partnerUid) {
                        // Partner disconnected
                        relRef.update(
                            mapOf(
                                "partnerUid" to "",
                                "partnerName" to "",
                                "partnerPhoto" to "",
                                "status" to "disconnected"
                            )
                        ).await()
                        if (code.isNotBlank()) {
                            firestore.collection("invites").document(code).update(
                                mapOf(
                                    "status" to "pending",
                                    "partnerUid" to ""
                                )
                            ).await()
                        }
                    } else if (userUid == creatorUid) {
                        // Creator disconnected
                        relRef.update("status", "disconnected").await()
                    }
                }
            }
            if (userUid.isNotBlank()) {
                firestore.collection("users").document(userUid).update(
                    mapOf(
                        "relationshipId" to "",
                        "relationshipCode" to "",
                        "partnerUid" to "",
                        "partnerName" to ""
                    )
                ).await()
            }
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error in disconnectRelationshipOnline: ${e.message}")
        }
    }

    // --- Online Presence ---
    suspend fun setUserPresence(uid: String, isOnline: Boolean) {
        if (uid.isBlank()) return
        try {
            firestore.collection("users").document(uid).set(
                mapOf(
                    "isOnline" to isOnline,
                    "lastSeenMillis" to System.currentTimeMillis()
                ),
                SetOptions.merge()
            ).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error setting user presence: ${e.message}")
        }
    }

    fun listenToPartnerPresence(partnerUid: String, onUpdate: (Boolean, Long) -> Unit): ListenerRegistration? {
        if (partnerUid.isBlank()) return null
        return try {
            firestore.collection("users").document(partnerUid)
                .addSnapshotListener { doc, err ->
                    if (err == null && doc != null && doc.exists()) {
                        val isOnline = doc.getBoolean("isOnline") ?: false
                        val lastSeenMillis = doc.getLong("lastSeenMillis") ?: 0L
                        onUpdate(isOnline, lastSeenMillis)
                    }
                }
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error listening to partner presence: ${e.message}")
            null
        }
    }

    // --- Real-time Voice & Video Calls Signaling ---
    suspend fun initiateCall(relId: String, callerUid: String, callerName: String, calleeUid: String, type: String): String {
        val callId = UUID.randomUUID().toString()
        val data = hashMapOf(
            "callId" to callId,
            "relationshipId" to relId,
            "callerUid" to callerUid,
            "callerName" to callerName,
            "calleeUid" to calleeUid,
            "type" to type,
            "status" to "calling",
            "createdAtMillis" to System.currentTimeMillis()
        )
        firestore.collection("relationships").document(relId)
            .collection("calls").document(callId).set(data).await()
        return callId
    }

    suspend fun updateCallStatus(relId: String, callId: String, status: String) {
        if (relId.isBlank() || callId.isBlank()) return
        try {
            firestore.collection("relationships").document(relId)
                .collection("calls").document(callId)
                .update("status", status).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error updating call status: ${e.message}")
        }
    }

    fun listenToIncomingCall(relId: String, currentUid: String, onCall: (com.example.data.model.CallSession?) -> Unit): ListenerRegistration? {
        if (relId.isBlank() || currentUid.isBlank()) return null
        return try {
            firestore.collection("relationships").document(relId)
                .collection("calls")
                .whereEqualTo("calleeUid", currentUid)
                .whereEqualTo("status", "calling")
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null || snapshot.isEmpty) {
                        onCall(null)
                        return@addSnapshotListener
                    }
                    val doc = snapshot.documents.firstOrNull()
                    if (doc != null) {
                        val session = com.example.data.model.CallSession(
                            callId = doc.getString("callId") ?: doc.id,
                            relationshipId = relId,
                            callerUid = doc.getString("callerUid") ?: "",
                            callerName = doc.getString("callerName") ?: "شريك حياتك",
                            calleeUid = currentUid,
                            type = doc.getString("type") ?: "voice",
                            status = doc.getString("status") ?: "calling",
                            createdAtMillis = doc.getLong("createdAtMillis") ?: System.currentTimeMillis()
                        )
                        onCall(session)
                    } else {
                        onCall(null)
                    }
                }
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error listening to incoming calls: ${e.message}")
            null
        }
    }

    fun listenToCallStatus(relId: String, callId: String, onStatus: (String) -> Unit): ListenerRegistration? {
        if (relId.isBlank() || callId.isBlank()) return null
        return try {
            firestore.collection("relationships").document(relId)
                .collection("calls").document(callId)
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null || !snapshot.exists()) {
                        return@addSnapshotListener
                    }
                    val status = snapshot.getString("status") ?: "ended"
                    onStatus(status)
                }
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error listening to call status: ${e.message}")
            null
        }
    }

    // --- App Update System (Non-Play Store) ---
    suspend fun checkAppUpdate(): com.example.data.model.AppUpdateInfo? {
        return try {
            val doc = firestore.collection("app_config").document("update").get().await()
            if (doc.exists()) {
                com.example.data.model.AppUpdateInfo(
                    latestVersionCode = (doc.getLong("latestVersionCode") ?: 1L).toInt(),
                    latestVersionName = doc.getString("latestVersionName") ?: "1.0",
                    downloadUrl = doc.getString("downloadUrl") ?: "",
                    releaseNotesAr = doc.getString("releaseNotesAr") ?: "",
                    isMandatory = doc.getBoolean("isMandatory") ?: false
                )
            } else {
                null
            }
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error checking app update: ${e.message}")
            null
        }
    }

    // --- Goals Online ---

    suspend fun addGoalOnline(relId: String, goal: GoalEntity) {
        try {
            val docId = goal.firestoreId.ifBlank { UUID.randomUUID().toString() }
            val data = hashMapOf(
                "id" to docId,
                "title" to goal.title,
                "description" to goal.description,
                "progress" to goal.progress,
                "isCompleted" to goal.isCompleted,
                "targetDate" to goal.targetDate,
                "category" to goal.category,
                "createdByName" to goal.createdByName,
                "createdByUid" to goal.createdByUid,
                "createdAtMillis" to goal.createdAtMillis
            )
            firestore.collection("relationships").document(relId)
                .collection("goals").document(docId).set(data).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error adding goal online: ${e.message}")
        }
    }

    suspend fun updateGoalOnline(relId: String, goalId: String, progress: Int, isCompleted: Boolean) {
        try {
            val updates = mapOf(
                "progress" to progress,
                "isCompleted" to isCompleted
            )
            firestore.collection("relationships").document(relId)
                .collection("goals").document(goalId).update(updates).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error updating goal online: ${e.message}")
        }
    }

    suspend fun deleteGoalOnline(relId: String, goalId: String) {
        try {
            firestore.collection("relationships").document(relId)
                .collection("goals").document(goalId).delete().await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error deleting goal online: ${e.message}")
        }
    }

    // --- Notes Online ---

    suspend fun addNoteOnline(relId: String, note: NoteEntity) {
        try {
            val docId = note.firestoreId.ifBlank { UUID.randomUUID().toString() }
            val data = hashMapOf(
                "id" to docId,
                "title" to note.title,
                "content" to note.content,
                "category" to note.category,
                "authorName" to note.authorName,
                "authorUid" to note.authorUid,
                "updatedAtMillis" to note.updatedAtMillis
            )
            firestore.collection("relationships").document(relId)
                .collection("notes").document(docId).set(data).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error adding note online: ${e.message}")
        }
    }

    suspend fun deleteNoteOnline(relId: String, noteId: String) {
        try {
            firestore.collection("relationships").document(relId)
                .collection("notes").document(noteId).delete().await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error deleting note online: ${e.message}")
        }
    }

    suspend fun updateRelationshipDetailsOnline(relId: String, name: String, startDateMillis: Long) {
        try {
            val updates = mapOf(
                "relationshipName" to name,
                "startDateMillis" to startDateMillis,
                "updatedAtMillis" to System.currentTimeMillis()
            )
            firestore.collection("relationships").document(relId).update(updates).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error updating relationship online: ${e.message}")
        }
    }

    suspend fun updateUserStatusOnline(
        uid: String,
        relId: String?,
        isCreator: Boolean,
        status: String,
        statusEmoji: String
    ) {
        try {
            val userUpdates = mapOf(
                "dailyStatus" to status,
                "dailyStatusEmoji" to statusEmoji,
                "statusUpdatedAtMillis" to System.currentTimeMillis()
            )
            firestore.collection("users").document(uid).set(userUpdates, SetOptions.merge()).await()

            if (!relId.isNullOrBlank()) {
                val relUpdates = if (isCreator) {
                    mapOf(
                        "creatorStatus" to status,
                        "creatorStatusEmoji" to statusEmoji
                    )
                } else {
                    mapOf(
                        "partnerStatus" to status,
                        "partnerStatusEmoji" to statusEmoji
                    )
                }
                firestore.collection("relationships").document(relId).update(relUpdates).await()
            }
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error updating status online: ${e.message}")
        }
    }

    suspend fun updateUserProfileOnline(
        uid: String,
        name: String,
        avatarRes: String,
        photoUrl: String,
        relId: String? = null,
        isCreator: Boolean = false
    ) {
        try {
            val userUpdates = mapOf(
                "displayName" to name,
                "name" to name,
                "avatarRes" to avatarRes,
                "photoUrl" to photoUrl,
                "updatedAtMillis" to System.currentTimeMillis()
            )
            firestore.collection("users").document(uid).set(userUpdates, SetOptions.merge()).await()

            if (!relId.isNullOrBlank()) {
                val relUpdates = if (isCreator) {
                    mapOf(
                        "creatorName" to name,
                        "creatorPhoto" to photoUrl.ifEmpty { avatarRes }
                    )
                } else {
                    mapOf(
                        "partnerName" to name,
                        "partnerPhoto" to photoUrl.ifEmpty { avatarRes }
                    )
                }
                firestore.collection("relationships").document(relId).update(relUpdates).await()
            }
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error updating profile online: ${e.message}")
        }
    }

    fun stopAllListeners() {
        relationshipListener?.remove()
        relationshipListener = null
        partnerProfileListener?.remove()
        partnerProfileListener = null
        currentListeningPartnerUid = null
        messagesListener?.remove()
        messagesListener = null
        memoriesListener?.remove()
        memoriesListener = null
        goalsListener?.remove()
        goalsListener = null
        notesListener?.remove()
        notesListener = null
    }
}
