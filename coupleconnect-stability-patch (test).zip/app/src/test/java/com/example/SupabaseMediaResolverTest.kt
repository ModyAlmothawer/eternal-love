package com.example

import com.example.data.remote.MediaUrlResolver
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SupabaseMediaResolverTest {

    @Test
    fun testIsSupabaseReference() {
        // Supabase references
        assertTrue(MediaUrlResolver.isSupabaseReference("https://epaebeouojogosygfxrv.supabase.co/storage/v1/object/app-media/users/uid123/profile/avatar.jpg"))
        assertTrue(MediaUrlResolver.isSupabaseReference("supabase://app-media/relationships/rel456/memories/mem.jpg"))
        assertTrue(MediaUrlResolver.isSupabaseReference("app-media/relationships/rel456/voice/v.m4a"))

        // Non-Supabase references (legacy or local)
        assertFalse(MediaUrlResolver.isSupabaseReference("https://firebasestorage.googleapis.com/v0/b/lyubov-c1aab.appspot.com/o/users..."))
        assertFalse(MediaUrlResolver.isSupabaseReference("content://media/external/images/media/123"))
        assertFalse(MediaUrlResolver.isSupabaseReference("file:///data/user/0/com.example/cache/voice.m4a"))
        assertFalse(MediaUrlResolver.isSupabaseReference(""))
        assertFalse(MediaUrlResolver.isSupabaseReference(null))
    }

    @Test
    fun testExtractCleanPath() {
        val profileUrl = "https://epaebeouojogosygfxrv.supabase.co/storage/v1/object/app-media/users/user_xyz/profile/avatar_123.jpg"
        assertEquals("users/user_xyz/profile/avatar_123.jpg", MediaUrlResolver.extractCleanPath(profileUrl))

        val memoryUrl = "https://epaebeouojogosygfxrv.supabase.co/storage/v1/object/app-media/relationships/rel_123/memories/mem_abc.jpg"
        assertEquals("relationships/rel_123/memories/mem_abc.jpg", MediaUrlResolver.extractCleanPath(memoryUrl))

        val voiceUrl = "https://epaebeouojogosygfxrv.supabase.co/storage/v1/object/app-media/relationships/rel_123/voice/voice_def.m4a"
        assertEquals("relationships/rel_123/voice/voice_def.m4a", MediaUrlResolver.extractCleanPath(voiceUrl))

        val customSchemeUrl = "supabase://app-media/users/user_xyz/profile/avatar_123.jpg"
        assertEquals("users/user_xyz/profile/avatar_123.jpg", MediaUrlResolver.extractCleanPath(customSchemeUrl))

        // Query params in signed URLs should be stripped during clean path extraction
        val signedUrlWithParams = "https://epaebeouojogosygfxrv.supabase.co/storage/v1/object/sign/app-media/users/user_xyz/profile/avatar_123.jpg?token=ey..."
        assertEquals("users/user_xyz/profile/avatar_123.jpg", MediaUrlResolver.extractCleanPath(signedUrlWithParams))

        // Non-Supabase URLs should return null
        assertNull(MediaUrlResolver.extractCleanPath("https://firebasestorage.googleapis.com/v0/b/..."))
    }
}
