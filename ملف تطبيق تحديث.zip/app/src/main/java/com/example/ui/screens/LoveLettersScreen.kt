package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.LoveLetterEntity
import com.example.ui.components.FloatingHeartsBackground
import com.example.ui.components.RomanticAvatar
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.RomanticGradient
import com.example.ui.theme.RoseGold
import com.example.ui.theme.SoftBlush
import com.example.ui.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LoveLettersScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // Suppress notifications and mark messages read while user is inside chat
    DisposableEffect(Unit) {
        viewModel.enterChatScreen(context)
        onDispose {
            viewModel.leaveChatScreen()
        }
    }

    val letters by viewModel.loveLetters.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val relationship by viewModel.currentRelationship.collectAsState()
    val partnerIsTyping by viewModel.partnerIsTyping.collectAsState()

    var messageText by remember { mutableStateOf("") }
    var letterToDelete by remember { mutableStateOf<LoveLetterEntity?>(null) }
    var replyingToLetter by remember { mutableStateOf<LoveLetterEntity?>(null) }
    var editingLetter by remember { mutableStateOf<LoveLetterEntity?>(null) }

    val listState = rememberLazyListState()

    // Auto-scroll to latest message on new incoming/outgoing messages
    LaunchedEffect(letters.firstOrNull()?.firestoreId, letters.size) {
        if (letters.isNotEmpty()) {
            listState.animateScrollToItem(0)
        }
    }

    val partnerName = currentUser?.partnerName?.ifBlank { stringResource(R.string.my_partner) }
        ?: relationship?.partnerName?.ifBlank { stringResource(R.string.my_partner) }
        ?: stringResource(R.string.my_partner)

    val quickPhrases = listOf(
        "وحشتني أوي ❤️",
        "بحبك من كل قلبي ✨",
        "صباح الورد يا روحي 🌸",
        "مساء الحب والسعادة 💕",
        "أنت أجمل نعمة في حياتي 👑"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(RomanticGradient)
            .testTag("chat_screen")
    ) {
        FloatingHeartsBackground(heartCount = 8)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .imePadding()
        ) {
            // Chat Header
            ChatHeader(
                partnerName = partnerName,
                partnerPhoto = currentUser?.partnerPhotoUrl ?: "",
                partnerStatus = currentUser?.partnerDailyStatus ?: "",
                partnerStatusEmoji = currentUser?.partnerDailyStatusEmoji ?: "❤️"
            )

            // Messages List (reversed order: newest at bottom)
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                reverseLayout = true,
                contentPadding = PaddingValues(vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (letters.isEmpty()) {
                    item {
                        EmptyChatPlaceholder()
                    }
                } else {
                    items(letters, key = { it.firestoreId.ifBlank { it.id.toString() } }) { letter ->
                        val isMe = (letter.senderUid == currentUser?.firebaseUid) ||
                                (letter.senderName == currentUser?.name && letter.senderUid.isBlank())

                        ChatMessageBubble(
                            letter = letter,
                            isMe = isMe,
                            onReplyClick = {
                                replyingToLetter = letter
                                editingLetter = null
                            },
                            onEditClick = {
                                editingLetter = letter
                                replyingToLetter = null
                                messageText = letter.message
                            },
                            onDeleteClick = {
                                letterToDelete = letter
                            }
                        )
                    }
                }
            }

            // Realtime Typing Indicator
            AnimatedVisibility(
                visible = partnerIsTyping,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0x33140510))
                        .padding(horizontal = 20.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "$partnerName ${stringResource(R.string.typing_indicator)}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontSize = 12.sp,
                            fontStyle = FontStyle.Italic
                        ),
                        color = RoseGold
                    )
                    TypingDotsAnimation()
                }
            }

            // Quick Romantic Phrases Strip (shown when not editing)
            if (editingLetter == null) {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0x33140510))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(quickPhrases) { phrase ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0x332B1020))
                                .border(1.dp, Color(0x33FF4D79), RoundedCornerShape(16.dp))
                                .clickable {
                                    messageText = phrase
                                    viewModel.setTyping(true)
                                }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = phrase,
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                                color = SoftBlush
                            )
                        }
                    }
                }
            }

            // Reply Preview Banner
            if (replyingToLetter != null) {
                ReplyBanner(
                    letter = replyingToLetter!!,
                    onDismiss = { replyingToLetter = null }
                )
            }

            // Edit Mode Banner
            if (editingLetter != null) {
                EditBanner(
                    letter = editingLetter!!,
                    onDismiss = {
                        editingLetter = null
                        messageText = ""
                        viewModel.setTyping(false)
                    }
                )
            }

            // Chat Input Bar
            ChatInputBar(
                text = messageText,
                isEditing = editingLetter != null,
                onTextChange = {
                    messageText = it
                    viewModel.setTyping(it.isNotBlank())
                },
                onSend = {
                    val trimmed = messageText.trim()
                    if (trimmed.isNotBlank()) {
                        val currentEdit = editingLetter
                        if (currentEdit != null) {
                            viewModel.editLoveLetter(currentEdit.firestoreId, trimmed)
                            editingLetter = null
                        } else {
                            viewModel.sendLoveLetter(
                                title = "",
                                message = trimmed,
                                themeIndex = 0,
                                replyToId = replyingToLetter?.firestoreId,
                                replyToSenderName = replyingToLetter?.senderName,
                                replyToText = replyingToLetter?.message
                            )
                            replyingToLetter = null
                        }
                        messageText = ""
                        viewModel.setTyping(false)
                    }
                }
            )
        }

        // Delete Confirmation Dialog (Real-time delete)
        if (letterToDelete != null) {
            AlertDialog(
                onDismissRequest = { letterToDelete = null },
                title = {
                    Text(
                        text = stringResource(R.string.delete_message_title),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = SoftBlush
                    )
                },
                text = {
                    Text(
                        text = stringResource(R.string.delete_for_both_warning),
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            letterToDelete?.let {
                                viewModel.deleteLoveLetter(it.firestoreId)
                            }
                            letterToDelete = null
                        }
                    ) {
                        Text(
                            text = stringResource(R.string.delete_for_both),
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                dismissButton = {
                    TextButton(onClick = { letterToDelete = null }) {
                        Text(text = stringResource(R.string.cancel), color = RoseGold)
                    }
                },
                containerColor = Color(0xFF200918),
                shape = RoundedCornerShape(20.dp)
            )
        }
    }
}

@Composable
private fun ChatHeader(
    partnerName: String,
    partnerPhoto: String,
    partnerStatus: String,
    partnerStatusEmoji: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xEE160712))
            .border(1.dp, Color(0x33FF4D79), RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp))
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        RomanticAvatar(
            photoUrl = partnerPhoto,
            avatarRes = "avatar_2",
            size = 44.dp,
            borderColor = CrimsonPrimary,
            borderWidth = 1.5.dp
        )

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = partnerName,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = SoftBlush
            )
            if (partnerStatus.isNotBlank()) {
                Text(
                    text = "$partnerStatusEmoji $partnerStatus",
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = RoseGold
                )
            } else {
                Text(
                    text = stringResource(R.string.chat_header_subtitle),
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = RoseGold.copy(alpha = 0.7f)
                )
            }
        }

        Box(
            modifier = Modifier
                .size(34.dp)
                .background(CrimsonPrimary.copy(alpha = 0.15f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Favorite,
                contentDescription = null,
                tint = CrimsonPrimary,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
private fun ChatMessageBubble(
    letter: LoveLetterEntity,
    isMe: Boolean,
    onReplyClick: () -> Unit,
    onEditClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val timeFormat = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }
    val formattedTime = remember(letter.dateMillis) { timeFormat.format(Date(letter.dateMillis)) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("chat_message_item"),
        horizontalArrangement = if (isMe) Arrangement.End else Arrangement.Start
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .clip(
                    RoundedCornerShape(
                        topStart = 18.dp,
                        topEnd = 18.dp,
                        bottomStart = if (isMe) 18.dp else 4.dp,
                        bottomEnd = if (isMe) 4.dp else 18.dp
                    )
                )
                .background(
                    if (isMe) Color(0xDD7A1838) else Color(0xDD2A1222)
                )
                .border(
                    1.dp,
                    if (isMe) CrimsonPrimary.copy(alpha = 0.5f) else Color(0x33FF4D79),
                    RoundedCornerShape(
                        topStart = 18.dp,
                        topEnd = 18.dp,
                        bottomStart = if (isMe) 18.dp else 4.dp,
                        bottomEnd = if (isMe) 4.dp else 18.dp
                    )
                )
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Column {
                // Reply quote header if message is a reply
                if (!letter.replyToText.isNullOrBlank()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0x22FFFFFF))
                            .padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .height(26.dp)
                                .background(CrimsonPrimary, RoundedCornerShape(2.dp))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = letter.replyToSenderName?.ifBlank { stringResource(R.string.reply) }
                                    ?: stringResource(R.string.reply),
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                ),
                                color = RoseGold
                            )
                            Text(
                                text = letter.replyToText,
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                color = SoftBlush.copy(alpha = 0.85f),
                                maxLines = 1
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                }

                if (letter.title.isNotBlank()) {
                    Text(
                        text = letter.title,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = RoseGold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                }

                Text(
                    text = letter.message,
                    style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 20.sp),
                    color = SoftBlush
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Bottom row: timestamp, edited status, and action buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = formattedTime,
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                            color = Color.White.copy(alpha = 0.5f)
                        )
                        if (letter.isEdited) {
                            Text(
                                text = "• ${stringResource(R.string.message_edited)}",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontSize = 10.sp,
                                    fontStyle = FontStyle.Italic
                                ),
                                color = RoseGold.copy(alpha = 0.7f)
                            )
                        }
                    }

                    // Action buttons: Reply (always), Edit & Delete (if sent by user)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Reply action
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Reply,
                            contentDescription = stringResource(R.string.reply),
                            tint = RoseGold.copy(alpha = 0.7f),
                            modifier = Modifier
                                .size(16.dp)
                                .clickable { onReplyClick() }
                        )

                        if (isMe) {
                            // Edit own message
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = stringResource(R.string.edit),
                                tint = RoseGold.copy(alpha = 0.7f),
                                modifier = Modifier
                                    .size(16.dp)
                                    .clickable { onEditClick() }
                            )

                            // Delete own message
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = stringResource(R.string.delete_for_both),
                                tint = RoseGold.copy(alpha = 0.7f),
                                modifier = Modifier
                                    .size(16.dp)
                                    .clickable { onDeleteClick() }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ReplyBanner(
    letter: LoveLetterEntity,
    onDismiss: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xEE2A1222))
            .border(1.dp, Color(0x33FF4D79), RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp))
            .padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = Icons.AutoMirrored.Filled.Reply,
            contentDescription = null,
            tint = CrimsonPrimary,
            modifier = Modifier.size(18.dp)
        )
        Box(
            modifier = Modifier
                .width(2.dp)
                .height(28.dp)
                .background(CrimsonPrimary)
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = stringResource(R.string.replying_to, letter.senderName.ifBlank { "الطرف الآخر" }),
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, fontSize = 11.sp),
                color = RoseGold
            )
            Text(
                text = letter.message,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                color = SoftBlush.copy(alpha = 0.85f),
                maxLines = 1
            )
        }
        IconButton(
            onClick = onDismiss,
            modifier = Modifier.size(24.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = stringResource(R.string.cancel),
                tint = SoftBlush.copy(alpha = 0.7f),
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
private fun EditBanner(
    letter: LoveLetterEntity,
    onDismiss: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xEE2A1222))
            .border(1.dp, CrimsonPrimary.copy(alpha = 0.5f), RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp))
            .padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Edit,
            contentDescription = null,
            tint = CrimsonPrimary,
            modifier = Modifier.size(18.dp)
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = stringResource(R.string.edit_message),
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, fontSize = 11.sp),
                color = RoseGold
            )
            Text(
                text = letter.message,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                color = SoftBlush.copy(alpha = 0.7f),
                maxLines = 1
            )
        }
        IconButton(
            onClick = onDismiss,
            modifier = Modifier.size(24.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = stringResource(R.string.cancel),
                tint = SoftBlush.copy(alpha = 0.7f),
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
private fun EmptyChatPlaceholder() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.Favorite,
            contentDescription = null,
            tint = CrimsonPrimary.copy(alpha = 0.4f),
            modifier = Modifier.size(54.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = stringResource(R.string.no_messages_yet),
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = SoftBlush
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = stringResource(R.string.start_chat_prompt),
            style = MaterialTheme.typography.bodySmall,
            color = RoseGold
        )
    }
}

@Composable
private fun ChatInputBar(
    text: String,
    isEditing: Boolean = false,
    onTextChange: (String) -> Unit,
    onSend: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xEE160712))
            .border(1.dp, Color(0x33FF4D79), RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        OutlinedTextField(
            value = text,
            onValueChange = onTextChange,
            placeholder = {
                Text(
                    text = if (isEditing) stringResource(R.string.edit_message) else stringResource(R.string.write_message_hint),
                    color = Color.White.copy(alpha = 0.4f),
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            modifier = Modifier
                .weight(1f)
                .testTag("chat_input_text_field"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = SoftBlush,
                unfocusedTextColor = SoftBlush,
                focusedBorderColor = CrimsonPrimary,
                unfocusedBorderColor = Color(0x33FF4D79),
                focusedContainerColor = Color(0x332B1020),
                unfocusedContainerColor = Color(0x222B1020)
            ),
            shape = RoundedCornerShape(24.dp),
            maxLines = 4
        )

        IconButton(
            onClick = onSend,
            enabled = text.isNotBlank(),
            modifier = Modifier
                .size(46.dp)
                .background(
                    if (text.isNotBlank()) CrimsonPrimary else Color(0x33FF4D79),
                    CircleShape
                )
                .testTag("btn_send_chat_message")
        ) {
            Icon(
                imageVector = Icons.Default.Send,
                contentDescription = "Send",
                tint = SoftBlush,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

@Composable
private fun TypingDotsAnimation() {
    val infiniteTransition = rememberInfiniteTransition(label = "typing_dots")
    val alpha1 by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "dot1"
    )
    val alpha2 by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(500, delayMillis = 180, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "dot2"
    )
    val alpha3 by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(500, delayMillis = 360, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "dot3"
    )

    Row(
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(modifier = Modifier.size(5.dp).background(CrimsonPrimary.copy(alpha = alpha1), CircleShape))
        Box(modifier = Modifier.size(5.dp).background(CrimsonPrimary.copy(alpha = alpha2), CircleShape))
        Box(modifier = Modifier.size(5.dp).background(CrimsonPrimary.copy(alpha = alpha3), CircleShape))
    }
}
