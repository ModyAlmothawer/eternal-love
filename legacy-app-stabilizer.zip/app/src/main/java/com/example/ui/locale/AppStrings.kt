package com.example.ui.locale

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

enum class AppLanguage(val code: String, val displayName: String) {
    ARABIC("ar", "العربية (المصرية) 🇪🇬"),
    ENGLISH("en", "English 🇬🇧")
}

object LocaleManager {
    var currentLanguage by mutableStateOf(AppLanguage.ARABIC)

    fun toggleLanguage() {
        currentLanguage = if (currentLanguage == AppLanguage.ARABIC) {
            AppLanguage.ENGLISH
        } else {
            AppLanguage.ARABIC
        }
    }

    fun setLanguage(lang: AppLanguage) {
        currentLanguage = lang
    }
}

val LocalAppStrings = compositionLocalOf { AppStrings.arabic() }

data class AppStrings(
    val appName: String,
    val welcomeTitle: String,
    val welcomeSubtitle: String,
    val startButton: String,
    val loginTitle: String,
    val registerTitle: String,
    val emailLabel: String,
    val passwordLabel: String,
    val nameLabel: String,
    val loginButton: String,
    val registerButton: String,
    val switchToRegister: String,
    val switchToLogin: String,
    val googleSignInButton: String,
    val pairingTitle: String,
    val pairingSubtitle: String,
    val yourPairingCode: String,
    val enterPartnerCode: String,
    val pairButton: String,
    val copyCode: String,
    val codeCopied: String,
    val pairingSuccess: String,
    val homeTab: String,
    val chatTab: String,
    val memoriesTab: String,
    val goalsTab: String,
    val partnerFeelingTitle: String,
    val yourFeelingTitle: String,
    val updateFeelingButton: String,
    val selectFeeling: String,
    val daysTogether: String,
    val days: String,
    val typeMessageHint: String,
    val sendButton: String,
    val deleteForBoth: String,
    val confirmDeleteMessage: String,
    val confirmDeleteMemory: String,
    val confirmDeleteGoal: String,
    val addMemoryTitle: String,
    val memoryTitleLabel: String,
    val memoryDescLabel: String,
    val choosePhoto: String,
    val changePhoto: String,
    val save: String,
    val cancel: String,
    val delete: String,
    val goalsTitle: String,
    val addGoalTitle: String,
    val goalTitleLabel: String,
    val goalDescLabel: String,
    val createdBy: String,
    val completed: String,
    val notCompleted: String,
    val profileTitle: String,
    val editProfile: String,
    val signOut: String,
    val languageSwitch: String,
    val errorEmptyFields: String,
    val errorInvalidCode: String,
    val errorGeneral: String,
    val noMessagesYet: String,
    val noMemoriesYet: String,
    val noGoalsYet: String,
    val partnerNotPaired: String,
    val partnerPaired: String,
    val feelingUpdatedSuccess: String,
    val goalAddedSuccess: String,
    val memoryAddedSuccess: String,
    val notificationsPrompt: String
) {
    companion object {
        fun arabic() = AppStrings(
            appName = "TwoOfUs",
            welcomeTitle = "مساحتنا الخاصة",
            welcomeSubtitle = "مكان يجمعنا سوا.. دردشة، ذكريات، وحاجات نفسنا نعملها مع بعض.",
            startButton = "يلا نبدأ",
            loginTitle = "تسجيل الدخول",
            registerTitle = "إنشاء حساب جديد",
            emailLabel = "البريد الإلكتروني",
            passwordLabel = "كلمة المرور",
            nameLabel = "اسمك",
            loginButton = "دخول",
            registerButton = "إنشاء الحساب",
            switchToRegister = "لسه معندكش حساب؟ سجل هنا",
            switchToLogin = "عندك حساب بالفعل؟ سجل دخولك",
            googleSignInButton = "تسجيل الدخول بحساب Google",
            pairingTitle = "ربط الحسابين",
            pairingSubtitle = "شارك الكود ده مع شريكك، أو اكتب الكود بتاعه عشان تبدأوا مع بعض.",
            yourPairingCode = "الكود الخاص بيك:",
            enterPartnerCode = "اكتب كود شريكك هنا",
            pairButton = "ربط الحسابين",
            copyCode = "نسخ الكود",
            codeCopied = "تم نسخ الكود!",
            pairingSuccess = "مبروك! تم ربط الحسابين بنجاح",
            homeTab = "الرئيسية",
            chatTab = "الدردشة",
            memoriesTab = "الذكريات",
            goalsTab = "أهدافنا",
            partnerFeelingTitle = "حالة شريكك النهاردة",
            yourFeelingTitle = "حاسس بإيه النهاردة؟",
            updateFeelingButton = "تغيير حالتك",
            selectFeeling = "اختر حالتك دلوقتي",
            daysTogether = "أيامنا مع بعض",
            days = "يوم",
            typeMessageHint = "اكتب رسالة...",
            sendButton = "إرسال",
            deleteForBoth = "حذف لكلا الطرفين",
            confirmDeleteMessage = "هل أنت متأكد من حذف هذه الرسالة عند الطرفين؟",
            confirmDeleteMemory = "هل أنت متأكد من حذف هذه الذكرى عند الطرفين؟",
            confirmDeleteGoal = "هل أنت متأكد من حذف هذا الهدف؟",
            addMemoryTitle = "إضافة ذكرى جديدة",
            memoryTitleLabel = "عنوان الذكرى",
            memoryDescLabel = "تفاصيل / ملاحظات",
            choosePhoto = "اختيار صورة من الموبايل",
            changePhoto = "تغيير الصورة",
            save = "حفظ",
            cancel = "إلغاء",
            delete = "حذف",
            goalsTitle = "أهدافنا المشتركة",
            addGoalTitle = "إضافة هدف جديد",
            goalTitleLabel = "عنوان الهدف",
            goalDescLabel = "تفاصيل بسيطة (اختياري)",
            createdBy = "هدف",
            completed = "تم إنجازه",
            notCompleted = "قيد الإنجاز",
            profileTitle = "الملف الشخصي",
            editProfile = "تعديل البيانات",
            signOut = "تسجيل الخروج",
            languageSwitch = "تغيير اللغة",
            errorEmptyFields = "من فضلك املأ كل الحقول المطلوبة",
            errorInvalidCode = "كود الشريك غير صحيح أو غير موجود",
            errorGeneral = "حصل خطأ، حاول تاني",
            noMessagesYet = "لسه مفيش رسائل.. ابدأ الدردشة دلوقتي! ❤️",
            noMemoriesYet = "لسه مفيش ذكريات متسجلة.. دوس على + وضيف أول ذكرى!",
            noGoalsYet = "لسه مفيش أهداف.. ضيفوا أهداف حابين تحققوها سوا!",
            partnerNotPaired = "في انتظار الشريك يربط حسابه...",
            partnerPaired = "متصلين سوا",
            feelingUpdatedSuccess = "تم تحديث حالتك بنجاح!",
            goalAddedSuccess = "تم حفظ الهدف بنجاح!",
            memoryAddedSuccess = "تمت إضافة الذكرى بنجاح!",
            notificationsPrompt = "يرجى تفعيل الإشعارات ليصلك كل جديد من شريكك أول بأول"
        )

        fun english() = AppStrings(
            appName = "TwoOfUs",
            welcomeTitle = "Our Private Space",
            welcomeSubtitle = "A cozy corner for the two of us — chat, memories, and shared dreams.",
            startButton = "Get Started",
            loginTitle = "Sign In",
            registerTitle = "Create Account",
            emailLabel = "Email Address",
            passwordLabel = "Password",
            nameLabel = "Your Name",
            loginButton = "Sign In",
            registerButton = "Create Account",
            switchToRegister = "Don't have an account? Sign up",
            switchToLogin = "Already have an account? Sign in",
            googleSignInButton = "Sign in with Google",
            pairingTitle = "Connect Together",
            pairingSubtitle = "Share your code with your partner, or enter their code to connect.",
            yourPairingCode = "Your Pairing Code:",
            enterPartnerCode = "Enter Partner's Code",
            pairButton = "Connect Accounts",
            copyCode = "Copy Code",
            codeCopied = "Code copied to clipboard!",
            pairingSuccess = "Connected successfully!",
            homeTab = "Home",
            chatTab = "Chat",
            memoriesTab = "Memories",
            goalsTab = "Goals",
            partnerFeelingTitle = "Partner's Status Today",
            yourFeelingTitle = "How are you feeling today?",
            updateFeelingButton = "Update Status",
            selectFeeling = "Select your mood",
            daysTogether = "Days Together",
            days = "days",
            typeMessageHint = "Type a message...",
            sendButton = "Send",
            deleteForBoth = "Delete for both",
            confirmDeleteMessage = "Are you sure you want to delete this message for both sides?",
            confirmDeleteMemory = "Are you sure you want to delete this memory for both sides?",
            confirmDeleteGoal = "Are you sure you want to delete this goal?",
            addMemoryTitle = "Add New Memory",
            memoryTitleLabel = "Memory Title",
            memoryDescLabel = "Details / Notes",
            choosePhoto = "Choose Photo from Gallery",
            changePhoto = "Change Photo",
            save = "Save",
            cancel = "Cancel",
            delete = "Delete",
            goalsTitle = "Our Shared Goals",
            addGoalTitle = "Add New Goal",
            goalTitleLabel = "Goal Title",
            goalDescLabel = "Details (optional)",
            createdBy = "Goal by",
            completed = "Completed",
            notCompleted = "In Progress",
            profileTitle = "Profile",
            editProfile = "Edit Profile",
            signOut = "Sign Out",
            languageSwitch = "Language",
            errorEmptyFields = "Please fill in all required fields",
            errorInvalidCode = "Partner code is invalid or not found",
            errorGeneral = "An error occurred, please try again",
            noMessagesYet = "No messages yet. Start chatting now! ❤️",
            noMemoriesYet = "No memories saved yet. Tap + to add your first photo!",
            noGoalsYet = "No goals added yet. Add things you want to do together!",
            partnerNotPaired = "Waiting for partner to connect...",
            partnerPaired = "Connected",
            feelingUpdatedSuccess = "Status updated successfully!",
            goalAddedSuccess = "Goal saved successfully!",
            memoryAddedSuccess = "Memory added successfully!",
            notificationsPrompt = "Please enable notifications to receive instant updates from your partner"
        )
    }
}

@Composable
fun ProvideAppLocale(content: @Composable () -> Unit) {
    val lang = LocaleManager.currentLanguage
    val strings = if (lang == AppLanguage.ARABIC) AppStrings.arabic() else AppStrings.english()
    val layoutDir = if (lang == AppLanguage.ARABIC) LayoutDirection.Rtl else LayoutDirection.Ltr

    CompositionLocalProvider(
        LocalAppStrings provides strings,
        LocalLayoutDirection provides layoutDir
    ) {
        content()
    }
}
