package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ChatMessage
import com.example.data.model.Couple
import com.example.data.model.Goal
import com.example.data.model.Memory
import com.example.data.model.UserProfile
import com.example.data.repository.CoupleRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch

class CoupleViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = CoupleRepository(application)

    private val _currentUser = MutableStateFlow<UserProfile?>(null)
    val currentUser: StateFlow<UserProfile?> = _currentUser.asStateFlow()

    private val _partner = MutableStateFlow<UserProfile?>(null)
    val partner: StateFlow<UserProfile?> = _partner.asStateFlow()

    private val _couple = MutableStateFlow<Couple?>(null)
    val couple: StateFlow<Couple?> = _couple.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _memories = MutableStateFlow<List<Memory>>(emptyList())
    val memories: StateFlow<List<Memory>> = _memories.asStateFlow()

    private val _goals = MutableStateFlow<List<Goal>>(emptyList())
    val goals: StateFlow<List<Goal>> = _goals.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _successMessage = MutableStateFlow<String?>(null)
    val successMessage: StateFlow<String?> = _successMessage.asStateFlow()

    private var currentUserJob: Job? = null
    private var coupleJob: Job? = null
    private var partnerJob: Job? = null
    private var messagesJob: Job? = null
    private var memoriesJob: Job? = null
    private var goalsJob: Job? = null

    init {
        checkAuthAndObserve()
    }

    fun checkAuthAndObserve() {
        if (repository.currentUserId != null) {
            observeCurrentUserData()
        } else {
            _currentUser.value = null
            _partner.value = null
            _couple.value = null
            _messages.value = emptyList()
            _memories.value = emptyList()
            _goals.value = emptyList()
        }
    }

    private fun observeCurrentUserData() {
        currentUserJob?.cancel()
        currentUserJob = viewModelScope.launch {
            repository.observeCurrentUser()
                .catch { e -> _errorMessage.value = e.message }
                .collect { profile ->
                    _currentUser.value = profile
                    val coupleId = profile?.coupleId
                    if (!coupleId.isNullOrBlank()) {
                        observeCoupleData(coupleId)
                    } else {
                        _couple.value = null
                        _partner.value = null
                        _messages.value = emptyList()
                        _memories.value = emptyList()
                        _goals.value = emptyList()
                    }
                }
        }
    }

    private fun observeCoupleData(coupleId: String) {
        coupleJob?.cancel()
        coupleJob = viewModelScope.launch {
            repository.observeCouple(coupleId)
                .catch { e -> _errorMessage.value = e.message }
                .collect { c ->
                    _couple.value = c
                    val currentUid = repository.currentUserId
                    if (c != null && currentUid != null) {
                        val partnerId = if (c.user1Id == currentUid) c.user2Id else c.user1Id
                        observePartnerData(partnerId)
                    }
                }
        }

        messagesJob?.cancel()
        messagesJob = viewModelScope.launch {
            repository.observeMessages(coupleId)
                .catch { e -> _errorMessage.value = e.message }
                .collect { msgList ->
                    _messages.value = msgList
                }
        }

        memoriesJob?.cancel()
        memoriesJob = viewModelScope.launch {
            repository.observeMemories(coupleId)
                .catch { e -> _errorMessage.value = e.message }
                .collect { memList ->
                    _memories.value = memList
                }
        }

        goalsJob?.cancel()
        goalsJob = viewModelScope.launch {
            repository.observeGoals(coupleId)
                .catch { e -> _errorMessage.value = e.message }
                .collect { goalList ->
                    _goals.value = goalList
                }
        }
    }

    private fun observePartnerData(partnerId: String) {
        partnerJob?.cancel()
        if (partnerId.isBlank()) return
        partnerJob = viewModelScope.launch {
            repository.observePartner(partnerId)
                .catch { e -> _errorMessage.value = e.message }
                .collect { p ->
                    _partner.value = p
                }
        }
    }

    // --- Authentication Actions ---

    fun signIn(email: String, pass: String, onSuccess: () -> Unit = {}) {
        if (email.isBlank() || pass.isBlank()) {
            _errorMessage.value = "من فضلك اكتب البريد الإلكتروني وكلمة المرور"
            return
        }
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            val result = repository.signInWithEmail(email, pass)
            _isLoading.value = false
            if (result.isSuccess) {
                observeCurrentUserData()
                onSuccess()
            } else {
                _errorMessage.value = result.exceptionOrNull()?.localizedMessage ?: "فشل تسجيل الدخول"
            }
        }
    }

    fun register(name: String, email: String, pass: String, photoBase64: String = "", onSuccess: () -> Unit = {}) {
        if (name.isBlank() || email.isBlank() || pass.isBlank()) {
            _errorMessage.value = "من فضلك املأ كل الحقول المطلوبة"
            return
        }
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            val result = repository.registerWithEmail(name, email, pass, photoBase64)
            _isLoading.value = false
            if (result.isSuccess) {
                observeCurrentUserData()
                onSuccess()
            } else {
                _errorMessage.value = result.exceptionOrNull()?.localizedMessage ?: "فشل إنشاء الحساب"
            }
        }
    }

    fun signOut(onSignedOut: () -> Unit = {}) {
        currentUserJob?.cancel()
        coupleJob?.cancel()
        partnerJob?.cancel()
        messagesJob?.cancel()
        memoriesJob?.cancel()
        goalsJob?.cancel()

        repository.signOut()
        _currentUser.value = null
        _partner.value = null
        _couple.value = null
        _messages.value = emptyList()
        _memories.value = emptyList()
        _goals.value = emptyList()
        onSignedOut()
    }

    // --- Pairing Actions ---

    fun pairWithPartner(partnerCode: String, onSuccess: () -> Unit = {}) {
        if (partnerCode.isBlank()) {
            _errorMessage.value = "من فضلك ادخل كود الشريك"
            return
        }
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            val result = repository.pairWithPartner(partnerCode)
            _isLoading.value = false
            if (result.isSuccess) {
                _successMessage.value = "تم ربط الحسابين بنجاح! 🎉"
                onSuccess()
            } else {
                _errorMessage.value = result.exceptionOrNull()?.localizedMessage ?: "فشل ربط الحسابين"
            }
        }
    }

    // --- Daily Feeling Actions ---

    fun updateDailyFeeling(status: String, emoji: String) {
        viewModelScope.launch {
            val result = repository.updateDailyFeeling(status, emoji)
            if (result.isSuccess) {
                _successMessage.value = "تم تحديث حالتك بنجاح!"
            } else {
                _errorMessage.value = "تعذر تحديث الحالة"
            }
        }
    }

    // --- Profile Actions ---

    fun updateProfile(name: String, photoBase64: String) {
        viewModelScope.launch {
            _isLoading.value = true
            val result = repository.updateProfile(name, photoBase64)
            _isLoading.value = false
            if (result.isSuccess) {
                _successMessage.value = "تم تحديث الملف الشخصي بنجاح!"
            } else {
                _errorMessage.value = "تعذر تحديث الملف الشخصي"
            }
        }
    }

    // --- Chat Actions ---

    fun sendMessage(text: String, photoBase64: String = "") {
        val coupleId = _currentUser.value?.coupleId ?: return
        val senderName = _currentUser.value?.displayName ?: "أنا"
        if (text.isBlank() && photoBase64.isBlank()) return

        viewModelScope.launch {
            val result = repository.sendMessage(coupleId, text, photoBase64, senderName)
            if (result.isFailure) {
                _errorMessage.value = "فشل إرسال الرسالة"
            }
        }
    }

    fun deleteMessageForBoth(messageId: String) {
        val coupleId = _currentUser.value?.coupleId ?: return
        viewModelScope.launch {
            val result = repository.deleteMessageForBoth(coupleId, messageId)
            if (result.isFailure) {
                _errorMessage.value = "تعذر حذف الرسالة"
            }
        }
    }

    // --- Memory Actions ---

    fun addMemory(title: String, description: String, photoBase64: String, onSuccess: () -> Unit = {}) {
        val coupleId = _currentUser.value?.coupleId ?: return
        val creatorName = _currentUser.value?.displayName ?: ""
        if (title.isBlank()) {
            _errorMessage.value = "من فضلك اكتب عنوان الذكرى"
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            val result = repository.addMemory(coupleId, title, description, photoBase64, creatorName)
            _isLoading.value = false
            if (result.isSuccess) {
                _successMessage.value = "تمت إضافة الذكرى بنجاح!"
                onSuccess()
            } else {
                _errorMessage.value = "تعذر حفظ الذكرى"
            }
        }
    }

    fun deleteMemoryForBoth(memoryId: String) {
        val coupleId = _currentUser.value?.coupleId ?: return
        viewModelScope.launch {
            val result = repository.deleteMemoryForBoth(coupleId, memoryId)
            if (result.isSuccess) {
                _successMessage.value = "تم حذف الذكرى"
            } else {
                _errorMessage.value = "تعذر حذف الذكرى"
            }
        }
    }

    // --- Goal Actions ---

    fun addGoal(title: String, description: String, onSuccess: () -> Unit = {}) {
        val coupleId = _currentUser.value?.coupleId ?: return
        val creatorName = _currentUser.value?.displayName ?: "أنا"
        if (title.isBlank()) {
            _errorMessage.value = "من فضلك اكتب عنوان الهدف"
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            val result = repository.addGoal(coupleId, title, description, creatorName)
            _isLoading.value = false
            if (result.isSuccess) {
                _successMessage.value = "تمت إضافة الهدف بنجاح!"
                onSuccess()
            } else {
                _errorMessage.value = "تعذر حفظ الهدف"
            }
        }
    }

    fun toggleGoal(goalId: String, currentStatus: Boolean) {
        val coupleId = _currentUser.value?.coupleId ?: return
        viewModelScope.launch {
            val result = repository.toggleGoalCompleted(coupleId, goalId, currentStatus)
            if (result.isFailure) {
                _errorMessage.value = "تعذر تحديث حالة الهدف"
            }
        }
    }

    fun deleteGoal(goalId: String) {
        val coupleId = _currentUser.value?.coupleId ?: return
        viewModelScope.launch {
            val result = repository.deleteGoalForBoth(coupleId, goalId)
            if (result.isFailure) {
                _errorMessage.value = "تعذر حذف الهدف"
            }
        }
    }

    fun clearFeedback() {
        _errorMessage.value = null
        _successMessage.value = null
    }
}
