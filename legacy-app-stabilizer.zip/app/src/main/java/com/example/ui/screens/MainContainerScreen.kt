package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.automirrored.outlined.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.UserAvatar
import com.example.ui.locale.AppLanguage
import com.example.ui.locale.LocalAppStrings
import com.example.ui.locale.LocaleManager
import com.example.ui.theme.RosePrimary
import com.example.ui.viewmodel.CoupleViewModel

enum class MainTab {
    HOME, CHAT, MEMORIES, GOALS, PROFILE
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainContainerScreen(
    viewModel: CoupleViewModel,
    onSignOut: () -> Unit
) {
    val strings = LocalAppStrings.current
    val isArabic = LocaleManager.currentLanguage == AppLanguage.ARABIC

    var currentTab by remember { mutableStateOf(MainTab.HOME) }
    val currentUser by viewModel.currentUser.collectAsState()
    val partner by viewModel.partner.collectAsState()

    // Request Notification Permission on Android 13+ (API 33+)
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            // Notification permission granted
        }
    }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        UserAvatar(
                            photoBase64 = if (currentTab == MainTab.PROFILE) currentUser?.photoBase64 else partner?.photoBase64,
                            size = 36.dp,
                            onClick = { currentTab = MainTab.PROFILE }
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = when (currentTab) {
                                    MainTab.HOME -> strings.homeTab
                                    MainTab.CHAT -> "${strings.chatTab} ${partner?.displayName?.let { "مع $it" } ?: ""}"
                                    MainTab.MEMORIES -> strings.memoriesTab
                                    MainTab.GOALS -> strings.goalsTab
                                    MainTab.PROFILE -> strings.profileTitle
                                },
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                            if (currentTab != MainTab.PROFILE && partner != null && partner?.feelingEmoji?.isNotBlank() == true) {
                                Text(
                                    text = "${partner?.displayName ?: ""}: ${partner?.feelingStatus ?: ""} ${partner?.feelingEmoji ?: ""}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                            }
                        }
                    }
                },
                actions = {
                    if (currentTab != MainTab.PROFILE) {
                        IconButton(
                            onClick = { currentTab = MainTab.PROFILE },
                            modifier = Modifier.testTag("nav_to_profile_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Settings / Profile",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .navigationBarsPadding()
                    .testTag("bottom_nav_bar")
            ) {
                NavigationBarItem(
                    selected = currentTab == MainTab.HOME,
                    onClick = { currentTab = MainTab.HOME },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == MainTab.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                            contentDescription = strings.homeTab
                        )
                    },
                    label = { Text(strings.homeTab, fontSize = 12.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag("tab_home")
                )

                NavigationBarItem(
                    selected = currentTab == MainTab.CHAT,
                    onClick = { currentTab = MainTab.CHAT },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == MainTab.CHAT) Icons.AutoMirrored.Filled.Chat else Icons.AutoMirrored.Outlined.Chat,
                            contentDescription = strings.chatTab
                        )
                    },
                    label = { Text(strings.chatTab, fontSize = 12.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag("tab_chat")
                )

                NavigationBarItem(
                    selected = currentTab == MainTab.MEMORIES,
                    onClick = { currentTab = MainTab.MEMORIES },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == MainTab.MEMORIES) Icons.Filled.PhotoLibrary else Icons.Outlined.PhotoLibrary,
                            contentDescription = strings.memoriesTab
                        )
                    },
                    label = { Text(strings.memoriesTab, fontSize = 12.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag("tab_memories")
                )

                NavigationBarItem(
                    selected = currentTab == MainTab.GOALS,
                    onClick = { currentTab = MainTab.GOALS },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == MainTab.GOALS) Icons.Filled.CheckCircle else Icons.Outlined.CheckCircle,
                            contentDescription = strings.goalsTab
                        )
                    },
                    label = { Text(strings.goalsTab, fontSize = 12.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag("tab_goals")
                )
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (currentTab) {
                MainTab.HOME -> HomeScreen(
                    viewModel = viewModel,
                    onNavigateToChat = { currentTab = MainTab.CHAT },
                    onNavigateToMemories = { currentTab = MainTab.MEMORIES },
                    onNavigateToGoals = { currentTab = MainTab.GOALS }
                )
                MainTab.CHAT -> ChatScreen(viewModel = viewModel)
                MainTab.MEMORIES -> MemoriesScreen(viewModel = viewModel)
                MainTab.GOALS -> GoalsScreen(viewModel = viewModel)
                MainTab.PROFILE -> ProfileScreen(
                    viewModel = viewModel,
                    onSignOut = onSignOut
                )
            }
        }
    }
}
