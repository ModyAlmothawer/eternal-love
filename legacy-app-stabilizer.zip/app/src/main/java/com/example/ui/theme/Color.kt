package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Romantic & Modern Palette
val RosePrimary = Color(0xFFD81B60)
val RoseSecondary = Color(0xFFAD1457)
val RoseTertiary = Color(0xFFFF4081)
val RosePrimaryLight = Color(0xFFF06292)
val RoseBackground = Color(0xFFFFF7F9)
val RoseSurface = Color(0xFFFFFFFF)
val RoseSurfaceVariant = Color(0xFFFDEEF2)
val RoseCardBg = Color(0xFFFFF0F5)
val RoseOnPrimary = Color(0xFFFFFFFF)
val RoseTextDark = Color(0xFF2C1920)
val RoseTextMuted = Color(0xFF7A646E)
val RoseAccentGreen = Color(0xFF2E7D32)
val ChatBubbleSender = Color(0xFFFFE0EB)
val ChatBubbleReceiver = Color(0xFFF1F3F5)

// Dark Palette
val RosePrimaryDark = Color(0xFFFF80AB)
val RoseSecondaryDark = Color(0xFFFF4081)
val RoseBackgroundDark = Color(0xFF1E1217)
val RoseSurfaceDark = Color(0xFF2B1A22)
val RoseSurfaceVariantDark = Color(0xFF3B232F)
val RoseTextLight = Color(0xFFFBE4EC)
val RoseTextMutedDark = Color(0xFFB09CA6)
val ChatBubbleSenderDark = Color(0xFF59223A)
val ChatBubbleReceiverDark = Color(0xFF302B33)

