package com.example.service

import android.util.Log
import com.example.util.NotificationHelper
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class CoupleMessagingService : FirebaseMessagingService() {

    companion object {
        private const val TAG = "CoupleMessagingService"
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d(TAG, "New FCM Token received: $token")
        val currentUserId = FirebaseAuth.getInstance().currentUser?.uid
        if (currentUserId != null) {
            try {
                FirebaseFirestore.getInstance()
                    .collection("users")
                    .document(currentUserId)
                    .update("fcmToken", token)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to update token: ${e.message}")
            }
        }
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.d(TAG, "From: ${remoteMessage.from}")

        // Check if message contains a data payload
        val data = remoteMessage.data
        val senderId = data["senderId"]
        val currentUserId = FirebaseAuth.getInstance().currentUser?.uid

        // Do not notify sender about their own action
        if (senderId != null && senderId == currentUserId) {
            return
        }

        val title = data["title"] ?: remoteMessage.notification?.title ?: "رسالة جديدة"
        val body = data["body"] ?: remoteMessage.notification?.body ?: "وصلتك رسالة جديدة من شريكك"

        NotificationHelper.showNotification(
            context = applicationContext,
            title = title,
            message = body
        )
    }
}
