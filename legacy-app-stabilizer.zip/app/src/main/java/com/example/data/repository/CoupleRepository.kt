package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.data.model.ChatMessage
import com.example.data.model.Couple
import com.example.data.model.Goal
import com.example.data.model.Memory
import com.example.data.model.UserProfile
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

class CoupleRepository(private val context: Context) {

    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    private val db: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }

    companion object {
        private const val TAG = "CoupleRepository"
    }

    val currentUserId: String?
        get() = auth.currentUser?.uid

    // --- Authentication ---

    suspend fun signInWithEmail(email: String, pass: String): Result<String> {
        return try {
            val result = auth.signInWithEmailAndPassword(email.trim(), pass).await()
            val uid = result.user?.uid ?: return Result.failure(Exception("User ID is null"))
            updateFcmToken()
            Result.success(uid)
        } catch (e: Exception) {
            Log.e(TAG, "signInWithEmail failed: ${e.message}")
            Result.failure(e)
        }
    }

    suspend fun registerWithEmail(name: String, email: String, pass: String, photoBase64: String = ""): Result<String> {
        return try {
            val result = auth.createUserWithEmailAndPassword(email.trim(), pass).await()
            val uid = result.user?.uid ?: return Result.failure(Exception("User ID is null"))

            // Generate unique 6-character pairing code
            val pairingCode = UUID.randomUUID().toString().take(6).uppercase()

            val profile = UserProfile(
                uid = uid,
                email = email.trim(),
                displayName = name.trim(),
                photoBase64 = photoBase64,
                coupleId = "",
                pairingCode = pairingCode,
                feelingStatus = "",
                feelingEmoji = "",
                feelingUpdatedAt = 0L,
                fcmToken = "",
                createdAt = System.currentTimeMillis()
            )

            db.collection("users").document(uid).set(profile).await()
            updateFcmToken()
            Result.success(uid)
        } catch (e: Exception) {
            Log.e(TAG, "registerWithEmail failed: ${e.message}")
            Result.failure(e)
        }
    }

    fun signOut() {
        try {
            auth.signOut()
        } catch (e: Exception) {
            Log.e(TAG, "signOut failed: ${e.message}")
        }
    }

    suspend fun updateFcmToken() {
        val uid = currentUserId ?: return
        try {
            FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
                if (!token.isNullOrBlank()) {
                    db.collection("users").document(uid).update("fcmToken", token)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "updateFcmToken error: ${e.message}")
        }
    }

    // --- User Profile & Pairing ---

    fun observeCurrentUser(): Flow<UserProfile?> = callbackFlow {
        val uid = currentUserId
        if (uid == null) {
            trySend(null)
            close()
            return@callbackFlow
        }

        var registration: ListenerRegistration? = null
        try {
            registration = db.collection("users").document(uid)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.e(TAG, "observeCurrentUser error: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null && snapshot.exists()) {
                        val profile = snapshot.toObject(UserProfile::class.java)
                        trySend(profile)
                    } else {
                        trySend(null)
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "observeCurrentUser exception: ${e.message}")
            trySend(null)
        }

        awaitClose {
            registration?.remove()
        }
    }

    fun observePartner(partnerId: String): Flow<UserProfile?> = callbackFlow {
        if (partnerId.isBlank()) {
            trySend(null)
            close()
            return@callbackFlow
        }

        var registration: ListenerRegistration? = null
        try {
            registration = db.collection("users").document(partnerId)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.e(TAG, "observePartner error: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null && snapshot.exists()) {
                        val profile = snapshot.toObject(UserProfile::class.java)
                        trySend(profile)
                    } else {
                        trySend(null)
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "observePartner exception: ${e.message}")
            trySend(null)
        }

        awaitClose {
            registration?.remove()
        }
    }

    fun observeCouple(coupleId: String): Flow<Couple?> = callbackFlow {
        if (coupleId.isBlank()) {
            trySend(null)
            close()
            return@callbackFlow
        }

        var registration: ListenerRegistration? = null
        try {
            registration = db.collection("couples").document(coupleId)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.e(TAG, "observeCouple error: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null && snapshot.exists()) {
                        val couple = snapshot.toObject(Couple::class.java)
                        trySend(couple)
                    } else {
                        trySend(null)
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "observeCouple exception: ${e.message}")
            trySend(null)
        }

        awaitClose {
            registration?.remove()
        }
    }

    suspend fun updateProfile(name: String, photoBase64: String): Result<Unit> {
        val uid = currentUserId ?: return Result.failure(Exception("Not logged in"))
        return try {
            val updates = mutableMapOf<String, Any>("displayName" to name.trim())
            if (photoBase64.isNotBlank()) {
                updates["photoBase64"] = photoBase64
            }
            db.collection("users").document(uid).update(updates).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "updateProfile error: ${e.message}")
            Result.failure(e)
        }
    }

    suspend fun updateDailyFeeling(status: String, emoji: String): Result<Unit> {
        val uid = currentUserId ?: return Result.failure(Exception("Not logged in"))
        return try {
            val updates = mapOf<String, Any>(
                "feelingStatus" to status,
                "feelingEmoji" to emoji,
                "feelingUpdatedAt" to System.currentTimeMillis()
            )
            db.collection("users").document(uid).update(updates).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "updateDailyFeeling error: ${e.message}")
            Result.failure(e)
        }
    }

    suspend fun pairWithPartner(partnerCode: String): Result<Couple> {
        val currentUid = currentUserId ?: return Result.failure(Exception("Not logged in"))
        val trimmedCode = partnerCode.trim().uppercase()

        return try {
            // Find partner by pairingCode
            val querySnapshot = db.collection("users")
                .whereEqualTo("pairingCode", trimmedCode)
                .get()
                .await()

            if (querySnapshot.isEmpty) {
                return Result.failure(Exception("كود الشريك غير صحيح أو غير موجود"))
            }

            val partnerDoc = querySnapshot.documents[0]
            val partner = partnerDoc.toObject(UserProfile::class.java)
                ?: return Result.failure(Exception("تعذر قراءة بيانات الشريك"))

            if (partner.uid == currentUid) {
                return Result.failure(Exception("لا يمكنك ربط الحساب مع نفسك"))
            }

            // Get current user profile
            val currentUserDoc = db.collection("users").document(currentUid).get().await()
            val currentUserProfile = currentUserDoc.toObject(UserProfile::class.java)
                ?: return Result.failure(Exception("تعذر قراءة بيانات حسابك"))

            val coupleId = UUID.randomUUID().toString()
            val couple = Couple(
                id = coupleId,
                user1Id = currentUid,
                user2Id = partner.uid,
                user1Name = currentUserProfile.displayName,
                user2Name = partner.displayName,
                anniversaryDate = "",
                createdAt = System.currentTimeMillis()
            )

            // Save couple document
            db.collection("couples").document(coupleId).set(couple).await()

            // Update coupleId for both users
            db.collection("users").document(currentUid).update("coupleId", coupleId).await()
            db.collection("users").document(partner.uid).update("coupleId", coupleId).await()

            Result.success(couple)
        } catch (e: Exception) {
            Log.e(TAG, "pairWithPartner error: ${e.message}")
            Result.failure(e)
        }
    }

    // --- Real-time Chat ---

    suspend fun sendMessage(coupleId: String, text: String, photoBase64: String = "", senderName: String): Result<String> {
        val uid = currentUserId ?: return Result.failure(Exception("Not logged in"))
        if (text.isBlank() && photoBase64.isBlank()) {
            return Result.failure(Exception("الرسالة فارغة"))
        }

        return try {
            val messageId = UUID.randomUUID().toString()
            val message = ChatMessage(
                id = messageId,
                coupleId = coupleId,
                senderId = uid,
                senderName = senderName,
                text = text.trim(),
                photoBase64 = photoBase64,
                timestamp = System.currentTimeMillis(),
                isDeleted = false
            )

            db.collection("couples").document(coupleId)
                .collection("messages").document(messageId)
                .set(message).await()

            // Update last message in couple document
            val snippet = if (text.isNotBlank()) text.trim() else "📷 صورة"
            db.collection("couples").document(coupleId).update(
                mapOf(
                    "lastMessageText" to snippet,
                    "lastMessageSenderId" to uid,
                    "lastMessageTimestamp" to System.currentTimeMillis()
                )
            )

            Result.success(messageId)
        } catch (e: Exception) {
            Log.e(TAG, "sendMessage error: ${e.message}")
            Result.failure(e)
        }
    }

    fun observeMessages(coupleId: String): Flow<List<ChatMessage>> = callbackFlow {
        if (coupleId.isBlank()) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        var registration: ListenerRegistration? = null
        try {
            registration = db.collection("couples").document(coupleId)
                .collection("messages")
                .orderBy("timestamp", Query.Direction.ASCENDING)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.e(TAG, "observeMessages error: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null) {
                        // Deduplicate messages by ID to prevent duplicate rendering
                        val messageMap = LinkedHashMap<String, ChatMessage>()
                        for (doc in snapshot.documents) {
                            val msg = doc.toObject(ChatMessage::class.java)
                            if (msg != null && !msg.isDeleted) {
                                messageMap[msg.id] = msg
                            }
                        }
                        trySend(messageMap.values.toList())
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "observeMessages exception: ${e.message}")
            trySend(emptyList())
        }

        awaitClose {
            registration?.remove()
        }
    }

    suspend fun deleteMessageForBoth(coupleId: String, messageId: String): Result<Unit> {
        return try {
            // Delete document permanently so it syncs deletion to both partners in real-time
            db.collection("couples").document(coupleId)
                .collection("messages").document(messageId)
                .delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "deleteMessageForBoth error: ${e.message}")
            Result.failure(e)
        }
    }

    // --- Memories ---

    suspend fun addMemory(
        coupleId: String,
        title: String,
        description: String,
        photoBase64: String,
        creatorName: String
    ): Result<String> {
        val uid = currentUserId ?: return Result.failure(Exception("Not logged in"))
        return try {
            val memoryId = UUID.randomUUID().toString()
            val memory = Memory(
                id = memoryId,
                coupleId = coupleId,
                creatorId = uid,
                creatorName = creatorName,
                title = title.trim(),
                description = description.trim(),
                photoBase64 = photoBase64,
                date = SimpleDateUtils.currentFormattedDate(),
                timestamp = System.currentTimeMillis()
            )

            db.collection("couples").document(coupleId)
                .collection("memories").document(memoryId)
                .set(memory).await()

            Result.success(memoryId)
        } catch (e: Exception) {
            Log.e(TAG, "addMemory error: ${e.message}")
            Result.failure(e)
        }
    }

    fun observeMemories(coupleId: String): Flow<List<Memory>> = callbackFlow {
        if (coupleId.isBlank()) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        var registration: ListenerRegistration? = null
        try {
            registration = db.collection("couples").document(coupleId)
                .collection("memories")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.e(TAG, "observeMemories error: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null) {
                        val memoryMap = LinkedHashMap<String, Memory>()
                        for (doc in snapshot.documents) {
                            val mem = doc.toObject(Memory::class.java)
                            if (mem != null) {
                                memoryMap[mem.id] = mem
                            }
                        }
                        trySend(memoryMap.values.toList())
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "observeMemories exception: ${e.message}")
            trySend(emptyList())
        }

        awaitClose {
            registration?.remove()
        }
    }

    suspend fun deleteMemoryForBoth(coupleId: String, memoryId: String): Result<Unit> {
        return try {
            db.collection("couples").document(coupleId)
                .collection("memories").document(memoryId)
                .delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "deleteMemoryForBoth error: ${e.message}")
            Result.failure(e)
        }
    }

    // --- Simple Goals ---

    suspend fun addGoal(coupleId: String, title: String, description: String, creatorName: String): Result<String> {
        val uid = currentUserId ?: return Result.failure(Exception("Not logged in"))
        if (title.isBlank()) {
            return Result.failure(Exception("عنوان الهدف مطلوب"))
        }

        return try {
            val goalId = UUID.randomUUID().toString()
            val goal = Goal(
                id = goalId,
                coupleId = coupleId,
                creatorId = uid,
                creatorName = creatorName,
                title = title.trim(),
                description = description.trim(),
                isCompleted = false,
                timestamp = System.currentTimeMillis()
            )

            db.collection("couples").document(coupleId)
                .collection("goals").document(goalId)
                .set(goal).await()

            Result.success(goalId)
        } catch (e: Exception) {
            Log.e(TAG, "addGoal error: ${e.message}")
            Result.failure(e)
        }
    }

    fun observeGoals(coupleId: String): Flow<List<Goal>> = callbackFlow {
        if (coupleId.isBlank()) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        var registration: ListenerRegistration? = null
        try {
            registration = db.collection("couples").document(coupleId)
                .collection("goals")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.e(TAG, "observeGoals error: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null) {
                        val goalsList = snapshot.documents.mapNotNull { it.toObject(Goal::class.java) }
                        trySend(goalsList)
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "observeGoals exception: ${e.message}")
            trySend(emptyList())
        }

        awaitClose {
            registration?.remove()
        }
    }

    suspend fun toggleGoalCompleted(coupleId: String, goalId: String, currentStatus: Boolean): Result<Unit> {
        return try {
            db.collection("couples").document(coupleId)
                .collection("goals").document(goalId)
                .update("isCompleted", !currentStatus).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "toggleGoalCompleted error: ${e.message}")
            Result.failure(e)
        }
    }

    suspend fun deleteGoalForBoth(coupleId: String, goalId: String): Result<Unit> {
        return try {
            db.collection("couples").document(coupleId)
                .collection("goals").document(goalId)
                .delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "deleteGoalForBoth error: ${e.message}")
            Result.failure(e)
        }
    }
}

object SimpleDateUtils {
    fun currentFormattedDate(): String {
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
        return sdf.format(java.util.Date())
    }

    fun formatTime(timestamp: Long): String {
        val sdf = java.text.SimpleDateFormat("hh:mm a", java.util.Locale.getDefault())
        return sdf.format(java.util.Date(timestamp))
    }
}
