package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp

@Keep
data class UserProfile(
    val uid: String = "",
    val email: String = "",
    val displayName: String = "",
    val photoBase64: String = "",
    val coupleId: String = "",
    val pairingCode: String = "",
    val feelingStatus: String = "",
    val feelingEmoji: String = "",
    val feelingUpdatedAt: Long = 0L,
    val fcmToken: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Keep
data class Couple(
    val id: String = "",
    val user1Id: String = "",
    val user2Id: String = "",
    val user1Name: String = "",
    val user2Name: String = "",
    val anniversaryDate: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val lastMessageText: String = "",
    val lastMessageSenderId: String = "",
    val lastMessageTimestamp: Long = 0L
)

@Keep
data class ChatMessage(
    val id: String = "",
    val coupleId: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val text: String = "",
    val photoBase64: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val isDeleted: Boolean = false
)

@Keep
data class Memory(
    val id: String = "",
    val coupleId: String = "",
    val creatorId: String = "",
    val creatorName: String = "",
    val title: String = "",
    val description: String = "",
    val photoBase64: String = "",
    val date: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Keep
data class Goal(
    val id: String = "",
    val coupleId: String = "",
    val creatorId: String = "",
    val creatorName: String = "",
    val title: String = "",
    val description: String = "",
    val isCompleted: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

data class DailyFeelingOption(
    val id: String,
    val emoji: String,
    val labelAr: String,
    val labelEn: String
)

object FeelingOptions {
    val list = listOf(
        DailyFeelingOption("happy", "😊", "فرحان", "Happy"),
        DailyFeelingOption("joyful", "🥰", "مبسوط", "Joyful"),
        DailyFeelingOption("chill", "😎", "رايق", "Chill / Relaxed"),
        DailyFeelingOption("excited", "🔥", "متحمس", "Excited"),
        DailyFeelingOption("loving", "❤️", "في قمة الحب", "In Love"),
        DailyFeelingOption("missing", "🥺", "مشتاق", "Missing You"),
        DailyFeelingOption("tired", "😴", "تعبان", "Tired"),
        DailyFeelingOption("upset", "😔", "زعلان", "Upset"),
        DailyFeelingOption("stressed", "🤯", "متوتر", "Stressed"),
        DailyFeelingOption("calm", "☕", "هادي", "Peaceful / Calm"),
        DailyFeelingOption("hug", "🤗", "محتاج حضن", "Need a Hug"),
        DailyFeelingOption("busy", "💼", "مشغول شوية", "A bit busy")
    )
}
