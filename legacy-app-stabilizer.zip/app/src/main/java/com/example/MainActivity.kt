package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.ui.locale.ProvideAppLocale
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.MainContainerScreen
import com.example.ui.screens.PairingScreen
import com.example.ui.screens.WelcomeScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.CoupleViewModel
import com.google.firebase.auth.FirebaseAuth

class MainActivity : ComponentActivity() {

    private val viewModel: CoupleViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                ProvideAppLocale {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        AppNavigationGate(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

enum class AppScreenState {
    WELCOME, AUTH, PAIRING, MAIN
}

@Composable
fun AppNavigationGate(viewModel: CoupleViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()
    val isAuthUser = remember { mutableStateOf(FirebaseAuth.getInstance().currentUser != null) }

    var screenState by remember {
        mutableStateOf(
            if (isAuthUser.value) {
                if (!currentUser?.coupleId.isNullOrBlank()) AppScreenState.MAIN else AppScreenState.PAIRING
            } else {
                AppScreenState.WELCOME
            }
        )
    }

    LaunchedEffect(currentUser) {
        val authUser = FirebaseAuth.getInstance().currentUser
        if (authUser == null) {
            if (screenState != AppScreenState.WELCOME && screenState != AppScreenState.AUTH) {
                screenState = AppScreenState.WELCOME
            }
        } else {
            if (currentUser != null) {
                if (!currentUser?.coupleId.isNullOrBlank()) {
                    screenState = AppScreenState.MAIN
                } else {
                    screenState = AppScreenState.PAIRING
                }
            }
        }
    }

    when (screenState) {
        AppScreenState.WELCOME -> {
            WelcomeScreen(
                onStartClick = { screenState = AppScreenState.AUTH }
            )
        }
        AppScreenState.AUTH -> {
            AuthScreen(
                viewModel = viewModel,
                onAuthSuccess = {
                    viewModel.checkAuthAndObserve()
                }
            )
        }
        AppScreenState.PAIRING -> {
            PairingScreen(
                viewModel = viewModel,
                onPairedSuccess = {
                    screenState = AppScreenState.MAIN
                },
                onSignOut = {
                    screenState = AppScreenState.WELCOME
                }
            )
        }
        AppScreenState.MAIN -> {
            MainContainerScreen(
                viewModel = viewModel,
                onSignOut = {
                    screenState = AppScreenState.WELCOME
                }
            )
        }
    }
}
