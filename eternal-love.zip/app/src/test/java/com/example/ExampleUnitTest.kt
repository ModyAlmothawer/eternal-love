package com.example

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun invitationCode_isValidFormat() {
        val testCode = "427339"
        assertEquals(6, testCode.length)
        assertTrue(testCode.all { it.isDigit() })
    }

    @Test
    fun invitationCode_selfJoinValidation() {
        val userAUid = "user_a_12345"
        val creatorUid = "user_a_12345"
        val userBUid = "user_b_67890"

        val cannotJoinOwn = (creatorUid == userAUid)
        val canJoinOther = (creatorUid != userBUid)

        assertTrue("User A should not be able to join own relationship", cannotJoinOwn)
        assertTrue("User B should be able to join User A relationship", canJoinOther)
    }
}
