package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.GoalEntity
import com.example.data.model.LoveLetterEntity
import com.example.data.model.MemoryEntity
import com.example.data.model.NoteEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.RelationshipEntity
import com.example.data.model.SpecialDateEntity
import com.example.data.model.UserEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface LoveDao {
    // User operations
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity): Long

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    fun getUserByIdFlow(id: Long): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    suspend fun getUserById(id: Long): UserEntity?

    // Relationship operations
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRelationship(relationship: RelationshipEntity): Long

    @Update
    suspend fun updateRelationship(relationship: RelationshipEntity)

    @Query("SELECT * FROM relationships WHERE code = :code LIMIT 1")
    suspend fun getRelationshipByCode(code: String): RelationshipEntity?

    @Query("SELECT * FROM relationships WHERE id = :id LIMIT 1")
    fun getRelationshipFlow(id: Long): Flow<RelationshipEntity?>

    @Query("SELECT * FROM relationships WHERE id = :id LIMIT 1")
    suspend fun getRelationshipById(id: Long): RelationshipEntity?

    @Query("DELETE FROM relationships WHERE id = :id")
    suspend fun deleteRelationshipById(id: Long)

    // Memories
    @Query("SELECT * FROM memories WHERE relationshipId = :relationshipId ORDER BY dateMillis DESC")
    fun getMemoriesFlow(relationshipId: Long): Flow<List<MemoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(memory: MemoryEntity): Long

    @Update
    suspend fun updateMemory(memory: MemoryEntity)

    @Query("DELETE FROM memories WHERE id = :id")
    suspend fun deleteMemory(id: Long)

    // Love Letters
    @Query("SELECT * FROM love_letters WHERE relationshipId = :relationshipId ORDER BY dateMillis DESC")
    fun getLoveLettersFlow(relationshipId: Long): Flow<List<LoveLetterEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLoveLetter(letter: LoveLetterEntity): Long

    @Query("UPDATE love_letters SET isRead = 1 WHERE id = :id")
    suspend fun markLoveLetterAsRead(id: Long)

    @Query("DELETE FROM love_letters WHERE id = :id")
    suspend fun deleteLoveLetter(id: Long)

    // Notes
    @Query("SELECT * FROM notes WHERE relationshipId = :relationshipId ORDER BY updatedAtMillis DESC")
    fun getNotesFlow(relationshipId: Long): Flow<List<NoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: NoteEntity): Long

    @Update
    suspend fun updateNote(note: NoteEntity)

    @Query("DELETE FROM notes WHERE id = :id")
    suspend fun deleteNote(id: Long)

    // Goals
    @Query("SELECT * FROM goals WHERE relationshipId = :relationshipId ORDER BY id ASC")
    fun getGoalsFlow(relationshipId: Long): Flow<List<GoalEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoal(goal: GoalEntity): Long

    @Update
    suspend fun updateGoal(goal: GoalEntity)

    @Query("DELETE FROM goals WHERE id = :id")
    suspend fun deleteGoal(id: Long)

    // Special Dates
    @Query("SELECT * FROM special_dates WHERE relationshipId = :relationshipId ORDER BY dateMillis ASC")
    fun getSpecialDatesFlow(relationshipId: Long): Flow<List<SpecialDateEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSpecialDate(date: SpecialDateEntity): Long

    @Query("DELETE FROM special_dates WHERE id = :id")
    suspend fun deleteSpecialDate(id: Long)

    // Notifications
    @Query("SELECT * FROM notifications WHERE relationshipId = :relationshipId ORDER BY timestampMillis DESC")
    fun getNotificationsFlow(relationshipId: Long): Flow<List<NotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity): Long

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :id")
    suspend fun markNotificationAsRead(id: Long)
}
