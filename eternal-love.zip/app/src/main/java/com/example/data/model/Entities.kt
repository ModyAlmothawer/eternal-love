package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val email: String,
    val passwordHash: String,
    val avatarRes: String = "avatar_1",
    val partnerName: String = "",
    val relationshipCode: String = "",
    val connectedRelationshipId: Long? = null,
    val isConnected: Boolean = false,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "relationships")
data class RelationshipEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val code: String, // 6-digit code e.g. "483921"
    val creatorId: Long,
    val creatorName: String,
    val partnerId: Long? = null,
    val partnerName: String = "",
    val startDateMillis: Long = System.currentTimeMillis() - (1000L * 60 * 60 * 24 * 365 * 2 + 1000L * 60 * 60 * 24 * 135), // default 2+ years for vivid counter demo
    val relationshipName: String = "Our Eternal Love",
    val status: String = "connected", // "pending", "connected", "disconnected"
    val coverImageRes: String = "default_cover",
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val relationshipId: Long,
    val title: String,
    val description: String,
    val dateMillis: Long,
    val imageDrawableName: String = "img_memory_default",
    val location: String = "Our Favorite Place",
    val createdByName: String = "",
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "love_letters")
data class LoveLetterEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val relationshipId: Long,
    val senderName: String,
    val title: String,
    val message: String,
    val dateMillis: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val themeColorIndex: Int = 0
)

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val relationshipId: Long,
    val title: String,
    val content: String,
    val category: String = "General", // "Things to do", "Places to visit", "Ideas", "Love Notes"
    val authorName: String = "",
    val updatedAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "goals")
data class GoalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val relationshipId: Long,
    val title: String,
    val description: String,
    val progress: Int = 0, // 0 to 100
    val isCompleted: Boolean = false,
    val targetDate: String = "2026",
    val category: String = "Life & Romance"
)

@Entity(tableName = "special_dates")
data class SpecialDateEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val relationshipId: Long,
    val title: String,
    val dateMillis: Long,
    val type: String = "Anniversary", // "Anniversary", "Birthday", "First Date", "First Meeting", "Special Trip"
    val iconName: String = "favorite"
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val relationshipId: Long,
    val title: String,
    val message: String,
    val timestampMillis: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val iconType: String = "love"
)
