package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val firebaseUid: String = "",
    val name: String,
    val email: String,
    val passwordHash: String = "",
    val avatarRes: String = "avatar_1",
    val photoUrl: String = "",
    val partnerName: String = "",
    val partnerUid: String = "",
    val partnerPhotoUrl: String = "",
    val relationshipCode: String = "",
    val connectedRelationshipId: String? = null,
    val localRelationshipId: Long? = null,
    val isConnected: Boolean = false,
    val dailyStatus: String = "",
    val dailyStatusEmoji: String = "",
    val statusUpdatedAtMillis: Long = 0L,
    val partnerDailyStatus: String = "",
    val partnerDailyStatusEmoji: String = "",
    val partnerStatusUpdatedAtMillis: Long = 0L,
    val createdAtMillis: Long = System.currentTimeMillis()
) {
    val dailyEmoji: String get() = dailyStatusEmoji
    val partnerDailyEmoji: String get() = partnerDailyStatusEmoji
}

@Entity(tableName = "relationships")
data class RelationshipEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val firestoreId: String = "",
    val code: String, // 6-digit unique code e.g. "483921"
    val creatorId: String = "",
    val creatorName: String = "",
    val creatorPhoto: String = "",
    val creatorStatus: String = "",
    val creatorStatusEmoji: String = "",
    val partnerId: String? = null,
    val partnerName: String = "",
    val partnerPhoto: String = "",
    val partnerStatus: String = "",
    val partnerStatusEmoji: String = "",
    val startDateMillis: Long = System.currentTimeMillis(),
    val relationshipName: String = "Our Story",
    val status: String = "connected", // "pending", "connected", "disconnected"
    val coverImageRes: String = "default_cover",
    val createdAtMillis: Long = System.currentTimeMillis()
) {
    val invitationCode: String get() = code
}

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey val firestoreId: String = "",
    val id: Long = 0,
    val relationshipId: String = "",
    val title: String,
    val description: String,
    val dateMillis: Long,
    val imageDrawableName: String = "",
    val imageUrl: String = "",
    val location: String = "",
    val createdByName: String = "",
    val createdByUid: String = "",
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "love_letters")
data class LoveLetterEntity(
    @PrimaryKey val firestoreId: String = "",
    val id: Long = 0,
    val relationshipId: String = "",
    val senderUid: String = "",
    val senderName: String,
    val title: String,
    val message: String,
    val dateMillis: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val themeColorIndex: Int = 0
)

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey val firestoreId: String = "",
    val id: Long = 0,
    val relationshipId: String = "",
    val title: String,
    val content: String,
    val category: String = "General",
    val authorName: String = "",
    val authorUid: String = "",
    val updatedAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "goals")
data class GoalEntity(
    @PrimaryKey val firestoreId: String = "",
    val id: Long = 0,
    val relationshipId: String = "",
    val title: String,
    val description: String,
    val progress: Int = 0, // 0 to 100
    val isCompleted: Boolean = false,
    val targetDate: String = "2026",
    val category: String = "Life & Romance"
)

@Entity(tableName = "special_dates")
data class SpecialDateEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val firestoreId: String = "",
    val relationshipId: String = "",
    val title: String,
    val dateMillis: Long,
    val type: String = "Anniversary",
    val iconName: String = "favorite"
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val firestoreId: String = "",
    val relationshipId: String = "",
    val title: String,
    val message: String,
    val timestampMillis: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val iconType: String = "love"
)

data class AchievementItem(
    val id: String,
    val titleRes: Int,
    val descRes: Int,
    val isUnlocked: Boolean,
    val progressPercent: Float,
    val icon: String,
    val unlockedDate: String? = null
)

data class DailyMoodOption(
    val id: String,
    val emoji: String,
    val titleAr: String,
    val titleEn: String
)
