package com.example.data.remote

import android.util.Log
import com.example.data.local.LoveDatabase
import com.example.util.NotificationHelper
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class LoveFirebaseMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d("LoveFCM", "New FCM token received: $token")
        
        val context = applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = LoveDatabase.getDatabase(context)
                val user = db.loveDao().getFirstUser()
                if (user != null && user.firebaseUid.isNotBlank()) {
                    FirebaseLoveService().updateFcmToken(user.firebaseUid, token)
                }
            } catch (e: Exception) {
                Log.w("LoveFCM", "Failed to update new FCM token: ${e.message}")
            }
        }
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.d("LoveFCM", "FCM message received from: ${remoteMessage.from}")

        val data = remoteMessage.data
        val notificationType = data["type"] ?: "chat"
        val senderUid = data["senderUid"] ?: ""
        val uniqueId = data["id"] ?: data["messageId"] ?: data["goalId"] ?: "${System.currentTimeMillis()}"

        // Filter out notifications triggered by the user themselves
        val db = LoveDatabase.getDatabase(applicationContext)
        CoroutineScope(Dispatchers.IO).launch {
            val currentUser = db.loveDao().getFirstUser()
            if (currentUser != null && senderUid.isNotBlank() && currentUser.firebaseUid == senderUid) {
                Log.d("LoveFCM", "Ignored notification because sender is current user")
                return@launch
            }

            val title = remoteMessage.notification?.title
                ?: data["title"]
                ?: when (notificationType) {
                    "chat" -> "رسالة جديدة 💌"
                    "status" -> "تحديث حالة الشريك ✨"
                    "goal" -> "هدف جديد 🎯"
                    else -> "إشعار جديد من حكايتنا ❤️"
                }

            val body = remoteMessage.notification?.body
                ?: data["body"]
                ?: data["message"]
                ?: ""

            if (body.isNotBlank()) {
                val channelId = if (notificationType == "chat") {
                    NotificationHelper.CHANNEL_ID_CHAT
                } else {
                    NotificationHelper.CHANNEL_ID_UPDATES
                }
                val notificationId = when (notificationType) {
                    "chat" -> 1001
                    "status" -> 1002
                    "goal" -> 1003
                    else -> 1004
                }

                NotificationHelper.showNotification(
                    context = applicationContext,
                    channelId = channelId,
                    notificationId = notificationId,
                    uniqueEventKey = "${notificationType}_${uniqueId}",
                    title = title,
                    body = body
                )
            }
        }
    }
}
