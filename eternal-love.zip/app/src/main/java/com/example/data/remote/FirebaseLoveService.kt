package com.example.data.remote

import android.net.Uri
import android.util.Log
import com.example.data.model.GoalEntity
import com.example.data.model.LoveLetterEntity
import com.example.data.model.MemoryEntity
import com.example.data.model.NoteEntity
import com.example.data.model.RelationshipEntity
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import java.util.UUID

class FirebaseLoveService {
    companion object {
        const val AUTH_TIMEOUT_MILLIS = 15_000L
        const val FIRESTORE_TIMEOUT_MILLIS = 12_000L

        fun mapFirebaseException(e: Throwable, language: String = "ar"): String {
            return when (e) {
                is FirebaseAuthUserCollisionException -> {
                    if (language == "ar") "البريد ده مسجل قبل كده، ادخل بحسابك أو استخدم بريد تاني."
                    else "This email address is already registered. Please log in or use another email."
                }
                is FirebaseAuthWeakPasswordException -> {
                    if (language == "ar") "كلمة السر ضعيفة، لازم تكون 6 حروف أو أكتر."
                    else "Password is too weak. Please use at least 6 characters."
                }
                is FirebaseAuthInvalidCredentialsException -> {
                    if (language == "ar") "البريد أو كلمة السر مش صح، اتأكد وجرّب تاني."
                    else "The email address or password entered is incorrect."
                }
                is FirebaseAuthInvalidUserException -> {
                    if (language == "ar") "الحساب ده مش موجود أو تم تعطيله."
                    else "This account does not exist or has been disabled."
                }
                is FirebaseNetworkException -> {
                    if (language == "ar") "حصلت مشكلة في الاتصال بالإنترنت، اتأكد من الشبكة وجرّب تاني."
                    else "Network connection issue. Please check your connection and try again."
                }
                is FirebaseTooManyRequestsException -> {
                    if (language == "ar") "محاولات كتير ورا بعض، استنى دقيقة وجرّب تاني."
                    else "Too many requests. Please wait a moment and try again."
                }
                is TimeoutCancellationException -> {
                    if (language == "ar") "العملية أخدت وقت طويل، اتأكد من الإنترنت وجرّب تاني."
                    else "The operation timed out. Please check your internet connection."
                }
                is FirebaseFirestoreException -> {
                    if (e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED) {
                        if (language == "ar") "ما فيش صلاحية للوصول للبيانات دي."
                        else "Permission denied on cloud database."
                    } else if (e.code == FirebaseFirestoreException.Code.UNAVAILABLE) {
                        if (language == "ar") "السيرفر مش متاح حالياً، جرّب كمان شوية."
                        else "Cloud service is currently unavailable. Please try again shortly."
                    } else {
                        val msg = e.localizedMessage ?: ""
                        if (language == "ar") {
                            if (msg.contains("permission", ignoreCase = true)) "ما فيش صلاحية للوصول للبيانات."
                            else "حصلت مشكلة في قاعدة البيانات، جرّب تاني."
                        } else {
                            msg.ifBlank { "Cloud database error" }
                        }
                    }
                }
                else -> {
                    val msg = e.localizedMessage ?: e.message ?: ""
                    if (msg.contains("API key not valid", ignoreCase = true)) {
                        if (language == "ar") "مفتاح Firebase API غير صالح. يرجى تزويد ملف الإعدادات الرسمي من Firebase Console."
                        else "Firebase API key is invalid. Please check your Firebase configuration."
                    } else if (msg.contains("The email address is already in use", ignoreCase = true)) {
                        if (language == "ar") "البريد ده مسجل قبل كده، ادخل بحسابك أو استخدم بريد تاني."
                        else "This email address is already in use by another account."
                    } else if (msg.contains("Password should be at least", ignoreCase = true)) {
                        if (language == "ar") "كلمة السر لازم تكون 6 حروف أو أكتر."
                        else "Password should be at least 6 characters."
                    } else if (msg.contains("network error", ignoreCase = true) || msg.contains("timeout", ignoreCase = true)) {
                        if (language == "ar") "حصلت مشكلة في الاتصال بالإنترنت، اتأكد من الشبكة وجرّب تاني."
                        else "Network error. Please check your internet connection."
                    } else {
                        msg.ifBlank { if (language == "ar") "حصلت مشكلة، جرّب تاني." else "An unexpected error occurred. Please try again." }
                    }
                }
            }
        }
    }

    private val auth: FirebaseAuth
        get() = try {
            FirebaseAuth.getInstance()
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "FirebaseAuth instance error: ${e.message}")
            FirebaseAuth.getInstance()
        }

    private val firestore: FirebaseFirestore
        get() = try {
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "FirebaseFirestore instance error: ${e.message}")
            FirebaseFirestore.getInstance()
        }

    private val storage: FirebaseStorage
        get() = try {
            FirebaseStorage.getInstance()
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "FirebaseStorage instance error: ${e.message}")
            FirebaseStorage.getInstance()
        }

    private var relationshipListener: ListenerRegistration? = null
    private var partnerProfileListener: ListenerRegistration? = null
    private var currentListeningPartnerUid: String? = null
    private var messagesListener: ListenerRegistration? = null
    private var memoriesListener: ListenerRegistration? = null
    private var goalsListener: ListenerRegistration? = null
    private var notesListener: ListenerRegistration? = null

    val currentFirebaseUser: FirebaseUser?
        get() = try {
            auth.currentUser
        } catch (e: Exception) {
            null
        }

    suspend fun registerWithFirebase(email: String, pass: String): Result<String> {
        return try {
            withTimeout(AUTH_TIMEOUT_MILLIS) {
                val authResult = auth.createUserWithEmailAndPassword(email.trim(), pass).await()
                val uid = authResult.user?.uid
                if (!uid.isNullOrBlank()) {
                    Result.success(uid)
                } else {
                    Result.failure(Exception("Could not retrieve user ID from Firebase Authentication"))
                }
            }
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "FirebaseAuth register error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun loginWithFirebase(email: String, pass: String): Result<String> {
        return try {
            withTimeout(AUTH_TIMEOUT_MILLIS) {
                val authResult = auth.signInWithEmailAndPassword(email.trim(), pass).await()
                val uid = authResult.user?.uid
                if (!uid.isNullOrBlank()) {
                    Result.success(uid)
                } else {
                    Result.failure(Exception("Could not retrieve user ID from Firebase Authentication"))
                }
            }
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "FirebaseAuth login error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun sendPasswordResetEmail(email: String): Result<Unit> {
        return try {
            withTimeout(AUTH_TIMEOUT_MILLIS) {
                auth.sendPasswordResetEmail(email.trim()).await()
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "sendPasswordResetEmail error: ${e.message}", e)
            Result.failure(e)
        }
    }

    fun signOut() {
        try {
            stopAllListeners()
            auth.signOut()
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "SignOut error: ${e.message}")
        }
    }

    // --- User Profile Cloud Sync ---
    suspend fun syncUserProfileOnline(
        uid: String,
        name: String,
        email: String,
        avatarRes: String = "avatar_1",
        photoUrl: String = "",
        relationshipId: String? = null
    ): Result<Unit> {
        if (uid.isBlank()) return Result.failure(Exception("UID is empty"))
        return try {
            withTimeout(FIRESTORE_TIMEOUT_MILLIS) {
                val data = mutableMapOf<String, Any>(
                    "uid" to uid,
                    "displayName" to name,
                    "name" to name,
                    "email" to email,
                    "avatarRes" to avatarRes,
                    "photoUrl" to photoUrl,
                    "updatedAtMillis" to System.currentTimeMillis()
                )
                if (relationshipId != null) {
                    data["relationshipId"] = relationshipId
                }
                firestore.collection("users").document(uid)
                    .set(data, SetOptions.merge())
                    .await()
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error syncing user profile online: ${e.message}")
            Result.failure(e)
        }
    }

    suspend fun fetchUserProfileOnline(uid: String): Map<String, Any?>? {
        if (uid.isBlank()) return null
        return try {
            withTimeout(FIRESTORE_TIMEOUT_MILLIS) {
                val doc = firestore.collection("users").document(uid).get().await()
                if (doc.exists()) doc.data else null
            }
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error fetching user profile: ${e.message}")
            null
        }
    }

    suspend fun uploadProfileImage(uid: String, imageUri: Uri): String? {
        if (uid.isBlank()) return null
        return try {
            withTimeout(20_000L) {
                val ref = storage.reference.child("users/$uid/profile/avatar_${System.currentTimeMillis()}.jpg")
                ref.putFile(imageUri).await()
                val downloadUrl = ref.downloadUrl.await().toString()
                val updates = mapOf<String, Any>(
                    "photoUrl" to downloadUrl,
                    "updatedAtMillis" to System.currentTimeMillis()
                )
                firestore.collection("users").document(uid)
                    .set(updates, SetOptions.merge())
                    .await()
                downloadUrl
            }
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "Error uploading profile image: ${e.message}")
            null
        }
    }

    // --- Relationship Creation & Connection using invites/{code} ---

    suspend fun createFirestoreRelationship(
        creatorUid: String,
        creatorName: String,
        creatorPhoto: String,
        startDateMillis: Long,
        code: String
    ): String {
        val relId = UUID.randomUUID().toString().take(12)
        val relData = hashMapOf(
            "id" to relId,
            "code" to code.trim(),
            "creatorUid" to creatorUid,
            "creatorName" to creatorName,
            "creatorPhoto" to creatorPhoto,
            "partnerUid" to "",
            "partnerName" to "",
            "partnerPhoto" to "",
            "startDateMillis" to startDateMillis,
            "relationshipName" to "حكايتنا ❤️",
            "status" to "pending",
            "createdAtMillis" to System.currentTimeMillis(),
            "updatedAtMillis" to System.currentTimeMillis()
        )

        val inviteData = hashMapOf(
            "code" to code.trim(),
            "relationshipId" to relId,
            "creatorUid" to creatorUid,
            "creatorName" to creatorName,
            "status" to "pending",
            "createdAtMillis" to System.currentTimeMillis()
        )

        try {
            withTimeout(FIRESTORE_TIMEOUT_MILLIS) {
                // 1. Create document in relationships/{relId}
                firestore.collection("relationships").document(relId).set(relData).await()

                // 2. Create document in invites/{code} for direct lookup
                firestore.collection("invites").document(code.trim()).set(inviteData).await()

                // 3. Link user document
                if (creatorUid.isNotBlank()) {
                    firestore.collection("users").document(creatorUid)
                        .set(
                            mapOf(
                                "relationshipId" to relId,
                                "relationshipCode" to code.trim()
                            ),
                            SetOptions.merge()
                        )
                        .await()
                }
            }
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error creating relationship on Firestore: ${e.message}")
        }
        return relId
    }

    suspend fun joinFirestoreRelationship(
        code: String,
        partnerUid: String,
        partnerName: String,
        partnerPhoto: String = "",
        language: String = "ar"
    ): Pair<String, Map<String, Any?>> {
        val cleanCode = code.trim()
        return try {
            withTimeout(FIRESTORE_TIMEOUT_MILLIS) {
                // 1. Direct GET on invites/{code} (No whereEqualTo on relationships)
                val inviteDoc = firestore.collection("invites").document(cleanCode).get().await()

                if (!inviteDoc.exists()) {
                    val msg = if (language == "ar") "كود الدعوة مش صحيح أو مش موجود، اتأكد من الكود وجرّب تاني." else "The invite code is invalid or does not exist."
                    throw Exception(msg)
                }

                val relId = inviteDoc.getString("relationshipId") ?: ""
                val creatorUid = inviteDoc.getString("creatorUid") ?: ""

                // 2. Prevent user from joining their own relationship
                if (creatorUid == partnerUid && partnerUid.isNotBlank()) {
                    val msg = if (language == "ar") "ما ينفعش تنضم لنفس علاقتك! شارك الكود مع شريكك." else "You cannot join your own relationship! Share the code with your partner."
                    throw Exception(msg)
                }

                if (relId.isBlank()) {
                    val msg = if (language == "ar") "بيانات كود الدعوة غير مكتملة، جرّب تاني." else "Invalid invite code data."
                    throw Exception(msg)
                }

                // 3. Direct GET on relationships/{relId}
                val relDoc = firestore.collection("relationships").document(relId).get().await()
                if (!relDoc.exists()) {
                    val msg = if (language == "ar") "العلاقة مش موجودة أو تم حذفها." else "Relationship does not exist or was deleted."
                    throw Exception(msg)
                }

                // 4. Prevent a 3rd user from joining a full relationship
                val existingPartnerUid = relDoc.getString("partnerUid")
                if (!existingPartnerUid.isNullOrBlank() && existingPartnerUid != partnerUid) {
                    val msg = if (language == "ar") "العلاقة دي ممتلئة بالفعل بشريك تاني." else "This relationship already has a connected partner."
                    throw Exception(msg)
                }

                val creatorName = relDoc.getString("creatorName") ?: ""
                val creatorPhoto = relDoc.getString("creatorPhoto") ?: "avatar_1"

                // 5. Update relationships/{relId}
                val relUpdates = mapOf(
                    "partnerUid" to partnerUid,
                    "partnerName" to partnerName,
                    "partnerPhoto" to partnerPhoto.ifEmpty { "avatar_2" },
                    "status" to "connected",
                    "updatedAtMillis" to System.currentTimeMillis()
                )
                firestore.collection("relationships").document(relId).update(relUpdates).await()

                // 6. Update invites/{code}
                val inviteUpdates = mapOf(
                    "status" to "connected",
                    "partnerUid" to partnerUid,
                    "connectedAtMillis" to System.currentTimeMillis()
                )
                firestore.collection("invites").document(cleanCode).set(inviteUpdates, SetOptions.merge()).await()

                // 7. Update joining user document (users/{partnerUid})
                if (partnerUid.isNotBlank()) {
                    firestore.collection("users").document(partnerUid).set(
                        mapOf(
                            "relationshipId" to relId,
                            "partnerUid" to creatorUid,
                            "partnerName" to creatorName,
                            "relationshipCode" to cleanCode
                        ),
                        SetOptions.merge()
                    ).await()
                }

                // 8. Update creator user document (users/{creatorUid})
                if (creatorUid.isNotBlank()) {
                    firestore.collection("users").document(creatorUid).set(
                        mapOf(
                            "partnerUid" to partnerUid,
                            "partnerName" to partnerName
                        ),
                        SetOptions.merge()
                    ).await()
                }

                Pair(relId, relDoc.data ?: emptyMap())
            }
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "Error joining relationship with code $cleanCode: ${e.message}")
            throw e
        }
    }

    // --- Realtime Sync: Relationships, Messages, Memories, Goals, Notes ---
    fun startRealtimeListeners(
        relationshipId: String,
        currentUid: String = "",
        onRelationshipUpdate: (RelationshipEntity) -> Unit,
        onPartnerProfileUpdate: (name: String, photoUrl: String, avatarRes: String) -> Unit = { _, _, _ -> },
        onMessagesUpdate: (List<LoveLetterEntity>) -> Unit,
        onMemoriesUpdate: (List<MemoryEntity>) -> Unit,
        onGoalsUpdate: (List<GoalEntity>) -> Unit,
        onNotesUpdate: (List<NoteEntity>) -> Unit
    ) {
        stopAllListeners()

        try {
            // 1. Realtime Relationship Document Listener
            relationshipListener = firestore.collection("relationships")
                .document(relationshipId)
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null || !snapshot.exists()) {
                        return@addSnapshotListener
                    }
                    val creatorId = snapshot.getString("creatorUid") ?: ""
                    val partnerId = snapshot.getString("partnerUid") ?: ""
                    val creatorName = snapshot.getString("creatorName") ?: ""
                    val partnerName = snapshot.getString("partnerName") ?: ""
                    val creatorPhoto = snapshot.getString("creatorPhoto") ?: "avatar_1"
                    val partnerPhoto = snapshot.getString("partnerPhoto") ?: "avatar_2"

                    val entity = RelationshipEntity(
                        firestoreId = snapshot.id,
                        code = snapshot.getString("code") ?: "",
                        creatorId = creatorId,
                        creatorName = creatorName,
                        creatorPhoto = creatorPhoto,
                        partnerId = partnerId.takeIf { it.isNotBlank() },
                        partnerName = partnerName,
                        partnerPhoto = partnerPhoto,
                        startDateMillis = snapshot.getLong("startDateMillis") ?: System.currentTimeMillis(),
                        relationshipName = snapshot.getString("relationshipName") ?: "حكايتنا ❤️",
                        status = snapshot.getString("status") ?: "connected",
                        createdAtMillis = snapshot.getLong("createdAtMillis") ?: System.currentTimeMillis()
                    )
                    onRelationshipUpdate(entity)

                    // Listen to partner profile doc in real time to sync live name/avatar updates
                    val partnerUidToListen = if (currentUid.isNotBlank()) {
                        if (currentUid == creatorId) partnerId else creatorId
                    } else {
                        partnerId
                    }

                    if (partnerUidToListen.isNotBlank() && partnerUidToListen != currentListeningPartnerUid) {
                        partnerProfileListener?.remove()
                        currentListeningPartnerUid = partnerUidToListen
                        partnerProfileListener = firestore.collection("users")
                            .document(partnerUidToListen)
                            .addSnapshotListener { userDoc, userErr ->
                                if (userErr == null && userDoc != null && userDoc.exists()) {
                                    val name = userDoc.getString("displayName") ?: userDoc.getString("name") ?: ""
                                    val photo = userDoc.getString("photoUrl") ?: ""
                                    val avatar = userDoc.getString("avatarRes") ?: "avatar_2"
                                    if (name.isNotBlank() || photo.isNotBlank()) {
                                        onPartnerProfileUpdate(name, photo, avatar)
                                    }
                                }
                            }
                    }
                }

            // 2. Realtime Messages Listener (relationships/{relationshipId}/messages/{messageId})
            messagesListener = firestore.collection("relationships")
                .document(relationshipId)
                .collection("messages")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) {
                        // Fallback check on letters collection if needed
                        return@addSnapshotListener
                    }
                    val list = snapshot.documents.mapNotNull { doc ->
                        val senderId = doc.getString("senderId") ?: doc.getString("senderUid") ?: ""
                        val text = doc.getString("text") ?: doc.getString("message") ?: ""
                        val timestamp = doc.getLong("timestamp") ?: doc.getLong("dateMillis") ?: System.currentTimeMillis()
                        val messageId = doc.getString("messageId") ?: doc.id

                        LoveLetterEntity(
                            firestoreId = messageId,
                            relationshipId = relationshipId,
                            senderUid = senderId,
                            senderName = doc.getString("senderName") ?: "",
                            title = doc.getString("title") ?: "",
                            message = text,
                            dateMillis = timestamp,
                            isRead = doc.getBoolean("isRead") ?: false,
                            themeColorIndex = (doc.getLong("themeColorIndex") ?: 0L).toInt()
                        )
                    }
                    onMessagesUpdate(list)
                }

            // 3. Realtime Memories Listener
            memoriesListener = firestore.collection("relationships")
                .document(relationshipId)
                .collection("memories")
                .orderBy("dateMillis", Query.Direction.DESCENDING)
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) return@addSnapshotListener
                    val list = snapshot.documents.mapNotNull { doc ->
                        MemoryEntity(
                            firestoreId = doc.id,
                            relationshipId = relationshipId,
                            title = doc.getString("title") ?: "",
                            description = doc.getString("description") ?: "",
                            dateMillis = doc.getLong("dateMillis") ?: System.currentTimeMillis(),
                            imageUrl = doc.getString("imageUrl") ?: "",
                            imageDrawableName = doc.getString("imageDrawableName") ?: "img_memory_default",
                            location = doc.getString("location") ?: "",
                            createdByName = doc.getString("createdByName") ?: "",
                            createdByUid = doc.getString("createdByUid") ?: ""
                        )
                    }
                    onMemoriesUpdate(list)
                }

            // 4. Realtime Goals Listener
            goalsListener = firestore.collection("relationships")
                .document(relationshipId)
                .collection("goals")
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) return@addSnapshotListener
                    val list = snapshot.documents.mapNotNull { doc ->
                        GoalEntity(
                            firestoreId = doc.id,
                            relationshipId = relationshipId,
                            title = doc.getString("title") ?: "",
                            description = doc.getString("description") ?: "",
                            progress = (doc.getLong("progress") ?: 0L).toInt(),
                            isCompleted = doc.getBoolean("isCompleted") ?: false,
                            targetDate = doc.getString("targetDate") ?: "",
                            category = doc.getString("category") ?: "Life & Romance"
                        )
                    }
                    onGoalsUpdate(list)
                }

            // 5. Realtime Notes Listener
            notesListener = firestore.collection("relationships")
                .document(relationshipId)
                .collection("notes")
                .orderBy("updatedAtMillis", Query.Direction.DESCENDING)
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) return@addSnapshotListener
                    val list = snapshot.documents.mapNotNull { doc ->
                        NoteEntity(
                            firestoreId = doc.id,
                            relationshipId = relationshipId,
                            title = doc.getString("title") ?: "",
                            content = doc.getString("content") ?: "",
                            category = doc.getString("category") ?: "General",
                            authorName = doc.getString("authorName") ?: "",
                            authorUid = doc.getString("authorUid") ?: "",
                            updatedAtMillis = doc.getLong("updatedAtMillis") ?: System.currentTimeMillis()
                        )
                    }
                    onNotesUpdate(list)
                }

        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Could not start Firestore listeners: ${e.message}")
        }
    }

    // --- Send Message / Letter Online with exact schema: senderId, text, timestamp, messageId ---
    suspend fun sendMessageOnline(relId: String, letter: LoveLetterEntity) {
        try {
            val messageId = letter.firestoreId.ifBlank { UUID.randomUUID().toString() }
            val messageData = hashMapOf(
                "messageId" to messageId,
                "senderId" to letter.senderUid,
                "senderName" to letter.senderName,
                "text" to letter.message,
                "timestamp" to letter.dateMillis,
                "title" to letter.title,
                "themeColorIndex" to letter.themeColorIndex,
                "isRead" to false
            )
            // Save to messages collection
            firestore.collection("relationships").document(relId)
                .collection("messages").document(messageId)
                .set(messageData).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error sending message online: ${e.message}")
        }
    }

    suspend fun addMemoryOnline(relId: String, memory: MemoryEntity) {
        try {
            val docId = UUID.randomUUID().toString()
            val data = hashMapOf(
                "id" to docId,
                "title" to memory.title,
                "description" to memory.description,
                "dateMillis" to memory.dateMillis,
                "imageUrl" to memory.imageUrl,
                "imageDrawableName" to memory.imageDrawableName,
                "location" to memory.location,
                "createdByName" to memory.createdByName,
                "createdByUid" to memory.createdByUid,
                "createdAtMillis" to memory.createdAtMillis
            )
            firestore.collection("relationships").document(relId).collection("memories").document(docId).set(data).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error adding memory online: ${e.message}")
        }
    }

    suspend fun addGoalOnline(relId: String, goal: GoalEntity) {
        try {
            val docId = UUID.randomUUID().toString()
            val data = hashMapOf(
                "id" to docId,
                "title" to goal.title,
                "description" to goal.description,
                "progress" to goal.progress,
                "isCompleted" to goal.isCompleted,
                "targetDate" to goal.targetDate,
                "category" to goal.category
            )
            firestore.collection("relationships").document(relId).collection("goals").document(docId).set(data).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error adding goal online: ${e.message}")
        }
    }

    suspend fun updateGoalOnline(relId: String, goalId: String, progress: Int, isCompleted: Boolean) {
        try {
            val updates = mapOf(
                "progress" to progress,
                "isCompleted" to isCompleted
            )
            firestore.collection("relationships").document(relId).collection("goals").document(goalId).update(updates).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error updating goal online: ${e.message}")
        }
    }

    suspend fun addNoteOnline(relId: String, note: NoteEntity) {
        try {
            val docId = UUID.randomUUID().toString()
            val data = hashMapOf(
                "id" to docId,
                "title" to note.title,
                "content" to note.content,
                "category" to note.category,
                "authorName" to note.authorName,
                "authorUid" to note.authorUid,
                "updatedAtMillis" to note.updatedAtMillis
            )
            firestore.collection("relationships").document(relId).collection("notes").document(docId).set(data).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error adding note online: ${e.message}")
        }
    }

    suspend fun updateRelationshipDetailsOnline(relId: String, name: String, startDateMillis: Long) {
        try {
            val updates = mapOf(
                "relationshipName" to name,
                "startDateMillis" to startDateMillis,
                "updatedAtMillis" to System.currentTimeMillis()
            )
            firestore.collection("relationships").document(relId).update(updates).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error updating relationship online: ${e.message}")
        }
    }

    suspend fun updateUserProfileOnline(
        uid: String,
        name: String,
        avatarRes: String,
        photoUrl: String,
        relId: String? = null,
        isCreator: Boolean = false
    ) {
        try {
            val userUpdates = mapOf(
                "displayName" to name,
                "name" to name,
                "avatarRes" to avatarRes,
                "photoUrl" to photoUrl,
                "updatedAtMillis" to System.currentTimeMillis()
            )
            firestore.collection("users").document(uid).set(userUpdates, SetOptions.merge()).await()

            if (!relId.isNullOrBlank()) {
                val relUpdates = if (isCreator) {
                    mapOf(
                        "creatorName" to name,
                        "creatorPhoto" to photoUrl.ifEmpty { avatarRes }
                    )
                } else {
                    mapOf(
                        "partnerName" to name,
                        "partnerPhoto" to photoUrl.ifEmpty { avatarRes }
                    )
                }
                firestore.collection("relationships").document(relId).update(relUpdates).await()
            }
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error updating profile online: ${e.message}")
        }
    }

    fun stopAllListeners() {
        relationshipListener?.remove()
        relationshipListener = null
        partnerProfileListener?.remove()
        partnerProfileListener = null
        currentListeningPartnerUid = null
        messagesListener?.remove()
        messagesListener = null
        memoriesListener?.remove()
        memoriesListener = null
        goalsListener?.remove()
        goalsListener = null
        notesListener?.remove()
        notesListener = null
    }
}
