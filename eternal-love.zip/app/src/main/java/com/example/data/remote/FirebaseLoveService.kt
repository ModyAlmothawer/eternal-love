package com.example.data.remote

import android.net.Uri
import android.util.Log
import com.example.data.model.GoalEntity
import com.example.data.model.LoveLetterEntity
import com.example.data.model.MemoryEntity
import com.example.data.model.NoteEntity
import com.example.data.model.RelationshipEntity
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import java.util.UUID

class FirebaseLoveService {
    companion object {
        const val AUTH_TIMEOUT_MILLIS = 15_000L
        const val FIRESTORE_TIMEOUT_MILLIS = 10_000L

        fun mapFirebaseException(e: Throwable, language: String = "ar"): String {
            return when (e) {
                is FirebaseAuthUserCollisionException -> {
                    if (language == "ar") "هذا البريد الإلكتروني مسجل بالفعل. يرجى تسجيل الدخول أو استخدام بريد آخر."
                    else "This email address is already in use by another account."
                }
                is FirebaseAuthWeakPasswordException -> {
                    if (language == "ar") "كلمة المرور ضعيفة جداً. يجب أن تحتوي على 6 أحرف على الأقل."
                    else "Password is too weak. Please use at least 6 characters."
                }
                is FirebaseAuthInvalidCredentialsException -> {
                    if (language == "ar") "البريد الإلكتروني أو كلمة المرور غير صحيحة."
                    else "The email address or password entered is incorrect."
                }
                is FirebaseAuthInvalidUserException -> {
                    if (language == "ar") "الحساب غير موجود أو تم تعطيله."
                    else "This account does not exist or has been disabled."
                }
                is FirebaseNetworkException -> {
                    if (language == "ar") "تعذر الاتصال بالشبكة. يرجى التحقق من اتصال الإنترنت والمحاولة مجدداً."
                    else "Network error. Please check your internet connection and try again."
                }
                is FirebaseTooManyRequestsException -> {
                    if (language == "ar") "تم حظر المحاولات مؤقتاً بسبب كثرة الطلبات. يرجى المحاولة بعد قليل."
                    else "Too many requests. Access temporarily disabled. Please try again later."
                }
                is TimeoutCancellationException -> {
                    if (language == "ar") "استغرقت العملية وقتاً طويلاً. يرجى التحقق من اتصال الإنترنت."
                    else "The operation timed out. Please check your internet connection."
                }
                is FirebaseFirestoreException -> {
                    if (e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED) {
                        if (language == "ar") "تم رفض الصلاحيات من الخادم السحابي."
                        else "Permission denied on cloud database."
                    } else if (e.code == FirebaseFirestoreException.Code.UNAVAILABLE) {
                        if (language == "ar") "خدمة السحابة غير متاحة حالياً، يرجى المحاولة لاحقاً."
                        else "Cloud service is currently unavailable."
                    } else {
                        e.localizedMessage ?: (if (language == "ar") "خطأ في قاعدة البيانات السحابية" else "Cloud database error")
                    }
                }
                else -> {
                    val msg = e.localizedMessage ?: e.message ?: ""
                    if (msg.contains("API key not valid", ignoreCase = true)) {
                        if (language == "ar") "مفتاح Firebase API غير صالح في ملف google-services.json. يرجى تزويد ملف الإعدادات الرسمي من Firebase Console."
                        else "Firebase API key in google-services.json is invalid. Please provide the configuration file from Firebase Console."
                    } else if (msg.contains("The email address is already in use", ignoreCase = true)) {
                        if (language == "ar") "هذا البريد الإلكتروني مسجل بالفعل. يرجى تسجيل الدخول أو استخدام بريد آخر."
                        else "This email address is already in use by another account."
                    } else if (msg.contains("Password should be at least", ignoreCase = true)) {
                        if (language == "ar") "يجب ألا تقل كلمة المرور عن 6 أحرف."
                        else "Password should be at least 6 characters."
                    } else if (msg.contains("network error", ignoreCase = true) || msg.contains("timeout", ignoreCase = true)) {
                        if (language == "ar") "تعذر الاتصال بالشبكة. يرجى التحقق من اتصال الإنترنت."
                        else "Network error. Please check your connection."
                    } else {
                        msg.ifBlank { if (language == "ar") "حدث خطأ أثناء العملية، يرجى المحاولة مجدداً." else "An unexpected error occurred." }
                    }
                }
            }
        }
    }

    private val auth: FirebaseAuth
        get() = try {
            FirebaseAuth.getInstance()
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "FirebaseAuth instance error: ${e.message}")
            FirebaseAuth.getInstance()
        }

    private val firestore: FirebaseFirestore
        get() = try {
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "FirebaseFirestore instance error: ${e.message}")
            FirebaseFirestore.getInstance()
        }

    private val storage: FirebaseStorage
        get() = try {
            FirebaseStorage.getInstance()
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "FirebaseStorage instance error: ${e.message}")
            FirebaseStorage.getInstance()
        }

    private var relationshipListener: ListenerRegistration? = null
    private var partnerProfileListener: ListenerRegistration? = null
    private var currentListeningPartnerUid: String? = null
    private var lettersListener: ListenerRegistration? = null
    private var memoriesListener: ListenerRegistration? = null
    private var goalsListener: ListenerRegistration? = null
    private var notesListener: ListenerRegistration? = null

    val currentFirebaseUser: FirebaseUser?
        get() = try {
            auth.currentUser
        } catch (e: Exception) {
            null
        }

    suspend fun registerWithFirebase(email: String, pass: String): Result<String> {
        return try {
            withTimeout(AUTH_TIMEOUT_MILLIS) {
                val authResult = auth.createUserWithEmailAndPassword(email.trim(), pass).await()
                val uid = authResult.user?.uid
                if (!uid.isNullOrBlank()) {
                    Result.success(uid)
                } else {
                    Result.failure(Exception("Could not retrieve user ID from Firebase Authentication"))
                }
            }
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "FirebaseAuth register error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun loginWithFirebase(email: String, pass: String): Result<String> {
        return try {
            withTimeout(AUTH_TIMEOUT_MILLIS) {
                val authResult = auth.signInWithEmailAndPassword(email.trim(), pass).await()
                val uid = authResult.user?.uid
                if (!uid.isNullOrBlank()) {
                    Result.success(uid)
                } else {
                    Result.failure(Exception("Could not retrieve user ID from Firebase Authentication"))
                }
            }
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "FirebaseAuth login error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun sendPasswordResetEmail(email: String): Result<Unit> {
        return try {
            withTimeout(AUTH_TIMEOUT_MILLIS) {
                auth.sendPasswordResetEmail(email.trim()).await()
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "sendPasswordResetEmail error: ${e.message}", e)
            Result.failure(e)
        }
    }

    fun signOut() {
        try {
            stopAllListeners()
            auth.signOut()
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "SignOut error: ${e.message}")
        }
    }

    // --- User Profile Cloud Sync ---
    suspend fun syncUserProfileOnline(
        uid: String,
        name: String,
        email: String,
        avatarRes: String = "avatar_1",
        photoUrl: String = "",
        relationshipId: String? = null
    ): Result<Unit> {
        if (uid.isBlank()) return Result.failure(Exception("UID is empty"))
        return try {
            withTimeout(FIRESTORE_TIMEOUT_MILLIS) {
                val data = mutableMapOf<String, Any>(
                    "uid" to uid,
                    "displayName" to name,
                    "email" to email,
                    "avatarRes" to avatarRes,
                    "photoUrl" to photoUrl,
                    "updatedAtMillis" to System.currentTimeMillis()
                )
                if (relationshipId != null) {
                    data["relationshipId"] = relationshipId
                }
                firestore.collection("users").document(uid)
                    .set(data, SetOptions.merge())
                    .await()
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error syncing user profile online: ${e.message}")
            Result.failure(e)
        }
    }

    suspend fun fetchUserProfileOnline(uid: String): Map<String, Any?>? {
        if (uid.isBlank()) return null
        return try {
            withTimeout(FIRESTORE_TIMEOUT_MILLIS) {
                val doc = firestore.collection("users").document(uid).get().await()
                if (doc.exists()) doc.data else null
            }
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error fetching user profile: ${e.message}")
            null
        }
    }

    suspend fun uploadProfileImage(uid: String, imageUri: Uri): String? {
        if (uid.isBlank()) return null
        return try {
            withTimeout(20_000L) {
                val ref = storage.reference.child("users/$uid/profile/avatar_${System.currentTimeMillis()}.jpg")
                ref.putFile(imageUri).await()
                val downloadUrl = ref.downloadUrl.await().toString()
                val updates = mapOf<String, Any>(
                    "photoUrl" to downloadUrl,
                    "updatedAtMillis" to System.currentTimeMillis()
                )
                firestore.collection("users").document(uid)
                    .set(updates, SetOptions.merge())
                    .await()
                downloadUrl
            }
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "Error uploading profile image: ${e.message}")
            null
        }
    }

    // --- Relationship Creation & Connection ---
    suspend fun createFirestoreRelationship(
        creatorUid: String,
        creatorName: String,
        creatorPhoto: String,
        startDateMillis: Long,
        code: String
    ): String {
        val relId = UUID.randomUUID().toString().take(12)
        val data = hashMapOf(
            "id" to relId,
            "code" to code,
            "creatorUid" to creatorUid,
            "creatorName" to creatorName,
            "creatorPhoto" to creatorPhoto,
            "partnerUid" to "",
            "partnerName" to "",
            "partnerPhoto" to "",
            "startDateMillis" to startDateMillis,
            "relationshipName" to "حكايتنا ❤️",
            "status" to "pending",
            "createdAtMillis" to System.currentTimeMillis(),
            "updatedAtMillis" to System.currentTimeMillis()
        )

        try {
            withTimeout(FIRESTORE_TIMEOUT_MILLIS) {
                firestore.collection("relationships").document(relId).set(data).await()
                // Link user doc
                if (creatorUid.isNotBlank()) {
                    firestore.collection("users").document(creatorUid)
                        .set(mapOf("relationshipId" to relId), SetOptions.merge())
                        .await()
                }
            }
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error creating relationship on Firestore: ${e.message}")
        }
        return relId
    }

    suspend fun joinFirestoreRelationship(
        code: String,
        partnerUid: String,
        partnerName: String,
        partnerPhoto: String = ""
    ): Pair<String, Map<String, Any?>>? {
        return try {
            withTimeout(FIRESTORE_TIMEOUT_MILLIS) {
                val querySnapshot = firestore.collection("relationships")
                    .whereEqualTo("code", code.trim())
                    .limit(1)
                    .get()
                    .await()

                if (querySnapshot.isEmpty) {
                    return@withTimeout null
                }

                val doc = querySnapshot.documents[0]
                val relId = doc.id
                val creatorUid = doc.getString("creatorUid") ?: ""

                if (creatorUid == partnerUid && partnerUid.isNotBlank()) {
                    throw Exception("لا يمكنك الانضمام إلى كود العلاقة الخاص بك. شارك الكود مع شريكك!")
                }

                val currentPartnerUid = doc.getString("partnerUid")
                if (!currentPartnerUid.isNullOrBlank() && currentPartnerUid != partnerUid) {
                    throw Exception("هذه العلاقة متصلة بالفعل بحساب آخر.")
                }

                val updates = mapOf(
                    "partnerUid" to partnerUid,
                    "partnerName" to partnerName,
                    "partnerPhoto" to partnerPhoto,
                    "status" to "connected",
                    "updatedAtMillis" to System.currentTimeMillis()
                )

                firestore.collection("relationships").document(relId).update(updates).await()

                // Update user document with relationshipId
                if (partnerUid.isNotBlank()) {
                    firestore.collection("users").document(partnerUid)
                        .set(
                            mapOf(
                                "relationshipId" to relId,
                                "partnerUid" to creatorUid
                            ),
                            SetOptions.merge()
                        )
                        .await()
                }

                Pair(relId, doc.data ?: emptyMap())
            }
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "Error joining relationship: ${e.message}")
            throw e
        }
    }

    // --- Realtime Sync ---
    fun startRealtimeListeners(
        relationshipId: String,
        currentUid: String = "",
        onRelationshipUpdate: (RelationshipEntity) -> Unit,
        onPartnerProfileUpdate: (name: String, photoUrl: String, avatarRes: String) -> Unit = { _, _, _ -> },
        onLettersUpdate: (List<LoveLetterEntity>) -> Unit,
        onMemoriesUpdate: (List<MemoryEntity>) -> Unit,
        onGoalsUpdate: (List<GoalEntity>) -> Unit,
        onNotesUpdate: (List<NoteEntity>) -> Unit
    ) {
        stopAllListeners()

        try {
            // 1. Relationship Document Listener
            relationshipListener = firestore.collection("relationships")
                .document(relationshipId)
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null || !snapshot.exists()) {
                        return@addSnapshotListener
                    }
                    val creatorId = snapshot.getString("creatorUid") ?: ""
                    val partnerId = snapshot.getString("partnerUid") ?: ""
                    val creatorName = snapshot.getString("creatorName") ?: ""
                    val partnerName = snapshot.getString("partnerName") ?: ""
                    val creatorPhoto = snapshot.getString("creatorPhoto") ?: "avatar_1"
                    val partnerPhoto = snapshot.getString("partnerPhoto") ?: "avatar_2"

                    val entity = RelationshipEntity(
                        firestoreId = snapshot.id,
                        code = snapshot.getString("code") ?: "",
                        creatorId = creatorId,
                        creatorName = creatorName,
                        creatorPhoto = creatorPhoto,
                        partnerId = partnerId.takeIf { it.isNotBlank() },
                        partnerName = partnerName,
                        partnerPhoto = partnerPhoto,
                        startDateMillis = snapshot.getLong("startDateMillis") ?: System.currentTimeMillis(),
                        relationshipName = snapshot.getString("relationshipName") ?: "حكايتنا ❤️",
                        status = snapshot.getString("status") ?: "connected",
                        createdAtMillis = snapshot.getLong("createdAtMillis") ?: System.currentTimeMillis()
                    )
                    onRelationshipUpdate(entity)

                    // Start partner user profile listener if partner UID is known
                    val partnerUidToListen = if (currentUid.isNotBlank()) {
                        if (currentUid == creatorId) partnerId else creatorId
                    } else {
                        partnerId
                    }

                    if (partnerUidToListen.isNotBlank() && partnerUidToListen != currentListeningPartnerUid) {
                        partnerProfileListener?.remove()
                        currentListeningPartnerUid = partnerUidToListen
                        partnerProfileListener = firestore.collection("users")
                            .document(partnerUidToListen)
                            .addSnapshotListener { userDoc, userErr ->
                                if (userErr == null && userDoc != null && userDoc.exists()) {
                                    val name = userDoc.getString("displayName") ?: userDoc.getString("name") ?: ""
                                    val photo = userDoc.getString("photoUrl") ?: ""
                                    val avatar = userDoc.getString("avatarRes") ?: "avatar_2"
                                    if (name.isNotBlank() || photo.isNotBlank()) {
                                        onPartnerProfileUpdate(name, photo, avatar)
                                    }
                                }
                            }
                    }
                }

            // 2. Letters Listener
            lettersListener = firestore.collection("relationships")
                .document(relationshipId)
                .collection("letters")
                .orderBy("dateMillis", Query.Direction.DESCENDING)
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) return@addSnapshotListener
                    val list = snapshot.documents.mapNotNull { doc ->
                        LoveLetterEntity(
                            firestoreId = doc.id,
                            relationshipId = relationshipId,
                            senderUid = doc.getString("senderUid") ?: "",
                            senderName = doc.getString("senderName") ?: "",
                            title = doc.getString("title") ?: "",
                            message = doc.getString("message") ?: "",
                            dateMillis = doc.getLong("dateMillis") ?: System.currentTimeMillis(),
                            isRead = doc.getBoolean("isRead") ?: false,
                            themeColorIndex = (doc.getLong("themeColorIndex") ?: 0L).toInt()
                        )
                    }
                    onLettersUpdate(list)
                }

            // 3. Memories Listener
            memoriesListener = firestore.collection("relationships")
                .document(relationshipId)
                .collection("memories")
                .orderBy("dateMillis", Query.Direction.DESCENDING)
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) return@addSnapshotListener
                    val list = snapshot.documents.mapNotNull { doc ->
                        MemoryEntity(
                            firestoreId = doc.id,
                            relationshipId = relationshipId,
                            title = doc.getString("title") ?: "",
                            description = doc.getString("description") ?: "",
                            dateMillis = doc.getLong("dateMillis") ?: System.currentTimeMillis(),
                            imageUrl = doc.getString("imageUrl") ?: "",
                            imageDrawableName = doc.getString("imageDrawableName") ?: "img_memory_default",
                            location = doc.getString("location") ?: "",
                            createdByName = doc.getString("createdByName") ?: "",
                            createdByUid = doc.getString("createdByUid") ?: ""
                        )
                    }
                    onMemoriesUpdate(list)
                }

            // 4. Goals Listener
            goalsListener = firestore.collection("relationships")
                .document(relationshipId)
                .collection("goals")
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) return@addSnapshotListener
                    val list = snapshot.documents.mapNotNull { doc ->
                        GoalEntity(
                            firestoreId = doc.id,
                            relationshipId = relationshipId,
                            title = doc.getString("title") ?: "",
                            description = doc.getString("description") ?: "",
                            progress = (doc.getLong("progress") ?: 0L).toInt(),
                            isCompleted = doc.getBoolean("isCompleted") ?: false,
                            targetDate = doc.getString("targetDate") ?: "",
                            category = doc.getString("category") ?: "Life & Romance"
                        )
                    }
                    onGoalsUpdate(list)
                }

            // 5. Notes Listener
            notesListener = firestore.collection("relationships")
                .document(relationshipId)
                .collection("notes")
                .orderBy("updatedAtMillis", Query.Direction.DESCENDING)
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) return@addSnapshotListener
                    val list = snapshot.documents.mapNotNull { doc ->
                        NoteEntity(
                            firestoreId = doc.id,
                            relationshipId = relationshipId,
                            title = doc.getString("title") ?: "",
                            content = doc.getString("content") ?: "",
                            category = doc.getString("category") ?: "General",
                            authorName = doc.getString("authorName") ?: "",
                            authorUid = doc.getString("authorUid") ?: "",
                            updatedAtMillis = doc.getLong("updatedAtMillis") ?: System.currentTimeMillis()
                        )
                    }
                    onNotesUpdate(list)
                }

        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Could not start Firestore listeners: ${e.message}")
        }
    }

    suspend fun sendLetterOnline(relId: String, letter: LoveLetterEntity) {
        try {
            val docId = UUID.randomUUID().toString()
            val data = hashMapOf(
                "id" to docId,
                "senderUid" to letter.senderUid,
                "senderName" to letter.senderName,
                "title" to letter.title,
                "message" to letter.message,
                "dateMillis" to letter.dateMillis,
                "isRead" to false,
                "themeColorIndex" to letter.themeColorIndex
            )
            firestore.collection("relationships").document(relId).collection("letters").document(docId).set(data).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error sending letter online: ${e.message}")
        }
    }

    suspend fun addMemoryOnline(relId: String, memory: MemoryEntity) {
        try {
            val docId = UUID.randomUUID().toString()
            val data = hashMapOf(
                "id" to docId,
                "title" to memory.title,
                "description" to memory.description,
                "dateMillis" to memory.dateMillis,
                "imageUrl" to memory.imageUrl,
                "imageDrawableName" to memory.imageDrawableName,
                "location" to memory.location,
                "createdByName" to memory.createdByName,
                "createdByUid" to memory.createdByUid,
                "createdAtMillis" to memory.createdAtMillis
            )
            firestore.collection("relationships").document(relId).collection("memories").document(docId).set(data).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error adding memory online: ${e.message}")
        }
    }

    suspend fun addGoalOnline(relId: String, goal: GoalEntity) {
        try {
            val docId = UUID.randomUUID().toString()
            val data = hashMapOf(
                "id" to docId,
                "title" to goal.title,
                "description" to goal.description,
                "progress" to goal.progress,
                "isCompleted" to goal.isCompleted,
                "targetDate" to goal.targetDate,
                "category" to goal.category
            )
            firestore.collection("relationships").document(relId).collection("goals").document(docId).set(data).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error adding goal online: ${e.message}")
        }
    }

    suspend fun updateGoalOnline(relId: String, goalId: String, progress: Int, isCompleted: Boolean) {
        try {
            val updates = mapOf(
                "progress" to progress,
                "isCompleted" to isCompleted
            )
            firestore.collection("relationships").document(relId).collection("goals").document(goalId).update(updates).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error updating goal online: ${e.message}")
        }
    }

    suspend fun addNoteOnline(relId: String, note: NoteEntity) {
        try {
            val docId = UUID.randomUUID().toString()
            val data = hashMapOf(
                "id" to docId,
                "title" to note.title,
                "content" to note.content,
                "category" to note.category,
                "authorName" to note.authorName,
                "authorUid" to note.authorUid,
                "updatedAtMillis" to note.updatedAtMillis
            )
            firestore.collection("relationships").document(relId).collection("notes").document(docId).set(data).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error adding note online: ${e.message}")
        }
    }

    suspend fun updateRelationshipDetailsOnline(relId: String, name: String, startDateMillis: Long) {
        try {
            val updates = mapOf(
                "relationshipName" to name,
                "startDateMillis" to startDateMillis,
                "updatedAtMillis" to System.currentTimeMillis()
            )
            firestore.collection("relationships").document(relId).update(updates).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error updating relationship online: ${e.message}")
        }
    }

    suspend fun updateUserProfileOnline(
        uid: String,
        name: String,
        avatarRes: String,
        photoUrl: String,
        relId: String? = null,
        isCreator: Boolean = false
    ) {
        try {
            val userUpdates = mapOf(
                "displayName" to name,
                "avatarRes" to avatarRes,
                "photoUrl" to photoUrl,
                "updatedAtMillis" to System.currentTimeMillis()
            )
            firestore.collection("users").document(uid).set(userUpdates, SetOptions.merge()).await()

            if (!relId.isNullOrBlank()) {
                val relUpdates = if (isCreator) {
                    mapOf(
                        "creatorName" to name,
                        "creatorPhoto" to photoUrl.ifEmpty { avatarRes }
                    )
                } else {
                    mapOf(
                        "partnerName" to name,
                        "partnerPhoto" to photoUrl.ifEmpty { avatarRes }
                    )
                }
                firestore.collection("relationships").document(relId).update(relUpdates).await()
            }
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error updating profile online: ${e.message}")
        }
    }

    fun stopAllListeners() {
        relationshipListener?.remove()
        relationshipListener = null
        partnerProfileListener?.remove()
        partnerProfileListener = null
        currentListeningPartnerUid = null
        lettersListener?.remove()
        lettersListener = null
        memoriesListener?.remove()
        memoriesListener = null
        goalsListener?.remove()
        goalsListener = null
        notesListener?.remove()
        notesListener = null
    }
}
