package com.example.data.remote

import android.net.Uri
import android.util.Log
import com.example.data.model.GoalEntity
import com.example.data.model.LoveLetterEntity
import com.example.data.model.MemoryEntity
import com.example.data.model.NoteEntity
import com.example.data.model.RelationshipEntity
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import java.util.UUID

class FirebaseLoveService {
    companion object {
        const val AUTH_TIMEOUT_MILLIS = 15_000L
        const val FIRESTORE_TIMEOUT_MILLIS = 12_000L

        fun mapFirebaseException(e: Throwable, language: String = "ar"): String {
            return when (e) {
                is FirebaseAuthUserCollisionException -> {
                    if (language == "ar") "البريد ده مسجل قبل كده، ادخل بحسابك أو استخدم بريد تاني."
                    else "This email address is already registered. Please log in or use another email."
                }
                is FirebaseAuthWeakPasswordException -> {
                    if (language == "ar") "كلمة السر ضعيفة، لازم تكون 6 حروف أو أكتر."
                    else "Password is too weak. Please use at least 6 characters."
                }
                is FirebaseAuthInvalidCredentialsException -> {
                    if (language == "ar") "البريد أو كلمة السر مش صح، اتأكد وجرّب تاني."
                    else "The email address or password entered is incorrect."
                }
                is FirebaseAuthInvalidUserException -> {
                    if (language == "ar") "الحساب ده مش موجود أو تم تعطيله."
                    else "This account does not exist or has been disabled."
                }
                is FirebaseNetworkException -> {
                    if (language == "ar") "حصلت مشكلة في الاتصال بالإنترنت، اتأكد من الشبكة وجرّب تاني."
                    else "Network connection issue. Please check your connection and try again."
                }
                is FirebaseTooManyRequestsException -> {
                    if (language == "ar") "محاولات كتير ورا بعض، استنى دقيقة وجرّب تاني."
                    else "Too many requests. Please wait a moment and try again."
                }
                is TimeoutCancellationException -> {
                    if (language == "ar") "العملية أخدت وقت طويل، اتأكد من الإنترنت وجرّب تاني."
                    else "The operation timed out. Please check your internet connection."
                }
                is FirebaseFirestoreException -> {
                    if (e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED) {
                        if (language == "ar") "ما فيش صلاحية للوصول للبيانات دي."
                        else "Permission denied on cloud database."
                    } else if (e.code == FirebaseFirestoreException.Code.UNAVAILABLE) {
                        if (language == "ar") "السيرفر مش متاح حالياً، جرّب كمان شوية."
                        else "Cloud service is currently unavailable. Please try again shortly."
                    } else {
                        val msg = e.localizedMessage ?: ""
                        if (language == "ar") {
                            if (msg.contains("permission", ignoreCase = true)) "ما فيش صلاحية للوصول للبيانات."
                            else "حصلت مشكلة في قاعدة البيانات، جرّب تاني."
                        } else {
                            msg.ifBlank { "Cloud database error" }
                        }
                    }
                }
                else -> {
                    val msg = e.localizedMessage ?: e.message ?: ""
                    if (msg.contains("API key not valid", ignoreCase = true)) {
                        if (language == "ar") "مفتاح Firebase غير صالح. يرجى مراجعة إعدادات Firebase."
                        else "Firebase API key is invalid. Please check your Firebase configuration."
                    } else if (msg.contains("The email address is already in use", ignoreCase = true)) {
                        if (language == "ar") "البريد ده مسجل قبل كده، ادخل بحسابك أو استخدم بريد تاني."
                        else "This email address is already in use by another account."
                    } else if (msg.contains("Password should be at least", ignoreCase = true)) {
                        if (language == "ar") "كلمة السر لازم تكون 6 حروف أو أكتر."
                        else "Password should be at least 6 characters."
                    } else if (msg.contains("network error", ignoreCase = true) || msg.contains("timeout", ignoreCase = true)) {
                        if (language == "ar") "حصلت مشكلة في الاتصال بالإنترنت، اتأكد من الشبكة وجرّب تاني."
                        else "Network error. Please check your internet connection."
                    } else {
                        msg.ifBlank { if (language == "ar") "حصلت مشكلة، جرّب تاني." else "An unexpected error occurred. Please try again." }
                    }
                }
            }
        }
    }

    private val auth: FirebaseAuth
        get() = try {
            FirebaseAuth.getInstance()
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "FirebaseAuth instance error: ${e.message}")
            FirebaseAuth.getInstance()
        }

    private val firestore: FirebaseFirestore
        get() = try {
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "FirebaseFirestore instance error: ${e.message}")
            FirebaseFirestore.getInstance()
        }

    private val storage: FirebaseStorage
        get() = try {
            FirebaseStorage.getInstance()
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "FirebaseStorage instance error: ${e.message}")
            FirebaseStorage.getInstance()
        }

    private var relationshipListener: ListenerRegistration? = null
    private var partnerProfileListener: ListenerRegistration? = null
    private var currentListeningPartnerUid: String? = null
    private var messagesListener: ListenerRegistration? = null
    private var memoriesListener: ListenerRegistration? = null
    private var goalsListener: ListenerRegistration? = null
    private var notesListener: ListenerRegistration? = null

    val currentFirebaseUser: FirebaseUser?
        get() = try {
            auth.currentUser
        } catch (e: Exception) {
            null
        }

    suspend fun registerWithFirebase(email: String, pass: String): Result<String> {
        return try {
            withTimeout(AUTH_TIMEOUT_MILLIS) {
                val authResult = auth.createUserWithEmailAndPassword(email.trim(), pass).await()
                val uid = authResult.user?.uid
                if (!uid.isNullOrBlank()) {
                    Result.success(uid)
                } else {
                    Result.failure(Exception("Could not retrieve user ID from Firebase Authentication"))
                }
            }
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "FirebaseAuth register error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun loginWithFirebase(email: String, pass: String): Result<String> {
        return try {
            withTimeout(AUTH_TIMEOUT_MILLIS) {
                val authResult = auth.signInWithEmailAndPassword(email.trim(), pass).await()
                val uid = authResult.user?.uid
                if (!uid.isNullOrBlank()) {
                    Result.success(uid)
                } else {
                    Result.failure(Exception("Could not retrieve user ID from Firebase Authentication"))
                }
            }
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "FirebaseAuth login error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun sendPasswordResetEmail(email: String): Result<Unit> {
        return try {
            withTimeout(AUTH_TIMEOUT_MILLIS) {
                auth.sendPasswordResetEmail(email.trim()).await()
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "sendPasswordResetEmail error: ${e.message}", e)
            Result.failure(e)
        }
    }

    fun signOut() {
        try {
            stopAllListeners()
            auth.signOut()
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "SignOut error: ${e.message}")
        }
    }

    // --- FCM Token Management ---
    suspend fun updateFcmToken(uid: String, token: String) {
        if (uid.isBlank() || token.isBlank()) return
        try {
            val tokenData = mapOf(
                "fcmToken" to token,
                "fcmTokenUpdatedAtMillis" to System.currentTimeMillis()
            )
            firestore.collection("users").document(uid)
                .set(tokenData, SetOptions.merge())
                .await()
            Log.d("FirebaseLoveService", "FCM token updated successfully for user $uid")
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Failed to update FCM token for $uid: ${e.message}")
        }
    }

    suspend fun fetchPartnerFcmToken(partnerUid: String): String? {
        if (partnerUid.isBlank()) return null
        return try {
            val doc = firestore.collection("users").document(partnerUid).get().await()
            doc.getString("fcmToken")
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Could not fetch partner FCM token: ${e.message}")
            null
        }
    }

    // --- Outbox Notification Queue in Firestore ---
    suspend fun queuePushNotification(
        recipientUid: String,
        senderUid: String,
        type: String,
        title: String,
        body: String,
        dataPayload: Map<String, String> = emptyMap()
    ) {
        if (recipientUid.isBlank() || recipientUid == senderUid) return
        try {
            val notifId = UUID.randomUUID().toString()
            val notifDoc = hashMapOf<String, Any>(
                "id" to notifId,
                "recipientUid" to recipientUid,
                "senderUid" to senderUid,
                "type" to type,
                "title" to title,
                "body" to body,
                "data" to dataPayload,
                "createdAtMillis" to System.currentTimeMillis(),
                "status" to "queued"
            )
            firestore.collection("notifications_queue").document(notifId).set(notifDoc).await()
            Log.d("FirebaseLoveService", "Queued push notification $notifId for $recipientUid (type: $type)")
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Failed to queue push notification: ${e.message}")
        }
    }

    // --- User Profile Cloud Sync ---
    suspend fun syncUserProfileOnline(
        uid: String,
        name: String,
        email: String,
        avatarRes: String = "avatar_1",
        photoUrl: String = "",
        relationshipId: String? = null
    ): Result<Unit> {
        if (uid.isBlank()) return Result.failure(Exception("UID is empty"))
        return try {
            withTimeout(FIRESTORE_TIMEOUT_MILLIS) {
                val data = mutableMapOf<String, Any>(
                    "uid" to uid,
                    "displayName" to name,
                    "name" to name,
                    "email" to email,
                    "avatarRes" to avatarRes,
                    "photoUrl" to photoUrl,
                    "updatedAtMillis" to System.currentTimeMillis()
                )
                if (relationshipId != null) {
                    data["relationshipId"] = relationshipId
                }
                firestore.collection("users").document(uid)
                    .set(data, SetOptions.merge())
                    .await()
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error syncing user profile online: ${e.message}")
            Result.failure(e)
        }
    }

    suspend fun fetchUserProfileOnline(uid: String): Map<String, Any?>? {
        if (uid.isBlank()) return null
        return try {
            withTimeout(FIRESTORE_TIMEOUT_MILLIS) {
                val doc = firestore.collection("users").document(uid).get().await()
                if (doc.exists()) doc.data else null
            }
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error fetching user profile: ${e.message}")
            null
        }
    }

    suspend fun uploadProfileImageBytes(uid: String, bytes: ByteArray): String? {
        if (uid.isBlank() || bytes.isEmpty()) return null
        return try {
            withTimeout(25_000L) {
                val ref = storage.reference.child("users/$uid/profile/avatar_${System.currentTimeMillis()}.jpg")
                ref.putBytes(bytes).await()
                val downloadUrl = ref.downloadUrl.await().toString()
                val updates = mapOf<String, Any>(
                    "photoUrl" to downloadUrl,
                    "updatedAtMillis" to System.currentTimeMillis()
                )
                firestore.collection("users").document(uid)
                    .set(updates, SetOptions.merge())
                    .await()
                downloadUrl
            }
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "Error uploading profile image bytes: ${e.message}")
            null
        }
    }

    suspend fun uploadMemoryImageBytes(relId: String, uid: String, bytes: ByteArray): String? {
        if (bytes.isEmpty()) return null
        return try {
            withTimeout(25_000L) {
                val safeRelId = relId.ifBlank { "general" }
                val ref = storage.reference.child("relationships/$safeRelId/memories/mem_${UUID.randomUUID()}.jpg")
                ref.putBytes(bytes).await()
                ref.downloadUrl.await().toString()
            }
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "Error uploading memory image bytes: ${e.message}")
            null
        }
    }

    suspend fun uploadProfileImage(uid: String, imageUri: Uri): String? {
        if (uid.isBlank()) return null
        return try {
            withTimeout(25_000L) {
                val ref = storage.reference.child("users/$uid/profile/avatar_${System.currentTimeMillis()}.jpg")
                ref.putFile(imageUri).await()
                val downloadUrl = ref.downloadUrl.await().toString()
                val updates = mapOf<String, Any>(
                    "photoUrl" to downloadUrl,
                    "updatedAtMillis" to System.currentTimeMillis()
                )
                firestore.collection("users").document(uid)
                    .set(updates, SetOptions.merge())
                    .await()
                downloadUrl
            }
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "Error uploading profile image: ${e.message}")
            null
        }
    }

    // --- Relationship Creation & Connection using invites/{code} ---

    suspend fun createFirestoreRelationship(
        creatorUid: String,
        creatorName: String,
        creatorPhoto: String,
        startDateMillis: Long,
        code: String
    ): String {
        val relId = UUID.randomUUID().toString().take(12)
        val relData = hashMapOf(
            "id" to relId,
            "code" to code.trim(),
            "creatorUid" to creatorUid,
            "creatorName" to creatorName,
            "creatorPhoto" to creatorPhoto,
            "creatorStatus" to "",
            "creatorStatusEmoji" to "",
            "partnerUid" to "",
            "partnerName" to "",
            "partnerPhoto" to "",
            "partnerStatus" to "",
            "partnerStatusEmoji" to "",
            "startDateMillis" to startDateMillis,
            "relationshipName" to "حكايتنا ❤️",
            "status" to "pending",
            "createdAtMillis" to System.currentTimeMillis()
        )

        val inviteData = hashMapOf(
            "relationshipId" to relId,
            "creatorUid" to creatorUid,
            "creatorName" to creatorName,
            "creatorPhoto" to creatorPhoto,
            "startDateMillis" to startDateMillis,
            "status" to "pending",
            "createdAtMillis" to System.currentTimeMillis()
        )

        withTimeout(FIRESTORE_TIMEOUT_MILLIS) {
            firestore.collection("relationships").document(relId).set(relData).await()
            firestore.collection("invites").document(code.trim()).set(inviteData).await()
            if (creatorUid.isNotBlank()) {
                firestore.collection("users").document(creatorUid).set(
                    mapOf(
                        "relationshipId" to relId,
                        "relationshipCode" to code.trim()
                    ),
                    SetOptions.merge()
                ).await()
            }
        }

        return relId
    }

    suspend fun joinFirestoreRelationship(
        code: String,
        partnerUid: String,
        partnerName: String,
        partnerPhoto: String,
        language: String = "ar"
    ): Pair<String, Map<String, Any?>> {
        val cleanCode = code.trim()

        if (cleanCode.length != 6 || !cleanCode.all { it.isDigit() }) {
            val msg = if (language == "ar") "كود الدعوة لازم يكون 6 أرقام." else "Invitation code must be 6 digits."
            throw IllegalArgumentException(msg)
        }

        try {
            return withTimeout(FIRESTORE_TIMEOUT_MILLIS) {
                val inviteDoc = firestore.collection("invites").document(cleanCode).get().await()

                if (!inviteDoc.exists()) {
                    val msg = if (language == "ar") "كود الدعوة غير صحيح أو غير موجود." else "Invalid or non-existent invitation code."
                    throw IllegalArgumentException(msg)
                }

                val creatorUid = inviteDoc.getString("creatorUid") ?: ""
                val relId = inviteDoc.getString("relationshipId") ?: ""

                if (creatorUid == partnerUid) {
                    val msg = if (language == "ar") "ما ينفعش تنضم لنفس الكود اللي أنشأته!" else "You cannot join your own invitation code!"
                    throw IllegalArgumentException(msg)
                }

                if (relId.isBlank()) {
                    val msg = if (language == "ar") "العلاقة المرتبطة بهذا الكود غير موجودة." else "Relationship associated with this code was not found."
                    throw IllegalArgumentException(msg)
                }

                val relDoc = firestore.collection("relationships").document(relId).get().await()
                if (!relDoc.exists()) {
                    val msg = if (language == "ar") "العلاقة غير موجودة أو تم حذفها." else "Relationship document not found or deleted."
                    throw IllegalArgumentException(msg)
                }

                val currentPartnerUid = relDoc.getString("partnerUid")
                if (!currentPartnerUid.isNullOrBlank() && currentPartnerUid != partnerUid) {
                    val msg = if (language == "ar") "هذه العلاقة مكتملة بالفعل بوجود شريك آخر." else "This relationship already has two connected partners."
                    throw IllegalArgumentException(msg)
                }

                val creatorName = relDoc.getString("creatorName") ?: inviteDoc.getString("creatorName") ?: (if (language == "ar") "حبيبي" else "My Love")

                val updateRelData = mapOf<String, Any>(
                    "partnerUid" to partnerUid,
                    "partnerName" to partnerName,
                    "partnerPhoto" to partnerPhoto,
                    "status" to "connected"
                )
                firestore.collection("relationships").document(relId).update(updateRelData).await()

                firestore.collection("invites").document(cleanCode).update(
                    mapOf<String, Any>(
                        "status" to "connected",
                        "partnerUid" to partnerUid
                    )
                ).await()

                if (partnerUid.isNotBlank()) {
                    firestore.collection("users").document(partnerUid).set(
                        mapOf(
                            "relationshipId" to relId,
                            "partnerUid" to creatorUid,
                            "partnerName" to creatorName,
                            "relationshipCode" to cleanCode
                        ),
                        SetOptions.merge()
                    ).await()
                }

                if (creatorUid.isNotBlank()) {
                    firestore.collection("users").document(creatorUid).set(
                        mapOf(
                            "partnerUid" to partnerUid,
                            "partnerName" to partnerName
                        ),
                        SetOptions.merge()
                    ).await()
                }

                Pair(relId, relDoc.data ?: emptyMap())
            }
        } catch (e: Exception) {
            Log.e("FirebaseLoveService", "Error joining relationship with code $cleanCode: ${e.message}")
            throw e
        }
    }

    // --- Realtime Sync: Relationships, Messages, Memories, Goals, Notes ---
    fun startRealtimeListeners(
        relationshipId: String,
        currentUid: String = "",
        onRelationshipUpdate: (RelationshipEntity) -> Unit,
        onPartnerProfileUpdate: (name: String, photoUrl: String, avatarRes: String, status: String, statusEmoji: String) -> Unit = { _, _, _, _, _ -> },
        onMessagesUpdate: (List<LoveLetterEntity>) -> Unit,
        onMemoriesUpdate: (List<MemoryEntity>) -> Unit,
        onGoalsUpdate: (List<GoalEntity>) -> Unit,
        onNotesUpdate: (List<NoteEntity>) -> Unit
    ) {
        stopAllListeners()

        try {
            // 1. Realtime Relationship Document Listener
            relationshipListener = firestore.collection("relationships")
                .document(relationshipId)
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null || !snapshot.exists()) {
                        return@addSnapshotListener
                    }
                    val creatorId = snapshot.getString("creatorUid") ?: ""
                    val partnerId = snapshot.getString("partnerUid") ?: ""
                    val creatorName = snapshot.getString("creatorName") ?: ""
                    val partnerName = snapshot.getString("partnerName") ?: ""
                    val creatorPhoto = snapshot.getString("creatorPhoto") ?: "avatar_1"
                    val partnerPhoto = snapshot.getString("partnerPhoto") ?: "avatar_2"
                    val creatorStatus = snapshot.getString("creatorStatus") ?: ""
                    val creatorStatusEmoji = snapshot.getString("creatorStatusEmoji") ?: ""
                    val partnerStatus = snapshot.getString("partnerStatus") ?: ""
                    val partnerStatusEmoji = snapshot.getString("partnerStatusEmoji") ?: ""

                    val entity = RelationshipEntity(
                        firestoreId = snapshot.id,
                        code = snapshot.getString("code") ?: "",
                        creatorId = creatorId,
                        creatorName = creatorName,
                        creatorPhoto = creatorPhoto,
                        creatorStatus = creatorStatus,
                        creatorStatusEmoji = creatorStatusEmoji,
                        partnerId = partnerId.takeIf { it.isNotBlank() },
                        partnerName = partnerName,
                        partnerPhoto = partnerPhoto,
                        partnerStatus = partnerStatus,
                        partnerStatusEmoji = partnerStatusEmoji,
                        startDateMillis = snapshot.getLong("startDateMillis") ?: System.currentTimeMillis(),
                        relationshipName = snapshot.getString("relationshipName") ?: "حكايتنا ❤️",
                        status = snapshot.getString("status") ?: "connected",
                        createdAtMillis = snapshot.getLong("createdAtMillis") ?: System.currentTimeMillis()
                    )
                    onRelationshipUpdate(entity)

                    // Listen to partner profile doc in real time to sync live name/avatar/status updates
                    val partnerUidToListen = if (currentUid.isNotBlank()) {
                        if (currentUid == creatorId) partnerId else creatorId
                    } else {
                        partnerId
                    }

                    if (partnerUidToListen.isNotBlank() && partnerUidToListen != currentListeningPartnerUid) {
                        partnerProfileListener?.remove()
                        currentListeningPartnerUid = partnerUidToListen
                        partnerProfileListener = firestore.collection("users")
                            .document(partnerUidToListen)
                            .addSnapshotListener { userDoc, userErr ->
                                if (userErr == null && userDoc != null && userDoc.exists()) {
                                    val name = userDoc.getString("displayName") ?: userDoc.getString("name") ?: ""
                                    val photo = userDoc.getString("photoUrl") ?: ""
                                    val avatar = userDoc.getString("avatarRes") ?: "avatar_2"
                                    val status = userDoc.getString("dailyStatus") ?: ""
                                    val emoji = userDoc.getString("dailyStatusEmoji") ?: ""
                                    onPartnerProfileUpdate(name, photo, avatar, status, emoji)
                                }
                            }
                    }
                }

            // 2. Realtime Messages Listener
            messagesListener = firestore.collection("relationships")
                .document(relationshipId)
                .collection("messages")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) {
                        return@addSnapshotListener
                    }
                    val list = snapshot.documents.mapNotNull { doc ->
                        val senderId = doc.getString("senderId") ?: doc.getString("senderUid") ?: ""
                        val text = doc.getString("text") ?: doc.getString("message") ?: ""
                        val timestamp = doc.getLong("timestamp") ?: doc.getLong("dateMillis") ?: System.currentTimeMillis()
                        val messageId = doc.getString("messageId") ?: doc.id

                        LoveLetterEntity(
                            firestoreId = messageId,
                            relationshipId = relationshipId,
                            senderUid = senderId,
                            senderName = doc.getString("senderName") ?: "",
                            title = doc.getString("title") ?: "",
                            message = text,
                            dateMillis = timestamp,
                            isRead = doc.getBoolean("isRead") ?: false,
                            themeColorIndex = (doc.getLong("themeColorIndex") ?: 0L).toInt()
                        )
                    }
                    onMessagesUpdate(list)
                }

            // 3. Realtime Memories Listener
            memoriesListener = firestore.collection("relationships")
                .document(relationshipId)
                .collection("memories")
                .orderBy("dateMillis", Query.Direction.DESCENDING)
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) return@addSnapshotListener
                    val list = snapshot.documents.mapNotNull { doc ->
                        MemoryEntity(
                            firestoreId = doc.id,
                            relationshipId = relationshipId,
                            title = doc.getString("title") ?: "",
                            description = doc.getString("description") ?: "",
                            dateMillis = doc.getLong("dateMillis") ?: System.currentTimeMillis(),
                            imageUrl = doc.getString("imageUrl") ?: "",
                            imageDrawableName = doc.getString("imageDrawableName") ?: "",
                            location = doc.getString("location") ?: "",
                            createdByName = doc.getString("createdByName") ?: "",
                            createdByUid = doc.getString("createdByUid") ?: ""
                        )
                    }
                    onMemoriesUpdate(list)
                }

            // 4. Realtime Goals Listener
            goalsListener = firestore.collection("relationships")
                .document(relationshipId)
                .collection("goals")
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) return@addSnapshotListener
                    val list = snapshot.documents.mapNotNull { doc ->
                        GoalEntity(
                            firestoreId = doc.id,
                            relationshipId = relationshipId,
                            title = doc.getString("title") ?: "",
                            description = doc.getString("description") ?: "",
                            progress = (doc.getLong("progress") ?: 0L).toInt(),
                            isCompleted = doc.getBoolean("isCompleted") ?: false,
                            targetDate = doc.getString("targetDate") ?: "",
                            category = doc.getString("category") ?: "Life & Romance"
                        )
                    }
                    onGoalsUpdate(list)
                }

            // 5. Realtime Notes Listener
            notesListener = firestore.collection("relationships")
                .document(relationshipId)
                .collection("notes")
                .orderBy("updatedAtMillis", Query.Direction.DESCENDING)
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) return@addSnapshotListener
                    val list = snapshot.documents.mapNotNull { doc ->
                        NoteEntity(
                            firestoreId = doc.id,
                            relationshipId = relationshipId,
                            title = doc.getString("title") ?: "",
                            content = doc.getString("content") ?: "",
                            category = doc.getString("category") ?: "General",
                            authorName = doc.getString("authorName") ?: "",
                            authorUid = doc.getString("authorUid") ?: "",
                            updatedAtMillis = doc.getLong("updatedAtMillis") ?: System.currentTimeMillis()
                        )
                    }
                    onNotesUpdate(list)
                }

        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Could not start Firestore listeners: ${e.message}")
        }
    }

    // --- Send Message / Letter Online ---
    suspend fun sendMessageOnline(relId: String, letter: LoveLetterEntity) {
        try {
            val messageId = letter.firestoreId.ifBlank { UUID.randomUUID().toString() }
            val messageData = hashMapOf(
                "messageId" to messageId,
                "senderId" to letter.senderUid,
                "senderName" to letter.senderName,
                "text" to letter.message,
                "timestamp" to letter.dateMillis,
                "title" to letter.title,
                "themeColorIndex" to letter.themeColorIndex,
                "isRead" to false
            )
            firestore.collection("relationships").document(relId)
                .collection("messages").document(messageId)
                .set(messageData).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error sending message online: ${e.message}")
        }
    }

    suspend fun deleteMessageOnline(relId: String, messageId: String) {
        try {
            firestore.collection("relationships").document(relId)
                .collection("messages").document(messageId).delete().await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error deleting message online: ${e.message}")
        }
    }

    suspend fun addMemoryOnline(relId: String, memory: MemoryEntity) {
        try {
            val docId = memory.firestoreId.ifBlank { UUID.randomUUID().toString() }
            val data = hashMapOf(
                "id" to docId,
                "title" to memory.title,
                "description" to memory.description,
                "dateMillis" to memory.dateMillis,
                "imageUrl" to memory.imageUrl,
                "imageDrawableName" to memory.imageDrawableName,
                "location" to memory.location,
                "createdByName" to memory.createdByName,
                "createdByUid" to memory.createdByUid,
                "createdAtMillis" to memory.createdAtMillis
            )
            firestore.collection("relationships").document(relId)
                .collection("memories").document(docId).set(data).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error adding memory online: ${e.message}")
        }
    }

    suspend fun deleteMemoryOnline(relId: String, memoryId: String) {
        try {
            firestore.collection("relationships").document(relId)
                .collection("memories").document(memoryId).delete().await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error deleting memory online: ${e.message}")
        }
    }

    suspend fun addGoalOnline(relId: String, goal: GoalEntity) {
        try {
            val docId = goal.firestoreId.ifBlank { UUID.randomUUID().toString() }
            val data = hashMapOf(
                "id" to docId,
                "title" to goal.title,
                "description" to goal.description,
                "progress" to goal.progress,
                "isCompleted" to goal.isCompleted,
                "targetDate" to goal.targetDate,
                "category" to goal.category
            )
            firestore.collection("relationships").document(relId).collection("goals").document(docId).set(data).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error adding goal online: ${e.message}")
        }
    }

    suspend fun updateGoalOnline(relId: String, goalId: String, progress: Int, isCompleted: Boolean) {
        try {
            val updates = mapOf(
                "progress" to progress,
                "isCompleted" to isCompleted
            )
            firestore.collection("relationships").document(relId).collection("goals").document(goalId).update(updates).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error updating goal online: ${e.message}")
        }
    }

    suspend fun deleteGoalOnline(relId: String, goalId: String) {
        try {
            firestore.collection("relationships").document(relId).collection("goals").document(goalId).delete().await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error deleting goal online: ${e.message}")
        }
    }

    suspend fun addNoteOnline(relId: String, note: NoteEntity) {
        try {
            val docId = note.firestoreId.ifBlank { UUID.randomUUID().toString() }
            val data = hashMapOf(
                "id" to docId,
                "title" to note.title,
                "content" to note.content,
                "category" to note.category,
                "authorName" to note.authorName,
                "authorUid" to note.authorUid,
                "updatedAtMillis" to note.updatedAtMillis
            )
            firestore.collection("relationships").document(relId).collection("notes").document(docId).set(data).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error adding note online: ${e.message}")
        }
    }

    suspend fun deleteNoteOnline(relId: String, noteId: String) {
        try {
            firestore.collection("relationships").document(relId).collection("notes").document(noteId).delete().await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error deleting note online: ${e.message}")
        }
    }

    suspend fun updateRelationshipDetailsOnline(relId: String, name: String, startDateMillis: Long) {
        try {
            val updates = mapOf(
                "relationshipName" to name,
                "startDateMillis" to startDateMillis,
                "updatedAtMillis" to System.currentTimeMillis()
            )
            firestore.collection("relationships").document(relId).update(updates).await()
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error updating relationship online: ${e.message}")
        }
    }

    suspend fun updateUserStatusOnline(
        uid: String,
        relId: String?,
        isCreator: Boolean,
        status: String,
        statusEmoji: String
    ) {
        try {
            val userUpdates = mapOf(
                "dailyStatus" to status,
                "dailyStatusEmoji" to statusEmoji,
                "statusUpdatedAtMillis" to System.currentTimeMillis()
            )
            firestore.collection("users").document(uid).set(userUpdates, SetOptions.merge()).await()

            if (!relId.isNullOrBlank()) {
                val relUpdates = if (isCreator) {
                    mapOf(
                        "creatorStatus" to status,
                        "creatorStatusEmoji" to statusEmoji
                    )
                } else {
                    mapOf(
                        "partnerStatus" to status,
                        "partnerStatusEmoji" to statusEmoji
                    )
                }
                firestore.collection("relationships").document(relId).update(relUpdates).await()
            }
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error updating status online: ${e.message}")
        }
    }

    suspend fun updateUserProfileOnline(
        uid: String,
        name: String,
        avatarRes: String,
        photoUrl: String,
        relId: String? = null,
        isCreator: Boolean = false
    ) {
        try {
            val userUpdates = mapOf(
                "displayName" to name,
                "name" to name,
                "avatarRes" to avatarRes,
                "photoUrl" to photoUrl,
                "updatedAtMillis" to System.currentTimeMillis()
            )
            firestore.collection("users").document(uid).set(userUpdates, SetOptions.merge()).await()

            if (!relId.isNullOrBlank()) {
                val relUpdates = if (isCreator) {
                    mapOf(
                        "creatorName" to name,
                        "creatorPhoto" to photoUrl.ifEmpty { avatarRes }
                    )
                } else {
                    mapOf(
                        "partnerName" to name,
                        "partnerPhoto" to photoUrl.ifEmpty { avatarRes }
                    )
                }
                firestore.collection("relationships").document(relId).update(relUpdates).await()
            }
        } catch (e: Exception) {
            Log.w("FirebaseLoveService", "Error updating profile online: ${e.message}")
        }
    }

    fun stopAllListeners() {
        relationshipListener?.remove()
        relationshipListener = null
        partnerProfileListener?.remove()
        partnerProfileListener = null
        currentListeningPartnerUid = null
        messagesListener?.remove()
        messagesListener = null
        memoriesListener?.remove()
        memoriesListener = null
        goalsListener?.remove()
        goalsListener = null
        notesListener?.remove()
        notesListener = null
    }
}
