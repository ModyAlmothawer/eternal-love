package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.util.Log
import com.example.R
import com.example.data.local.LoveDao
import com.example.data.model.AchievementItem
import com.example.data.model.GoalEntity
import com.example.data.model.LoveLetterEntity
import com.example.data.model.MemoryEntity
import com.example.data.model.NoteEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.RelationshipEntity
import com.example.data.model.SpecialDateEntity
import com.example.data.model.UserEntity
import com.example.data.remote.FirebaseLoveService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Random

class LoveRepository(
    private val loveDao: LoveDao,
    context: Context
) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("hikaytna_love_prefs", Context.MODE_PRIVATE)

    private val firebaseService = FirebaseLoveService()
    private val repoScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _currentUserId = MutableStateFlow<Long?>(
        prefs.getLong("saved_user_id", -1L).takeIf { it != -1L }
    )
    val currentUserId = _currentUserId.asStateFlow()

    private val _isDarkMode = MutableStateFlow(prefs.getBoolean("pref_dark_mode", true))
    val isDarkMode = _isDarkMode.asStateFlow()

    private val _currentLanguage = MutableStateFlow(prefs.getString("pref_language", "ar") ?: "ar")
    val currentLanguage = _currentLanguage.asStateFlow()

    val currentUserFlow: Flow<UserEntity?> = _currentUserId.flatMapLatest { id ->
        if (id != null) loveDao.getUserByIdFlow(id) else flowOf(null)
    }.distinctUntilChanged()

    val currentRelationshipFlow: Flow<RelationshipEntity?> = currentUserFlow.flatMapLatest { user ->
        val relFirestoreId = user?.connectedRelationshipId
        val localRelId = user?.localRelationshipId
        when {
            !relFirestoreId.isNullOrBlank() -> loveDao.getRelationshipByFirestoreIdFlow(relFirestoreId)
            localRelId != null -> loveDao.getRelationshipFlow(localRelId)
            else -> flowOf(null)
        }
    }.distinctUntilChanged()

    init {
        // Start real-time sync for current user if connected
        repoScope.launch {
            currentUserFlow.collect { user ->
                val relId = user?.connectedRelationshipId
                if (!relId.isNullOrBlank()) {
                    startRealtimeSync(relId, user.firebaseUid)
                }
            }
        }
    }

    suspend fun setDarkMode(enabled: Boolean) {
        prefs.edit().putBoolean("pref_dark_mode", enabled).apply()
        _isDarkMode.value = enabled
    }

    suspend fun setLanguage(lang: String) {
        prefs.edit().putString("pref_language", lang).apply()
        _currentLanguage.value = lang
    }

    suspend fun registerUser(name: String, email: String, pass: String): Result<UserEntity> =
        withContext(Dispatchers.IO) {
            val cleanEmail = email.trim().lowercase()
            val existing = loveDao.getUserByEmail(cleanEmail)
            if (existing != null) {
                return@withContext Result.failure(Exception("البريد الإلكتروني مسجل بالفعل"))
            }

            val firebaseUid = firebaseService.registerWithFirebase(cleanEmail, pass)
                ?: "local_${System.currentTimeMillis()}"

            val newUser = UserEntity(
                firebaseUid = firebaseUid,
                name = name.trim(),
                email = cleanEmail,
                passwordHash = pass,
                avatarRes = "avatar_1"
            )
            val userId = loveDao.insertUser(newUser)
            val createdUser = newUser.copy(id = userId)
            prefs.edit().putLong("saved_user_id", userId).apply()
            _currentUserId.value = userId

            // Sync user profile to Firestore
            firebaseService.syncUserProfileOnline(
                uid = firebaseUid,
                name = name.trim(),
                email = cleanEmail,
                avatarRes = "avatar_1"
            )

            Result.success(createdUser)
        }

    suspend fun loginUser(email: String, pass: String): Result<UserEntity> =
        withContext(Dispatchers.IO) {
            val cleanEmail = email.trim().lowercase()
            val firebaseUid = firebaseService.loginWithFirebase(cleanEmail, pass)

            var user = loveDao.getUserByEmail(cleanEmail)
            if (user == null) {
                if (firebaseUid != null) {
                    // Fetch profile from Firestore if it exists
                    val onlineProfile = firebaseService.fetchUserProfileOnline(firebaseUid)
                    val onlineName = (onlineProfile?.get("displayName") as? String)
                        ?: cleanEmail.substringBefore("@").replaceFirstChar { it.uppercase() }
                    val onlineAvatar = (onlineProfile?.get("avatarRes") as? String) ?: "avatar_1"
                    val onlinePhoto = (onlineProfile?.get("photoUrl") as? String) ?: ""
                    val onlineRelId = onlineProfile?.get("relationshipId") as? String

                    val newUser = UserEntity(
                        firebaseUid = firebaseUid,
                        name = onlineName,
                        email = cleanEmail,
                        passwordHash = pass,
                        avatarRes = onlineAvatar,
                        photoUrl = onlinePhoto,
                        connectedRelationshipId = onlineRelId,
                        isConnected = !onlineRelId.isNullOrBlank()
                    )
                    val id = loveDao.insertUser(newUser)
                    user = newUser.copy(id = id)
                } else {
                    return@withContext Result.failure(Exception("المستخدم غير موجود. يرجى التأكد من البيانات"))
                }
            } else if (user.passwordHash.isNotEmpty() && user.passwordHash != pass && firebaseUid == null) {
                return@withContext Result.failure(Exception("كلمة المرور غير صحيحة"))
            }

            prefs.edit().putLong("saved_user_id", user.id).apply()
            _currentUserId.value = user.id

            user.connectedRelationshipId?.let { relId ->
                if (relId.isNotBlank()) {
                    startRealtimeSync(relId, user.firebaseUid)
                }
            }

            Result.success(user)
        }

    suspend fun sendPasswordResetEmail(email: String): Result<Unit> = withContext(Dispatchers.IO) {
        if (email.isBlank()) {
            return@withContext Result.failure(Exception("يرجى إدخال البريد الإلكتروني"))
        }
        firebaseService.sendPasswordResetEmail(email)
    }

    fun logout() {
        firebaseService.signOut()
        prefs.edit().remove("saved_user_id").apply()
        _currentUserId.value = null
    }

    suspend fun updateUserProfile(name: String, avatarRes: String, photoUrl: String = "") = withContext(Dispatchers.IO) {
        val userId = _currentUserId.value ?: return@withContext
        val user = loveDao.getUserById(userId) ?: return@withContext
        val updatedUser = user.copy(name = name.trim(), avatarRes = avatarRes, photoUrl = photoUrl)
        loveDao.updateUser(updatedUser)

        val relFirestoreId = user.connectedRelationshipId
        var isCreator = false
        if (!relFirestoreId.isNullOrBlank()) {
            val rel = loveDao.getRelationshipByFirestoreId(relFirestoreId)
            if (rel != null) {
                isCreator = (rel.creatorId == user.firebaseUid)
                val updatedRel = if (isCreator) {
                    rel.copy(creatorName = name.trim(), creatorPhoto = photoUrl.ifEmpty { avatarRes })
                } else {
                    rel.copy(partnerName = name.trim(), partnerPhoto = photoUrl.ifEmpty { avatarRes })
                }
                loveDao.updateRelationship(updatedRel)
            }
        }

        // Sync to Firestore
        if (user.firebaseUid.isNotBlank()) {
            firebaseService.updateUserProfileOnline(
                uid = user.firebaseUid,
                name = name.trim(),
                avatarRes = avatarRes,
                photoUrl = photoUrl,
                relId = relFirestoreId,
                isCreator = isCreator
            )
        }
    }

    suspend fun uploadProfileImage(imageUri: Uri): String? = withContext(Dispatchers.IO) {
        val userId = _currentUserId.value ?: return@withContext null
        val user = loveDao.getUserById(userId) ?: return@withContext null
        if (user.firebaseUid.isBlank()) return@withContext null

        val photoUrl = firebaseService.uploadProfileImage(user.firebaseUid, imageUri)
        if (!photoUrl.isNullOrBlank()) {
            updateUserProfile(user.name, user.avatarRes, photoUrl)
        }
        photoUrl
    }

    // --- Relationship Creation & Connection ---
    suspend fun createRelationship(
        startDateMillis: Long = System.currentTimeMillis()
    ): Result<Pair<RelationshipEntity, String>> = withContext(Dispatchers.IO) {
        val userId = _currentUserId.value ?: return@withContext Result.failure(Exception("لم يتم تسجيل الدخول"))
        val user = loveDao.getUserById(userId) ?: return@withContext Result.failure(Exception("المستخدم غير موجود"))

        val code = generateUnique6DigitCode()
        val creatorUid = if (user.firebaseUid.isNotBlank()) user.firebaseUid else "user_$userId"
        val creatorPhoto = user.photoUrl.ifEmpty { user.avatarRes }

        // Create on Firestore
        val firestoreRelId = firebaseService.createFirestoreRelationship(
            creatorUid = creatorUid,
            creatorName = user.name,
            creatorPhoto = creatorPhoto,
            startDateMillis = startDateMillis,
            code = code
        )

        val relationship = RelationshipEntity(
            firestoreId = firestoreRelId,
            code = code,
            creatorId = creatorUid,
            creatorName = user.name,
            creatorPhoto = creatorPhoto,
            partnerName = "بانتظار الشريك...",
            partnerPhoto = "avatar_2",
            startDateMillis = startDateMillis,
            relationshipName = "حكايتنا ❤️",
            status = "pending"
        )
        val relLocalId = loveDao.insertRelationship(relationship)
        val savedRel = relationship.copy(id = relLocalId)

        val updatedUser = user.copy(
            relationshipCode = code,
            connectedRelationshipId = firestoreRelId,
            localRelationshipId = relLocalId,
            isConnected = true
        )
        loveDao.updateUser(updatedUser)

        startRealtimeSync(firestoreRelId, user.firebaseUid)
        seedStarterContent(firestoreRelId, user.name, startDateMillis)

        Result.success(Pair(savedRel, code))
    }

    suspend fun joinRelationship(code: String): Result<RelationshipEntity> =
        withContext(Dispatchers.IO) {
            val userId = _currentUserId.value ?: return@withContext Result.failure(Exception("لم يتم تسجيل الدخول"))
            val user = loveDao.getUserById(userId) ?: return@withContext Result.failure(Exception("المستخدم غير موجود"))

            val cleanCode = code.trim()
            val userUid = if (user.firebaseUid.isNotBlank()) user.firebaseUid else "user_$userId"
            val userPhoto = user.photoUrl.ifEmpty { user.avatarRes }

            try {
                val joinResult = firebaseService.joinFirestoreRelationship(
                    code = cleanCode,
                    partnerUid = userUid,
                    partnerName = user.name,
                    partnerPhoto = userPhoto
                )
                if (joinResult == null) {
                    return@withContext Result.failure(Exception("كود الدعوة غير صالح أو غير موجود"))
                }

                val (relId, data) = joinResult
                val creatorUid = data["creatorUid"] as? String ?: ""
                val creatorName = data["creatorName"] as? String ?: "حبيبي"
                val creatorPhoto = data["creatorPhoto"] as? String ?: "avatar_1"
                val startDateMillis = (data["startDateMillis"] as? Long) ?: System.currentTimeMillis()
                val relName = data["relationshipName"] as? String ?: "$creatorName ❤️ ${user.name}"

                val relationship = RelationshipEntity(
                    firestoreId = relId,
                    code = cleanCode,
                    creatorId = creatorUid,
                    creatorName = creatorName,
                    creatorPhoto = creatorPhoto,
                    partnerId = userUid,
                    partnerName = user.name,
                    partnerPhoto = userPhoto,
                    startDateMillis = startDateMillis,
                    relationshipName = relName,
                    status = "connected"
                )
                val localId = loveDao.insertRelationship(relationship)

                val updatedUser = user.copy(
                    partnerName = creatorName,
                    partnerUid = creatorUid,
                    partnerPhotoUrl = creatorPhoto,
                    relationshipCode = cleanCode,
                    connectedRelationshipId = relId,
                    localRelationshipId = localId,
                    isConnected = true
                )
                loveDao.updateUser(updatedUser)

                startRealtimeSync(relId, user.firebaseUid)

                Result.success(relationship.copy(id = localId))
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    private fun startRealtimeSync(relationshipId: String, currentUid: String) {
        firebaseService.startRealtimeListeners(
            relationshipId = relationshipId,
            currentUid = currentUid,
            onRelationshipUpdate = { rel ->
                repoScope.launch {
                    val existing = loveDao.getRelationshipByFirestoreId(rel.firestoreId)
                    val relLocalId = if (existing != null) {
                        loveDao.updateRelationship(rel.copy(id = existing.id))
                        existing.id
                    } else {
                        loveDao.insertRelationship(rel)
                    }

                    // Update user's partner info if it changed
                    val currentUserIdVal = _currentUserId.value
                    if (currentUserIdVal != null) {
                        val currentUser = loveDao.getUserById(currentUserIdVal)
                        if (currentUser != null) {
                            val isCreator = (rel.creatorId == currentUser.firebaseUid)
                            val newPartnerName = if (isCreator) rel.partnerName else rel.creatorName
                            val newPartnerPhoto = if (isCreator) rel.partnerPhoto else rel.creatorPhoto
                            val newPartnerUid = if (isCreator) (rel.partnerId ?: "") else rel.creatorId

                            if (newPartnerName.isNotBlank() && (currentUser.partnerName != newPartnerName || currentUser.partnerPhotoUrl != newPartnerPhoto)) {
                                loveDao.updateUser(
                                    currentUser.copy(
                                        partnerName = newPartnerName,
                                        partnerUid = newPartnerUid,
                                        partnerPhotoUrl = newPartnerPhoto,
                                        isConnected = true,
                                        localRelationshipId = relLocalId
                                    )
                                )
                            }
                        }
                    }
                }
            },
            onPartnerProfileUpdate = { name, photo, avatar ->
                repoScope.launch {
                    val currentUserIdVal = _currentUserId.value ?: return@launch
                    val currentUser = loveDao.getUserById(currentUserIdVal) ?: return@launch
                    val updatedPartnerPhoto = photo.ifEmpty { avatar }
                    if (name.isNotBlank() || updatedPartnerPhoto.isNotBlank()) {
                        loveDao.updateUser(
                            currentUser.copy(
                                partnerName = name.ifEmpty { currentUser.partnerName },
                                partnerPhotoUrl = updatedPartnerPhoto
                            )
                        )
                    }
                }
            },
            onLettersUpdate = { letters ->
                repoScope.launch {
                    loveDao.insertLoveLetters(letters)
                }
            },
            onMemoriesUpdate = { memories ->
                repoScope.launch {
                    loveDao.insertMemories(memories)
                }
            },
            onGoalsUpdate = { goals ->
                repoScope.launch {
                    loveDao.insertGoals(goals)
                }
            },
            onNotesUpdate = { notes ->
                repoScope.launch {
                    loveDao.insertNotes(notes)
                }
            }
        )
    }

    suspend fun disconnectRelationship(): Result<Unit> = withContext(Dispatchers.IO) {
        val userId = _currentUserId.value ?: return@withContext Result.failure(Exception("لم يتم تسجيل الدخول"))
        val user = loveDao.getUserById(userId) ?: return@withContext Result.failure(Exception("المستخدم غير موجود"))
        val relFirestoreId = user.connectedRelationshipId ?: ""
        val localId = user.localRelationshipId ?: 0L

        firebaseService.stopAllListeners()

        val updatedUser = user.copy(
            connectedRelationshipId = null,
            localRelationshipId = null,
            isConnected = false,
            relationshipCode = "",
            partnerName = "",
            partnerUid = "",
            partnerPhotoUrl = ""
        )
        loveDao.updateUser(updatedUser)
        loveDao.deleteRelationship(localId, relFirestoreId)
        Result.success(Unit)
    }

    suspend fun updateRelationshipDetails(name: String, startDateMillis: Long) =
        withContext(Dispatchers.IO) {
            val user = _currentUserId.value?.let { loveDao.getUserById(it) } ?: return@withContext
            val relId = user.connectedRelationshipId ?: return@withContext
            val rel = loveDao.getRelationshipByFirestoreId(relId) ?: return@withContext

            val updated = rel.copy(
                relationshipName = name,
                startDateMillis = startDateMillis
            )
            loveDao.updateRelationship(updated)
            firebaseService.updateRelationshipDetailsOnline(relId, name, startDateMillis)
        }

    // Memories
    fun getMemories(relationshipId: String): Flow<List<MemoryEntity>> =
        loveDao.getMemoriesFlow(relationshipId)

    suspend fun addMemory(
        relationshipId: String,
        title: String,
        description: String,
        dateMillis: Long,
        imageDrawable: String,
        location: String,
        authorName: String
    ) = withContext(Dispatchers.IO) {
        val user = _currentUserId.value?.let { loveDao.getUserById(it) }
        val memory = MemoryEntity(
            relationshipId = relationshipId,
            title = title,
            description = description,
            dateMillis = dateMillis,
            imageDrawableName = imageDrawable,
            location = location,
            createdByName = authorName,
            createdByUid = user?.firebaseUid ?: ""
        )
        loveDao.insertMemory(memory)
        firebaseService.addMemoryOnline(relationshipId, memory)
    }

    suspend fun deleteMemory(id: Long, firestoreId: String = "") = withContext(Dispatchers.IO) {
        loveDao.deleteMemory(id, firestoreId)
    }

    // Love Letters
    fun getLoveLetters(relationshipId: String): Flow<List<LoveLetterEntity>> =
        loveDao.getLoveLettersFlow(relationshipId)

    suspend fun sendLoveLetter(
        relationshipId: String,
        senderName: String,
        title: String,
        message: String,
        themeIndex: Int
    ) = withContext(Dispatchers.IO) {
        val user = _currentUserId.value?.let { loveDao.getUserById(it) }
        val letter = LoveLetterEntity(
            relationshipId = relationshipId,
            senderUid = user?.firebaseUid ?: "",
            senderName = senderName,
            title = title,
            message = message,
            themeColorIndex = themeIndex
        )
        loveDao.insertLoveLetter(letter)
        firebaseService.sendLetterOnline(relationshipId, letter)
    }

    suspend fun markLetterRead(id: Long, firestoreId: String = "") = withContext(Dispatchers.IO) {
        loveDao.markLoveLetterAsRead(id, firestoreId)
    }

    suspend fun deleteLetter(id: Long, firestoreId: String = "") = withContext(Dispatchers.IO) {
        loveDao.deleteLoveLetter(id, firestoreId)
    }

    // Notes
    fun getNotes(relationshipId: String): Flow<List<NoteEntity>> =
        loveDao.getNotesFlow(relationshipId)

    suspend fun addNote(
        relationshipId: String,
        title: String,
        content: String,
        category: String,
        authorName: String
    ) = withContext(Dispatchers.IO) {
        val user = _currentUserId.value?.let { loveDao.getUserById(it) }
        val note = NoteEntity(
            relationshipId = relationshipId,
            title = title,
            content = content,
            category = category,
            authorName = authorName,
            authorUid = user?.firebaseUid ?: ""
        )
        loveDao.insertNote(note)
        firebaseService.addNoteOnline(relationshipId, note)
    }

    suspend fun deleteNote(id: Long, firestoreId: String = "") = withContext(Dispatchers.IO) {
        loveDao.deleteNote(id, firestoreId)
    }

    // Goals
    fun getGoals(relationshipId: String): Flow<List<GoalEntity>> =
        loveDao.getGoalsFlow(relationshipId)

    suspend fun addGoal(
        relationshipId: String,
        title: String,
        description: String,
        targetDate: String,
        category: String
    ) = withContext(Dispatchers.IO) {
        val goal = GoalEntity(
            relationshipId = relationshipId,
            title = title,
            description = description,
            targetDate = targetDate,
            category = category
        )
        loveDao.insertGoal(goal)
        firebaseService.addGoalOnline(relationshipId, goal)
    }

    suspend fun updateGoalProgress(goal: GoalEntity, progress: Int, completed: Boolean) =
        withContext(Dispatchers.IO) {
            val updated = goal.copy(progress = progress, isCompleted = completed)
            loveDao.updateGoal(updated)
            if (goal.firestoreId.isNotBlank()) {
                firebaseService.updateGoalOnline(goal.relationshipId, goal.firestoreId, progress, completed)
            }
        }

    suspend fun deleteGoal(id: Long, firestoreId: String = "") = withContext(Dispatchers.IO) {
        loveDao.deleteGoal(id, firestoreId)
    }

    // Special Dates
    fun getSpecialDates(relationshipId: String): Flow<List<SpecialDateEntity>> =
        loveDao.getSpecialDatesFlow(relationshipId)

    suspend fun addSpecialDate(relationshipId: String, title: String, dateMillis: Long, type: String) =
        withContext(Dispatchers.IO) {
            loveDao.insertSpecialDate(
                SpecialDateEntity(
                    relationshipId = relationshipId,
                    title = title,
                    dateMillis = dateMillis,
                    type = type
                )
            )
        }

    suspend fun deleteSpecialDate(id: Long) = withContext(Dispatchers.IO) {
        loveDao.deleteSpecialDate(id)
    }

    // Notifications
    fun getNotifications(relationshipId: String): Flow<List<NotificationEntity>> =
        loveDao.getNotificationsFlow(relationshipId)

    // Dynamic Achievements Engine
    fun computeAchievements(
        startDateMillis: Long,
        lettersCount: Int,
        memoriesCount: Int,
        goalsCount: Int
    ): List<AchievementItem> {
        val now = System.currentTimeMillis()
        val diffDays = maxOf(0L, (now - startDateMillis) / (1000L * 60 * 60 * 24))

        return listOf(
            AchievementItem(
                id = "day_1",
                titleRes = R.string.achievement_first_day,
                descRes = R.string.achievement_first_day_desc,
                isUnlocked = diffDays >= 1,
                progressPercent = if (diffDays >= 1) 1f else 0.5f,
                icon = "favorite"
            ),
            AchievementItem(
                id = "day_7",
                titleRes = R.string.achievement_7_days,
                descRes = R.string.achievement_7_days_desc,
                isUnlocked = diffDays >= 7,
                progressPercent = (diffDays.toFloat() / 7f).coerceIn(0f, 1f),
                icon = "local_florist"
            ),
            AchievementItem(
                id = "day_30",
                titleRes = R.string.achievement_30_days,
                descRes = R.string.achievement_30_days_desc,
                isUnlocked = diffDays >= 30,
                progressPercent = (diffDays.toFloat() / 30f).coerceIn(0f, 1f),
                icon = "favorite_border"
            ),
            AchievementItem(
                id = "day_100",
                titleRes = R.string.achievement_100_days,
                descRes = R.string.achievement_100_days_desc,
                isUnlocked = diffDays >= 100,
                progressPercent = (diffDays.toFloat() / 100f).coerceIn(0f, 1f),
                icon = "celebration"
            ),
            AchievementItem(
                id = "year_1",
                titleRes = R.string.achievement_1_year,
                descRes = R.string.achievement_1_year_desc,
                isUnlocked = diffDays >= 365,
                progressPercent = (diffDays.toFloat() / 365f).coerceIn(0f, 1f),
                icon = "workspace_premium"
            ),
            AchievementItem(
                id = "year_2",
                titleRes = R.string.achievement_2_years,
                descRes = R.string.achievement_2_years_desc,
                isUnlocked = diffDays >= 730,
                progressPercent = (diffDays.toFloat() / 730f).coerceIn(0f, 1f),
                icon = "stars"
            ),
            AchievementItem(
                id = "first_letter",
                titleRes = R.string.achievement_first_letter,
                descRes = R.string.achievement_first_letter_desc,
                isUnlocked = lettersCount > 0,
                progressPercent = if (lettersCount > 0) 1f else 0f,
                icon = "mail"
            ),
            AchievementItem(
                id = "first_memory",
                titleRes = R.string.achievement_first_memory,
                descRes = R.string.achievement_first_memory_desc,
                isUnlocked = memoriesCount > 0,
                progressPercent = if (memoriesCount > 0) 1f else 0f,
                icon = "photo_library"
            ),
            AchievementItem(
                id = "first_goal",
                titleRes = R.string.achievement_first_goal,
                descRes = R.string.achievement_first_goal_desc,
                isUnlocked = goalsCount > 0,
                progressPercent = if (goalsCount > 0) 1f else 0f,
                icon = "flag"
            )
        )
    }

    private fun generateUnique6DigitCode(): String {
        val rand = Random()
        val num = 100000 + rand.nextInt(900000)
        return num.toString()
    }

    private suspend fun seedStarterContent(
        relId: String,
        userName: String,
        startDateMillis: Long
    ) {
        val initialLetter = LoveLetterEntity(
            relationshipId = relId,
            senderName = userName,
            title = "بداية حكايتنا الجميلة ❤️",
            message = "أهلاً بك في عالمنا الخاص. كل نبضة في قلبي تشهد أن حكايتنا هي أجمل ما حدث لي في هذا الكون.",
            dateMillis = startDateMillis,
            themeColorIndex = 0
        )
        loveDao.insertLoveLetter(initialLetter)

        val initialMemory = MemoryEntity(
            relationshipId = relId,
            title = "اليوم الذي التقت فيه قلوبنا",
            description = "لحظة البداية، بداية كل شيء جميل في حياتنا.",
            dateMillis = startDateMillis,
            location = "أجمل مكان جمعنا",
            createdByName = userName,
            imageDrawableName = "img_memory_default"
        )
        loveDao.insertMemory(initialMemory)

        val initialGoal = GoalEntity(
            relationshipId = relId,
            title = "رحلة الأحلام معاً",
            description = "السفر إلى مدينتنا المفضلة وصنع ذكريات جديدة لا تُنسى",
            progress = 35,
            isCompleted = false,
            targetDate = "2026",
            category = "سفر ورومانسية"
        )
        loveDao.insertGoal(initialGoal)

        val initialNote = NoteEntity(
            relationshipId = relId,
            title = "أشياء تسعد قلبك",
            content = "1. الابتسامة الصباحية\n2. القهوة المفضلة\n3. الحديث معك قبل النوم",
            category = "خواطر",
            authorName = userName
        )
        loveDao.insertNote(initialNote)

        val anniversary = SpecialDateEntity(
            relationshipId = relId,
            title = "ذكرى بداية حكايتنا السنوية",
            dateMillis = startDateMillis,
            type = "ذكرى سنوية"
        )
        loveDao.insertSpecialDate(anniversary)
    }
}
