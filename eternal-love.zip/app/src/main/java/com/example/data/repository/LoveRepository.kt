package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.local.LoveDao
import com.example.data.model.GoalEntity
import com.example.data.model.LoveLetterEntity
import com.example.data.model.MemoryEntity
import com.example.data.model.NoteEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.RelationshipEntity
import com.example.data.model.SpecialDateEntity
import com.example.data.model.UserEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.withContext
import java.util.Random

class LoveRepository(
    private val loveDao: LoveDao,
    context: Context
) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("eternal_love_prefs", Context.MODE_PRIVATE)

    private val _currentUserId = MutableStateFlow<Long?>(
        prefs.getLong("saved_user_id", -1L).takeIf { it != -1L }
    )
    val currentUserId = _currentUserId.asStateFlow()

    private val _isDarkMode = MutableStateFlow(prefs.getBoolean("pref_dark_mode", true))
    val isDarkMode = _isDarkMode.asStateFlow()

    private val _currentLanguage = MutableStateFlow(prefs.getString("pref_language", "ar") ?: "ar")
    val currentLanguage = _currentLanguage.asStateFlow()

    val currentUserFlow: Flow<UserEntity?> = _currentUserId.flatMapLatest { id ->
        if (id != null) loveDao.getUserByIdFlow(id) else flowOf(null)
    }.distinctUntilChanged()

    val currentRelationshipFlow: Flow<RelationshipEntity?> = currentUserFlow.flatMapLatest { user ->
        val relId = user?.connectedRelationshipId
        if (relId != null) loveDao.getRelationshipFlow(relId) else flowOf(null)
    }.distinctUntilChanged()

    suspend fun setDarkMode(enabled: Boolean) {
        prefs.edit().putBoolean("pref_dark_mode", enabled).apply()
        _isDarkMode.value = enabled
    }

    suspend fun setLanguage(lang: String) {
        prefs.edit().putString("pref_language", lang).apply()
        _currentLanguage.value = lang
    }

    suspend fun registerUser(name: String, email: String, pass: String): Result<UserEntity> =
        withContext(Dispatchers.IO) {
            val existing = loveDao.getUserByEmail(email.trim().lowercase())
            if (existing != null) {
                return@withContext Result.failure(Exception("Email already registered"))
            }

            val newUser = UserEntity(
                name = name.trim(),
                email = email.trim().lowercase(),
                passwordHash = pass // Simple secure storage in Room
            )
            val userId = loveDao.insertUser(newUser)
            val createdUser = newUser.copy(id = userId)
            prefs.edit().putLong("saved_user_id", userId).apply()
            _currentUserId.value = userId
            Result.success(createdUser)
        }

    suspend fun loginUser(email: String, pass: String): Result<UserEntity> =
        withContext(Dispatchers.IO) {
            val user = loveDao.getUserByEmail(email.trim().lowercase())
                ?: return@withContext Result.failure(Exception("User not found"))

            if (user.passwordHash != pass) {
                return@withContext Result.failure(Exception("Incorrect password"))
            }

            prefs.edit().putLong("saved_user_id", user.id).apply()
            _currentUserId.value = user.id
            Result.success(user)
        }

    fun logout() {
        prefs.edit().remove("saved_user_id").apply()
        _currentUserId.value = null
    }

    suspend fun updateUserProfile(name: String, avatarRes: String) = withContext(Dispatchers.IO) {
        val userId = _currentUserId.value ?: return@withContext
        val user = loveDao.getUserById(userId) ?: return@withContext
        val updatedUser = user.copy(name = name, avatarRes = avatarRes)
        loveDao.updateUser(updatedUser)

        val relId = user.connectedRelationshipId
        if (relId != null) {
            val rel = loveDao.getRelationshipById(relId)
            if (rel != null) {
                val updatedRel = if (rel.creatorId == userId) {
                    rel.copy(creatorName = name)
                } else {
                    rel.copy(partnerName = name)
                }
                loveDao.updateRelationship(updatedRel)
            }
        }
    }

    // Relationship Creation & Connection
    suspend fun createRelationship(partnerName: String): Result<Pair<RelationshipEntity, String>> =
        withContext(Dispatchers.IO) {
            val userId = _currentUserId.value ?: return@withContext Result.failure(Exception("Not logged in"))
            val user = loveDao.getUserById(userId) ?: return@withContext Result.failure(Exception("User not found"))

            val code = generateUnique6DigitCode()
            // Default start date 2 years and 4 months ago for full realistic counter visualization
            val twoYearsAgo = System.currentTimeMillis() - (1000L * 60 * 60 * 24 * 860)

            val relationship = RelationshipEntity(
                code = code,
                creatorId = userId,
                creatorName = user.name,
                partnerName = partnerName.trim(),
                startDateMillis = twoYearsAgo,
                relationshipName = "${user.name} ❤️ ${partnerName.trim()}"
            )
            val relId = loveDao.insertRelationship(relationship)
            val savedRel = relationship.copy(id = relId)

            val updatedUser = user.copy(
                partnerName = partnerName.trim(),
                relationshipCode = code,
                connectedRelationshipId = relId,
                isConnected = true
            )
            loveDao.updateUser(updatedUser)

            seedStarterContent(relId, user.name, partnerName.trim())

            Result.success(Pair(savedRel, code))
        }

    suspend fun joinRelationship(code: String): Result<RelationshipEntity> =
        withContext(Dispatchers.IO) {
            val userId = _currentUserId.value ?: return@withContext Result.failure(Exception("Not logged in"))
            val user = loveDao.getUserById(userId) ?: return@withContext Result.failure(Exception("User not found"))

            val cleanCode = code.trim()
            val relationship = loveDao.getRelationshipByCode(cleanCode)
                ?: return@withContext Result.failure(Exception("Invalid code. Relationship not found."))

            val updatedRelationship = relationship.copy(
                partnerId = userId,
                partnerName = user.name,
                status = "connected"
            )
            loveDao.updateRelationship(updatedRelationship)

            val updatedUser = user.copy(
                partnerName = relationship.creatorName,
                relationshipCode = cleanCode,
                connectedRelationshipId = relationship.id,
                isConnected = true
            )
            loveDao.updateUser(updatedUser)

            // Notify in-app
            loveDao.insertNotification(
                NotificationEntity(
                    relationshipId = relationship.id,
                    title = "Connected with ${user.name} ❤️",
                    message = "Your love story has officially begun! You are now connected.",
                    iconType = "love"
                )
            )

            Result.success(updatedRelationship)
        }

    suspend fun disconnectRelationship(): Result<Unit> = withContext(Dispatchers.IO) {
        val userId = _currentUserId.value ?: return@withContext Result.failure(Exception("Not logged in"))
        val user = loveDao.getUserById(userId) ?: return@withContext Result.failure(Exception("User not found"))
        val relId = user.connectedRelationshipId ?: return@withContext Result.success(Unit)

        val updatedUser = user.copy(
            connectedRelationshipId = null,
            isConnected = false,
            relationshipCode = "",
            partnerName = ""
        )
        loveDao.updateUser(updatedUser)
        loveDao.deleteRelationshipById(relId)
        Result.success(Unit)
    }

    suspend fun updateRelationshipDetails(name: String, startDateMillis: Long) =
        withContext(Dispatchers.IO) {
            val user = _currentUserId.value?.let { loveDao.getUserById(it) } ?: return@withContext
            val relId = user.connectedRelationshipId ?: return@withContext
            val rel = loveDao.getRelationshipById(relId) ?: return@withContext

            loveDao.updateRelationship(
                rel.copy(
                    relationshipName = name,
                    startDateMillis = startDateMillis
                )
            )
        }

    // Memories
    fun getMemories(relationshipId: Long): Flow<List<MemoryEntity>> =
        loveDao.getMemoriesFlow(relationshipId)

    suspend fun addMemory(
        relationshipId: Long,
        title: String,
        description: String,
        dateMillis: Long,
        imageDrawable: String,
        location: String,
        authorName: String
    ) = withContext(Dispatchers.IO) {
        val memory = MemoryEntity(
            relationshipId = relationshipId,
            title = title,
            description = description,
            dateMillis = dateMillis,
            imageDrawableName = imageDrawable,
            location = location,
            createdByName = authorName
        )
        loveDao.insertMemory(memory)
        loveDao.insertNotification(
            NotificationEntity(
                relationshipId = relationshipId,
                title = "New Memory Added 📸",
                message = "$authorName added '$title'",
                iconType = "memory"
            )
        )
    }

    suspend fun updateMemory(memory: MemoryEntity) = withContext(Dispatchers.IO) {
        loveDao.updateMemory(memory)
    }

    suspend fun deleteMemory(id: Long) = withContext(Dispatchers.IO) {
        loveDao.deleteMemory(id)
    }

    // Love Letters
    fun getLoveLetters(relationshipId: Long): Flow<List<LoveLetterEntity>> =
        loveDao.getLoveLettersFlow(relationshipId)

    suspend fun sendLoveLetter(
        relationshipId: Long,
        senderName: String,
        title: String,
        message: String,
        themeIndex: Int
    ) = withContext(Dispatchers.IO) {
        val letter = LoveLetterEntity(
            relationshipId = relationshipId,
            senderName = senderName,
            title = title,
            message = message,
            themeColorIndex = themeIndex
        )
        loveDao.insertLoveLetter(letter)
        loveDao.insertNotification(
            NotificationEntity(
                relationshipId = relationshipId,
                title = "New Love Letter Received 💌",
                message = "$senderName sent you a romantic love letter: '$title'",
                iconType = "letter"
            )
        )
    }

    suspend fun markLetterRead(id: Long) = withContext(Dispatchers.IO) {
        loveDao.markLoveLetterAsRead(id)
    }

    suspend fun deleteLetter(id: Long) = withContext(Dispatchers.IO) {
        loveDao.deleteLoveLetter(id)
    }

    // Notes
    fun getNotes(relationshipId: Long): Flow<List<NoteEntity>> =
        loveDao.getNotesFlow(relationshipId)

    suspend fun addNote(
        relationshipId: Long,
        title: String,
        content: String,
        category: String,
        authorName: String
    ) = withContext(Dispatchers.IO) {
        val note = NoteEntity(
            relationshipId = relationshipId,
            title = title,
            content = content,
            category = category,
            authorName = authorName
        )
        loveDao.insertNote(note)
    }

    suspend fun updateNote(note: NoteEntity) = withContext(Dispatchers.IO) {
        loveDao.updateNote(note)
    }

    suspend fun deleteNote(id: Long) = withContext(Dispatchers.IO) {
        loveDao.deleteNote(id)
    }

    // Goals
    fun getGoals(relationshipId: Long): Flow<List<GoalEntity>> =
        loveDao.getGoalsFlow(relationshipId)

    suspend fun addGoal(
        relationshipId: Long,
        title: String,
        description: String,
        targetDate: String,
        category: String
    ) = withContext(Dispatchers.IO) {
        val goal = GoalEntity(
            relationshipId = relationshipId,
            title = title,
            description = description,
            progress = 10,
            targetDate = targetDate,
            category = category
        )
        loveDao.insertGoal(goal)
    }

    suspend fun updateGoalProgress(goal: GoalEntity, newProgress: Int, completed: Boolean) =
        withContext(Dispatchers.IO) {
            val updated = goal.copy(
                progress = newProgress.coerceIn(0, 100),
                isCompleted = completed || newProgress >= 100
            )
            loveDao.updateGoal(updated)
            if (updated.isCompleted && !goal.isCompleted) {
                loveDao.insertNotification(
                    NotificationEntity(
                        relationshipId = goal.relationshipId,
                        title = "Goal Completed! 🎉",
                        message = "You both achieved the goal: '${goal.title}'",
                        iconType = "goal"
                    )
                )
            }
        }

    suspend fun deleteGoal(id: Long) = withContext(Dispatchers.IO) {
        loveDao.deleteGoal(id)
    }

    // Special Dates
    fun getSpecialDates(relationshipId: Long): Flow<List<SpecialDateEntity>> =
        loveDao.getSpecialDatesFlow(relationshipId)

    suspend fun addSpecialDate(
        relationshipId: Long,
        title: String,
        dateMillis: Long,
        type: String
    ) = withContext(Dispatchers.IO) {
        val item = SpecialDateEntity(
            relationshipId = relationshipId,
            title = title,
            dateMillis = dateMillis,
            type = type
        )
        loveDao.insertSpecialDate(item)
    }

    suspend fun deleteSpecialDate(id: Long) = withContext(Dispatchers.IO) {
        loveDao.deleteSpecialDate(id)
    }

    // Notifications
    fun getNotifications(relationshipId: Long): Flow<List<NotificationEntity>> =
        loveDao.getNotificationsFlow(relationshipId)

    suspend fun markNotificationRead(id: Long) = withContext(Dispatchers.IO) {
        loveDao.markNotificationAsRead(id)
    }

    // Pre-seed starter content
    private suspend fun seedStarterContent(relId: Long, user1: String, user2: String) {
        // Starter Memories
        loveDao.insertMemory(
            MemoryEntity(
                relationshipId = relId,
                title = "Magical Sunset by the Sea",
                description = "The day we promised to be together forever under the pink twilight sky.",
                dateMillis = System.currentTimeMillis() - 1000L * 60 * 60 * 24 * 120,
                imageDrawableName = "img_memory_default",
                location = "Golden Bay",
                createdByName = user1
            )
        )
        loveDao.insertMemory(
            MemoryEntity(
                relationshipId = relId,
                title = "Our First Romantic Dinner",
                description = "Candlelight, sweet whispers, and our hands touching for the first time.",
                dateMillis = System.currentTimeMillis() - 1000L * 60 * 60 * 24 * 300,
                imageDrawableName = "img_memory_default",
                location = "Skyline Terrace",
                createdByName = user2
            )
        )

        // Starter Love Letter
        loveDao.insertLoveLetter(
            LoveLetterEntity(
                relationshipId = relId,
                senderName = user1,
                title = "To the Love of My Life ❤️",
                message = "From the very moment our paths crossed, my world turned into poetry. Thank you for choosing me every single day. Here is to our eternal journey together, hand in hand forever.",
                dateMillis = System.currentTimeMillis(),
                isRead = false,
                themeColorIndex = 0
            )
        )

        // Starter Notes
        loveDao.insertNote(
            NoteEntity(
                relationshipId = relId,
                title = "Dream Destinations",
                content = "1. Paris Cherry Blossom Walk\n2. Northern Lights in Iceland\n3. Romantic Venice Gondola Ride\n4. Cozy Mountain Cabin",
                category = "Places to visit",
                authorName = user1
            )
        )
        loveDao.insertNote(
            NoteEntity(
                relationshipId = relId,
                title = "Favorite Things We Love",
                content = "Late night talks, morning coffee together, sharing playlists, and laughing till our cheeks hurt.",
                category = "Love Notes",
                authorName = user2
            )
        )

        // Starter Goals
        loveDao.insertGoal(
            GoalEntity(
                relationshipId = relId,
                title = "Travel to Paris Together",
                description = "Spend a romantic week in Paris exploring museums and quaint cafes.",
                progress = 65,
                targetDate = "October 2026",
                category = "Travel"
            )
        )
        loveDao.insertGoal(
            GoalEntity(
                relationshipId = relId,
                title = "Build Our Dream Home",
                description = "Create our cozy sanctuary filled with warmth, love, and laughter.",
                progress = 40,
                targetDate = "2027",
                category = "Life"
            )
        )
        loveDao.insertGoal(
            GoalEntity(
                relationshipId = relId,
                title = "100 Romantic Date Nights",
                description = "Dedicate special uninterrupted date nights every weekend.",
                progress = 28,
                targetDate = "Ongoing",
                category = "Romance"
            )
        )

        // Starter Special Dates
        loveDao.insertSpecialDate(
            SpecialDateEntity(
                relationshipId = relId,
                title = "Our Anniversary",
                dateMillis = System.currentTimeMillis() + 1000L * 60 * 60 * 24 * 42,
                type = "Anniversary"
            )
        )
        loveDao.insertSpecialDate(
            SpecialDateEntity(
                relationshipId = relId,
                title = "$user2's Birthday",
                dateMillis = System.currentTimeMillis() + 1000L * 60 * 60 * 24 * 88,
                type = "Birthday"
            )
        )
        loveDao.insertSpecialDate(
            SpecialDateEntity(
                relationshipId = relId,
                title = "First Date Celebration",
                dateMillis = System.currentTimeMillis() + 1000L * 60 * 60 * 24 * 18,
                type = "First Date"
            )
        )

        // Starter Notification
        loveDao.insertNotification(
            NotificationEntity(
                relationshipId = relId,
                title = "Welcome to ETERNAL LOVE ❤️",
                message = "Two hearts are now bonded. Explore memories, letters, and milestones together!",
                iconType = "love"
            )
        )
    }

    private fun generateUnique6DigitCode(): String {
        val random = Random()
        val num = 100000 + random.nextInt(900000)
        return num.toString()
    }
}
