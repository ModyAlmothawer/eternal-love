package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.model.RelationshipEntity
import com.example.data.model.UserEntity
import com.example.ui.components.FloatingHeartsBackground
import com.example.ui.components.GlassCard
import com.example.ui.components.RomanticButton
import com.example.ui.components.RomanticOutlinedButton
import com.example.ui.components.RomanticTextField
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.MutedRose
import com.example.ui.theme.RomanticGradient
import com.example.ui.theme.RoseGold
import com.example.ui.theme.SoftBlush
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ProfileAndSettingsScreen(
    currentUser: UserEntity?,
    relationship: RelationshipEntity?,
    isDarkMode: Boolean,
    currentLanguage: String,
    onToggleDarkMode: (Boolean) -> Unit,
    onSetLanguage: (String) -> Unit,
    onEditProfile: () -> Unit,
    onEditRelationship: () -> Unit,
    onDisconnectClick: () -> Unit,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val appName = stringResource(R.string.app_name)
    val formattedAnniversary = remember(relationship?.startDateMillis) {
        val sdf = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault())
        sdf.format(Date(relationship?.startDateMillis ?: System.currentTimeMillis()))
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(RomanticGradient)
            .testTag("profile_settings_screen")
    ) {
        FloatingHeartsBackground(heartCount = 6)

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Header
            item {
                Column {
                    Text(
                        text = stringResource(R.string.nav_profile),
                        style = MaterialTheme.typography.displayMedium.copy(
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold
                        ),
                        color = SoftBlush
                    )
                    Text(
                        text = stringResource(R.string.profile_subtitle),
                        style = MaterialTheme.typography.labelSmall,
                        color = RoseGold
                    )
                }
            }

            // User & Partner Profiles
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    backgroundColor = Color(0x33260B1C)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                com.example.ui.components.RomanticAvatar(
                                    photoUrl = currentUser?.photoUrl ?: "",
                                    avatarRes = currentUser?.avatarRes ?: "avatar_1",
                                    size = 56.dp,
                                    borderColor = CrimsonPrimary,
                                    borderWidth = 2.dp,
                                    onClick = onEditProfile
                                )

                                Spacer(modifier = Modifier.width(14.dp))

                                Column {
                                    Text(
                                        text = currentUser?.name?.takeIf { it.isNotBlank() } ?: stringResource(R.string.you),
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = SoftBlush
                                    )
                                    Text(
                                        text = currentUser?.email ?: "",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MutedRose
                                    )
                                }
                            }

                            IconButton(onClick = onEditProfile) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = stringResource(R.string.edit_profile),
                                    tint = RoseGold
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(1.dp)
                                .background(Color(0x22FF4D79))
                        )

                        // Partner Info
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                val partnerPhoto = currentUser?.partnerPhotoUrl?.takeIf { it.isNotBlank() }
                                    ?: relationship?.partnerPhoto?.takeIf { it.isNotBlank() }
                                    ?: "avatar_2"
                                val partnerAvatarRes = if (partnerPhoto.startsWith("http") || partnerPhoto.startsWith("content")) "avatar_2" else partnerPhoto

                                com.example.ui.components.RomanticAvatar(
                                    photoUrl = if (partnerPhoto.startsWith("http") || partnerPhoto.startsWith("content")) partnerPhoto else "",
                                    avatarRes = partnerAvatarRes,
                                    size = 50.dp,
                                    borderColor = RoseGold,
                                    borderWidth = 2.dp
                                )

                                Spacer(modifier = Modifier.width(14.dp))

                                Column {
                                    Text(
                                        text = currentUser?.partnerName?.ifBlank { stringResource(R.string.my_partner) } ?: stringResource(R.string.my_partner),
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = RoseGold
                                    )
                                    Text(
                                        text = stringResource(R.string.connected_soulmate),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MutedRose
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Relationship Details & Love Code
            item {
                val loveCode = relationship?.code ?: currentUser?.relationshipCode
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    backgroundColor = Color(0x33260B1C)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.title_relationship_details),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.Bold
                            ),
                            color = SoftBlush
                        )

                        if (!loveCode.isNullOrBlank()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0x4414050E), RoundedCornerShape(14.dp))
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(stringResource(R.string.your_love_code), style = MaterialTheme.typography.labelSmall, color = MutedRose)
                                    Text(
                                        loveCode,
                                        style = MaterialTheme.typography.titleLarge.copy(
                                            fontWeight = FontWeight.ExtraBold,
                                            letterSpacing = 3.sp
                                        ),
                                        color = SoftBlush
                                    )
                                }

                                Row {
                                    IconButton(onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clipboard.setPrimaryClip(ClipData.newPlainText("Love Code", loveCode))
                                        Toast.makeText(context, context.getString(R.string.copied), Toast.LENGTH_SHORT).show()
                                    }) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = stringResource(R.string.copy), tint = RoseGold)
                                    }
                                    IconButton(onClick = {
                                        val sendIntent = Intent().apply {
                                            action = Intent.ACTION_SEND
                                            putExtra(Intent.EXTRA_TEXT, "Join me on $appName ❤️: $loveCode")
                                            type = "text/plain"
                                        }
                                        context.startActivity(Intent.createChooser(sendIntent, context.getString(R.string.share)))
                                    }) {
                                        Icon(Icons.Default.Share, contentDescription = stringResource(R.string.share), tint = RoseGold)
                                    }
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(stringResource(R.string.anniversary_date), style = MaterialTheme.typography.labelSmall, color = MutedRose)
                                Text(formattedAnniversary, style = MaterialTheme.typography.titleSmall, color = SoftBlush)
                            }

                            IconButton(onClick = onEditRelationship) {
                                Icon(Icons.Default.Edit, contentDescription = stringResource(R.string.edit_relationship), tint = RoseGold)
                            }
                        }
                    }
                }
            }

            // Preferences & Settings
            item {
                Text(
                    text = stringResource(R.string.preferences),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold
                    ),
                    color = SoftBlush
                )
            }

            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    backgroundColor = Color(0x33260B1C)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Dark Theme Toggle
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.DarkMode, contentDescription = null, tint = RoseGold)
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(stringResource(R.string.dark_mode), color = SoftBlush)
                            }
                            Switch(
                                checked = isDarkMode,
                                onCheckedChange = onToggleDarkMode,
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = CrimsonPrimary
                                )
                            )
                        }

                        // Language Toggle
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Language, contentDescription = null, tint = RoseGold)
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(stringResource(R.string.language_preference), color = SoftBlush)
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (currentLanguage == "en") CrimsonPrimary else Color(0x22FFFFFF))
                                        .clickable { onSetLanguage("en") }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text("EN", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = Color.White)
                                }

                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (currentLanguage == "ar") CrimsonPrimary else Color(0x22FFFFFF))
                                        .clickable { onSetLanguage("ar") }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text("عربي", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = Color.White)
                                }
                            }
                        }

                        // About App
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Info, contentDescription = null, tint = RoseGold)
                                Spacer(modifier = Modifier.width(12.dp))
                                Text("$appName v2.0", color = SoftBlush)
                            }
                            Text(stringResource(R.string.forever_status), style = MaterialTheme.typography.labelSmall, color = RoseGold)
                        }
                    }
                }
            }

            // Danger & Exit Actions
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    RomanticOutlinedButton(
                        text = stringResource(R.string.disconnect_relationship),
                        onClick = onDisconnectClick,
                        icon = Icons.Default.LinkOff,
                        borderColor = MaterialTheme.colorScheme.error,
                        textColor = MaterialTheme.colorScheme.error,
                        testTag = "btn_disconnect"
                    )

                    RomanticOutlinedButton(
                        text = stringResource(R.string.logout),
                        onClick = onLogout,
                        icon = Icons.Default.Logout,
                        borderColor = RoseGold.copy(alpha = 0.5f),
                        textColor = RoseGold,
                        testTag = "btn_logout"
                    )
                }
            }
        }
    }
}

@Composable
fun EditProfileDialog(
    currentName: String,
    currentAvatar: String = "avatar_1",
    currentPhotoUrl: String = "",
    onDismiss: () -> Unit,
    onSave: (name: String, avatar: String, photoUri: Uri?) -> Unit
) {
    var name by remember { mutableStateOf(currentName) }
    var selectedAvatar by remember { mutableStateOf(currentAvatar.ifEmpty { "avatar_1" }) }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedImageUri = uri
        }
    }

    val avatars = listOf(
        "avatar_1" to R.string.avatar_king,
        "avatar_2" to R.string.avatar_queen,
        "avatar_3" to R.string.avatar_sparkle,
        "avatar_4" to R.string.avatar_heart,
        "avatar_5" to R.string.avatar_moon,
        "avatar_6" to R.string.avatar_diamond
    )

    Dialog(onDismissRequest = onDismiss) {
        GlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(28.dp),
            backgroundColor = Color(0xF51A0815)
        ) {
            Column(
                modifier = Modifier
                    .padding(22.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = stringResource(R.string.edit_profile),
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = SoftBlush
                )

                // Current / Selected Image Preview
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .clickable { photoPickerLauncher.launch("image/*") },
                    contentAlignment = Alignment.Center
                ) {
                    if (selectedImageUri != null) {
                        coil.compose.AsyncImage(
                            model = selectedImageUri,
                            contentDescription = stringResource(R.string.selected_photo),
                            contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxSize()
                                .border(2.dp, CrimsonPrimary, CircleShape)
                        )
                    } else {
                        com.example.ui.components.RomanticAvatar(
                            photoUrl = currentPhotoUrl,
                            avatarRes = selectedAvatar,
                            size = 80.dp,
                            borderColor = CrimsonPrimary,
                            borderWidth = 2.dp
                        )
                    }
                }

                RomanticOutlinedButton(
                    text = stringResource(R.string.upload_photo_gallery),
                    onClick = { photoPickerLauncher.launch("image/*") },
                    borderColor = RoseGold,
                    textColor = RoseGold,
                    modifier = Modifier.fillMaxWidth()
                )

                RomanticTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = stringResource(R.string.name),
                    placeholder = stringResource(R.string.name)
                )

                Text(
                    text = stringResource(R.string.or_choose_avatar),
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                    color = RoseGold,
                    modifier = Modifier.align(Alignment.Start)
                )

                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    avatars.chunked(2).forEach { rowItems ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            rowItems.forEach { (avatarKey, labelRes) ->
                                val isSelected = selectedAvatar == avatarKey && selectedImageUri == null
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(if (isSelected) CrimsonPrimary.copy(alpha = 0.35f) else Color(0x22FFFFFF))
                                        .border(
                                            width = if (isSelected) 2.dp else 1.dp,
                                            color = if (isSelected) CrimsonPrimary else Color(0x33FF4D79),
                                            shape = RoundedCornerShape(12.dp)
                                        )
                                        .clickable {
                                            selectedAvatar = avatarKey
                                            selectedImageUri = null
                                        }
                                        .padding(horizontal = 8.dp, vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = stringResource(labelRes),
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        ),
                                        color = if (isSelected) SoftBlush else RoseGold
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                RomanticButton(
                    text = stringResource(R.string.save_changes),
                    onClick = {
                        if (name.isNotBlank()) onSave(name, selectedAvatar, selectedImageUri)
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditRelationshipDialog(
    currentName: String,
    onDismiss: () -> Unit,
    onSave: (name: String, startDateMillis: Long) -> Unit
) {
    var name by remember { mutableStateOf(currentName) }
    var selectedDateMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var showDatePicker by remember { mutableStateOf(false) }

    val datePickerState = rememberDatePickerState(
        initialSelectedDateMillis = selectedDateMillis
    )

    val formattedDate = remember(selectedDateMillis) {
        val sdf = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault())
        sdf.format(Date(selectedDateMillis))
    }

    Dialog(onDismissRequest = onDismiss) {
        GlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(28.dp),
            backgroundColor = Color(0xF51A0815)
        ) {
            Column(
                modifier = Modifier.padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = stringResource(R.string.title_relationship_details),
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = SoftBlush
                )

                RomanticTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = stringResource(R.string.couple_title),
                    placeholder = stringResource(R.string.couple_title_placeholder)
                )

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = stringResource(R.string.anniversary_date),
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                        color = RoseGold
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0x332B1020))
                            .border(1.dp, Color(0x33FF4D79), RoundedCornerShape(16.dp))
                            .clickable { showDatePicker = true }
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = CrimsonPrimary)
                            Text(text = formattedDate, color = SoftBlush, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        }
                        Text(text = stringResource(R.string.change_date), color = RoseGold, style = MaterialTheme.typography.bodySmall)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                RomanticButton(
                    text = stringResource(R.string.save_changes),
                    onClick = {
                        onSave(name, selectedDateMillis)
                    }
                )
            }
        }
    }

    if (showDatePicker) {
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        datePickerState.selectedDateMillis?.let {
                            selectedDateMillis = it
                        }
                        showDatePicker = false
                    }
                ) {
                    Text(text = stringResource(R.string.save), color = CrimsonPrimary, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) {
                    Text(text = stringResource(R.string.cancel), color = RoseGold)
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }
}
