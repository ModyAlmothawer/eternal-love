package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.GoalEntity
import com.example.data.model.LoveLetterEntity
import com.example.data.model.MemoryEntity
import com.example.data.model.NoteEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.RelationshipEntity
import com.example.data.model.SpecialDateEntity
import com.example.data.model.UserEntity
import com.example.data.repository.LoveRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.TimeZone

data class RelationshipDuration(
    val years: Long = 0,
    val months: Long = 0,
    val days: Long = 0,
    val hours: Long = 0,
    val minutes: Long = 0,
    val seconds: Long = 0,
    val totalDays: Long = 0
)

enum class MainTab {
    HOME,
    MEMORIES,
    LETTERS,
    GOALS,
    PROFILE
}

class MainViewModel(
    private val repository: LoveRepository
) : ViewModel() {

    val isDarkMode: StateFlow<Boolean> = repository.isDarkMode
    val currentLanguage: StateFlow<String> = repository.currentLanguage

    val currentUser: StateFlow<UserEntity?> = repository.currentUserFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val currentRelationship: StateFlow<RelationshipEntity?> = repository.currentRelationshipFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _currentTab = MutableStateFlow(MainTab.HOME)
    val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

    // Real-time dynamic counter ticker
    private val _relationshipDuration = MutableStateFlow(RelationshipDuration())
    val relationshipDuration: StateFlow<RelationshipDuration> = _relationshipDuration.asStateFlow()

    // Active sub-screen/dialog states
    val selectedMemory = MutableStateFlow<MemoryEntity?>(null)
    val selectedLoveLetter = MutableStateFlow<LoveLetterEntity?>(null)
    val isWritingLetter = MutableStateFlow(false)
    val isAddingMemory = MutableStateFlow(false)
    val isAddingNote = MutableStateFlow(false)
    val isAddingGoal = MutableStateFlow(false)
    val isAddingSpecialDate = MutableStateFlow(false)
    val isViewingNotes = MutableStateFlow(false)
    val isViewingSpecialDates = MutableStateFlow(false)
    val isViewingNotifications = MutableStateFlow(false)
    val isViewingStory = MutableStateFlow(false)
    val isEditingProfile = MutableStateFlow(false)
    val isEditingRelationship = MutableStateFlow(false)
    val showDisconnectConfirmation = MutableStateFlow(false)

    // Data streams based on connected relationship
    val memories: StateFlow<List<MemoryEntity>> = currentRelationship.flatMapLatest { rel ->
        if (rel != null) repository.getMemories(rel.id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val loveLetters: StateFlow<List<LoveLetterEntity>> = currentRelationship.flatMapLatest { rel ->
        if (rel != null) repository.getLoveLetters(rel.id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notes: StateFlow<List<NoteEntity>> = currentRelationship.flatMapLatest { rel ->
        if (rel != null) repository.getNotes(rel.id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val goals: StateFlow<List<GoalEntity>> = currentRelationship.flatMapLatest { rel ->
        if (rel != null) repository.getGoals(rel.id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val specialDates: StateFlow<List<SpecialDateEntity>> = currentRelationship.flatMapLatest { rel ->
        if (rel != null) repository.getSpecialDates(rel.id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<NotificationEntity>> = currentRelationship.flatMapLatest { rel ->
        if (rel != null) repository.getNotifications(rel.id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Start real-time ticker
        viewModelScope.launch {
            while (isActive) {
                updateDuration()
                delay(1000)
            }
        }
    }

    private fun updateDuration() {
        val rel = currentRelationship.value ?: return
        val startMillis = rel.startDateMillis
        val nowMillis = System.currentTimeMillis()

        if (nowMillis < startMillis) {
            _relationshipDuration.value = RelationshipDuration()
            return
        }

        val startCal = Calendar.getInstance(TimeZone.getDefault()).apply { timeInMillis = startMillis }
        val nowCal = Calendar.getInstance(TimeZone.getDefault()).apply { timeInMillis = nowMillis }

        var years = nowCal.get(Calendar.YEAR) - startCal.get(Calendar.YEAR)
        var months = nowCal.get(Calendar.MONTH) - startCal.get(Calendar.MONTH)
        var days = nowCal.get(Calendar.DAY_OF_MONTH) - startCal.get(Calendar.DAY_OF_MONTH)

        if (days < 0) {
            months -= 1
            val tempCal = Calendar.getInstance().apply {
                timeInMillis = nowMillis
                add(Calendar.MONTH, -1)
            }
            days += tempCal.getActualMaximum(Calendar.DAY_OF_MONTH)
        }

        if (months < 0) {
            years -= 1
            months += 12
        }

        val totalDiffMillis = nowMillis - startMillis
        val totalDays = totalDiffMillis / (1000 * 60 * 60 * 24)
        val hours = (totalDiffMillis / (1000 * 60 * 60)) % 24
        val minutes = (totalDiffMillis / (1000 * 60)) % 60
        val seconds = (totalDiffMillis / 1000) % 60

        _relationshipDuration.value = RelationshipDuration(
            years = maxOf(0, years.toLong()),
            months = maxOf(0, months.toLong()),
            days = maxOf(0, days.toLong()),
            hours = maxOf(0, hours),
            minutes = maxOf(0, minutes),
            seconds = maxOf(0, seconds),
            totalDays = maxOf(0, totalDays)
        )
    }

    fun selectTab(tab: MainTab) {
        _currentTab.value = tab
    }

    fun toggleDarkMode(enabled: Boolean) {
        viewModelScope.launch {
            repository.setDarkMode(enabled)
        }
    }

    fun setLanguage(lang: String) {
        viewModelScope.launch {
            repository.setLanguage(lang)
        }
    }

    fun addMemory(
        title: String,
        description: String,
        dateMillis: Long,
        imageDrawable: String,
        location: String
    ) {
        val rel = currentRelationship.value ?: return
        val user = currentUser.value ?: return
        viewModelScope.launch {
            repository.addMemory(
                relationshipId = rel.id,
                title = title,
                description = description,
                dateMillis = dateMillis,
                imageDrawable = imageDrawable,
                location = location,
                authorName = user.name
            )
            isAddingMemory.value = false
        }
    }

    fun deleteMemory(id: Long) {
        viewModelScope.launch {
            repository.deleteMemory(id)
            if (selectedMemory.value?.id == id) {
                selectedMemory.value = null
            }
        }
    }

    fun sendLoveLetter(title: String, message: String, themeIndex: Int) {
        val rel = currentRelationship.value ?: return
        val user = currentUser.value ?: return
        viewModelScope.launch {
            repository.sendLoveLetter(
                relationshipId = rel.id,
                senderName = user.name,
                title = title,
                message = message,
                themeIndex = themeIndex
            )
            isWritingLetter.value = false
        }
    }

    fun openLoveLetter(letter: LoveLetterEntity) {
        selectedLoveLetter.value = letter
        viewModelScope.launch {
            repository.markLetterRead(letter.id)
        }
    }

    fun deleteLoveLetter(id: Long) {
        viewModelScope.launch {
            repository.deleteLetter(id)
            if (selectedLoveLetter.value?.id == id) {
                selectedLoveLetter.value = null
            }
        }
    }

    fun addNote(title: String, content: String, category: String) {
        val rel = currentRelationship.value ?: return
        val user = currentUser.value ?: return
        viewModelScope.launch {
            repository.addNote(
                relationshipId = rel.id,
                title = title,
                content = content,
                category = category,
                authorName = user.name
            )
            isAddingNote.value = false
        }
    }

    fun deleteNote(id: Long) {
        viewModelScope.launch {
            repository.deleteNote(id)
        }
    }

    fun addGoal(title: String, description: String, targetDate: String, category: String) {
        val rel = currentRelationship.value ?: return
        viewModelScope.launch {
            repository.addGoal(
                relationshipId = rel.id,
                title = title,
                description = description,
                targetDate = targetDate,
                category = category
            )
            isAddingGoal.value = false
        }
    }

    fun updateGoalProgress(goal: GoalEntity, progress: Int, completed: Boolean) {
        viewModelScope.launch {
            repository.updateGoalProgress(goal, progress, completed)
        }
    }

    fun deleteGoal(id: Long) {
        viewModelScope.launch {
            repository.deleteGoal(id)
        }
    }

    fun addSpecialDate(title: String, dateMillis: Long, type: String) {
        val rel = currentRelationship.value ?: return
        viewModelScope.launch {
            repository.addSpecialDate(
                relationshipId = rel.id,
                title = title,
                dateMillis = dateMillis,
                type = type
            )
            isAddingSpecialDate.value = false
        }
    }

    fun deleteSpecialDate(id: Long) {
        viewModelScope.launch {
            repository.deleteSpecialDate(id)
        }
    }

    fun updateProfile(name: String, avatarRes: String) {
        viewModelScope.launch {
            repository.updateUserProfile(name, avatarRes)
            isEditingProfile.value = false
        }
    }

    fun updateRelationship(name: String, startDateMillis: Long) {
        viewModelScope.launch {
            repository.updateRelationshipDetails(name, startDateMillis)
            isEditingRelationship.value = false
        }
    }

    fun disconnectRelationship(onDisconnected: () -> Unit) {
        viewModelScope.launch {
            repository.disconnectRelationship()
            showDisconnectConfirmation.value = false
            onDisconnected()
        }
    }
}

class MainViewModelFactory(private val repository: LoveRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return MainViewModel(repository) as T
    }
}
