package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TrackChanges
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.GoalEntity
import com.example.data.model.LoveLetterEntity
import com.example.data.model.MemoryEntity
import com.example.data.model.NoteEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.RelationshipEntity
import com.example.data.model.SpecialDateEntity
import com.example.data.model.UserEntity
import com.example.ui.components.FloatingHeartsBackground
import com.example.ui.components.GlassCard
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.CrimsonPrimaryLight
import com.example.ui.theme.GoldAccentGradient
import com.example.ui.theme.MutedRose
import com.example.ui.theme.RomanticGradient
import com.example.ui.theme.RoseGold
import com.example.ui.theme.SoftBlush
import com.example.ui.viewmodel.RelationshipDuration
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    currentUser: UserEntity?,
    relationship: RelationshipEntity?,
    duration: RelationshipDuration,
    memories: List<MemoryEntity>,
    loveLetters: List<LoveLetterEntity>,
    notes: List<NoteEntity>,
    goals: List<GoalEntity>,
    specialDates: List<SpecialDateEntity>,
    notifications: List<NotificationEntity>,
    onOpenMemories: () -> Unit,
    onOpenLetters: () -> Unit,
    onOpenNotes: () -> Unit,
    onOpenGoals: () -> Unit,
    onOpenSpecialDates: () -> Unit,
    onOpenStory: () -> Unit,
    onOpenNotifications: () -> Unit,
    onOpenProfile: () -> Unit,
    modifier: Modifier = Modifier
) {
    val unreadNotifications = notifications.count { !it.isRead }
    val unreadLetters = loveLetters.count { !it.isRead }

    val formattedStartDate = remember(relationship?.startDateMillis) {
        val millis = relationship?.startDateMillis ?: System.currentTimeMillis()
        val sdf = SimpleDateFormat("MMMM d, yyyy", Locale.getDefault())
        sdf.format(Date(millis))
    }

    val pulseTransition = rememberInfiniteTransition(label = "heart_pulse")
    val heartScale by pulseTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(RomanticGradient)
            .testTag("home_screen")
    ) {
        FloatingHeartsBackground(heartCount = 8)

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Top Bar
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "ETERNAL LOVE",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontFamily = FontFamily.Serif,
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 1.sp
                                ),
                                color = SoftBlush
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = null,
                                tint = CrimsonPrimary,
                                modifier = Modifier
                                    .size(20.dp)
                                    .scale(heartScale)
                            )
                        }
                        Text(
                            text = stringResource(R.string.tagline),
                            style = MaterialTheme.typography.labelSmall,
                            color = RoseGold
                        )
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        BadgedBox(
                            badge = {
                                if (unreadNotifications > 0) {
                                    Badge(
                                        containerColor = CrimsonPrimary,
                                        contentColor = Color.White
                                    ) {
                                        Text(unreadNotifications.toString())
                                    }
                                }
                            }
                        ) {
                            IconButton(
                                onClick = onOpenNotifications,
                                modifier = Modifier
                                    .background(Color(0x332B1020), CircleShape)
                                    .border(1.dp, Color(0x44FF4D79), CircleShape)
                                    .size(42.dp)
                                    .testTag("btn_notifications")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Notifications,
                                    contentDescription = "Notifications",
                                    tint = SoftBlush,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Relationship Names & Together Banner
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(28.dp),
                    backgroundColor = Color(0x442A0D1F)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        val name1 = currentUser?.name ?: "You"
                        val name2 = currentUser?.partnerName?.takeIf { it.isNotBlank() }
                            ?: relationship?.partnerName?.takeIf { it.isNotBlank() }
                            ?: "My Love"

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = name1,
                                style = MaterialTheme.typography.headlineMedium.copy(
                                    fontFamily = FontFamily.Serif,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = SoftBlush
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = null,
                                tint = CrimsonPrimary,
                                modifier = Modifier
                                    .size(28.dp)
                                    .scale(heartScale)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = name2,
                                style = MaterialTheme.typography.headlineMedium.copy(
                                    fontFamily = FontFamily.Serif,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = RoseGold
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "${stringResource(R.string.together_since)}: ",
                                style = MaterialTheme.typography.labelSmall,
                                color = MutedRose
                            )
                            Text(
                                text = formattedStartDate,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = SoftBlush
                            )
                        }
                    }
                }
            }

            // Real-Time Relationship Live Counter (Years, Months, Days, Hours, Minutes, Seconds)
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(28.dp),
                    borderColor = CrimsonPrimary.copy(alpha = 0.5f)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = RoseGold,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "LOVE CLOCK • REAL-TIME",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    letterSpacing = 2.sp,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = RoseGold
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Large Row: Years, Months, Days
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            CounterDigitUnit(
                                value = duration.years.toString(),
                                label = "Years",
                                isPrimary = true
                            )
                            CounterSeparator()
                            CounterDigitUnit(
                                value = duration.months.toString(),
                                label = "Months",
                                isPrimary = true
                            )
                            CounterSeparator()
                            CounterDigitUnit(
                                value = duration.days.toString(),
                                label = "Days",
                                isPrimary = true
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Secondary Row: Hours, Minutes, Seconds
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0x3314050F), RoundedCornerShape(18.dp))
                                .padding(vertical = 10.dp, horizontal = 12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceEvenly,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CounterSmallDigitUnit(
                                    value = String.format("%02d", duration.hours),
                                    label = "Hours"
                                )
                                Text(":", color = RoseGold, fontWeight = FontWeight.Bold)
                                CounterSmallDigitUnit(
                                    value = String.format("%02d", duration.minutes),
                                    label = "Mins"
                                )
                                Text(":", color = RoseGold, fontWeight = FontWeight.Bold)
                                CounterSmallDigitUnit(
                                    value = String.format("%02d", duration.seconds),
                                    label = "Secs"
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "❤️ ${duration.totalDays} Total Days of Endless Love ❤️",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                            color = SoftBlush
                        )
                    }
                }
            }

            // Quick Interactive Cards Grid
            item {
                Text(
                    text = "Our Love Journey",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold
                    ),
                    color = SoftBlush
                )
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        HomeActionCard(
                            title = stringResource(R.string.card_our_story),
                            subtitle = "Timeline & milestones",
                            icon = Icons.Default.Favorite,
                            badge = "Story",
                            modifier = Modifier.weight(1f),
                            onClick = onOpenStory,
                            testTag = "card_our_story"
                        )
                        HomeActionCard(
                            title = stringResource(R.string.card_memories),
                            subtitle = "${memories.size} Photos",
                            icon = Icons.Default.PhotoLibrary,
                            badge = memories.size.toString(),
                            modifier = Modifier.weight(1f),
                            onClick = onOpenMemories,
                            testTag = "card_memories"
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        HomeActionCard(
                            title = stringResource(R.string.card_love_letters),
                            subtitle = "${loveLetters.size} Letters",
                            icon = Icons.Default.Mail,
                            badge = if (unreadLetters > 0) "$unreadLetters New" else null,
                            badgeColor = CrimsonPrimary,
                            modifier = Modifier.weight(1f),
                            onClick = onOpenLetters,
                            testTag = "card_love_letters"
                        )
                        HomeActionCard(
                            title = stringResource(R.string.card_notes),
                            subtitle = "${notes.size} Notes",
                            icon = Icons.Default.Edit,
                            badge = notes.size.toString(),
                            modifier = Modifier.weight(1f),
                            onClick = onOpenNotes,
                            testTag = "card_notes"
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        val completedGoals = goals.count { it.isCompleted }
                        HomeActionCard(
                            title = stringResource(R.string.card_goals),
                            subtitle = "$completedGoals/${goals.size} Done",
                            icon = Icons.Default.TrackChanges,
                            badge = if (goals.isNotEmpty()) "${(completedGoals * 100 / goals.size)}%" else null,
                            modifier = Modifier.weight(1f),
                            onClick = onOpenGoals,
                            testTag = "card_goals"
                        )
                        HomeActionCard(
                            title = stringResource(R.string.card_special_dates),
                            subtitle = "${specialDates.size} Events",
                            icon = Icons.Default.Event,
                            badge = "Dates",
                            modifier = Modifier.weight(1f),
                            onClick = onOpenSpecialDates,
                            testTag = "card_special_dates"
                        )
                    }
                }
            }

            // Daily Romance Quote / Surprise Widget
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    backgroundColor = Color(0x333D1426),
                    borderColor = Color(0x55FFD194)
                ) {
                    Row(
                        modifier = Modifier.padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(GoldAccentGradient, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CardGiftcard,
                                contentDescription = null,
                                tint = Color(0xFF3B1F00),
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Column {
                            Text(
                                text = "Daily Sweet Thought",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = RoseGold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "“In all the world, there is no heart for me like yours. In all the world, there is no love for you like mine.”",
                                style = MaterialTheme.typography.bodySmall,
                                color = SoftBlush
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CounterDigitUnit(
    value: String,
    label: String,
    isPrimary: Boolean = false
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(width = 72.dp, height = 64.dp)
                .background(
                    if (isPrimary) Color(0x44FF2E63) else Color(0x332B1020),
                    RoundedCornerShape(18.dp)
                )
                .border(
                    1.dp,
                    if (isPrimary) CrimsonPrimaryLight.copy(alpha = 0.6f) else Color(0x33FF4D79),
                    RoundedCornerShape(18.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.displayMedium.copy(
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Serif
                ),
                color = SoftBlush
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
            color = RoseGold
        )
    }
}

@Composable
private fun CounterSmallDigitUnit(
    value: String,
    label: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = SoftBlush
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MutedRose
        )
    }
}

@Composable
private fun CounterSeparator() {
    Text(
        text = ":",
        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
        color = RoseGold.copy(alpha = 0.7f),
        modifier = Modifier.padding(top = 14.dp)
    )
}

@Composable
private fun HomeActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    badge: String? = null,
    badgeColor: Color = RoseGold,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = "home_card"
) {
    GlassCard(
        modifier = modifier
            .clickable { onClick() }
            .testTag(testTag),
        shape = RoundedCornerShape(22.dp),
        backgroundColor = Color(0x33230A19)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(Color(0x44FF2E63), CircleShape)
                        .border(1.dp, CrimsonPrimary.copy(alpha = 0.5f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = SoftBlush,
                        modifier = Modifier.size(22.dp)
                    )
                }

                if (badge != null) {
                    Box(
                        modifier = Modifier
                            .background(badgeColor.copy(alpha = 0.2f), RoundedCornerShape(10.dp))
                            .border(1.dp, badgeColor.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = badge,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = badgeColor
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = SoftBlush
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MutedRose
            )
        }
    }
}
