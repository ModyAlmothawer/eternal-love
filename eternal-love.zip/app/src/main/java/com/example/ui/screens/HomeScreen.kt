package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TrackChanges
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.AchievementItem
import com.example.data.model.GoalEntity
import com.example.data.model.LoveLetterEntity
import com.example.data.model.MemoryEntity
import com.example.data.model.NoteEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.RelationshipEntity
import com.example.data.model.SpecialDateEntity
import com.example.data.model.UserEntity
import com.example.ui.components.FloatingHeartsBackground
import com.example.ui.components.GlassCard
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.CrimsonPrimaryLight
import com.example.ui.theme.GoldAccentGradient
import com.example.ui.theme.MutedRose
import com.example.ui.theme.RomanticGradient
import com.example.ui.theme.RoseGold
import com.example.ui.theme.SoftBlush
import com.example.ui.viewmodel.RelationshipDuration
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    currentUser: UserEntity?,
    relationship: RelationshipEntity?,
    duration: RelationshipDuration,
    memories: List<MemoryEntity>,
    loveLetters: List<LoveLetterEntity>,
    notes: List<NoteEntity>,
    goals: List<GoalEntity>,
    specialDates: List<SpecialDateEntity>,
    notifications: List<NotificationEntity>,
    achievements: List<AchievementItem> = emptyList(),
    onOpenMemories: () -> Unit,
    onOpenLetters: () -> Unit,
    onOpenNotes: () -> Unit,
    onOpenGoals: () -> Unit,
    onOpenSpecialDates: () -> Unit,
    onOpenStory: () -> Unit,
    onOpenNotifications: () -> Unit,
    onOpenProfile: () -> Unit,
    modifier: Modifier = Modifier
) {
    val unreadNotifications = notifications.count { !it.isRead }
    val unreadLetters = loveLetters.count { !it.isRead }

    val formattedStartDate = remember(relationship?.startDateMillis) {
        val millis = relationship?.startDateMillis ?: System.currentTimeMillis()
        val sdf = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault())
        sdf.format(Date(millis))
    }

    val pulseTransition = rememberInfiniteTransition(label = "heart_pulse")
    val heartScale by pulseTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(RomanticGradient)
            .testTag("home_screen")
    ) {
        FloatingHeartsBackground(heartCount = 8)

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Top Bar with App Name
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = stringResource(R.string.app_name),
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontFamily = FontFamily.Serif,
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 1.sp
                                ),
                                color = SoftBlush
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = null,
                                tint = CrimsonPrimary,
                                modifier = Modifier
                                    .size(20.dp)
                                    .scale(heartScale)
                            )
                        }
                        Text(
                            text = stringResource(R.string.tagline),
                            style = MaterialTheme.typography.labelSmall,
                            color = RoseGold
                        )
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        BadgedBox(
                            badge = {
                                if (unreadNotifications > 0) {
                                    Badge(
                                        containerColor = CrimsonPrimary,
                                        contentColor = Color.White
                                    ) {
                                        Text(unreadNotifications.toString())
                                    }
                                }
                            }
                        ) {
                            IconButton(
                                onClick = onOpenNotifications,
                                modifier = Modifier
                                    .background(Color(0x332B1020), CircleShape)
                                    .border(1.dp, Color(0x44FF4D79), CircleShape)
                                    .size(42.dp)
                                    .testTag("btn_notifications")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Notifications,
                                    contentDescription = "Notifications",
                                    tint = SoftBlush,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Couple Avatar Card & Start Date
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(28.dp),
                    backgroundColor = Color(0x442A0D1F)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        val name1 = currentUser?.name?.takeIf { it.isNotBlank() } ?: stringResource(R.string.you)
                        val name2 = currentUser?.partnerName?.takeIf { it.isNotBlank() }
                            ?: relationship?.partnerName?.takeIf { it.isNotBlank() }
                            ?: stringResource(R.string.my_love)

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            // User
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                com.example.ui.components.RomanticAvatar(
                                    photoUrl = currentUser?.photoUrl ?: "",
                                    avatarRes = currentUser?.avatarRes ?: "avatar_1",
                                    size = 58.dp,
                                    borderColor = CrimsonPrimary,
                                    borderWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = name1,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center
                                    ),
                                    color = SoftBlush
                                )
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = null,
                                tint = CrimsonPrimary,
                                modifier = Modifier
                                    .size(30.dp)
                                    .scale(heartScale)
                            )

                            Spacer(modifier = Modifier.width(16.dp))

                            // Partner
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                val partnerPhoto = currentUser?.partnerPhotoUrl?.takeIf { it.isNotBlank() }
                                    ?: relationship?.partnerPhoto?.takeIf { it.isNotBlank() }
                                    ?: "avatar_2"
                                val partnerAvatarRes = if (partnerPhoto.startsWith("http") || partnerPhoto.startsWith("content")) "avatar_2" else partnerPhoto

                                com.example.ui.components.RomanticAvatar(
                                    photoUrl = if (partnerPhoto.startsWith("http") || partnerPhoto.startsWith("content")) partnerPhoto else "",
                                    avatarRes = partnerAvatarRes,
                                    size = 58.dp,
                                    borderColor = RoseGold,
                                    borderWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = name2,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center
                                    ),
                                    color = RoseGold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "${stringResource(R.string.together_since)}: ",
                                style = MaterialTheme.typography.labelSmall,
                                color = MutedRose
                            )
                            Text(
                                text = formattedStartDate,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = SoftBlush
                            )
                        }
                    }
                }
            }

            // Real-Time Relationship Live Counter (Years, Months, Days + Total Days, Total Months, Total Hours)
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(28.dp),
                    borderColor = CrimsonPrimary.copy(alpha = 0.5f)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = RoseGold,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = stringResource(R.string.time_in_love).uppercase(Locale.getDefault()),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    letterSpacing = 1.sp,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = RoseGold
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Large Row: Years, Months, Days
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            CounterDigitUnit(
                                value = duration.years.toString(),
                                label = stringResource(R.string.counter_years),
                                isPrimary = true
                            )
                            CounterSeparator()
                            CounterDigitUnit(
                                value = duration.months.toString(),
                                label = stringResource(R.string.counter_months),
                                isPrimary = true
                            )
                            CounterSeparator()
                            CounterDigitUnit(
                                value = duration.days.toString(),
                                label = stringResource(R.string.counter_days),
                                isPrimary = true
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Secondary Row: Hours, Minutes, Seconds
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0x3314050F), RoundedCornerShape(18.dp))
                                .padding(vertical = 12.dp, horizontal = 8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceEvenly
                            ) {
                                CounterDigitUnit(
                                    value = duration.hours.toString().padStart(2, '0'),
                                    label = stringResource(R.string.counter_hours),
                                    isPrimary = false
                                )
                                Text(text = ":", color = RoseGold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                CounterDigitUnit(
                                    value = duration.minutes.toString().padStart(2, '0'),
                                    label = stringResource(R.string.counter_minutes),
                                    isPrimary = false
                                )
                                Text(text = ":", color = RoseGold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                CounterDigitUnit(
                                    value = duration.seconds.toString().padStart(2, '0'),
                                    label = stringResource(R.string.counter_seconds),
                                    isPrimary = false
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Total Days / Total Months / Total Hours Banner
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "${duration.totalDays}",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = SoftBlush
                                )
                                Text(
                                    text = stringResource(R.string.total_days),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MutedRose
                                )
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "${duration.totalMonths}",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = SoftBlush
                                )
                                Text(
                                    text = stringResource(R.string.total_months),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MutedRose
                                )
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "${duration.totalHours}",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = SoftBlush
                                )
                                Text(
                                    text = stringResource(R.string.total_hours),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MutedRose
                                )
                            }
                        }
                    }
                }
            }

            // Quick Hub Cards Grid
            item {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        FeatureCard(
                            title = stringResource(R.string.card_memories),
                            subtitle = "${memories.size} ${stringResource(R.string.moments_count)}",
                            icon = Icons.Default.PhotoLibrary,
                            iconTint = Color(0xFFFF5277),
                            onClick = onOpenMemories,
                            modifier = Modifier.weight(1f),
                            testTag = "card_memories"
                        )
                        FeatureCard(
                            title = stringResource(R.string.card_love_letters),
                            subtitle = if (unreadLetters > 0) "$unreadLetters ${stringResource(R.string.unread)}" else "${loveLetters.size} ${stringResource(R.string.letters_count)}",
                            icon = Icons.Default.Mail,
                            iconTint = Color(0xFFFFD194),
                            onClick = onOpenLetters,
                            modifier = Modifier.weight(1f),
                            badgeCount = unreadLetters,
                            testTag = "card_letters"
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        FeatureCard(
                            title = stringResource(R.string.card_goals),
                            subtitle = "${goals.count { it.isCompleted }}/${goals.size} ${stringResource(R.string.done_count)}",
                            icon = Icons.Default.TrackChanges,
                            iconTint = Color(0xFF64FFDA),
                            onClick = onOpenGoals,
                            modifier = Modifier.weight(1f),
                            testTag = "card_goals"
                        )
                        FeatureCard(
                            title = stringResource(R.string.card_notes),
                            subtitle = "${notes.size} ${stringResource(R.string.notes_count)}",
                            icon = Icons.Default.Event,
                            iconTint = Color(0xFFFF8DA1),
                            onClick = onOpenNotes,
                            modifier = Modifier.weight(1f),
                            testTag = "card_notes"
                        )
                    }
                }
            }

            // Dynamic Achievements / Milestones Section
            if (achievements.isNotEmpty()) {
                item {
                    GlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(28.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = null,
                                        tint = RoseGold,
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Text(
                                        text = stringResource(R.string.card_achievements),
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = SoftBlush
                                    )
                                }

                                val unlockedCount = achievements.count { it.isUnlocked }
                                Text(
                                    text = "$unlockedCount / ${achievements.size}",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = CrimsonPrimary
                                )
                            }

                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                achievements.take(4).forEach { item ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(14.dp))
                                            .background(if (item.isUnlocked) Color(0x332B1020) else Color(0x1A150810))
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(CircleShape)
                                                .background(if (item.isUnlocked) CrimsonPrimary.copy(alpha = 0.3f) else Color(0x22FFFFFF)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = if (item.isUnlocked) Icons.Default.Favorite else Icons.Default.Star,
                                                contentDescription = null,
                                                tint = if (item.isUnlocked) CrimsonPrimary else Color.White.copy(alpha = 0.3f),
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }

                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = stringResource(item.titleRes),
                                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                                color = if (item.isUnlocked) SoftBlush else Color.White.copy(alpha = 0.5f)
                                            )
                                            Text(
                                                text = stringResource(item.descRes),
                                                style = MaterialTheme.typography.labelSmall,
                                                color = if (item.isUnlocked) RoseGold else Color.White.copy(alpha = 0.35f)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CounterDigitUnit(
    value: String,
    label: String,
    isPrimary: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = value,
            style = if (isPrimary) {
                MaterialTheme.typography.displaySmall.copy(
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Serif
                )
            } else {
                MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold
                )
            },
            color = if (isPrimary) SoftBlush else RoseGold
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MutedRose
        )
    }
}

@Composable
fun CounterSeparator() {
    Text(
        text = "•",
        style = MaterialTheme.typography.titleLarge,
        color = CrimsonPrimary,
        modifier = Modifier.padding(top = 8.dp)
    )
}

@Composable
fun FeatureCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconTint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    badgeCount: Int = 0,
    testTag: String = ""
) {
    GlassCard(
        modifier = modifier
            .clickable { onClick() }
            .testTag(testTag),
        shape = RoundedCornerShape(22.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(iconTint.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(22.dp)
                    )
                }

                if (badgeCount > 0) {
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(CrimsonPrimary)
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = badgeCount.toString(),
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = SoftBlush
            )

            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MutedRose
            )
        }
    }
}
