package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.model.MemoryEntity
import com.example.ui.components.FloatingHeartsBackground
import com.example.ui.components.GlassCard
import com.example.ui.components.RomanticButton
import com.example.ui.components.RomanticOutlinedButton
import com.example.ui.components.RomanticTextField
import com.example.ui.theme.CrimsonButtonGradient
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.MutedRose
import com.example.ui.theme.RomanticGradient
import com.example.ui.theme.RoseGold
import com.example.ui.theme.SoftBlush
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MemoriesScreen(
    memories: List<MemoryEntity>,
    selectedMemory: MemoryEntity?,
    isAddingMemory: Boolean,
    onSelectMemory: (MemoryEntity?) -> Unit,
    onOpenAddMemory: () -> Unit,
    onCloseAddMemory: () -> Unit,
    onAddMemory: (title: String, description: String, dateMillis: Long, imageDrawable: String, location: String) -> Unit,
    onDeleteMemory: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(RomanticGradient)
            .testTag("memories_screen")
    ) {
        FloatingHeartsBackground(heartCount = 6)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 16.dp, start = 20.dp, end = 20.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = stringResource(R.string.nav_memories),
                        style = MaterialTheme.typography.displayMedium.copy(
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold
                        ),
                        color = SoftBlush
                    )
                    Text(
                        text = "Captured moments of our beautiful love",
                        style = MaterialTheme.typography.labelSmall,
                        color = RoseGold
                    )
                }

                FloatingActionButton(
                    onClick = onOpenAddMemory,
                    containerColor = CrimsonPrimary,
                    contentColor = Color.White,
                    shape = CircleShape,
                    modifier = Modifier
                        .size(50.dp)
                        .testTag("btn_add_memory")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Memory",
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (memories.isEmpty()) {
                // Empty State
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = 80.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(90.dp)
                                .background(Color(0x33FF2E63), CircleShape)
                                .border(1.5.dp, CrimsonPrimary.copy(alpha = 0.5f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PhotoLibrary,
                                contentDescription = null,
                                tint = SoftBlush,
                                modifier = Modifier.size(44.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "No memories yet ❤️",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.Bold
                            ),
                            color = SoftBlush
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Capture and treasure your first shared moment together.",
                            style = MaterialTheme.typography.bodyMedium.copy(textAlign = TextAlign.Center),
                            color = RoseGold
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        RomanticButton(
                            text = "Add First Memory",
                            onClick = onOpenAddMemory,
                            icon = Icons.Default.PhotoCamera,
                            modifier = Modifier.width(220.dp)
                        )
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(bottom = 110.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(memories) { memory ->
                        MemoryGridCard(
                            memory = memory,
                            onClick = { onSelectMemory(memory) }
                        )
                    }
                }
            }
        }

        // Memory Detail Dialog
        if (selectedMemory != null) {
            MemoryDetailDialog(
                memory = selectedMemory,
                onDismiss = { onSelectMemory(null) },
                onDelete = { onDeleteMemory(selectedMemory.id) }
            )
        }

        // Add Memory Dialog
        if (isAddingMemory) {
            AddMemoryDialog(
                onDismiss = onCloseAddMemory,
                onAdd = onAddMemory
            )
        }
    }
}

@Composable
private fun MemoryGridCard(
    memory: MemoryEntity,
    onClick: () -> Unit
) {
    val formattedDate = remember(memory.dateMillis) {
        val sdf = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())
        sdf.format(Date(memory.dateMillis))
    }

    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("memory_card_${memory.id}"),
        shape = RoundedCornerShape(20.dp),
        backgroundColor = Color(0x441F0A18)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
            ) {
                val imageRes = when (memory.imageDrawableName) {
                    "img_romantic_hero" -> R.drawable.img_romantic_hero
                    "img_celebration" -> R.drawable.img_celebration
                    else -> R.drawable.img_memory_default
                }
                Image(
                    painter = painterResource(id = imageRes),
                    contentDescription = memory.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color(0xBB12040C))
                            )
                        )
                )
            }

            Column(
                modifier = Modifier.padding(12.dp)
            ) {
                Text(
                    text = memory.title,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = SoftBlush,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CalendarToday,
                        contentDescription = null,
                        tint = RoseGold,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = formattedDate,
                        style = MaterialTheme.typography.labelSmall,
                        color = RoseGold
                    )
                }
            }
        }
    }
}

@Composable
private fun MemoryDetailDialog(
    memory: MemoryEntity,
    onDismiss: () -> Unit,
    onDelete: () -> Unit
) {
    val formattedDate = remember(memory.dateMillis) {
        val sdf = SimpleDateFormat("MMMM d, yyyy", Locale.getDefault())
        sdf.format(Date(memory.dateMillis))
    }

    Dialog(onDismissRequest = onDismiss) {
        GlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 20.dp),
            shape = RoundedCornerShape(28.dp),
            backgroundColor = Color(0xEE160712)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                ) {
                    val imageRes = when (memory.imageDrawableName) {
                        "img_romantic_hero" -> R.drawable.img_romantic_hero
                        "img_celebration" -> R.drawable.img_celebration
                        else -> R.drawable.img_memory_default
                    }
                    Image(
                        painter = painterResource(id = imageRes),
                        contentDescription = memory.title,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                            .background(Color(0x88000000), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.White
                        )
                    }
                }

                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = memory.title,
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold
                        ),
                        color = SoftBlush
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CalendarToday,
                                contentDescription = null,
                                tint = RoseGold,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = formattedDate,
                                style = MaterialTheme.typography.bodySmall,
                                color = RoseGold
                            )
                        }

                        if (memory.location.isNotBlank()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.LocationOn,
                                    contentDescription = null,
                                    tint = CrimsonPrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = memory.location,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SoftBlush
                                )
                            }
                        }
                    }

                    Text(
                        text = memory.description,
                        style = MaterialTheme.typography.bodyLarge.copy(lineHeight = 22.sp),
                        color = Color.White.copy(alpha = 0.9f)
                    )

                    if (memory.createdByName.isNotBlank()) {
                        Text(
                            text = "Added with love by ${memory.createdByName} ❤️",
                            style = MaterialTheme.typography.labelSmall,
                            color = MutedRose
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    RomanticOutlinedButton(
                        text = "Delete Memory",
                        onClick = onDelete,
                        icon = Icons.Default.Delete,
                        borderColor = MaterialTheme.colorScheme.error,
                        textColor = MaterialTheme.colorScheme.error,
                        testTag = "btn_delete_memory"
                    )
                }
            }
        }
    }
}

@Composable
private fun AddMemoryDialog(
    onDismiss: () -> Unit,
    onAdd: (title: String, description: String, dateMillis: Long, imageDrawable: String, location: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var selectedImage by remember { mutableStateOf("img_memory_default") }

    Dialog(onDismissRequest = onDismiss) {
        GlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 20.dp),
            shape = RoundedCornerShape(28.dp),
            backgroundColor = Color(0xF01A0915)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Add New Memory 📸",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold
                        ),
                        color = SoftBlush
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = SoftBlush)
                    }
                }

                RomanticTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = "Memory Title",
                    placeholder = "e.g. Sunset in Venice",
                    testTag = "input_memory_title"
                )

                RomanticTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = "Love Note / Story",
                    placeholder = "Describe this special moment together...",
                    testTag = "input_memory_desc"
                )

                RomanticTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = "Location",
                    placeholder = "e.g. Seaside Restaurant",
                    leadingIcon = Icons.Default.LocationOn,
                    testTag = "input_memory_location"
                )

                Text(
                    text = "Select Memory Cover Theme",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = RoseGold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    listOf(
                        "img_memory_default" to R.drawable.img_memory_default,
                        "img_romantic_hero" to R.drawable.img_romantic_hero,
                        "img_celebration" to R.drawable.img_celebration
                    ).forEach { (key, resId) ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(60.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .border(
                                    if (selectedImage == key) 2.dp else 1.dp,
                                    if (selectedImage == key) CrimsonPrimary else Color(0x33FF4D79),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { selectedImage = key }
                        ) {
                            Image(
                                painter = painterResource(id = resId),
                                contentDescription = null,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                RomanticButton(
                    text = "Save Memory ❤️",
                    onClick = {
                        if (title.isNotBlank()) {
                            onAdd(
                                title,
                                description.ifBlank { "A cherished memory forever etched in our hearts." },
                                System.currentTimeMillis(),
                                selectedImage,
                                location
                            )
                        }
                    },
                    icon = Icons.Default.PhotoCamera,
                    testTag = "btn_save_memory"
                )
            }
        }
    }
}
