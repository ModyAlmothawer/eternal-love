package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Drafts
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.MarkEmailRead
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.model.LoveLetterEntity
import com.example.ui.components.FloatingHeartsBackground
import com.example.ui.components.GlassCard
import com.example.ui.components.RomanticButton
import com.example.ui.components.RomanticOutlinedButton
import com.example.ui.components.RomanticTextField
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.GoldAccentGradient
import com.example.ui.theme.MutedRose
import com.example.ui.theme.RomanticGradient
import com.example.ui.theme.RoseGold
import com.example.ui.theme.SoftBlush
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LoveLettersScreen(
    loveLetters: List<LoveLetterEntity>,
    selectedLetter: LoveLetterEntity?,
    isWritingLetter: Boolean,
    onOpenLetter: (LoveLetterEntity) -> Unit,
    onCloseLetter: () -> Unit,
    onOpenWriteLetter: () -> Unit,
    onCloseWriteLetter: () -> Unit,
    onSendLetter: (title: String, message: String, themeIndex: Int) -> Unit,
    onDeleteLetter: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(RomanticGradient)
            .testTag("love_letters_screen")
    ) {
        FloatingHeartsBackground(heartCount = 6)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 16.dp, start = 20.dp, end = 20.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = stringResource(R.string.nav_letters),
                        style = MaterialTheme.typography.displayMedium.copy(
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold
                        ),
                        color = SoftBlush
                    )
                    Text(
                        text = "Whispers of adoration sealed forever",
                        style = MaterialTheme.typography.labelSmall,
                        color = RoseGold
                    )
                }

                FloatingActionButton(
                    onClick = onOpenWriteLetter,
                    containerColor = CrimsonPrimary,
                    contentColor = Color.White,
                    shape = CircleShape,
                    modifier = Modifier
                        .size(50.dp)
                        .testTag("btn_write_letter")
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Write Love Letter",
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (loveLetters.isEmpty()) {
                // Empty State
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = 80.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(90.dp)
                                .background(Color(0x33FF2E63), CircleShape)
                                .border(1.5.dp, CrimsonPrimary.copy(alpha = 0.5f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Mail,
                                contentDescription = null,
                                tint = SoftBlush,
                                modifier = Modifier.size(44.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "No Love Letters Yet ❤️",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.Bold
                            ),
                            color = SoftBlush
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Pour your heart onto paper and surprise your soulmate.",
                            style = MaterialTheme.typography.bodyMedium.copy(textAlign = TextAlign.Center),
                            color = RoseGold
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        RomanticButton(
                            text = stringResource(R.string.send_love_letter),
                            onClick = onOpenWriteLetter,
                            icon = Icons.Default.Send,
                            modifier = Modifier.width(240.dp)
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(bottom = 110.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(loveLetters) { letter ->
                        LoveLetterCard(
                            letter = letter,
                            onClick = { onOpenLetter(letter) }
                        )
                    }
                }
            }
        }

        // Open Letter Dialog
        if (selectedLetter != null) {
            ReadLoveLetterDialog(
                letter = selectedLetter,
                onDismiss = onCloseLetter,
                onDelete = { onDeleteLetter(selectedLetter.id) }
            )
        }

        // Write Letter Dialog
        if (isWritingLetter) {
            WriteLoveLetterDialog(
                onDismiss = onCloseWriteLetter,
                onSend = onSendLetter
            )
        }
    }
}

@Composable
private fun LoveLetterCard(
    letter: LoveLetterEntity,
    onClick: () -> Unit
) {
    val formattedDate = remember(letter.dateMillis) {
        val sdf = SimpleDateFormat("MMMM d, yyyy", Locale.getDefault())
        sdf.format(Date(letter.dateMillis))
    }

    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("love_letter_item_${letter.id}"),
        shape = RoundedCornerShape(22.dp),
        backgroundColor = if (letter.isRead) Color(0x33220A1A) else Color(0x55380F29),
        borderColor = if (letter.isRead) Color(0x33FF4D79) else CrimsonPrimary
    ) {
        Row(
            modifier = Modifier.padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Wax Seal Stamp Icon
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .background(
                        if (letter.isRead) Color(0x44FF2E63) else Color(0xFFFF2E63),
                        CircleShape
                    )
                    .border(1.5.dp, RoseGold, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (letter.isRead) Icons.Default.MarkEmailRead else Icons.Default.Drafts,
                    contentDescription = null,
                    tint = if (letter.isRead) SoftBlush else Color.White,
                    modifier = Modifier.size(26.dp)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = letter.title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif
                        ),
                        color = SoftBlush,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    if (!letter.isRead) {
                        Box(
                            modifier = Modifier
                                .background(CrimsonPrimary, RoundedCornerShape(8.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("NEW", style = MaterialTheme.typography.labelSmall, color = Color.White)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = letter.message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.75f),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "From: ${letter.senderName}",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                        color = RoseGold
                    )
                    Text(
                        text = formattedDate,
                        style = MaterialTheme.typography.labelSmall,
                        color = MutedRose
                    )
                }
            }
        }
    }
}

@Composable
private fun ReadLoveLetterDialog(
    letter: LoveLetterEntity,
    onDismiss: () -> Unit,
    onDelete: () -> Unit
) {
    val scaleAnim = remember { Animatable(0.75f) }
    LaunchedEffect(Unit) {
        scaleAnim.animateTo(
            targetValue = 1f,
            animationSpec = tween(500, easing = FastOutSlowInEasing)
        )
    }

    val formattedDate = remember(letter.dateMillis) {
        val sdf = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault())
        sdf.format(Date(letter.dateMillis))
    }

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .scale(scaleAnim.value)
                .fillMaxWidth()
        ) {
            // Elegant Parchment-like romantic card
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                shape = RoundedCornerShape(28.dp),
                backgroundColor = Color(0xF81C0816),
                borderColor = RoseGold.copy(alpha = 0.6f)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = null,
                                tint = CrimsonPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Love Letter",
                                style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 2.sp),
                                color = RoseGold
                            )
                        }

                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = SoftBlush)
                        }
                    }

                    Text(
                        text = letter.title,
                        style = MaterialTheme.typography.displayMedium.copy(
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold
                        ),
                        color = SoftBlush
                    )

                    Text(
                        text = formattedDate,
                        style = MaterialTheme.typography.labelSmall,
                        color = RoseGold
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Color.Transparent, RoseGold, Color.Transparent)
                                )
                            )
                    )

                    Text(
                        text = letter.message,
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontFamily = FontFamily.Serif,
                            fontStyle = FontStyle.Italic,
                            lineHeight = 26.sp,
                            fontSize = 17.sp
                        ),
                        color = Color(0xFFFFF0F3)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Forever & Always,\n${letter.senderName} ❤️",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.End
                        ),
                        color = RoseGold,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    RomanticOutlinedButton(
                        text = "Delete Letter",
                        onClick = onDelete,
                        icon = Icons.Default.Delete,
                        borderColor = MaterialTheme.colorScheme.error,
                        textColor = MaterialTheme.colorScheme.error,
                        testTag = "btn_delete_letter"
                    )
                }
            }
        }
    }
}

@Composable
private fun WriteLoveLetterDialog(
    onDismiss: () -> Unit,
    onSend: (title: String, message: String, themeIndex: Int) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var selectedTheme by remember { mutableIntStateOf(0) }

    Dialog(onDismissRequest = onDismiss) {
        GlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(28.dp),
            backgroundColor = Color(0xF51A0815)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Write Love Letter 💌",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold
                        ),
                        color = SoftBlush
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = SoftBlush)
                    }
                }

                RomanticTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = "Letter Title",
                    placeholder = "e.g. My Heart Belongs To You",
                    testTag = "input_letter_title"
                )

                RomanticTextField(
                    value = message,
                    onValueChange = { message = it },
                    label = "Your Love Message",
                    placeholder = "Write your heartfelt message here...",
                    testTag = "input_letter_message"
                )

                Spacer(modifier = Modifier.height(8.dp))

                RomanticButton(
                    text = stringResource(R.string.send_love_letter),
                    onClick = {
                        if (title.isNotBlank() && message.isNotBlank()) {
                            onSend(title, message, selectedTheme)
                        }
                    },
                    icon = Icons.Default.Send,
                    testTag = "btn_submit_letter"
                )
            }
        }
    }
}
