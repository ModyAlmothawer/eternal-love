package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.TrackChanges
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.model.GoalEntity
import com.example.ui.components.FloatingHeartsBackground
import com.example.ui.components.GlassCard
import com.example.ui.components.RomanticButton
import com.example.ui.components.RomanticTextField
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.GoldAccentGradient
import com.example.ui.theme.MutedRose
import com.example.ui.theme.RomanticGradient
import com.example.ui.theme.RoseGold
import com.example.ui.theme.SoftBlush

@Composable
fun GoalsScreen(
    goals: List<GoalEntity>,
    isAddingGoal: Boolean,
    onOpenAddGoal: () -> Unit,
    onCloseAddGoal: () -> Unit,
    onAddGoal: (title: String, description: String, targetDate: String, category: String) -> Unit,
    onUpdateProgress: (goal: GoalEntity, progress: Int, isCompleted: Boolean) -> Unit,
    onDeleteGoal: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(RomanticGradient)
            .testTag("goals_screen")
    ) {
        FloatingHeartsBackground(heartCount = 6)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 16.dp, start = 20.dp, end = 20.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = stringResource(R.string.nav_goals),
                        style = MaterialTheme.typography.displayMedium.copy(
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold
                        ),
                        color = SoftBlush
                    )
                    Text(
                        text = stringResource(R.string.goals_subtitle),
                        style = MaterialTheme.typography.labelSmall,
                        color = RoseGold
                    )
                }

                FloatingActionButton(
                    onClick = onOpenAddGoal,
                    containerColor = CrimsonPrimary,
                    contentColor = Color.White,
                    shape = CircleShape,
                    modifier = Modifier
                        .size(50.dp)
                        .testTag("btn_add_goal")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = stringResource(R.string.add_goal),
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (goals.isEmpty()) {
                // Empty State
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = 80.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(90.dp)
                                .background(Color(0x33FF2E63), CircleShape)
                                .border(1.5.dp, CrimsonPrimary.copy(alpha = 0.5f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.TrackChanges,
                                contentDescription = null,
                                tint = SoftBlush,
                                modifier = Modifier.size(44.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = stringResource(R.string.no_goals_title),
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.Bold
                            ),
                            color = SoftBlush
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = stringResource(R.string.no_goals_desc),
                            style = MaterialTheme.typography.bodyMedium.copy(textAlign = TextAlign.Center),
                            color = RoseGold
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        RomanticButton(
                            text = stringResource(R.string.add_first_goal),
                            onClick = onOpenAddGoal,
                            icon = Icons.Default.Flag,
                            modifier = Modifier.width(220.dp)
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(bottom = 110.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(goals) { goal ->
                        GoalItemCard(
                            goal = goal,
                            onUpdateProgress = { progress, completed ->
                                onUpdateProgress(goal, progress, completed)
                            },
                            onDelete = { onDeleteGoal(goal.id) }
                        )
                    }
                }
            }
        }

        // Add Goal Dialog
        if (isAddingGoal) {
            AddGoalDialog(
                onDismiss = onCloseAddGoal,
                onAdd = onAddGoal
            )
        }
    }
}

@Composable
private fun GoalItemCard(
    goal: GoalEntity,
    onUpdateProgress: (progress: Int, completed: Boolean) -> Unit,
    onDelete: () -> Unit
) {
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("goal_item_${goal.id}"),
        shape = RoundedCornerShape(24.dp),
        backgroundColor = if (goal.isCompleted) Color(0x33102B19) else Color(0x33250A1C),
        borderColor = if (goal.isCompleted) Color(0x664CAF50) else Color(0x33FF4D79)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    IconButton(
                        onClick = {
                            val newCompleted = !goal.isCompleted
                            val newProg = if (newCompleted) 100 else 50
                            onUpdateProgress(newProg, newCompleted)
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = if (goal.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                            contentDescription = "Toggle Complete",
                            tint = if (goal.isCompleted) Color(0xFF4CAF50) else CrimsonPrimary,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Column {
                        Text(
                            text = goal.title,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Serif
                            ),
                            color = if (goal.isCompleted) Color(0xFFE8F5E9) else SoftBlush
                        )
                        Text(
                            text = "${goal.category} • Target: ${goal.targetDate}",
                            style = MaterialTheme.typography.labelSmall,
                            color = RoseGold
                        )
                    }
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete",
                        tint = MutedRose.copy(alpha = 0.7f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            if (goal.description.isNotBlank()) {
                Text(
                    text = goal.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.8f)
                )
            }

            // Progress Bar and Quick Adjust Buttons
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (goal.isCompleted) stringResource(R.string.completed) else stringResource(R.string.goal_progress),
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = if (goal.isCompleted) Color(0xFF4CAF50) else RoseGold
                    )
                    Text(
                        text = "${goal.progress}%",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = SoftBlush
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                LinearProgressIndicator(
                    progress = { goal.progress / 100f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = if (goal.isCompleted) Color(0xFF4CAF50) else CrimsonPrimary,
                    trackColor = Color(0x33FFFFFF)
                )
            }

            // Quick Progress Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(25, 50, 75, 100).forEach { p ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (goal.progress >= p) Color(0x44FF2E63) else Color(0x22FFFFFF))
                            .clickable {
                                onUpdateProgress(p, p == 100)
                            }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "$p%",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                            color = if (goal.progress >= p) SoftBlush else MutedRose
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AddGoalDialog(
    onDismiss: () -> Unit,
    onAdd: (title: String, description: String, targetDate: String, category: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var targetDate by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        GlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(28.dp),
            backgroundColor = Color(0xF51A0815)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.add_new_goal_dialog_title),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold
                        ),
                        color = SoftBlush
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = stringResource(R.string.close), tint = SoftBlush)
                    }
                }

                RomanticTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = stringResource(R.string.goal_title),
                    placeholder = stringResource(R.string.goal_title_placeholder),
                    testTag = "input_goal_title"
                )

                RomanticTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = stringResource(R.string.goal_description),
                    placeholder = stringResource(R.string.goal_desc_placeholder),
                    testTag = "input_goal_desc"
                )

                RomanticTextField(
                    value = targetDate,
                    onValueChange = { targetDate = it },
                    label = stringResource(R.string.target_date),
                    placeholder = stringResource(R.string.target_date_placeholder),
                    testTag = "input_goal_date"
                )

                RomanticTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = stringResource(R.string.goal_category),
                    placeholder = stringResource(R.string.goal_category_placeholder),
                    testTag = "input_goal_category"
                )

                Spacer(modifier = Modifier.height(8.dp))

                RomanticButton(
                    text = stringResource(R.string.save_goal),
                    onClick = {
                        if (title.isNotBlank()) {
                            onAdd(
                                title,
                                description,
                                targetDate,
                                category
                            )
                        }
                    },
                    icon = Icons.Default.TrackChanges,
                    testTag = "btn_submit_goal"
                )
            }
        }
    }
}
