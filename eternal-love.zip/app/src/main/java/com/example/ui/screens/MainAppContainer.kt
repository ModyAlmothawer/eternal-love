package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.TrackChanges
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.ui.components.GlassCard
import com.example.ui.components.RomanticButton
import com.example.ui.components.RomanticTextField
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.viewmodel.MainTab
import com.example.ui.viewmodel.MainViewModel

@Composable
fun MainAppContainer(
    viewModel: MainViewModel,
    onLogout: () -> Unit,
    onDisconnected: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val relationship by viewModel.currentRelationship.collectAsState()
    val currentTab by viewModel.currentTab.collectAsState()
    val duration by viewModel.relationshipDuration.collectAsState()

    val memories by viewModel.memories.collectAsState()
    val loveLetters by viewModel.loveLetters.collectAsState()
    val notes by viewModel.notes.collectAsState()
    val goals by viewModel.goals.collectAsState()
    val specialDates by viewModel.specialDates.collectAsState()
    val notifications by viewModel.notifications.collectAsState()
    val achievements by viewModel.achievements.collectAsState()

    val isDarkMode by viewModel.isDarkMode.collectAsState()
    val currentLanguage by viewModel.currentLanguage.collectAsState()

    val selectedMemory by viewModel.selectedMemory.collectAsState()
    val selectedLetter by viewModel.selectedLoveLetter.collectAsState()
    val isAddingMemory by viewModel.isAddingMemory.collectAsState()
    val isWritingLetter by viewModel.isWritingLetter.collectAsState()
    val isAddingNote by viewModel.isAddingNote.collectAsState()
    val isAddingGoal by viewModel.isAddingGoal.collectAsState()
    val isAddingSpecialDate by viewModel.isAddingSpecialDate.collectAsState()

    val isViewingNotes by viewModel.isViewingNotes.collectAsState()
    val isViewingSpecialDates by viewModel.isViewingSpecialDates.collectAsState()
    val isViewingNotifications by viewModel.isViewingNotifications.collectAsState()
    val isViewingStory by viewModel.isViewingStory.collectAsState()
    val isUpdatingStatus by viewModel.isUpdatingStatus.collectAsState()

    val isEditingProfile by viewModel.isEditingProfile.collectAsState()
    val isEditingRelationship by viewModel.isEditingRelationship.collectAsState()
    val showDisconnectConfirmation by viewModel.showDisconnectConfirmation.collectAsState()

    Scaffold(
        bottomBar = {
            ModernBottomNavBar(
                currentTab = currentTab,
                onTabSelected = { viewModel.selectTab(it) }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "tab_transition"
            ) { tab ->
                when (tab) {
                    MainTab.HOME -> {
                        HomeScreen(
                            currentUser = currentUser,
                            relationship = relationship,
                            duration = duration,
                            memories = memories,
                            loveLetters = loveLetters,
                            notes = notes,
                            goals = goals,
                            specialDates = specialDates,
                            notifications = notifications,
                            achievements = achievements,
                            onOpenMemories = { viewModel.selectTab(MainTab.MEMORIES) },
                            onOpenLetters = { viewModel.selectTab(MainTab.LETTERS) },
                            onOpenNotes = { viewModel.isViewingNotes.value = true },
                            onOpenGoals = { viewModel.selectTab(MainTab.GOALS) },
                            onOpenSpecialDates = { viewModel.isViewingSpecialDates.value = true },
                            onOpenStory = { viewModel.isViewingStory.value = true },
                            onOpenNotifications = { viewModel.isViewingNotifications.value = true },
                            onOpenProfile = { viewModel.selectTab(MainTab.PROFILE) },
                            onOpenStatusPicker = { viewModel.isUpdatingStatus.value = true }
                        )
                    }
                    MainTab.MEMORIES -> {
                        MemoriesScreen(
                            memories = memories,
                            selectedMemory = selectedMemory,
                            isAddingMemory = isAddingMemory,
                            onSelectMemory = { viewModel.selectedMemory.value = it },
                            onOpenAddMemory = { viewModel.isAddingMemory.value = true },
                            onCloseAddMemory = { viewModel.isAddingMemory.value = false },
                            onAddMemory = { title, desc, date, imgUri, loc ->
                                viewModel.addMemory(title, desc, date, imgUri, loc)
                            },
                            onDeleteMemory = { viewModel.deleteMemory(it) }
                        )
                    }
                    MainTab.LETTERS -> {
                        LoveLettersScreen(
                            loveLetters = loveLetters,
                            selectedLetter = selectedLetter,
                            isWritingLetter = isWritingLetter,
                            onOpenLetter = { viewModel.openLoveLetter(it) },
                            onCloseLetter = { viewModel.selectedLoveLetter.value = null },
                            onOpenWriteLetter = { viewModel.isWritingLetter.value = true },
                            onCloseWriteLetter = { viewModel.isWritingLetter.value = false },
                            onSendLetter = { title, msg, theme ->
                                viewModel.sendLoveLetter(title, msg, theme)
                            },
                            onDeleteLetter = { viewModel.deleteLoveLetter(it) }
                        )
                    }
                    MainTab.GOALS -> {
                        GoalsScreen(
                            goals = goals,
                            isAddingGoal = isAddingGoal,
                            onOpenAddGoal = { viewModel.isAddingGoal.value = true },
                            onCloseAddGoal = { viewModel.isAddingGoal.value = false },
                            onAddGoal = { title, desc, date, cat ->
                                viewModel.addGoal(title, desc, date, cat)
                            },
                            onUpdateProgress = { goal, prog, done ->
                                viewModel.updateGoalProgress(goal, prog, done)
                            },
                            onDeleteGoal = { viewModel.deleteGoal(it) }
                        )
                    }
                    MainTab.PROFILE -> {
                        ProfileAndSettingsScreen(
                            currentUser = currentUser,
                            relationship = relationship,
                            isDarkMode = isDarkMode,
                            currentLanguage = currentLanguage,
                            onToggleDarkMode = { viewModel.toggleDarkMode(it) },
                            onSetLanguage = { viewModel.setLanguage(it) },
                            onEditProfile = { viewModel.isEditingProfile.value = true },
                            onEditRelationship = { viewModel.isEditingRelationship.value = true },
                            onDisconnectClick = { viewModel.showDisconnectConfirmation.value = true },
                            onLogout = onLogout
                        )
                    }
                }
            }

            // Daily Mood / Status Picker Dialog
            if (isUpdatingStatus) {
                DailyStatusPickerDialog(
                    currentStatus = currentUser?.dailyStatus ?: "",
                    currentEmoji = currentUser?.dailyEmoji ?: "😄",
                    onDismiss = { viewModel.isUpdatingStatus.value = false },
                    onSave = { status, emoji ->
                        viewModel.updateDailyStatus(status, emoji)
                    }
                )
            }

            // Modals
            if (isViewingNotes) {
                NotesModalDialog(
                    notes = notes,
                    onDismiss = { viewModel.isViewingNotes.value = false },
                    onOpenAddNote = { viewModel.isAddingNote.value = true },
                    onDeleteNote = { viewModel.deleteNote(it) }
                )
            }

            if (isAddingNote) {
                AddNoteDialog(
                    onDismiss = { viewModel.isAddingNote.value = false },
                    onAdd = { title, content, cat ->
                        viewModel.addNote(title, content, cat)
                    }
                )
            }

            if (isViewingSpecialDates) {
                SpecialDatesModalDialog(
                    specialDates = specialDates,
                    onDismiss = { viewModel.isViewingSpecialDates.value = false },
                    onOpenAddDate = { viewModel.isAddingSpecialDate.value = true },
                    onDeleteDate = { viewModel.deleteSpecialDate(it) }
                )
            }

            if (isAddingSpecialDate) {
                AddSpecialDateDialog(
                    onDismiss = { viewModel.isAddingSpecialDate.value = false },
                    onAdd = { title, dateMillis, type ->
                        viewModel.addSpecialDate(title, dateMillis, type)
                    }
                )
            }

            if (isViewingStory) {
                OurStoryModalDialog(
                    relationship = relationship,
                    onDismiss = { viewModel.isViewingStory.value = false }
                )
            }

            if (isViewingNotifications) {
                NotificationsModalDialog(
                    notifications = notifications,
                    onDismiss = { viewModel.isViewingNotifications.value = false },
                    onMarkRead = { /* repository mark notif */ }
                )
            }

            if (isEditingProfile) {
                EditProfileDialog(
                    currentName = currentUser?.name ?: "",
                    currentAvatar = currentUser?.avatarRes ?: "avatar_1",
                    currentPhotoUrl = currentUser?.photoUrl ?: "",
                    onDismiss = { viewModel.isEditingProfile.value = false },
                    onSave = { name, avatar, photoUri ->
                        if (photoUri != null) {
                            viewModel.uploadProfileImage(photoUri)
                        }
                        viewModel.updateProfile(name, avatar)
                    }
                )
            }

            if (isEditingRelationship) {
                EditRelationshipDialog(
                    currentName = relationship?.relationshipName ?: "",
                    onDismiss = { viewModel.isEditingRelationship.value = false },
                    onSave = { name, startMillis ->
                        viewModel.updateRelationship(name, startMillis)
                    }
                )
            }

            if (showDisconnectConfirmation) {
                AlertDialog(
                    onDismissRequest = { viewModel.showDisconnectConfirmation.value = false },
                    title = {
                        Text(
                            text = stringResource(R.string.disconnect_relationship),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    },
                    text = {
                        Text(
                            text = stringResource(R.string.disconnect_dialog_message),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    },
                    confirmButton = {
                        TextButton(
                            onClick = {
                                viewModel.disconnectRelationship(onDisconnected)
                            },
                            colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) {
                            Text(stringResource(R.string.disconnect))
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { viewModel.showDisconnectConfirmation.value = false }) {
                            Text(stringResource(R.string.cancel), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    },
                    containerColor = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(20.dp)
                )
            }
        }
    }
}

@Composable
fun DailyStatusPickerDialog(
    currentStatus: String,
    currentEmoji: String,
    onDismiss: () -> Unit,
    onSave: (status: String, emoji: String) -> Unit
) {
    var statusText by remember { mutableStateOf(currentStatus) }
    var selectedEmoji by remember { mutableStateOf(currentEmoji.ifBlank { "😄" }) }

    val presetOptions = listOf(
        "😄" to "فرحان وبحبك",
        "💼" to "مشغول في الشغل",
        "❤️" to "محتاج أكلمك",
        "🥱" to "تعبان شوية",
        "✨" to "مبسوط وفايق",
        "🎉" to "متحمس لحاجة حلوة",
        "☕" to "باخد استراحة قهوة",
        "😴" to "هنام، تصبح على خير"
    )

    Dialog(onDismissRequest = onDismiss) {
        GlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            shape = RoundedCornerShape(24.dp),
            backgroundColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "إزاي حاسس النهاردة؟",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(
                            Icons.Default.Close,
                            contentDescription = "Close",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Text(
                    text = "اختار حالتك عشان شريكك يشوفها على الشاشة الرئيسية فورًا:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Presets Grid / Chips
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    presetOptions.forEach { (emoji, text) ->
                        val isSelected = selectedEmoji == emoji && statusText == text
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable {
                                    selectedEmoji = emoji
                                    statusText = text
                                }
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = emoji, fontSize = 20.sp)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = text,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                ),
                                color = if (isSelected) CrimsonPrimary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                RomanticTextField(
                    value = statusText,
                    onValueChange = { statusText = it },
                    label = "أو اكتب حالتك الخاصة",
                    placeholder = "اكتب حالتك هنا...",
                    testTag = "input_custom_status"
                )

                Spacer(modifier = Modifier.height(4.dp))

                RomanticButton(
                    text = "حفظ ومشاركة الحالة",
                    onClick = {
                        if (statusText.isNotBlank()) {
                            onSave(statusText.trim(), selectedEmoji)
                        }
                    },
                    testTag = "btn_save_daily_status"
                )
            }
        }
    }
}

@Composable
fun ModernBottomNavBar(
    currentTab: MainTab,
    onTabSelected: (MainTab) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier.navigationBarsPadding(),
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp
    ) {
        val items = listOf(
            Triple(MainTab.HOME, stringResource(R.string.nav_home), Icons.Default.Home),
            Triple(MainTab.MEMORIES, stringResource(R.string.nav_memories), Icons.Default.PhotoLibrary),
            Triple(MainTab.LETTERS, stringResource(R.string.nav_letters), Icons.Default.Mail),
            Triple(MainTab.GOALS, stringResource(R.string.nav_goals), Icons.Default.TrackChanges),
            Triple(MainTab.PROFILE, stringResource(R.string.nav_profile), Icons.Default.Person)
        )

        items.forEach { (tab, title, icon) ->
            val selected = currentTab == tab
            NavigationBarItem(
                selected = selected,
                onClick = { onTabSelected(tab) },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        modifier = Modifier.size(22.dp)
                    )
                },
                label = {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                        )
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = CrimsonPrimary,
                    selectedTextColor = CrimsonPrimary,
                    indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                ),
                modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
            )
        }
    }
}
