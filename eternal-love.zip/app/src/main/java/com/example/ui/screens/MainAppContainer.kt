package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.TrackChanges
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.MutedRose
import com.example.ui.theme.RomanticGradient
import com.example.ui.theme.RoseGold
import com.example.ui.theme.SoftBlush
import com.example.ui.viewmodel.MainTab
import com.example.ui.viewmodel.MainViewModel

@Composable
fun MainAppContainer(
    viewModel: MainViewModel,
    onLogout: () -> Unit,
    onDisconnected: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val relationship by viewModel.currentRelationship.collectAsState()
    val currentTab by viewModel.currentTab.collectAsState()
    val duration by viewModel.relationshipDuration.collectAsState()

    val memories by viewModel.memories.collectAsState()
    val loveLetters by viewModel.loveLetters.collectAsState()
    val notes by viewModel.notes.collectAsState()
    val goals by viewModel.goals.collectAsState()
    val specialDates by viewModel.specialDates.collectAsState()
    val notifications by viewModel.notifications.collectAsState()

    val isDarkMode by viewModel.isDarkMode.collectAsState()
    val currentLanguage by viewModel.currentLanguage.collectAsState()

    val selectedMemory by viewModel.selectedMemory.collectAsState()
    val selectedLetter by viewModel.selectedLoveLetter.collectAsState()
    val isAddingMemory by viewModel.isAddingMemory.collectAsState()
    val isWritingLetter by viewModel.isWritingLetter.collectAsState()
    val isAddingNote by viewModel.isAddingNote.collectAsState()
    val isAddingGoal by viewModel.isAddingGoal.collectAsState()
    val isAddingSpecialDate by viewModel.isAddingSpecialDate.collectAsState()

    val isViewingNotes by viewModel.isViewingNotes.collectAsState()
    val isViewingSpecialDates by viewModel.isViewingSpecialDates.collectAsState()
    val isViewingNotifications by viewModel.isViewingNotifications.collectAsState()
    val isViewingStory by viewModel.isViewingStory.collectAsState()

    val isEditingProfile by viewModel.isEditingProfile.collectAsState()
    val isEditingRelationship by viewModel.isEditingRelationship.collectAsState()
    val showDisconnectConfirmation by viewModel.showDisconnectConfirmation.collectAsState()

    Scaffold(
        bottomBar = {
            RomanticBottomNavBar(
                currentTab = currentTab,
                onTabSelected = { viewModel.selectTab(it) }
            )
        },
        containerColor = Color.Transparent
    ) { innerPadding ->
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "tab_transition"
            ) { tab ->
                when (tab) {
                    MainTab.HOME -> {
                        HomeScreen(
                            currentUser = currentUser,
                            relationship = relationship,
                            duration = duration,
                            memories = memories,
                            loveLetters = loveLetters,
                            notes = notes,
                            goals = goals,
                            specialDates = specialDates,
                            notifications = notifications,
                            onOpenMemories = { viewModel.selectTab(MainTab.MEMORIES) },
                            onOpenLetters = { viewModel.selectTab(MainTab.LETTERS) },
                            onOpenNotes = { viewModel.isViewingNotes.value = true },
                            onOpenGoals = { viewModel.selectTab(MainTab.GOALS) },
                            onOpenSpecialDates = { viewModel.isViewingSpecialDates.value = true },
                            onOpenStory = { viewModel.isViewingStory.value = true },
                            onOpenNotifications = { viewModel.isViewingNotifications.value = true },
                            onOpenProfile = { viewModel.selectTab(MainTab.PROFILE) }
                        )
                    }
                    MainTab.MEMORIES -> {
                        MemoriesScreen(
                            memories = memories,
                            selectedMemory = selectedMemory,
                            isAddingMemory = isAddingMemory,
                            onSelectMemory = { viewModel.selectedMemory.value = it },
                            onOpenAddMemory = { viewModel.isAddingMemory.value = true },
                            onCloseAddMemory = { viewModel.isAddingMemory.value = false },
                            onAddMemory = { title, desc, date, img, loc ->
                                viewModel.addMemory(title, desc, date, img, loc)
                            },
                            onDeleteMemory = { viewModel.deleteMemory(it) }
                        )
                    }
                    MainTab.LETTERS -> {
                        LoveLettersScreen(
                            loveLetters = loveLetters,
                            selectedLetter = selectedLetter,
                            isWritingLetter = isWritingLetter,
                            onOpenLetter = { viewModel.openLoveLetter(it) },
                            onCloseLetter = { viewModel.selectedLoveLetter.value = null },
                            onOpenWriteLetter = { viewModel.isWritingLetter.value = true },
                            onCloseWriteLetter = { viewModel.isWritingLetter.value = false },
                            onSendLetter = { title, msg, theme ->
                                viewModel.sendLoveLetter(title, msg, theme)
                            },
                            onDeleteLetter = { viewModel.deleteLoveLetter(it) }
                        )
                    }
                    MainTab.GOALS -> {
                        GoalsScreen(
                            goals = goals,
                            isAddingGoal = isAddingGoal,
                            onOpenAddGoal = { viewModel.isAddingGoal.value = true },
                            onCloseAddGoal = { viewModel.isAddingGoal.value = false },
                            onAddGoal = { title, desc, date, cat ->
                                viewModel.addGoal(title, desc, date, cat)
                            },
                            onUpdateProgress = { goal, prog, done ->
                                viewModel.updateGoalProgress(goal, prog, done)
                            },
                            onDeleteGoal = { viewModel.deleteGoal(it) }
                        )
                    }
                    MainTab.PROFILE -> {
                        ProfileAndSettingsScreen(
                            currentUser = currentUser,
                            relationship = relationship,
                            isDarkMode = isDarkMode,
                            currentLanguage = currentLanguage,
                            onToggleDarkMode = { viewModel.toggleDarkMode(it) },
                            onSetLanguage = { viewModel.setLanguage(it) },
                            onEditProfile = { viewModel.isEditingProfile.value = true },
                            onEditRelationship = { viewModel.isEditingRelationship.value = true },
                            onDisconnectClick = { viewModel.showDisconnectConfirmation.value = true },
                            onLogout = onLogout
                        )
                    }
                }
            }

            // Modals
            if (isViewingNotes) {
                NotesModalDialog(
                    notes = notes,
                    onDismiss = { viewModel.isViewingNotes.value = false },
                    onOpenAddNote = { viewModel.isAddingNote.value = true },
                    onDeleteNote = { viewModel.deleteNote(it) }
                )
            }

            if (isAddingNote) {
                AddNoteDialog(
                    onDismiss = { viewModel.isAddingNote.value = false },
                    onAdd = { title, content, cat ->
                        viewModel.addNote(title, content, cat)
                    }
                )
            }

            if (isViewingSpecialDates) {
                SpecialDatesModalDialog(
                    specialDates = specialDates,
                    onDismiss = { viewModel.isViewingSpecialDates.value = false },
                    onOpenAddDate = { viewModel.isAddingSpecialDate.value = true },
                    onDeleteDate = { viewModel.deleteSpecialDate(it) }
                )
            }

            if (isAddingSpecialDate) {
                AddSpecialDateDialog(
                    onDismiss = { viewModel.isAddingSpecialDate.value = false },
                    onAdd = { title, dateMillis, type ->
                        viewModel.addSpecialDate(title, dateMillis, type)
                    }
                )
            }

            if (isViewingStory) {
                OurStoryModalDialog(
                    relationship = relationship,
                    onDismiss = { viewModel.isViewingStory.value = false }
                )
            }

            if (isViewingNotifications) {
                NotificationsModalDialog(
                    notifications = notifications,
                    onDismiss = { viewModel.isViewingNotifications.value = false },
                    onMarkRead = { /* repository mark notif */ }
                )
            }

            if (isEditingProfile) {
                EditProfileDialog(
                    currentName = currentUser?.name ?: "",
                    onDismiss = { viewModel.isEditingProfile.value = false },
                    onSave = { name, avatar ->
                        viewModel.updateProfile(name, avatar)
                    }
                )
            }

            if (isEditingRelationship) {
                EditRelationshipDialog(
                    currentName = relationship?.relationshipName ?: "",
                    onDismiss = { viewModel.isEditingRelationship.value = false },
                    onSave = { name, startMillis ->
                        viewModel.updateRelationship(name, startMillis)
                    }
                )
            }

            if (showDisconnectConfirmation) {
                AlertDialog(
                    onDismissRequest = { viewModel.showDisconnectConfirmation.value = false },
                    title = {
                        Text(
                            text = "Disconnect Relationship?",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = SoftBlush
                        )
                    },
                    text = {
                        Text(
                            text = "Are you sure you want to disconnect from this relationship? You will return to the connection screen.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                    },
                    confirmButton = {
                        TextButton(
                            onClick = {
                                viewModel.disconnectRelationship(onDisconnected)
                            },
                            colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) {
                            Text("Disconnect")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { viewModel.showDisconnectConfirmation.value = false }) {
                            Text("Cancel", color = SoftBlush)
                        }
                    },
                    containerColor = Color(0xF01D0A18),
                    shape = RoundedCornerShape(24.dp)
                )
            }
        }
    }
}

@Composable
fun RomanticBottomNavBar(
    currentTab: MainTab,
    onTabSelected: (MainTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .shadow(16.dp, RoundedCornerShape(32.dp), ambientColor = CrimsonPrimary, spotColor = CrimsonPrimary)
            .border(1.dp, Color(0x44FF4D79), RoundedCornerShape(32.dp)),
        shape = RoundedCornerShape(32.dp),
        color = Color(0xF0180614)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp, horizontal = 6.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            NavBarItem(
                title = stringResource(R.string.nav_home),
                icon = Icons.Default.Home,
                isSelected = currentTab == MainTab.HOME,
                onClick = { onTabSelected(MainTab.HOME) },
                testTag = "nav_tab_home"
            )

            NavBarItem(
                title = stringResource(R.string.nav_memories),
                icon = Icons.Default.PhotoLibrary,
                isSelected = currentTab == MainTab.MEMORIES,
                onClick = { onTabSelected(MainTab.MEMORIES) },
                testTag = "nav_tab_memories"
            )

            NavBarItem(
                title = stringResource(R.string.nav_letters),
                icon = Icons.Default.Mail,
                isSelected = currentTab == MainTab.LETTERS,
                onClick = { onTabSelected(MainTab.LETTERS) },
                testTag = "nav_tab_letters"
            )

            NavBarItem(
                title = stringResource(R.string.nav_goals),
                icon = Icons.Default.TrackChanges,
                isSelected = currentTab == MainTab.GOALS,
                onClick = { onTabSelected(MainTab.GOALS) },
                testTag = "nav_tab_goals"
            )

            NavBarItem(
                title = stringResource(R.string.nav_profile),
                icon = Icons.Default.Person,
                isSelected = currentTab == MainTab.PROFILE,
                onClick = { onTabSelected(MainTab.PROFILE) },
                testTag = "nav_tab_profile"
            )
        }
    }
}

@Composable
private fun NavBarItem(
    title: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (isSelected) Color(0x33FF2E63) else Color.Transparent)
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (isSelected) CrimsonPrimary else MutedRose,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                    fontSize = 10.sp
                ),
                color = if (isSelected) SoftBlush else MutedRose
            )
        }
    }
}
