package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.FloatingHeartsBackground
import com.example.ui.components.GlassCard
import com.example.ui.components.RomanticButton
import com.example.ui.components.RomanticOutlinedButton
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.RomanticGradient
import com.example.ui.theme.RoseGold
import com.example.ui.theme.SoftBlush
import kotlin.random.Random

@Composable
fun CelebrationScreen(
    userName: String,
    partnerName: String,
    loveCode: String?,
    onContinue: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val pulseScale = remember { Animatable(0.8f) }
    val heartFloat = remember { Animatable(0f) }
    val scrollState = rememberScrollState()

    LaunchedEffect(Unit) {
        pulseScale.animateTo(
            targetValue = 1f,
            animationSpec = tween(700, easing = FastOutSlowInEasing)
        )
        heartFloat.animateTo(
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(1500, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            )
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(RomanticGradient)
            .testTag("celebration_screen")
    ) {
        ConfettiParticleOverlay()
        FloatingHeartsBackground(heartCount = 16)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // Celebration Visual with Connected Hearts
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .scale(pulseScale.value)
                        .size(140.dp)
                        .shadow(24.dp, CircleShape, ambientColor = CrimsonPrimary, spotColor = CrimsonPrimary)
                        .clip(CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_celebration),
                        contentDescription = "Celebration Hearts",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = stringResource(R.string.you_are_connected),
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    ),
                    color = SoftBlush
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = stringResource(R.string.celebration_subtitle),
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontWeight = FontWeight.Normal,
                        textAlign = TextAlign.Center
                    ),
                    color = RoseGold
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Connected Avatars Card
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // User Avatar
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .background(Color(0x55FF2E63), CircleShape)
                                    .border(2.dp, CrimsonPrimary, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = SoftBlush,
                                    modifier = Modifier.size(34.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = userName.ifBlank { "You" },
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = SoftBlush
                            )
                        }

                        // Pulsing Heart Bridge
                        Box(
                            modifier = Modifier
                                .scale(1f + heartFloat.value * 0.18f)
                                .size(44.dp)
                                .background(CrimsonPrimary.copy(alpha = 0.2f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = null,
                                tint = CrimsonPrimary,
                                modifier = Modifier.size(28.dp)
                            )
                        }

                        // Partner Avatar
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .background(Color(0x55FFD194), CircleShape)
                                    .border(2.dp, RoseGold, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = RoseGold,
                                    modifier = Modifier.size(34.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = partnerName.ifBlank { "Partner" },
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = RoseGold
                            )
                        }
                    }

                    if (!loveCode.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(20.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0x441A0813), RoundedCornerShape(16.dp))
                                .border(1.dp, Color(0x55FF4D79), RoundedCornerShape(16.dp))
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = stringResource(R.string.your_love_code),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = RoseGold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = loveCode,
                                    style = MaterialTheme.typography.headlineMedium.copy(
                                        letterSpacing = 6.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    ),
                                    color = SoftBlush
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = stringResource(R.string.give_code_message),
                                    style = MaterialTheme.typography.bodySmall.copy(textAlign = TextAlign.Center),
                                    color = Color.White.copy(alpha = 0.7f)
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    RomanticOutlinedButton(
                                        text = stringResource(R.string.copy_code),
                                        onClick = {
                                            val clipboard =
                                                context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            val clip = ClipData.newPlainText("Love Code", loveCode)
                                            clipboard.setPrimaryClip(clip)
                                            Toast.makeText(context, "Code copied to clipboard ❤️", Toast.LENGTH_SHORT).show()
                                        },
                                        icon = Icons.Default.ContentCopy,
                                        modifier = Modifier.weight(1f),
                                        testTag = "btn_copy_code"
                                    )

                                    RomanticOutlinedButton(
                                        text = stringResource(R.string.share_code),
                                        onClick = {
                                            val sendIntent: Intent = Intent().apply {
                                                action = Intent.ACTION_SEND
                                                putExtra(
                                                    Intent.EXTRA_TEXT,
                                                    "Join me on ETERNAL LOVE ❤️ using our special code: $loveCode"
                                                )
                                                type = "text/plain"
                                            }
                                            val shareIntent = Intent.createChooser(sendIntent, "Share Love Code")
                                            context.startActivity(shareIntent)
                                        },
                                        icon = Icons.Default.Share,
                                        modifier = Modifier.weight(1f),
                                        testTag = "btn_share_code"
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            RomanticButton(
                text = stringResource(R.string.continue_action),
                onClick = onContinue,
                icon = Icons.Default.Favorite,
                testTag = "celebration_continue_button"
            )
        }
    }
}

@Composable
fun ConfettiParticleOverlay() {
    val particles = remember {
        List(30) {
            ConfettiParticle(
                x = Random.nextFloat(),
                speed = 0.4f + Random.nextFloat() * 0.6f,
                size = 6f + Random.nextFloat() * 8f,
                color = when (Random.nextInt(4)) {
                    0 -> CrimsonPrimary
                    1 -> RoseGold
                    2 -> SoftBlush
                    else -> Color(0xFFFF8DA1)
                }
            )
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "confetti")
    val animProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "confetti_anim"
    )

    Canvas(modifier = Modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        particles.forEachIndexed { i, p ->
            val progress = (animProgress * p.speed + (i.toFloat() / 30)) % 1f
            val y = height * progress
            val x = (p.x * width + Math.sin(progress * 4 * Math.PI).toFloat() * 20f).coerceIn(0f, width)

            drawCircle(
                color = p.color.copy(alpha = 0.7f),
                radius = p.size,
                center = Offset(x, y)
            )
        }
    }
}

private data class ConfettiParticle(
    val x: Float,
    val speed: Float,
    val size: Float,
    val color: Color
)
