package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Modern Dark Palette (Clean, Charcoal Slate, No Gothic Magenta)
val ModernDarkBackground = Color(0xFF0F1117)
val ModernDarkSurface = Color(0xFF181A22)
val ModernDarkSurfaceElevated = Color(0xFF222530)
val ModernDarkSurfaceBorder = Color(0xFF2E3240)

// Modern Primary Coral/Rose (Refined, Elegant)
val CrimsonPrimary = Color(0xFFE54861)
val CrimsonPrimaryLight = Color(0xFFF0657D)
val CrimsonPrimaryDark = Color(0xFFC7364D)

// Warm Champagne & Accent
val RoseGold = Color(0xFFE8BA8B)
val RoseGoldDark = Color(0xFFB07D4F)
val SoftBlush = Color(0xFFFDE8EC)
val WarmWhite = Color(0xFFF9FAFB)
val MutedRose = Color(0xFF9CA3AF)

val GlassCardBackground = Color(0x1AFFFFFF)
val GlassCardBorder = Color(0x2EFFFFFF)

// Modern Light Palette (Clean, Crisp, Minimalist)
val ModernLightBackground = Color(0xFFF8F9FA)
val ModernLightSurface = Color(0xFFFFFFFF)
val ModernLightSurfaceElevated = Color(0xFFF1F3F7)
val ModernLightText = Color(0xFF111827)
val ModernLightTextMuted = Color(0xFF6B7280)
val ModernLightBorder = Color(0xFFE5E7EB)

// Modern Gradients
val ModernBackgroundGradient = Brush.verticalGradient(
    colors = listOf(
        Color(0xFF151821),
        Color(0xFF0F1117),
        Color(0xFF0B0C10)
    )
)

val RomanticGradient = ModernBackgroundGradient

val ModernLightBackgroundGradient = Brush.verticalGradient(
    colors = listOf(
        Color(0xFFFFFFFF),
        Color(0xFFF8F9FA),
        Color(0xFFF1F3F5)
    )
)

val ModernCardGradient = Brush.linearGradient(
    colors = listOf(
        Color(0x33222530),
        Color(0x1A181A22)
    )
)

val RomanticCardGradient = ModernCardGradient

val CrimsonButtonGradient = Brush.horizontalGradient(
    colors = listOf(
        Color(0xFFE54861),
        Color(0xFFF0657D)
    )
)

val GoldAccentGradient = Brush.horizontalGradient(
    colors = listOf(
        Color(0xFFE8BA8B),
        Color(0xFFD49B6A)
    )
)
