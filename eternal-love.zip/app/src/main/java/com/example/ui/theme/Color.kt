package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Primary Romantic Palette
val WineDark = Color(0xFF0D0509)
val WineSurfaceDark = Color(0xFF180A12)
val WineSurfaceElevated = Color(0xFF24101D)
val WineSurfaceBorder = Color(0x33FF4D79)

val CrimsonPrimary = Color(0xFFFF2E63)
val CrimsonPrimaryLight = Color(0xFFFF577F)
val CrimsonPrimaryDark = Color(0xFFC70039)

val RoseGold = Color(0xFFFFD194)
val RoseGoldDark = Color(0xFFD1913C)
val SoftBlush = Color(0xFFFFDDE4)
val WarmWhite = Color(0xFFFFF7F8)
val MutedRose = Color(0xFFB3929C)

val GlassCardBackground = Color(0x332B1020)
val GlassCardBorder = Color(0x44FF3366)

// Light Theme Palette
val RoseLightBackground = Color(0xFFFFF5F7)
val RoseLightSurface = Color(0xFFFFFFFF)
val RoseLightSurfaceElevated = Color(0xFFFFEEF2)
val RoseLightText = Color(0xFF2B0E1B)
val RoseLightTextMuted = Color(0xFF885769)

// Gradients
val RomanticGradient = Brush.verticalGradient(
    colors = listOf(
        Color(0xFF230818),
        Color(0xFF10040B),
        Color(0xFF080205)
    )
)

val RomanticCardGradient = Brush.linearGradient(
    colors = listOf(
        Color(0x664A122A),
        Color(0x44260917)
    )
)

val CrimsonButtonGradient = Brush.horizontalGradient(
    colors = listOf(
        Color(0xFFFF2E63),
        Color(0xFFFF6480)
    )
)

val GoldAccentGradient = Brush.horizontalGradient(
    colors = listOf(
        Color(0xFFFFE259),
        Color(0xFFFFA751)
    )
)
