package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.data.model.NoteEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.RelationshipEntity
import com.example.data.model.SpecialDateEntity
import com.example.ui.components.GlassCard
import com.example.ui.components.RomanticButton
import com.example.ui.components.RomanticTextField
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.GoldAccentGradient
import com.example.ui.theme.MutedRose
import com.example.ui.theme.RoseGold
import com.example.ui.theme.SoftBlush
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

// NOTES DIALOG
@Composable
fun NotesModalDialog(
    notes: List<NoteEntity>,
    onDismiss: () -> Unit,
    onOpenAddNote: () -> Unit,
    onDeleteNote: (Long) -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        GlassCard(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            shape = RoundedCornerShape(28.dp),
            backgroundColor = Color(0xF8160613)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = stringResource(R.string.notes_title),
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.Bold
                            ),
                            color = SoftBlush
                        )
                        Text(
                            text = stringResource(R.string.notes_subtitle),
                            style = MaterialTheme.typography.labelSmall,
                            color = RoseGold
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = stringResource(R.string.close), tint = SoftBlush)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (notes.isEmpty()) {
                    Box(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(stringResource(R.string.no_notes_title), color = RoseGold)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(notes) { note ->
                            GlassCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(18.dp),
                                backgroundColor = Color(0x33260A1C)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = note.title,
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                            color = SoftBlush
                                        )
                                        IconButton(
                                            onClick = { onDeleteNote(note.id) },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(
                                                Icons.Default.Delete,
                                                contentDescription = stringResource(R.string.delete_note),
                                                tint = MutedRose,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = note.content,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Color.White.copy(alpha = 0.85f)
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = stringResource(R.string.by_author, note.authorName, note.category),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = RoseGold
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                RomanticButton(
                    text = stringResource(R.string.add_note),
                    onClick = onOpenAddNote,
                    icon = Icons.Default.Edit,
                    testTag = "btn_open_add_note"
                )
            }
        }
    }
}

@Composable
fun AddNoteDialog(
    onDismiss: () -> Unit,
    onAdd: (title: String, content: String, category: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Love Notes") }

    Dialog(onDismissRequest = onDismiss) {
        GlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(28.dp),
            backgroundColor = Color(0xF51A0815)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.add_new_note_dialog_title),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold
                        ),
                        color = SoftBlush
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = stringResource(R.string.close), tint = SoftBlush)
                    }
                }

                RomanticTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = stringResource(R.string.note_title),
                    placeholder = stringResource(R.string.note_title_placeholder),
                    testTag = "input_note_title"
                )

                RomanticTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = stringResource(R.string.note_content),
                    placeholder = stringResource(R.string.note_content_placeholder),
                    testTag = "input_note_content"
                )

                RomanticTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = stringResource(R.string.note_category),
                    placeholder = stringResource(R.string.note_category_placeholder),
                    testTag = "input_note_category"
                )

                Spacer(modifier = Modifier.height(8.dp))

                RomanticButton(
                    text = stringResource(R.string.save_note),
                    onClick = {
                        if (title.isNotBlank() && content.isNotBlank()) {
                            onAdd(title, content, category)
                        }
                    },
                    icon = Icons.Default.Edit,
                    testTag = "btn_submit_note"
                )
            }
        }
    }
}

// SPECIAL DATES DIALOG
@Composable
fun SpecialDatesModalDialog(
    specialDates: List<SpecialDateEntity>,
    onDismiss: () -> Unit,
    onOpenAddDate: () -> Unit,
    onDeleteDate: (Long) -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        GlassCard(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            shape = RoundedCornerShape(28.dp),
            backgroundColor = Color(0xF8160613)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = stringResource(R.string.special_dates_title),
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.Bold
                            ),
                            color = SoftBlush
                        )
                        Text(
                            text = stringResource(R.string.special_dates_subtitle),
                            style = MaterialTheme.typography.labelSmall,
                            color = RoseGold
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = stringResource(R.string.close), tint = SoftBlush)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(specialDates) { item ->
                        val diffDays = remember(item.dateMillis) {
                            val diff = item.dateMillis - System.currentTimeMillis()
                            TimeUnit.MILLISECONDS.toDays(diff)
                        }
                        val formattedDate = remember(item.dateMillis) {
                            val sdf = SimpleDateFormat("MMMM d, yyyy", Locale.getDefault())
                            sdf.format(Date(item.dateMillis))
                        }

                        GlassCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            backgroundColor = Color(0x33260A1C)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .background(Color(0x44FF2E63), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (item.type.contains("Birthday", true)) Icons.Default.Cake else Icons.Default.Event,
                                            contentDescription = null,
                                            tint = SoftBlush,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(12.dp))

                                    Column {
                                        Text(
                                            text = item.title,
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                            color = SoftBlush
                                        )
                                        Text(
                                            text = "$formattedDate (${item.type})",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = RoseGold
                                        )
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                if (diffDays in 0..30) CrimsonPrimary.copy(alpha = 0.25f) else Color(0x22FFFFFF),
                                                RoundedCornerShape(10.dp)
                                            )
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        val dateStatusText = when {
                                            diffDays == 0L -> stringResource(R.string.today)
                                            diffDays > 0 -> stringResource(R.string.days_left, diffDays.toInt())
                                            else -> stringResource(R.string.days_ago, (-diffDays).toInt())
                                        }
                                        Text(
                                            text = dateStatusText,
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            color = if (diffDays in 0..30) CrimsonPrimary else RoseGold
                                        )
                                    }

                                    IconButton(
                                        onClick = { onDeleteDate(item.id) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Delete,
                                            contentDescription = stringResource(R.string.delete_special_date),
                                            tint = MutedRose,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                RomanticButton(
                    text = stringResource(R.string.add_first_date),
                    onClick = onOpenAddDate,
                    icon = Icons.Default.Event,
                    testTag = "btn_open_add_date"
                )
            }
        }
    }
}

@Composable
fun AddSpecialDateDialog(
    onDismiss: () -> Unit,
    onAdd: (title: String, dateMillis: Long, type: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("Anniversary") }
    var inDays by remember { mutableStateOf("30") }

    Dialog(onDismissRequest = onDismiss) {
        GlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(28.dp),
            backgroundColor = Color(0xF51A0815)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.add_new_date_dialog_title),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold
                        ),
                        color = SoftBlush
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = stringResource(R.string.close), tint = SoftBlush)
                    }
                }

                RomanticTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = stringResource(R.string.date_title),
                    placeholder = stringResource(R.string.date_title_placeholder),
                    testTag = "input_date_title"
                )

                RomanticTextField(
                    value = type,
                    onValueChange = { type = it },
                    label = stringResource(R.string.date_icon_type),
                    placeholder = stringResource(R.string.date_type_placeholder),
                    testTag = "input_date_type"
                )

                RomanticTextField(
                    value = inDays,
                    onValueChange = { inDays = it },
                    label = stringResource(R.string.days_from_now),
                    placeholder = stringResource(R.string.days_placeholder),
                    testTag = "input_date_days"
                )

                Spacer(modifier = Modifier.height(8.dp))

                RomanticButton(
                    text = stringResource(R.string.save_special_date),
                    onClick = {
                        if (title.isNotBlank()) {
                            val days = inDays.toLongOrNull() ?: 30L
                            val futureMillis = System.currentTimeMillis() + TimeUnit.DAYS.toMillis(days)
                            onAdd(title, futureMillis, type)
                        }
                    },
                    icon = Icons.Default.Event,
                    testTag = "btn_submit_date"
                )
            }
        }
    }
}

// OUR STORY TIMELINE MODAL
@Composable
fun OurStoryModalDialog(
    relationship: RelationshipEntity?,
    onDismiss: () -> Unit
) {
    val formattedStart = remember(relationship?.startDateMillis) {
        val sdf = SimpleDateFormat("MMMM d, yyyy", Locale.getDefault())
        sdf.format(Date(relationship?.startDateMillis ?: System.currentTimeMillis()))
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        GlassCard(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            shape = RoundedCornerShape(28.dp),
            backgroundColor = Color(0xF8160613)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = stringResource(R.string.our_story_timeline_title),
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.Bold
                            ),
                            color = SoftBlush
                        )
                        Text(
                            text = stringResource(R.string.our_story_timeline_subtitle),
                            style = MaterialTheme.typography.labelSmall,
                            color = RoseGold
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = stringResource(R.string.close), tint = SoftBlush)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                val storyMilestones = listOf(
                    stringResource(R.string.story_milestone_1_title) to stringResource(R.string.story_milestone_1_desc),
                    stringResource(R.string.story_milestone_2_title) to stringResource(R.string.story_milestone_2_desc),
                    stringResource(R.string.story_milestone_3_title) to stringResource(R.string.story_milestone_3_desc),
                    stringResource(R.string.story_milestone_4_title) to stringResource(R.string.story_milestone_4_desc),
                    stringResource(R.string.story_milestone_5_title) to stringResource(R.string.story_milestone_5_desc)
                )

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(storyMilestones) { (milestoneTitle, milestoneDesc) ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.Top
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(Color(0x44FF2E63), CircleShape)
                                    .border(1.dp, CrimsonPrimary, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Favorite,
                                    contentDescription = null,
                                    tint = SoftBlush,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            GlassCard(
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(16.dp),
                                backgroundColor = Color(0x33260A1C)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(
                                        text = milestoneTitle,
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Serif
                                        ),
                                        color = SoftBlush
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = milestoneDesc,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Color.White.copy(alpha = 0.85f)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                RomanticButton(
                    text = stringResource(R.string.close),
                    onClick = onDismiss
                )
            }
        }
    }
}

// NOTIFICATIONS MODAL
@Composable
fun NotificationsModalDialog(
    notifications: List<NotificationEntity>,
    onDismiss: () -> Unit,
    onMarkRead: (Long) -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        GlassCard(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            shape = RoundedCornerShape(28.dp),
            backgroundColor = Color(0xF8160613)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = stringResource(R.string.notifications_title),
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.Bold
                            ),
                            color = SoftBlush
                        )
                        Text(
                            text = stringResource(R.string.notifications_subtitle),
                            style = MaterialTheme.typography.labelSmall,
                            color = RoseGold
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = stringResource(R.string.close), tint = SoftBlush)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (notifications.isEmpty()) {
                    Box(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(stringResource(R.string.no_notifications), color = RoseGold)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(notifications) { notif ->
                            val formattedTime = remember(notif.timestampMillis) {
                                val sdf = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault())
                                sdf.format(Date(notif.timestampMillis))
                            }

                            GlassCard(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onMarkRead(notif.id) },
                                shape = RoundedCornerShape(16.dp),
                                backgroundColor = if (notif.isRead) Color(0x22220A1A) else Color(0x443D0F29)
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .background(Color(0x44FF2E63), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Favorite,
                                            contentDescription = null,
                                            tint = CrimsonPrimary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(12.dp))

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = notif.title,
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                            color = SoftBlush
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = notif.message,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color.White.copy(alpha = 0.8f)
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = formattedTime,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MutedRose
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                RomanticButton(
                    text = stringResource(R.string.close),
                    onClick = onDismiss
                )
            }
        }
    }
}
