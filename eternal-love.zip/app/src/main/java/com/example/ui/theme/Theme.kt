package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = CrimsonPrimary,
    onPrimary = Color.White,
    primaryContainer = WineSurfaceElevated,
    onPrimaryContainer = SoftBlush,
    secondary = RoseGold,
    onSecondary = Color(0xFF331B00),
    secondaryContainer = Color(0xFF3D2111),
    onSecondaryContainer = RoseGold,
    tertiary = CrimsonPrimaryLight,
    onTertiary = Color.White,
    background = WineDark,
    onBackground = WarmWhite,
    surface = WineSurfaceDark,
    onSurface = WarmWhite,
    surfaceVariant = WineSurfaceElevated,
    onSurfaceVariant = MutedRose,
    outline = WineSurfaceBorder
)

private val LightColorScheme = lightColorScheme(
    primary = CrimsonPrimary,
    onPrimary = Color.White,
    primaryContainer = RoseLightSurfaceElevated,
    onPrimaryContainer = CrimsonPrimaryDark,
    secondary = RoseGoldDark,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFF0DC),
    onSecondaryContainer = Color(0xFF593800),
    tertiary = CrimsonPrimaryLight,
    onTertiary = Color.White,
    background = RoseLightBackground,
    onBackground = RoseLightText,
    surface = RoseLightSurface,
    onSurface = RoseLightText,
    surfaceVariant = RoseLightSurfaceElevated,
    onSurfaceVariant = RoseLightTextMuted,
    outline = Color(0xFFFFD4DE)
)

@Composable
fun EternalLoveTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
