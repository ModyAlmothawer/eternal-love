package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = CrimsonPrimary,
    onPrimary = Color.White,
    primaryContainer = ModernDarkSurfaceElevated,
    onPrimaryContainer = SoftBlush,
    secondary = RoseGold,
    onSecondary = Color(0xFF1E1408),
    secondaryContainer = Color(0xFF332514),
    onSecondaryContainer = RoseGold,
    tertiary = CrimsonPrimaryLight,
    onTertiary = Color.White,
    background = ModernDarkBackground,
    onBackground = WarmWhite,
    surface = ModernDarkSurface,
    onSurface = WarmWhite,
    surfaceVariant = ModernDarkSurfaceElevated,
    onSurfaceVariant = MutedRose,
    outline = ModernDarkSurfaceBorder
)

private val LightColorScheme = lightColorScheme(
    primary = CrimsonPrimary,
    onPrimary = Color.White,
    primaryContainer = ModernLightSurfaceElevated,
    onPrimaryContainer = CrimsonPrimaryDark,
    secondary = RoseGoldDark,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFDF0E2),
    onSecondaryContainer = Color(0xFF4A3018),
    tertiary = CrimsonPrimaryLight,
    onTertiary = Color.White,
    background = ModernLightBackground,
    onBackground = ModernLightText,
    surface = ModernLightSurface,
    onSurface = ModernLightText,
    surfaceVariant = ModernLightSurfaceElevated,
    onSurfaceVariant = ModernLightTextMuted,
    outline = ModernLightBorder
)

@Composable
fun EternalLoveTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
