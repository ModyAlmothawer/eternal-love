package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.RelationshipEntity
import com.example.data.model.UserEntity
import com.example.data.repository.LoveRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class AuthScreenState {
    object Splash : AuthScreenState()
    object Welcome : AuthScreenState()
    object Login : AuthScreenState()
    object Register : AuthScreenState()
    object SetupRelationship : AuthScreenState()
    object Celebration : AuthScreenState()
    object Main : AuthScreenState()
}

class AuthViewModel(
    private val repository: LoveRepository
) : ViewModel() {

    val currentUser: StateFlow<UserEntity?> = repository.currentUserFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val currentRelationship: StateFlow<RelationshipEntity?> = repository.currentRelationshipFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val currentLanguage: StateFlow<String> = repository.currentLanguage

    private val _screenState = MutableStateFlow<AuthScreenState>(AuthScreenState.Splash)
    val screenState: StateFlow<AuthScreenState> = _screenState.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _successMessage = MutableStateFlow<String?>(null)
    val successMessage: StateFlow<String?> = _successMessage.asStateFlow()

    private val _generatedCode = MutableStateFlow<String?>(null)
    val generatedCode: StateFlow<String?> = _generatedCode.asStateFlow()

    private val _showForgotPasswordDialog = MutableStateFlow(false)
    val showForgotPasswordDialog: StateFlow<Boolean> = _showForgotPasswordDialog.asStateFlow()

    private val _toastEvent = MutableSharedFlow<String>()
    val toastEvent: SharedFlow<String> = _toastEvent.asSharedFlow()

    init {
        viewModelScope.launch {
            delay(2200) // Romantic splash screen delay
            val user = currentUser.value
            val rel = currentRelationship.value
            if (user != null) {
                if (user.isConnected && rel != null) {
                    _screenState.value = AuthScreenState.Main
                } else {
                    _screenState.value = AuthScreenState.SetupRelationship
                }
            } else {
                _screenState.value = AuthScreenState.Welcome
            }
        }
    }

    fun navigateTo(state: AuthScreenState) {
        _errorMessage.value = null
        _successMessage.value = null
        _screenState.value = state
    }

    fun clearMessages() {
        _errorMessage.value = null
        _successMessage.value = null
    }

    fun setLanguage(lang: String) {
        viewModelScope.launch {
            repository.setLanguage(lang)
        }
    }

    fun showForgotPassword(show: Boolean) {
        _showForgotPasswordDialog.value = show
        if (!show) {
            _errorMessage.value = null
            _successMessage.value = null
        }
    }

    fun sendPasswordReset(email: String) {
        if (email.isBlank() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            _errorMessage.value = "يرجى إدخال بريد إلكتروني صالح"
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            val res = repository.sendPasswordResetEmail(email)
            _isLoading.value = false
            res.onSuccess {
                _successMessage.value = "تم إرسال رابط إعادة تعيين كلمة المرور إلى $email"
            }.onFailure {
                _errorMessage.value = it.message ?: "فشل في إرسال رابط إعادة التعيين"
            }
        }
    }

    fun register(name: String, email: String, pass: String, confirmPass: String) {
        if (name.isBlank()) {
            _errorMessage.value = "يرجى إدخال اسمك"
            return
        }
        if (email.isBlank() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            _errorMessage.value = "يرجى إدخال بريد إلكتروني صالح"
            return
        }
        if (pass.length < 6) {
            _errorMessage.value = "يجب أن تكون كلمة المرور 6 أحرف على الأقل"
            return
        }
        if (pass != confirmPass) {
            _errorMessage.value = "كلمتا المرور غير متطابقتين"
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            delay(500)
            val result = repository.registerUser(name, email, pass)
            _isLoading.value = false
            result.onSuccess {
                _screenState.value = AuthScreenState.SetupRelationship
            }.onFailure {
                _errorMessage.value = it.message ?: "فشل إنشاء الحساب"
            }
        }
    }

    fun login(email: String, pass: String) {
        if (email.isBlank() || pass.isBlank()) {
            _errorMessage.value = "يرجى إدخال البريد الإلكتروني وكلمة المرور"
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            delay(500)
            val result = repository.loginUser(email, pass)
            _isLoading.value = false
            result.onSuccess { user ->
                if (user.isConnected && (!user.connectedRelationshipId.isNullOrBlank() || user.localRelationshipId != null)) {
                    _screenState.value = AuthScreenState.Main
                } else {
                    _screenState.value = AuthScreenState.SetupRelationship
                }
            }.onFailure {
                _errorMessage.value = it.message ?: "البريد الإلكتروني أو كلمة المرور غير صحيحة"
            }
        }
    }

    fun createRelationship(startDateMillis: Long = System.currentTimeMillis()) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            delay(600)
            val result = repository.createRelationship(startDateMillis)
            _isLoading.value = false
            result.onSuccess { (_, code) ->
                _generatedCode.value = code
                _screenState.value = AuthScreenState.Celebration
            }.onFailure {
                _errorMessage.value = it.message ?: "فشل إنشاء العلاقة"
            }
        }
    }

    fun joinRelationship(code: String) {
        val clean = code.trim()
        if (clean.length != 6 || !clean.all { it.isDigit() }) {
            _errorMessage.value = "يرجى إدخال كود صالح مكون من 6 أرقام"
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            delay(800)
            val result = repository.joinRelationship(clean)
            _isLoading.value = false
            result.onSuccess {
                _screenState.value = AuthScreenState.Celebration
            }.onFailure {
                _errorMessage.value = it.message ?: "لم يتم العثور على الكود أو العلاقة ممتلئة"
            }
        }
    }

    fun proceedToMain() {
        _screenState.value = AuthScreenState.Main
    }

    fun logout() {
        repository.logout()
        _screenState.value = AuthScreenState.Welcome
    }
}

class AuthViewModelFactory(private val repository: LoveRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return AuthViewModel(repository) as T
    }
}
