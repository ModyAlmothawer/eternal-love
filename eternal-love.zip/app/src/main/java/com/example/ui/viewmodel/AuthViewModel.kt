package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.RelationshipEntity
import com.example.data.model.UserEntity
import com.example.data.repository.LoveRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class AuthScreenState {
    object Splash : AuthScreenState()
    object Welcome : AuthScreenState()
    object Login : AuthScreenState()
    object Register : AuthScreenState()
    object SetupRelationship : AuthScreenState()
    object Celebration : AuthScreenState()
    object Main : AuthScreenState()
}

class AuthViewModel(
    private val repository: LoveRepository
) : ViewModel() {

    val currentUser: StateFlow<UserEntity?> = repository.currentUserFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val currentRelationship: StateFlow<RelationshipEntity?> = repository.currentRelationshipFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val currentLanguage: StateFlow<String> = repository.currentLanguage

    private val _screenState = MutableStateFlow<AuthScreenState>(AuthScreenState.Splash)
    val screenState: StateFlow<AuthScreenState> = _screenState.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _successMessage = MutableStateFlow<String?>(null)
    val successMessage: StateFlow<String?> = _successMessage.asStateFlow()

    private val _generatedCode = MutableStateFlow<String?>(null)
    val generatedCode: StateFlow<String?> = _generatedCode.asStateFlow()

    private val _showForgotPasswordDialog = MutableStateFlow(false)
    val showForgotPasswordDialog: StateFlow<Boolean> = _showForgotPasswordDialog.asStateFlow()

    private val _toastEvent = MutableSharedFlow<String>()
    val toastEvent: SharedFlow<String> = _toastEvent.asSharedFlow()

    init {
        viewModelScope.launch {
            delay(2200) // Romantic splash screen delay
            val user = currentUser.value
            val rel = currentRelationship.value
            if (user != null) {
                if (user.isConnected && rel != null) {
                    _screenState.value = AuthScreenState.Main
                } else {
                    _screenState.value = AuthScreenState.SetupRelationship
                }
            } else {
                _screenState.value = AuthScreenState.Welcome
            }
        }
    }

    fun navigateTo(state: AuthScreenState) {
        _errorMessage.value = null
        _successMessage.value = null
        _screenState.value = state
    }

    fun clearMessages() {
        _errorMessage.value = null
        _successMessage.value = null
    }

    fun setLanguage(lang: String) {
        viewModelScope.launch {
            repository.setLanguage(lang)
        }
    }

    fun showForgotPassword(show: Boolean) {
        _showForgotPasswordDialog.value = show
        if (!show) {
            _errorMessage.value = null
            _successMessage.value = null
        }
    }

    fun sendPasswordReset(email: String) {
        if (_isLoading.value) return
        val currentLang = currentLanguage.value
        val trimmed = email.trim()
        if (trimmed.isBlank() || !android.util.Patterns.EMAIL_ADDRESS.matcher(trimmed).matches()) {
            _errorMessage.value = if (currentLang == "ar") "يرجى إدخال بريد إلكتروني صالح" else "Please enter a valid email address"
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            _successMessage.value = null
            try {
                val res = repository.sendPasswordResetEmail(trimmed)
                res.onSuccess {
                    _successMessage.value = if (currentLang == "ar") "تم إرسال رابط إعادة تعيين كلمة المرور إلى $trimmed" else "Password reset link sent to $trimmed"
                }.onFailure { ex ->
                    _errorMessage.value = ex.localizedMessage ?: ex.message ?: (if (currentLang == "ar") "فشل في إرسال رابط إعادة التعيين" else "Failed to send password reset email")
                }
            } catch (e: Exception) {
                _errorMessage.value = e.localizedMessage ?: e.message ?: (if (currentLang == "ar") "حدث خطأ غير متوقع" else "An unexpected error occurred")
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun register(name: String, email: String, pass: String, confirmPass: String) {
        if (_isLoading.value) return
        val currentLang = currentLanguage.value
        val trimmedName = name.trim()
        val trimmedEmail = email.trim()

        if (trimmedName.isBlank()) {
            _errorMessage.value = if (currentLang == "ar") "يرجى إدخال اسمك" else "Please enter your name"
            return
        }
        if (trimmedEmail.isBlank() || !android.util.Patterns.EMAIL_ADDRESS.matcher(trimmedEmail).matches()) {
            _errorMessage.value = if (currentLang == "ar") "يرجى إدخال بريد إلكتروني صالح" else "Please enter a valid email address"
            return
        }
        if (pass.length < 6) {
            _errorMessage.value = if (currentLang == "ar") "يجب أن تكون كلمة المرور 6 أحرف على الأقل" else "Password must be at least 6 characters"
            return
        }
        if (pass != confirmPass) {
            _errorMessage.value = if (currentLang == "ar") "كلمتا المرور غير متطابقتين" else "Passwords do not match"
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            _successMessage.value = null
            try {
                val result = repository.registerUser(trimmedName, trimmedEmail, pass)
                result.onSuccess {
                    _screenState.value = AuthScreenState.SetupRelationship
                }.onFailure { ex ->
                    _errorMessage.value = ex.localizedMessage ?: ex.message ?: (if (currentLang == "ar") "فشل إنشاء الحساب" else "Registration failed")
                }
            } catch (e: Exception) {
                _errorMessage.value = e.localizedMessage ?: e.message ?: (if (currentLang == "ar") "حدث خطأ أثناء إنشاء الحساب" else "An error occurred during registration")
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun login(email: String, pass: String) {
        if (_isLoading.value) return
        val currentLang = currentLanguage.value
        val trimmedEmail = email.trim()

        if (trimmedEmail.isBlank() || pass.isBlank()) {
            _errorMessage.value = if (currentLang == "ar") "يرجى إدخال البريد الإلكتروني وكلمة المرور" else "Please enter your email and password"
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            _successMessage.value = null
            try {
                val result = repository.loginUser(trimmedEmail, pass)
                result.onSuccess { user ->
                    if (user.isConnected && (!user.connectedRelationshipId.isNullOrBlank() || user.localRelationshipId != null)) {
                        _screenState.value = AuthScreenState.Main
                    } else {
                        _screenState.value = AuthScreenState.SetupRelationship
                    }
                }.onFailure { ex ->
                    _errorMessage.value = ex.localizedMessage ?: ex.message ?: (if (currentLang == "ar") "البريد الإلكتروني أو كلمة المرور غير صحيحة" else "Invalid email or password")
                }
            } catch (e: Exception) {
                _errorMessage.value = e.localizedMessage ?: e.message ?: (if (currentLang == "ar") "حدث خطأ أثناء تسجيل الدخول" else "An error occurred during login")
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun createRelationship(startDateMillis: Long = System.currentTimeMillis()) {
        if (_isLoading.value) return
        val currentLang = currentLanguage.value

        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            _successMessage.value = null
            try {
                val result = repository.createRelationship(startDateMillis)
                result.onSuccess { (_, code) ->
                    _generatedCode.value = code
                    _screenState.value = AuthScreenState.Celebration
                }.onFailure { ex ->
                    _errorMessage.value = ex.localizedMessage ?: ex.message ?: (if (currentLang == "ar") "فشل إنشاء العلاقة" else "Failed to create relationship")
                }
            } catch (e: Exception) {
                _errorMessage.value = e.localizedMessage ?: e.message ?: (if (currentLang == "ar") "حدث خطأ أثناء إنشاء العلاقة" else "An error occurred while creating relationship")
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun joinRelationship(code: String) {
        if (_isLoading.value) return
        val currentLang = currentLanguage.value
        val clean = code.trim()

        if (clean.length != 6 || !clean.all { it.isDigit() }) {
            _errorMessage.value = if (currentLang == "ar") "يرجى إدخال كود صالح مكون من 6 أرقام" else "Please enter a valid 6-digit code"
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            _successMessage.value = null
            try {
                val result = repository.joinRelationship(clean)
                result.onSuccess {
                    _screenState.value = AuthScreenState.Celebration
                }.onFailure { ex ->
                    _errorMessage.value = ex.localizedMessage ?: ex.message ?: (if (currentLang == "ar") "لم يتم العثور على الكود أو العلاقة ممتلئة" else "Code not found or relationship already full")
                }
            } catch (e: Exception) {
                _errorMessage.value = e.localizedMessage ?: e.message ?: (if (currentLang == "ar") "حدث خطأ أثناء الانضمام" else "An error occurred while joining relationship")
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun proceedToMain() {
        _screenState.value = AuthScreenState.Main
    }

    fun logout() {
        repository.logout()
        _screenState.value = AuthScreenState.Welcome
    }
}

class AuthViewModelFactory(private val repository: LoveRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return AuthViewModel(repository) as T
    }
}
