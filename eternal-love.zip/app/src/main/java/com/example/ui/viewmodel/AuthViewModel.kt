package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.RelationshipEntity
import com.example.data.model.UserEntity
import com.example.data.repository.LoveRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class AuthScreenState {
    object Splash : AuthScreenState()
    object Welcome : AuthScreenState()
    object Login : AuthScreenState()
    object Register : AuthScreenState()
    object SetupRelationship : AuthScreenState()
    object Celebration : AuthScreenState()
    object Main : AuthScreenState()
}

class AuthViewModel(
    private val repository: LoveRepository
) : ViewModel() {

    val currentUser: StateFlow<UserEntity?> = repository.currentUserFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val currentRelationship: StateFlow<RelationshipEntity?> = repository.currentRelationshipFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _screenState = MutableStateFlow<AuthScreenState>(AuthScreenState.Splash)
    val screenState: StateFlow<AuthScreenState> = _screenState.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _generatedCode = MutableStateFlow<String?>(null)
    val generatedCode: StateFlow<String?> = _generatedCode.asStateFlow()

    private val _toastEvent = MutableSharedFlow<String>()
    val toastEvent: SharedFlow<String> = _toastEvent.asSharedFlow()

    init {
        viewModelScope.launch {
            delay(2400) // Elegant splash delay
            val user = currentUser.value
            val rel = currentRelationship.value
            if (user != null) {
                if (user.isConnected && rel != null) {
                    _screenState.value = AuthScreenState.Main
                } else {
                    _screenState.value = AuthScreenState.SetupRelationship
                }
            } else {
                _screenState.value = AuthScreenState.Welcome
            }
        }
    }

    fun navigateTo(state: AuthScreenState) {
        _errorMessage.value = null
        _screenState.value = state
    }

    fun clearError() {
        _errorMessage.value = null
    }

    fun register(name: String, email: String, pass: String, confirmPass: String) {
        if (name.isBlank()) {
            _errorMessage.value = "Please enter your name"
            return
        }
        if (email.isBlank() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            _errorMessage.value = "Please enter a valid email address"
            return
        }
        if (pass.length < 6) {
            _errorMessage.value = "Password must be at least 6 characters"
            return
        }
        if (pass != confirmPass) {
            _errorMessage.value = "Passwords do not match"
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            delay(600)
            val result = repository.registerUser(name, email, pass)
            _isLoading.value = false
            result.onSuccess {
                _screenState.value = AuthScreenState.SetupRelationship
            }.onFailure {
                _errorMessage.value = it.message ?: "Registration failed"
            }
        }
    }

    fun login(email: String, pass: String) {
        if (email.isBlank() || pass.isBlank()) {
            _errorMessage.value = "Please enter email and password"
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            delay(600)
            val result = repository.loginUser(email, pass)
            _isLoading.value = false
            result.onSuccess { user ->
                if (user.isConnected && user.connectedRelationshipId != null) {
                    _screenState.value = AuthScreenState.Main
                } else {
                    _screenState.value = AuthScreenState.SetupRelationship
                }
            }.onFailure {
                _errorMessage.value = it.message ?: "Invalid email or password"
            }
        }
    }

    fun createRelationship(partnerName: String) {
        if (partnerName.isBlank()) {
            _errorMessage.value = "Please enter your partner's name"
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            delay(600)
            val result = repository.createRelationship(partnerName)
            _isLoading.value = false
            result.onSuccess { (_, code) ->
                _generatedCode.value = code
                _screenState.value = AuthScreenState.Celebration
            }.onFailure {
                _errorMessage.value = it.message ?: "Failed to create relationship"
            }
        }
    }

    fun joinRelationship(code: String) {
        if (code.length != 6 || !code.all { it.isDigit() }) {
            _errorMessage.value = "Please enter a valid 6-digit code"
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            delay(800)
            val result = repository.joinRelationship(code)
            _isLoading.value = false
            result.onSuccess {
                _screenState.value = AuthScreenState.Celebration
            }.onFailure {
                _errorMessage.value = it.message ?: "Relationship not found"
            }
        }
    }

    fun proceedToMain() {
        _screenState.value = AuthScreenState.Main
    }

    fun logout() {
        repository.logout()
        _screenState.value = AuthScreenState.Welcome
    }
}

class AuthViewModelFactory(private val repository: LoveRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return AuthViewModel(repository) as T
    }
}
