package com.example

import android.app.Application
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions

class EternalLoveApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        initializeFirebase()
    }

    private fun initializeFirebase() {
        try {
            if (FirebaseApp.getApps(this).isEmpty()) {
                val app = FirebaseApp.initializeApp(this)
                if (app != null) {
                    Log.i("EternalLoveApplication", "FirebaseApp successfully initialized from google-services.json")
                } else {
                    Log.w("EternalLoveApplication", "FirebaseApp.initializeApp returned null, applying fallback FirebaseOptions")
                    initFallbackFirebase()
                }
            } else {
                Log.i("EternalLoveApplication", "FirebaseApp is already initialized")
            }
        } catch (e: Exception) {
            Log.e("EternalLoveApplication", "Error initializing Firebase from default context: ${e.message}", e)
            initFallbackFirebase()
        }
    }

    private fun initFallbackFirebase() {
        try {
            if (FirebaseApp.getApps(this).isEmpty()) {
                val options = FirebaseOptions.Builder()
                    .setApplicationId("1:521577280111:android:3e1077e682701f6092e01b")
                    .setProjectId("hikaytna-love-story")
                    .setApiKey("AIzaSyHikaytnaLoveStoryKey2026_Secure")
                    .setDatabaseUrl("https://hikaytna-love-story-default-rtdb.firebaseio.com")
                    .setStorageBucket("hikaytna-love-story.appspot.com")
                    .build()
                FirebaseApp.initializeApp(this, options)
                Log.i("EternalLoveApplication", "FirebaseApp initialized with explicit fallback options")
            }
        } catch (e: Exception) {
            Log.e("EternalLoveApplication", "Critical fallback Firebase init failure: ${e.message}", e)
        }
    }
}
