package com.example.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.R
import java.util.concurrent.ConcurrentHashMap

object NotificationHelper {

    const val CHANNEL_ID_CHAT = "hikaytna_chat_channel"
    const val CHANNEL_NAME_CHAT = "الدردشة والرسائل"
    const val CHANNEL_DESC_CHAT = "إشعارات الرسائل الفورية من شريك حياتك"

    const val CHANNEL_ID_UPDATES = "hikaytna_updates_channel"
    const val CHANNEL_NAME_UPDATES = "تحديثات الشريك والأهداف"
    const val CHANNEL_DESC_UPDATES = "إشعارات تغير الحالة اليومية وإضافة الأهداف والذكريات"

    private val notifiedEvents = ConcurrentHashMap.newKeySet<String>()

    fun createNotificationChannels(context: Context) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager

                val chatChannel = NotificationChannel(
                    CHANNEL_ID_CHAT,
                    CHANNEL_NAME_CHAT,
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = CHANNEL_DESC_CHAT
                    enableVibration(true)
                    enableLights(true)
                    setSound(soundUri, null)
                }

                val updatesChannel = NotificationChannel(
                    CHANNEL_ID_UPDATES,
                    CHANNEL_NAME_UPDATES,
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = CHANNEL_DESC_UPDATES
                    enableVibration(true)
                    enableLights(true)
                    setSound(soundUri, null)
                }

                notificationManager?.createNotificationChannel(chatChannel)
                notificationManager?.createNotificationChannel(updatesChannel)
            }
        } catch (e: Exception) {
            Log.w("NotificationHelper", "Error creating notification channels: ${e.message}")
        }
    }

    fun showNotification(
        context: Context,
        channelId: String,
        notificationId: Int,
        uniqueEventKey: String,
        title: String,
        body: String
    ) {
        if (uniqueEventKey.isNotBlank()) {
            if (notifiedEvents.contains(uniqueEventKey)) {
                return
            }
            // Keep memory cache size bounded
            if (notifiedEvents.size > 200) {
                notifiedEvents.clear()
            }
            notifiedEvents.add(uniqueEventKey)
        }

        try {
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pendingIntent = PendingIntent.getActivity(
                context,
                notificationId,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

            val builder = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setSound(soundUri)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)

            val notificationManager = NotificationManagerCompat.from(context)
            if (notificationManager.areNotificationsEnabled()) {
                notificationManager.notify(notificationId, builder.build())
            }
        } catch (e: Exception) {
            Log.w("NotificationHelper", "Could not show notification: ${e.message}")
        }
    }
}
