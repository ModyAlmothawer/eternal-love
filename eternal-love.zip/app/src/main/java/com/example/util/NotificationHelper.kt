package com.example.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.R

object NotificationHelper {

    private const val CHANNEL_ID = "hikaytna_love_messages"
    private const val CHANNEL_NAME = "Hikaytna Messages"
    private const val CHANNEL_DESCRIPTION = "Notifications for love messages and updates from your partner"
    private const val NOTIFICATION_ID = 1001

    private var lastNotifiedMessageId: String? = null

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, importance).apply {
                description = CHANNEL_DESCRIPTION
                enableVibration(true)
                enableLights(true)
            }
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            notificationManager?.createNotificationChannel(channel)
        }
    }

    fun showMessageNotification(
        context: Context,
        messageId: String,
        senderUid: String,
        currentUid: String,
        senderName: String,
        title: String,
        messageText: String
    ) {
        // Never notify for messages sent by the user themselves
        if (senderUid == currentUid || senderUid.isBlank() || currentUid.isBlank()) {
            return
        }

        // Avoid duplicate notifications for the same message
        if (messageId == lastNotifiedMessageId) {
            return
        }
        lastNotifiedMessageId = messageId

        try {
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pendingIntent = PendingIntent.getActivity(
                context,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val displayTitle = if (title.isNotBlank()) "$senderName: $title" else senderName
            val displayBody = messageText.ifBlank { "أرسل لك رسالة حب جديدة 💌" }

            val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(displayTitle)
                .setContentText(displayBody)
                .setStyle(NotificationCompat.BigTextStyle().bigText(displayBody))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)

            val notificationManager = NotificationManagerCompat.from(context)
            if (notificationManager.areNotificationsEnabled()) {
                notificationManager.notify(NOTIFICATION_ID, builder.build())
            }
        } catch (e: Exception) {
            Log.w("NotificationHelper", "Could not show notification: ${e.message}")
        }
    }
}
